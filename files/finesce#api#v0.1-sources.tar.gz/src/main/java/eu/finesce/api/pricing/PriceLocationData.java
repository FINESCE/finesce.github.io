/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.pricing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "price_location_data")
public class PriceLocationData {

	private String	id;
	private String	name;
	private String	location_id;
	private String	measurement_type;
	private String	value_id;

	/**
	 * Creates an empty price_location data object
	 */
	public PriceLocationData() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a new price_location data object
	 * 
	 * @param id
	 *            The id of the object
	 * @param name
	 *            The name of the data object
	 * @param location_id
	 *            The id of the location in hand
	 * @param measurement_type
	 *            The measurement type
	 * @param value_id
	 *            The id of the value
	 */
	public PriceLocationData(String name, String location_id, String measurement_type, String value_id) {
		super();
		this.name = name;
		this.location_id = location_id;
		this.measurement_type = measurement_type;
		this.value_id = value_id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation_id() {
		return location_id;
	}

	public void setLocation_id(String location_id) {
		this.location_id = location_id;
	}

	public String getMeasurement_type() {
		return measurement_type;
	}

	public void setMeasurement_type(String measurement_type) {
		this.measurement_type = measurement_type;
	}

	public String getValue_id() {
		return value_id;
	}

	public void setValue_id(String value_id) {
		this.value_id = value_id;
	}

}
