/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.buildings;

import eu.finesce.api.generic.Address;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "building")
public class Building {

	private String				id;
	private String				type;
	private Address				address;
	private Map<String, String>	measurement_points;
	private Map<String, String>	related_entities;

	/**
	 * Creates an empty building
	 */
	public Building() {
		this.related_entities = new HashMap<>();
		this.measurement_points = new HashMap<>();
	}

	/**
	 * Creates a new Building object
	 * 
	 * @param id
	 *            The id of the building
	 * @param type
	 *            The type of the building
	 * @param address
	 *            The address of the building, if any
	 * @param related_entities
	 *            The list of related entities (owners, measuring equipment etc)
	 */
	public Building(String id, String type, Address address, Map<String, String> related_entities_ids) {
		this.id = id;
		this.type = type;
		this.address = address;
		this.related_entities = related_entities_ids;
		this.measurement_points = new HashMap<>();
	}

	/**
	 * Creates a new Building object
	 * 
	 * @param id
	 *            The id of the building
	 * @param type
	 *            The type of the building
	 * @param address
	 *            The address of the building, if any
	 */
	public Building(String id, String type, Address address) {
		this.id = id;
		this.type = type;
		this.address = address;
		this.related_entities = new HashMap<>();
		this.measurement_points = new HashMap<>();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void putRelatedEntity(String entity, String id) {
		this.getRelated_entities_ids().put(entity, id);
	}

	public Map<String, String> getRelated_entities_ids() {
		return related_entities;
	}

	public void setRelated_entities_ids(Map<String, String> related_entities_ids) {
		this.related_entities = related_entities_ids;
	}

	public void putMeasurementPoint(String type, String id) {
		this.getMeasurement_points().put(type, id);
	}

	public Map<String, String> getMeasurement_points() {
		return measurement_points;
	}

	public void setMeasurement_points(Map<String, String> measurement_points_map) {
		this.measurement_points = measurement_points_map;
	}
}
