/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ev_connection")
public class Connection {
	// TODO: Check with the measurements types
	private String	id;
	private String	start;
	private double	energy_current;
	private double	energy_previous;
	private int		duration;
	private double	total_energy_per_connection;
	private double	total_energy;
	private String	charging_mode_id;
	private String	ev_supply_equipment_id;
	private String	ev_supply_equipment_connection_state_id;
	private String	ev_id;

	/**
	 * Creates an empty ev connection
	 */
	public Connection() {
	}

	/**
	 * Creates a new ev-evse connection
	 * 
	 * @param id
	 *            The id of the connection
	 * @param start
	 *            The start time (in ISO 8601 CET) of the connection
	 * @param energy_current
	 *            The energy being consumed by the connection during the current
	 *            minute
	 * @param energy_previous
	 *            The energy beign consumed by the connection during the
	 *            previous minute
	 * @param duration
	 *            The duration of the connection (seconds)
	 * @param total_energy_per_connection
	 *            The total energy consumption of the connection
	 * @param total_energy
	 *            The total energy consumption of all connections of this ev
	 *            supply equipment
	 * @param charging_mode_id
	 *            The id of the charging mode of the connection
	 * @param ev_supply_equipment_id
	 *            The id of the of the ev supply equipment of the connection
	 * @param ev_supply_equipment_connection_state_id
	 *            The id of the connection state
	 * @param ev_id
	 *            The id of the electric vehicle in hand
	 */
	public Connection(String id, String start, double energy_current, double energy_previous, int duration, double total_energy_per_connection, double total_energy, String charging_mode_id, String ev_supply_equipment_id,
			String ev_supply_equipment_connection_state_id, String ev_id) {
		this.id = id;
		this.start = start;
		this.energy_current = energy_current;
		this.energy_previous = energy_previous;
		this.duration = duration;
		this.total_energy_per_connection = total_energy_per_connection;
		this.total_energy = total_energy;
		this.charging_mode_id = charging_mode_id;
		this.ev_supply_equipment_id = ev_supply_equipment_id;
		this.ev_supply_equipment_connection_state_id = ev_supply_equipment_connection_state_id;
		this.ev_id = ev_id;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * @param start
	 *            the start to set
	 */
	public void setStart(String start) {
		this.start = start;
	}

	/**
	 * @return the energy_current
	 */
	public double getEnergy_current() {
		return energy_current;
	}

	/**
	 * @param energy_current
	 *            the energy_current to set
	 */
	public void setEnergy_current(double energy_current) {
		this.energy_current = energy_current;
	}

	/**
	 * @return the energy_previous
	 */
	public double getEnergy_previous() {
		return energy_previous;
	}

	/**
	 * @param energy_previous
	 *            the energy_previous to set
	 */
	public void setEnergy_previous(double energy_previous) {
		this.energy_previous = energy_previous;
	}

	/**
	 * @return the duration
	 */
	public int getDuration() {
		return duration;
	}

	/**
	 * @param duration
	 *            the duration to set
	 */
	public void setDuration(int duration) {
		this.duration = duration;
	}

	/**
	 * @return the total_energy_per_connection
	 */
	public double getTotal_energy_per_connection() {
		return total_energy_per_connection;
	}

	/**
	 * @param total_energy_per_connection
	 *            the total_energy_per_connection to set
	 */
	public void setTotal_energy_per_connection(double total_energy_per_connection) {
		this.total_energy_per_connection = total_energy_per_connection;
	}

	/**
	 * @return the total_energy
	 */
	public double getTotal_energy() {
		return total_energy;
	}

	/**
	 * @param total_energy
	 *            the total_energy to set
	 */
	public void setTotal_energy(double total_energy) {
		this.total_energy = total_energy;
	}

	/**
	 * @return the charging_mode_id
	 */
	public String getCharging_mode_id() {
		return charging_mode_id;
	}

	/**
	 * @param charging_mode_id
	 *            the charging_mode_id to set
	 */
	public void setCharging_mode_id(String charging_mode_id) {
		this.charging_mode_id = charging_mode_id;
	}

	/**
	 * @return the ev_supply_equipment_id
	 */
	public String getEv_supply_equipment_id() {
		return ev_supply_equipment_id;
	}

	/**
	 * @param ev_supply_equipment_id
	 *            the ev_supply_equipment_id to set
	 */
	public void setEv_supply_equipment_id(String ev_supply_equipment_id) {
		this.ev_supply_equipment_id = ev_supply_equipment_id;
	}

	/**
	 * @return the ev_supply_equipment_connection_state_id
	 */
	public String getEv_supply_equipment_connection_state_id() {
		return ev_supply_equipment_connection_state_id;
	}

	/**
	 * @param ev_supply_equipment_connection_state_id
	 *            the ev_supply_equipment_connection_state_id to set
	 */
	public void setEv_supply_equipment_connection_state_id(String ev_supply_equipment_connection_state_id) {
		this.ev_supply_equipment_connection_state_id = ev_supply_equipment_connection_state_id;
	}

	/**
	 * @return the ev_id
	 */
	public String getEv_id() {
		return ev_id;
	}

	/**
	 * @param ev_id
	 *            the ev_id to set
	 */
	public void setEv_id(String ev_id) {
		this.ev_id = ev_id;
	}
}
