/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.optimisation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "algoweight")
public class Algoweight {

	private String	id;
	private String	renewables;
	private String	interconnect;
	private String	specific;
	private String	timeslot_id;
	private String	region_id;

	/**
	 * Creates a new algoweight object
	 */
	public Algoweight() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a new algoweight object
	 * 
	 * @param id
	 *            The id of the object (in the DB)
	 * @param renewables
	 *            Percentage of renewables optimised by the algorithm
	 * @param interconnect
	 *            Percentage of energy flows between regions which is optimised
	 *            by the algorithm
	 * @param specific
	 *            Percentage of energy by market requirements optimised by the
	 *            algorithm
	 * @param timeslot_id
	 *            The timeslot id
	 * @param region_id
	 *            The region id
	 */
	public Algoweight(String id, String renewables, String interconnect, String specific, String timeslot_id, String region_id) {
		this.id = id;
		this.renewables = renewables;
		this.interconnect = interconnect;
		this.specific = specific;
		this.timeslot_id = timeslot_id;
		this.region_id = region_id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRenewables() {
		return renewables;
	}

	public void setRenewables(String renewables) {
		this.renewables = renewables;
	}

	public String getInterconnect() {
		return interconnect;
	}

	public void setInterconnect(String interconnect) {
		this.interconnect = interconnect;
	}

	public String getSpecific() {
		return specific;
	}

	public void setSpecific(String specific) {
		this.specific = specific;
	}

	public String getTimeslot_id() {
		return timeslot_id;
	}

	public void setTimeslot_id(String timeslot_id) {
		this.timeslot_id = timeslot_id;
	}

	public String getRegion_id() {
		return region_id;
	}

	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}

}
