/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.electric_vehicles.Connection;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "connections")
public class ConnectionsReport extends FinesceApi {

	private List<Connection>	connections;

	/**
	 * Creates an empty ev connection
	 */
	public ConnectionsReport() {
		this.connections = new ArrayList<>();
	}

	/**
	 * Creates an empty ev connection
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public ConnectionsReport(Metadata metadata) {
		super(metadata);
		this.connections = new ArrayList<>();
	}

	/**
	 * Creates an empty ev connection
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public ConnectionsReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.connections = new ArrayList<>();
	}

	/**
	 * Creates an empty ev connection
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public ConnectionsReport(String api_version, String trial) {
		super(api_version, trial);
		this.connections = new ArrayList<>();
	}

	/**
	 * Creates an empty ev connection Adds a connection to the connections of
	 * connections
	 * 
	 * @param c
	 *            The connection to add
	 * @return The connections index of the inserted connection
	 */
	public int add(Connection c) {
		this.getList().add(c);
		return this.getList().size() - 1;
	}

	public List<Connection> getList() {
		return connections;
	}

	public void setList(List<Connection> list) {
		this.connections = list;
	}

}
