/*
 * Copyright 2014 Artemis Voulkidis <voulkidis@synelixis.com>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.metering.specific;

import eu.finesce.api.generic.Address;
import eu.finesce.api.generic.MeasurementTypeIdentifiers;
import eu.finesce.api.generic.SampleIdentifiers;
import eu.finesce.api.metering.Meter;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "meter")
@XmlSeeAlso({ Meter.class })
public class ElectricMeter extends Meter {
	private boolean	is_domestic;
	private String	SS_code;
	private String	line_number;
	private String	feeder_name;
	private String	node;

	public ElectricMeter() {
		super();
	}

	public ElectricMeter(String id, String customerId, String sector, Address address, String sampleIdentifier, String latitude, String longitude, List<String> meteringCapabilities, List<String> relatedEntities) {
		super(id, customerId, sector, address, sampleIdentifier, latitude, longitude, meteringCapabilities, relatedEntities);
	}

	public ElectricMeter(String id, String customerId, String sector, Address address, String sampleIdentifier, String latitude, String longitude, List<String> meteringCapabilities, List<String> relatedEntities, boolean isDomestic,
			String SSCode, String lineNumber, String feederName, String node) {
		super(id, customerId, sector, address, sampleIdentifier, latitude, longitude, meteringCapabilities, relatedEntities);
		this.is_domestic = isDomestic;
		this.SS_code = SSCode;
		this.line_number = lineNumber;
		this.feeder_name = feederName;
		this.node = node;
	}

	public boolean isIsDomestic() {
		return is_domestic;
	}

	public void setIsDomestic(boolean isDomestic) {
		this.is_domestic = isDomestic;
	}

	public String getSSCode() {
		return SS_code;
	}

	public void setSSCode(String SSCode) {
		this.SS_code = SSCode;
	}

	public String getLineNumber() {
		return line_number;
	}

	public void setLineNumber(String lineNumber) {
		this.line_number = lineNumber;
	}

	public String getFeederName() {
		return feeder_name;
	}

	public void setFeederName(String feederName) {
		this.feeder_name = feederName;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}
}
