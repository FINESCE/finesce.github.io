/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.generic;

import eu.finesce.api.buildings.Building;
import eu.finesce.api.electric_vehicles.Vehicle;
import eu.finesce.api.weather.WeatherDetails;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@XmlSeeAlso({ Building.class, Vehicle.class, WeatherDetails.class })
public class MeasurableEntity {
	@XmlElement
	private String					id;
	@XmlElement
	private EntityTypes				type;
	@XmlElementWrapper(name = "measurement_types")
	@XmlElement(name = "type")
	private List<MeasurementType>	measurementTypes;
	@XmlElementWrapper(name = "related_entities")
	@XmlElement(name = "entity")
	private List<String>			relatedEntities;

	public MeasurableEntity() {
		this.measurementTypes = new ArrayList<>();
		this.relatedEntities = new ArrayList<>();
	}

	public MeasurableEntity(String identifier, List<MeasurementType> measurements, List<String> relatedEntities) {
		this.id = identifier;
		this.measurementTypes = measurements;
		this.relatedEntities = relatedEntities;
	}

	public MeasurableEntity(String identifier, EntityTypes type, List<MeasurementType> measurements, List<String> relatedEntities) {
		this.id = identifier;
		this.type = type;
		this.measurementTypes = measurements;
		this.relatedEntities = relatedEntities;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<MeasurementType> getMeasurementTypes() {
		return measurementTypes;
	}

	public void setMeasurementTypes(List<MeasurementType> measurementTypes) {
		this.measurementTypes = measurementTypes;
	}

	public List<String> getRelatedEntities() {
		return relatedEntities;
	}

	public void setRelatedEntities(List<String> relatedEntities) {
		this.relatedEntities = relatedEntities;
	}

	public EntityTypes getType() {
		return type;
	}

	public void setType(EntityTypes type) {
		this.type = type;
	}
}
