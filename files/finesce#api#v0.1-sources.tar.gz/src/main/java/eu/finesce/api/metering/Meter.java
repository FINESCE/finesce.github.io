/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.metering;

import eu.finesce.api.generic.Address;
import eu.finesce.api.generic.MeasurementTypeIdentifiers;
import eu.finesce.api.generic.SampleIdentifiers;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "meter")
public class Meter {
	private String			id;
	private String			customer_id;
	private String			sector;
	private Address			address;
	private String			sample_identifier;
	private String			latitude;
	private String			longitude;
	private List<String>	measurement_type_identifiers;
	private List<String>	related_entities;

	public Meter(String id, String customerId, String sector, Address address, String sampleIdentifier, String latitude, String longitude, List<String> meteringCapabilities, List<String> relatedEntities) {
		this.id = id;
		this.customer_id = customerId;
		this.sector = sector;
		this.address = address;
		this.sample_identifier = sampleIdentifier;
		this.latitude = latitude;
		this.longitude = longitude;
		this.measurement_type_identifiers = meteringCapabilities;
		this.related_entities = relatedEntities;
	}

	public Meter() {
		this.measurement_type_identifiers = new ArrayList<>();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customer_id;
	}

	public void setCustomerId(String customerId) {
		this.customer_id = customerId;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getSampleIdentifier() {
		return sample_identifier;
	}

	public void setSampleIdentifier(String sampleIdentifier) {
		this.sample_identifier = sampleIdentifier;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public List<String> getMeteringCapabilities() {
		return measurement_type_identifiers;
	}

	public void setMeteringCapabilities(List<String> meteringCapabilities) {
		this.measurement_type_identifiers = meteringCapabilities;
	}

	public List<String> getRelatedEntities() {
		return related_entities;
	}

	public void setRelatedEntities(List<String> relatedEntities) {
		this.related_entities = relatedEntities;
	}
}