/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.measurements.types;

import eu.finesce.api.generic.MeasurementType;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class GlobalHorizontalIrradiance extends MeasurementType {

	/**
	 * 
	 */
	public GlobalHorizontalIrradiance() {
		super();
		super.setId(null);
		super.setName("GlobalHorizontalIrradiance");
		super.setDescription("Radiance flux per unit area received by a surface");
		super.setType("Flow");
		super.setUnit("W/m^2");
	}

	public GlobalHorizontalIrradiance(String id, String name, String description, String type, String unit) {
		super(id, name, description, type, unit);
	}

}
