/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.generic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class EntityMapAdapter extends XmlAdapter<EntityMapAdapter.AdaptedMap, Map<String, List<String>>> {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.xml.bind.annotation.adapters.XmlAdapter#marshal(java.lang.Object)
	 */
	@Override
	public AdaptedMap marshal(Map<String, List<String>> map) throws Exception {
		AdaptedMap adaptedMap = new AdaptedMap();
		for (Map.Entry<String, List<String>> mapEntry : map.entrySet()) {
			Entity entity = new Entity();
			entity.setType(mapEntry.getKey());
			entity.setList_id(mapEntry.getValue());
			adaptedMap.getEntities().add(entity);
		}
		return adaptedMap;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.xml.bind.annotation.adapters.XmlAdapter#unmarshal(java.lang.Object)
	 */
	@Override
	public Map<String, List<String>> unmarshal(AdaptedMap adaptedMap) throws Exception {
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		for (Entity entity : adaptedMap.getEntities()) {
			map.put(entity.getType(), entity.getList_id());
		}
		return map;
	}

	public static class AdaptedMap {
		@XmlElement(name = "entities")
		private List<Entity>	entityList	= new ArrayList<>();

		public List<Entity> getEntities() {
			return entityList;
		}

		public void setEntities(List<Entity> entities) {
			this.entityList = entities;
		}
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name = "entity")
	public static class Entity {
		private String			type;
		@XmlElementWrapper(name = "list_id")
		@XmlElement(name = "id")
		private List<String>	list_id;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public List<String> getList_id() {
			return list_id;
		}

		public void setList_id(List<String> list_id) {
			this.list_id = list_id;
		}
	}
}
