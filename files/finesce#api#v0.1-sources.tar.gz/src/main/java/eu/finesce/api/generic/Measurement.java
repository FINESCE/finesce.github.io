/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.generic;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "measurements")
public class Measurement<T> {
	@XmlElement
	private String			id;
	@XmlElement
	private String			measurement_type;
	private List<Value<T>>	values;

	private String			start_time;
	private String			end_time;

	public Measurement(String identifier, String type, List<Value<T>> values, String start_time, String end_time) {
		this.id = identifier;
		this.measurement_type = type;
		this.values = values;
		this.start_time = start_time;
		this.end_time = end_time;
	}

	public Measurement(String identifier, MeasurementType type, List<Value<T>> values) {
		this.id = identifier;
		this.measurement_type = type.getName();
		this.values = values;
	}

	public Measurement(String identifier, String type) {
		this.id = identifier;
		this.measurement_type = type;
		this.values = new ArrayList<>();
	}

	public Measurement(String identifier, MeasurementType type) {
		this.id = identifier;
		this.measurement_type = type.getName();
		this.values = new ArrayList<>();
	}

	public Measurement(MeasurementType type) {
		this.id = null;
		this.measurement_type = type.getName();
		this.values = new ArrayList<>();
	}

	public Measurement() {
		this.values = new ArrayList<>();
	}

	public int add(Value<T> v) {
		this.getValues().add(v);
		return this.getValues().size() - 1;
	}

	public String getIdentifier() {
		return id;
	}

	public void setIdentifier(String identifier) {
		this.id = identifier;
	}

	public String getType() {
		return measurement_type;
	}

	public void setType(MeasurementType type) {
		this.measurement_type = type.getName();
	}

	public void setType(String type) {
		this.measurement_type = type;
	}

	public List<Value<T>> getValues() {
		return values;
	}

	public void setValues(List<Value<T>> values) {
		this.values = values;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
}
