/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "vehicle")
public class Vehicle {

	private String				id;
	private String				type;
	private Map<String, String>	measurement_points;
	private Map<String, String>	related_entities;

	/**
	 * Creates an empty vehicle
	 */
	public Vehicle() {
		super();
		this.measurement_points = new HashMap<>();
		this.related_entities = new HashMap<>();
	}

	/**
	 * Creates a generic vehicle of a specific type
	 * 
	 * @param id
	 *            The id of the vehicle
	 * @param type
	 *            The type of the vehicle
	 */
	public Vehicle(String id, String type) {
		super();
		this.id = id;
		this.type = type;
		this.measurement_points = new HashMap<>();
		this.related_entities = new HashMap<>();
	}

	/**
	 * Creates a vehicle of a specific type, accompanied by a number of
	 * measurements points and one or more related entities (e.g. a Building)
	 * 
	 * @param idThe
	 *            id of the vehicle
	 * @param type
	 *            The type of the vehicle
	 * @param measurement_points
	 *            The measurements points (e.g. the type of measurements
	 *            capabilities the vehicle exposes)
	 * @param related_entities_ids
	 *            The list of entities related to the vehicle
	 */
	public Vehicle(String id, String type, Map<String, String> measurement_points, Map<String, String> related_entities_ids) {
		super();
		this.id = id;
		this.type = type;
		this.measurement_points = measurement_points;
		this.related_entities = related_entities_ids;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void putMeasurementPoint(String type, String id) {
		this.getMeasurement_points().put(type, id);
	}

	public Map<String, String> getMeasurement_points() {
		return measurement_points;
	}

	public void setMeasurement_points(Map<String, String> measurement_points) {
		this.measurement_points = measurement_points;
	}

	public void putRelatedEntity(String entity, String id) {
		this.getRelated_entities_ids().put(entity, id);
	}

	public Map<String, String> getRelated_entities_ids() {
		return related_entities;
	}

	public void setRelated_entities_ids(Map<String, String> related_entities_ids) {
		this.related_entities = related_entities_ids;
	}

}
