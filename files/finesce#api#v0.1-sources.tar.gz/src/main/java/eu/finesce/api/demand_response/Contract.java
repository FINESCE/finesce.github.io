/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.demand_response;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlSeeAlso({ ContractAction.class, DemandResponseAction.class })
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "contract")
public class Contract {

	private String					id;
	private String					incentive_plan_id;
	private String					customer_id;

	@XmlElementWrapper(name = "actions")
	@XmlElement(name = "action")
	private List<ContractAction>	actions;

	private String					state;

	/**
	 * 
	 */
	public Contract() {
		this.setActions(new ArrayList<ContractAction>());
	}

	/**
	 * @param id
	 * @param incentive_plan_id
	 * @param customer_id
	 * @param actions
	 * @param state
	 */
	public Contract(String id, String incentive_plan_id, String customer_id, List<ContractAction> actions, String state) {
		this.id = id;
		this.incentive_plan_id = incentive_plan_id;
		this.customer_id = customer_id;
		this.actions = actions;
		this.state = state;
		this.setActions(new ArrayList<ContractAction>());
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIncentive_plan_id() {
		return incentive_plan_id;
	}

	public void setIncentive_plan_id(String incentive_plan_id) {
		this.incentive_plan_id = incentive_plan_id;
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public List<ContractAction> getActions() {
		return actions;
	}

	public void setActions(List<ContractAction> actions) {
		this.actions = actions;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Adds a new ContractAction object into the list of actions
	 * 
	 * @param ca
	 *            The action to add
	 * @return The list index of the inserted action
	 */
	public int add(ContractAction ca) {
		if (this.getActions() == null) {
			this.setActions(new ArrayList<ContractAction>());
		}
		this.getActions().add(ca);
		return this.getActions().size() - 1;
	}
}
