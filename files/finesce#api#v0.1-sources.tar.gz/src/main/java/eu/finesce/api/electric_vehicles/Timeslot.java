/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "timeslot")
public class Timeslot {

	private String	id;
	private String	start;
	private int		duration;

	/**
	 * Creates an empty timeslot
	 */
	public Timeslot() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a new, empty timeslot
	 * 
	 * @param id
	 *            The id of the timeslot
	 * @param start
	 *            The start time of the timeslot (in ISO8601).
	 * @param duration
	 *            The duration of the timeslot (in minutes)
	 */
	public Timeslot(String id, String start, int duration) {
		this.id = id;
		this.start = start;
		this.duration = duration;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}
}
