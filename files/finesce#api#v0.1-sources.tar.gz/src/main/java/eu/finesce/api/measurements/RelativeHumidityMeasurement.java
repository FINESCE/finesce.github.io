package eu.finesce.api.measurements;

import java.util.List;

import eu.finesce.api.generic.Measurement;
import eu.finesce.api.generic.MeasurementType;
import eu.finesce.api.measurements.types.RelativeHumidity;

public class RelativeHumidityMeasurement extends Measurement {

	public RelativeHumidityMeasurement(String identifier, String type, List values, String start_time, String end_time) {
		super(identifier, type, values, start_time, end_time);
	}

	public RelativeHumidityMeasurement(String identifier, MeasurementType type, List values) {
		super(identifier, type, values);
	}

	public RelativeHumidityMeasurement(String identifier, String type) {
		super(identifier, type);
	}

	public RelativeHumidityMeasurement(String identifier, MeasurementType type) {
		super(identifier, type);
	}

	public RelativeHumidityMeasurement(MeasurementType type) {
		super(type);
	}

	public RelativeHumidityMeasurement() {
		super();
		super.setType(new RelativeHumidity());
	}

}
