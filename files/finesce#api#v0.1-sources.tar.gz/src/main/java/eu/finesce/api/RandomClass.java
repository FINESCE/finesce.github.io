/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api;

import java.util.List;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class RandomClass extends FinesceApi {

	List<Object>	list;

	/**
	 * 
	 */
	public RandomClass() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param metadata
	 */
	public RandomClass(Metadata metadata) {
		super(metadata);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param api_version
	 * @param trial
	 * @param created
	 * @param updated
	 */
	public RandomClass(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param api_version
	 * @param trial
	 */
	public RandomClass(String api_version, String trial) {
		super(api_version, trial);
		// TODO Auto-generated constructor stub
	}

}
