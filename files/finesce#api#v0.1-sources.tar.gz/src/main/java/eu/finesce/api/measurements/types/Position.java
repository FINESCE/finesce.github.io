/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.measurements.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.generic.MeasurementType;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "position")
public class Position extends MeasurementType {

	public Position() {
		super();
		super.setName("Position");
		super.setDescription("The geo-position of the vehicle measured in lat-lon.");
		super.setType("-");
		super.setUnit("-");
	}

	public Position(String id, String name, String description, String type, String unit) {
		super(id, name, description, unit, type);
	}
}
