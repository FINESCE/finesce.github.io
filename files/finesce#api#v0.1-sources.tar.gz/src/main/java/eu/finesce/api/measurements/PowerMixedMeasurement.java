package eu.finesce.api.measurements;

import java.util.List;

import eu.finesce.api.generic.Measurement;
import eu.finesce.api.generic.MeasurementType;
import eu.finesce.api.measurements.types.PowerMixed;

public class PowerMixedMeasurement extends Measurement {

	public PowerMixedMeasurement(String identifier, String type, List values, String start_time, String end_time) {
		super(identifier, type, values, start_time, end_time);
		// TODO Auto-generated constructor stub
	}

	public PowerMixedMeasurement(String identifier, MeasurementType type, List values) {
		super(identifier, type, values);
		// TODO Auto-generated constructor stub
	}

	public PowerMixedMeasurement(String identifier, String type) {
		super(identifier, type);
		// TODO Auto-generated constructor stub
	}

	public PowerMixedMeasurement(String identifier, MeasurementType type) {
		super(identifier, type);
		// TODO Auto-generated constructor stub
	}

	public PowerMixedMeasurement(MeasurementType type) {
		super(type);
		// TODO Auto-generated constructor stub
	}

	public PowerMixedMeasurement() {
		super();
		super.setType(new PowerMixed());
	}

}
