/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.smart_factory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import eu.finesce.api.generic.Measurement;
import eu.finesce.api.measurements.types.EnergyStatus;
import eu.finesce.api.measurements.types.EnergyStatusSingleton;
import eu.finesce.api.measurements.types.EnergyStatusValue;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "machine_history")
@XmlType(propOrder = { "id", "name", "process", "plc", "monitor", "resolution", "res_unit", "is_cumulative", "measurements" })
public class MachineHistory {

	private String								id;
	private String								name;
	private String								process;
	private String								plc;
	private String								monitor;
	private int									resolution;
	private String								res_unit;
	private boolean								is_cumulative;
	private Measurement<EnergyStatusSingleton>	measurements;

	/**
	 * Creates an empty machine
	 */
	public MachineHistory() {
		this.measurements = new Measurement<>(new EnergyStatus());
	}

	/**
	 * @param id
	 *            The id of the machine.
	 * @param name
	 *            The name of the machine.
	 * @param process
	 *            The process the machine is handling.
	 * @param plc
	 *            The controller unit deployed in the machine
	 * @param monitor
	 *            The external device used to monitor the energy consumption of
	 *            the machine.
	 * @param resolution
	 *            The time interval of the measurements.
	 * @param res_unit
	 *            The unit of the @param resolution field.
	 * @param is_cumulative
	 *            Checks whether the consumption is cumulative or not.
	 * @param measurements
	 *            The measurements container.
	 */
	public MachineHistory(String id, String name, String process, String plc, String monitor, int resolution, String res_unit, boolean is_cumulative, Measurement<EnergyStatusSingleton> measurements) {
		super();
		this.id = id;
		this.name = name;
		this.process = process;
		this.plc = plc;
		this.monitor = monitor;
		this.resolution = resolution;
		this.res_unit = res_unit;
		this.is_cumulative = is_cumulative;
		this.measurements = measurements;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	public String getPlc() {
		return plc;
	}

	public void setPlc(String plc) {
		this.plc = plc;
	}

	public String getMonitor() {
		return monitor;
	}

	public void setMonitor(String monitor) {
		this.monitor = monitor;
	}

	public int getResolution() {
		return resolution;
	}

	public void setResolution(int resolution) {
		this.resolution = resolution;
	}

	public String getRes_unit() {
		return res_unit;
	}

	public void setRes_unit(String string) {
		this.res_unit = string;
	}

	public boolean isIs_cumulative() {
		return is_cumulative;
	}

	public void setIs_cumulative(boolean is_cumulative) {
		this.is_cumulative = is_cumulative;
	}

	public int add(String datetime, String status, long consumption) {
		return this.getMeasurements().add(new EnergyStatusValue(datetime, status, consumption));
	}

	public Measurement<EnergyStatusSingleton> getMeasurements() {
		return measurements;
	}

	public void setMeasurements(Measurement<EnergyStatusSingleton> measurements) {
		this.measurements = measurements;
	}
}
