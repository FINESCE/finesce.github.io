/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.demand_response.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.demand_response.EnergyCosts;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "contracted_energy_prices_report")
public class EnergyCostsReport extends FinesceApi {

	@XmlElementWrapper(name = "contracted_energy_costs")
	@XmlElement(name = "contracted_energy_cost")
	private List<EnergyCosts>	contracted_energy_costs;

	/**
	 * Creates an empty contraced energy prices report
	 */
	public EnergyCostsReport() {
		this.setContracted_energy_costs(new ArrayList<EnergyCosts>());
	}

	/**
	 * Creates an empty contraced energy prices report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public EnergyCostsReport(Metadata metadata) {
		super(metadata);
		this.setContracted_energy_costs(new ArrayList<EnergyCosts>());
	}

	/**
	 * Creates an empty contraced energy prices report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public EnergyCostsReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.setContracted_energy_costs(new ArrayList<EnergyCosts>());
	}

	/**
	 * Creates an empty contraced energy prices report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public EnergyCostsReport(String api_version, String trial) {
		super(api_version, trial);
		this.setContracted_energy_costs(new ArrayList<EnergyCosts>());
	}

	public List<EnergyCosts> getContracted_energy_costs() {
		return contracted_energy_costs;
	}

	public void setContracted_energy_costs(List<EnergyCosts> contracted_energy_costs) {
		this.contracted_energy_costs = contracted_energy_costs;
	}

	/**
	 * Adds a new contracted energy costs object in the respective list
	 * 
	 * @param ec
	 *            The contracted energy costs object to add
	 * @return The list index of the contracted energy costs object
	 */
	public int add(EnergyCosts ec) {
		if (this.getContracted_energy_costs() == null) {
			this.setContracted_energy_costs(new ArrayList<EnergyCosts>());
		}
		this.getContracted_energy_costs().add(ec);
		return this.getContracted_energy_costs().size() - 1;
	}
}
