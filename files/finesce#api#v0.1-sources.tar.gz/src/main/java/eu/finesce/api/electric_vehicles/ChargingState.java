/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "charging_state")
public class ChargingState {
	private String	id;
	private boolean	change_requested;
	private boolean	responded;
	private boolean	requested_state_is_on;
	private boolean	is_charging;
	private boolean	is_connected;
	private boolean	battery_full;
	private String	ev_id;
	private String	ev_supply_equipment_id;
	private String	timeslot_id;
	private String	charging_mode_id;

	/**
	 * Creates a new, empty charging state
	 */
	public ChargingState() {
	}

	/**
	 * Creates a new charging state
	 * 
	 * @param id
	 *            The id of the charging state
	 * @param change_requested
	 *            Has a state change been requested?
	 * @param responded
	 *            Has the servo responded to the request?
	 * @param requested_state_is_on
	 *            Is the requested state on or off?
	 * @param is_charging
	 *            Is the ev charging?
	 * @param is_connected
	 *            Is the ev currently connected?
	 * @param battery_full
	 *            Is the ev battery full?
	 * @param ev_id
	 *            The id of the ev
	 * @param ev_supply_equipment_id
	 *            The id of the ev supply equipment
	 * @param timeslot_id
	 *            The timeslot id of the charging state
	 * @param charging_mode_id
	 *            The charging mode id of the charging state
	 */
	public ChargingState(String id, boolean change_requested, boolean responded, boolean requested_state_is_on, boolean is_charging, boolean is_connected, boolean battery_full, String ev_id, String ev_supply_equipment_id,
			String timeslot_id, String charging_mode_id) {
		this.id = id;
		this.change_requested = change_requested;
		this.responded = responded;
		this.requested_state_is_on = requested_state_is_on;
		this.is_charging = is_charging;
		this.is_connected = is_connected;
		this.battery_full = battery_full;
		this.ev_id = ev_id;
		this.ev_supply_equipment_id = ev_supply_equipment_id;
		this.timeslot_id = timeslot_id;
		this.charging_mode_id = charging_mode_id;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the change_requested
	 */
	public boolean isChange_requested() {
		return change_requested;
	}

	/**
	 * @param change_requested
	 *            the change_requested to set
	 */
	public void setChange_requested(boolean change_requested) {
		this.change_requested = change_requested;
	}

	/**
	 * @return the responded
	 */
	public boolean isResponded() {
		return responded;
	}

	/**
	 * @param responded
	 *            the responded to set
	 */
	public void setResponded(boolean responded) {
		this.responded = responded;
	}

	/**
	 * @return the requested_state_is_on
	 */
	public boolean isRequested_state_is_on() {
		return requested_state_is_on;
	}

	/**
	 * @param requested_state_is_on
	 *            the requested_state_is_on to set
	 */
	public void setRequested_state_is_on(boolean requested_state_is_on) {
		this.requested_state_is_on = requested_state_is_on;
	}

	/**
	 * @return the is_charging
	 */
	public boolean isIs_charging() {
		return is_charging;
	}

	/**
	 * @param is_charging
	 *            the is_charging to set
	 */
	public void setIs_charging(boolean is_charging) {
		this.is_charging = is_charging;
	}

	/**
	 * @return the is_connected
	 */
	public boolean isIs_connected() {
		return is_connected;
	}

	/**
	 * @param is_connected
	 *            the is_connected to set
	 */
	public void setIs_connected(boolean is_connected) {
		this.is_connected = is_connected;
	}

	/**
	 * @return the battery_full
	 */
	public boolean isBattery_full() {
		return battery_full;
	}

	/**
	 * @param battery_full
	 *            the battery_full to set
	 */
	public void setBattery_full(boolean battery_full) {
		this.battery_full = battery_full;
	}

	/**
	 * @return the ev_id
	 */
	public String getEv_id() {
		return ev_id;
	}

	/**
	 * @param ev_id
	 *            the ev_id to set
	 */
	public void setEv_id(String ev_id) {
		this.ev_id = ev_id;
	}

	/**
	 * @return the ev_supply_equipment_id
	 */
	public String getEv_supply_equipment_id() {
		return ev_supply_equipment_id;
	}

	/**
	 * @param ev_supply_equipment_id
	 *            the ev_supply_equipment_id to set
	 */
	public void setEv_supply_equipment_id(String ev_supply_equipment_id) {
		this.ev_supply_equipment_id = ev_supply_equipment_id;
	}

	/**
	 * @return the timeslot_id
	 */
	public String getTimeslot_id() {
		return timeslot_id;
	}

	/**
	 * @param timeslot_id
	 *            the timeslot_id to set
	 */
	public void setTimeslot_id(String timeslot_id) {
		this.timeslot_id = timeslot_id;
	}

	/**
	 * @return the charging_mode_id
	 */
	public String getCharging_mode_id() {
		return charging_mode_id;
	}

	/**
	 * @param charging_mode_id
	 *            the charging_mode_id to set
	 */
	public void setCharging_mode_id(String charging_mode_id) {
		this.charging_mode_id = charging_mode_id;
	}
}
