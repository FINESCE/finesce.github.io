/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.electric_vehicles.ConnectionState;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "connection_states_report")
public class ConnectionStatesReport extends FinesceApi {

	private List<ConnectionState>	connection_states;

	/**
	 * Creates an empty connection_states of connection states
	 */
	public ConnectionStatesReport() {
		this.connection_states = new ArrayList<>();
	}

	/**
	 * Creates an empty connection_states of connection states
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public ConnectionStatesReport(Metadata metadata) {
		super(metadata);
		this.connection_states = new ArrayList<>();
	}

	/**
	 * Creates an empty connection_states of connection states
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public ConnectionStatesReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.connection_states = new ArrayList<>();
	}

	/**
	 * Creates an empty connection_states of connection states
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public ConnectionStatesReport(String api_version, String trial) {
		super(api_version, trial);
		this.connection_states = new ArrayList<>();
	}

	/**
	 * Adds a connection state to the connection_states of connection states
	 * 
	 * @param cs
	 *            The connection state to add
	 * @return The connection_states index of the inserted connection state
	 */
	public int add(ConnectionState cs) {
		this.getConnection_states().add(cs);
		return this.getConnection_states().size() - 1;
	}

	public List<ConnectionState> getConnection_states() {
		return connection_states;
	}

	public void setConnection_states(List<ConnectionState> connection_states) {
		this.connection_states = connection_states;
	}
}
