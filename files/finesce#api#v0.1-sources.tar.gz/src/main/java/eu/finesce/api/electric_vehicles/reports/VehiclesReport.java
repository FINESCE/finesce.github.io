/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.electric_vehicles.Vehicle;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "vehicles_report")
public class VehiclesReport extends FinesceApi {

	private List<Vehicle>	vehicles;

	/**
	 * Creates a new vehicle report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public VehiclesReport(Metadata metadata) {
		super(metadata);
		this.vehicles = new ArrayList<>();
	}

	/**
	 * Creates a new vehicle report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public VehiclesReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.vehicles = new ArrayList<>();
	}

	/**
	 * Creates a new vehicle report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public VehiclesReport(String api_version, String trial) {
		super(api_version, trial);
		this.vehicles = new ArrayList<>();
	}

	/**
	 * Creates a new vehicle report
	 */
	public VehiclesReport() {
		this.vehicles = new ArrayList<>();
	}

	/**
	 * Adds a vehicle to the report
	 * 
	 * @param v
	 *            The vehicle to add
	 * @return The index of the vehicle added to the vehicles
	 */
	public int add(Vehicle v) {
		this.getList().add(v);
		return this.getList().size() - 1;
	}

	public List<Vehicle> getList() {
		return vehicles;
	}

	public void setList(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

}
