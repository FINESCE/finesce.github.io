/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.demand_response.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.demand_response.IssueResolutionPlan;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "issue_resolution_plans_report")
public class IssueResolutionPlanReport extends FinesceApi {

	@XmlElementWrapper(name = "issue_resolution_plans")
	@XmlElement(name = "issue_resolution_plan")
	private List<IssueResolutionPlan>	issue_resolution_plans;

	/**
	 * Creates an empty incentive plans report
	 */
	public IssueResolutionPlanReport() {
		this.setList(new ArrayList<IssueResolutionPlan>());
	}

	/**
	 * Creates an empty issue resolution plan report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public IssueResolutionPlanReport(Metadata metadata) {
		super(metadata);
		this.setList(new ArrayList<IssueResolutionPlan>());
	}

	/**
	 * Creates an empty issue resolution plan report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public IssueResolutionPlanReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.setList(new ArrayList<IssueResolutionPlan>());
	}

	/**
	 * Creates an empty issue resolution plan report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public IssueResolutionPlanReport(String api_version, String trial) {
		super(api_version, trial);
		this.setList(new ArrayList<IssueResolutionPlan>());
	}

	public List<IssueResolutionPlan> getList() {
		return issue_resolution_plans;
	}

	public void setList(List<IssueResolutionPlan> list) {
		this.issue_resolution_plans = list;
	}

	/**
	 * Adds an issue resolution plan to the issue_resolution_plans of incentive
	 * plans
	 * 
	 * @param ip
	 *            The issue resolution plan to add
	 * @return The issue_resolution_plans index of the contract inserted
	 */
	public int add(IssueResolutionPlan ip) {
		if (this.getList() == null) {
			this.setList(new ArrayList<IssueResolutionPlan>());
		}
		this.getList().add(ip);
		return this.getList().size() - 1;
	}

}
