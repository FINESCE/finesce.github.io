/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.electric_vehicles.ChargingMode;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "charging_modes")
public class ChargingModesReport extends FinesceApi {

	List<ChargingMode>	charging_modes;

	/**
	 * Creates an empty charging_modes of charging modes
	 */
	public ChargingModesReport() {
		this.charging_modes = new ArrayList<>();
	}

	/**
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public ChargingModesReport(Metadata metadata) {
		super(metadata);
		this.charging_modes = new ArrayList<>();
	}

	/**
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public ChargingModesReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.charging_modes = new ArrayList<>();
	}

	/**
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public ChargingModesReport(String api_version, String trial) {
		super(api_version, trial);
		this.charging_modes = new ArrayList<>();
	}

	/**
	 * Adds a charging mode to the charging_modes
	 * 
	 * @param cm
	 *            The charging mode to add
	 * @return The index of the charging mode in the charging_modes
	 */
	public int add(ChargingMode cm) {
		this.getCharging_modes().add(cm);
		return this.getCharging_modes().size() - 1;
	}

	public List<ChargingMode> getCharging_modes() {
		return charging_modes;
	}

	public void setCharging_modes(List<ChargingMode> charging_modes) {
		this.charging_modes = charging_modes;
	}
}
