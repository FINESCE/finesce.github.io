/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.vpp;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "component_data_container")
public class ComponentDataContainer {

	@XmlElementWrapper(name = "data_list")
	@XmlElement(name = "data")
	List<ComponentData>	data;

	/**
	 * 
	 */
	public ComponentDataContainer() {
		this.data = new ArrayList<>();
	}

	/**
	 * @param data
	 */
	public ComponentDataContainer(List<ComponentData> data) {
		super();
		this.data = data;
	}

	public int add(ComponentData cd) {
		this.getData().add(cd);
		return this.getData().size() - 1;
	}

	public List<ComponentData> getData() {
		return data;
	}

	public void setData(List<ComponentData> data) {
		this.data = data;
	}

}
