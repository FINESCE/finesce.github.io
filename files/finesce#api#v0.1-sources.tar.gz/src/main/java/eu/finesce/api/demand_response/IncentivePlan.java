/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.demand_response;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlSeeAlso(DemandResponseAction.class)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "incentive_plan")
public class IncentivePlan {

	private String			id;
	private String			time;
	private String			customer_id;
	private String			meter_id;
	private String			profile_object_name;
	private String			irp_id;

	private List<IPAction>	actions;

	private double			der_cost;
	private double			primary_energy_cost;
	private double			energy_cost;

	private String			state;
	private String			retailer_notes;
	private String			market_regulator_notes;
	private String			author;
	private String			author_email;

	/**
	 * 
	 */
	public IncentivePlan() {
		setActions(new ArrayList<IPAction>());
	}

	/**
	 * @param id
	 * @param time
	 * @param customer_id
	 * @param meter_id
	 * @param profile_object_name
	 * @param irp_id
	 * @param actions
	 * @param der_cost
	 * @param primary_energy_cost
	 * @param energy_cost
	 * @param state
	 * @param retailer_notes
	 * @param market_regulator_notes
	 * @param author
	 * @param author_email
	 */
	public IncentivePlan(String id, String time, String customer_id, String meter_id, String profile_object_name, String irp_id, List<IPAction> incentive_plan_actions, double der_cost, double primary_energy_cost, double energy_cost,
			String state, String retailer_notes, String market_regulator_notes, String author, String author_email) {
		this.id = id;
		this.time = time;
		this.customer_id = customer_id;
		this.meter_id = meter_id;
		this.profile_object_name = profile_object_name;
		this.irp_id = irp_id;
		this.actions = incentive_plan_actions;
		this.der_cost = der_cost;
		this.primary_energy_cost = primary_energy_cost;
		this.energy_cost = energy_cost;
		this.state = state;
		this.retailer_notes = retailer_notes;
		this.market_regulator_notes = market_regulator_notes;
		this.author = author;
		this.author_email = author_email;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public String getMeter_id() {
		return meter_id;
	}

	public void setMeter_id(String meter_id) {
		this.meter_id = meter_id;
	}

	public String getProfile_object_name() {
		return profile_object_name;
	}

	public void setProfile_object_name(String profile_object_name) {
		this.profile_object_name = profile_object_name;
	}

	public String getIrp_id() {
		return irp_id;
	}

	public void setIrp_id(String irp_id) {
		this.irp_id = irp_id;
	}

	public List<IPAction> getActions() {
		return actions;
	}

	public void setActions(List<IPAction> incentive_plan_actions) {
		this.actions = incentive_plan_actions;
	}

	public double getDer_cost() {
		return der_cost;
	}

	public void setDer_cost(double der_cost) {
		this.der_cost = der_cost;
	}

	public double getPrimary_energy_cost() {
		return primary_energy_cost;
	}

	public void setPrimary_energy_cost(double primary_energy_cost) {
		this.primary_energy_cost = primary_energy_cost;
	}

	public double getEnergy_cost() {
		return energy_cost;
	}

	public void setEnergy_cost(double energy_cost) {
		this.energy_cost = energy_cost;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getRetailer_notes() {
		return retailer_notes;
	}

	public void setRetailer_notes(String retailer_notes) {
		this.retailer_notes = retailer_notes;
	}

	public String getMarket_regulator_notes() {
		return market_regulator_notes;
	}

	public void setMarket_regulator_notes(String market_regulator_notes) {
		this.market_regulator_notes = market_regulator_notes;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthor_email() {
		return author_email;
	}

	public void setAuthor_email(String author_email) {
		this.author_email = author_email;
	}

	public void add(IPAction ipa) {
		if (this.getActions() == null) {
			this.setActions(new ArrayList<IPAction>());
		}
		this.getActions().add(ipa);
		return;
	}
}
