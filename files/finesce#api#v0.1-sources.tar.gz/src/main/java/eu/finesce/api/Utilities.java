/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class Utilities {

	public static String now() {
		return ISO8601.now();
	}

	public static String future(int seconds) {
		long ret = Calendar.getInstance().getTimeInMillis();
		ret += seconds * 1000;
		return dateFromMilliSeconds(ret);
	}

	public static String future(String date, int seconds) {
		Calendar c = Calendar.getInstance();
		try {
			c.setTimeInMillis(ISO8601.toCalendar(date).getTimeInMillis() + seconds * 1000);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return ISO8601.fromCalendar(c);
	}

	public static String past(int seconds) {
		return future(-seconds);
	}

	public static String past(String date, int seconds) {
		return future(date, -seconds);
	}

	public static String dateFromMilliSeconds(long date) {
		String ret = null;
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(date);
		ret = ISO8601.fromCalendar(cal);
		return ret;
	}

	public static String dateFromSeconds(long date) {
		return dateFromMilliSeconds(date * 1000);
	}

	public static long millisFromDateString(String date) {
		long ret = 0;
		try {
			ret = ISO8601.toCalendar(date).getTimeInMillis();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return ret;
	}

	public static long dateDiffMillis(String date1, String date2) {
		long ret = 0;
		try {
			ret = ISO8601.toCalendar(date1).getTimeInMillis() - ISO8601.toCalendar(date2).getTimeInMillis();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return ret;
	}

	public static long secondsFromDateString(String date) {
		return millisFromDateString(date) / 1000;
	}

	public static String fromZ(String datez) {
		String ret = datez;
		try {
			ret = ISO8601.fromCalendar(ISO8601.toCalendar(datez));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}

	private static final class ISO8601 {
		/** Transform Calendar to ISO 8601 string. */
		public static String fromCalendar(final Calendar calendar) {
			Date date = calendar.getTime();
			String formatted = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(date);
			return formatted.substring(0, 22) + ":" + formatted.substring(22);
		}

		/** Get current date and time formatted as ISO 8601 string. */
		public static String now() {
			return fromCalendar(GregorianCalendar.getInstance());
		}

		/** Transform ISO 8601 string to Calendar. */
		public static Calendar toCalendar(final String iso8601string) throws ParseException {
			Calendar calendar = GregorianCalendar.getInstance();
			String s = iso8601string.replace("Z", "+00:00");
			try {
				s = s.substring(0, 22) + s.substring(23); // to get rid of the
															// ":"
			} catch (IndexOutOfBoundsException e) {
				throw new ParseException("Invalid length", 0);
			}
			Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").parse(s);
			calendar.setTime(date);
			return calendar;
		}
	}

	public static List<String> get_n_dates(String start, String end, int dates_number) {
		List<String> ret = new ArrayList<String>();
		long _current = Utilities.millisFromDateString(start);
		long _end = Utilities.millisFromDateString(end);
		int diff = (int) Math.floor(Utilities.dateDiffMillis(end, start) / dates_number);
		while (_current < _end) {
			ret.add(Utilities.dateFromMilliSeconds(_current));
			_current += diff;
		}
		ret.add(end);
		return ret;
	}
}
