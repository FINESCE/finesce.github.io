/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.generic;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "measurement_types_report")
public class MeasurementTypesReport extends FinesceApi {

	private List<MeasurementType>	measurement_types;

	/**
	 * Creates an empty MeasurementType report
	 */
	public MeasurementTypesReport() {
		this.measurement_types = new ArrayList<>();
	}

	/**
	 * Creates an empty MeasurementType report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public MeasurementTypesReport(Metadata metadata) {
		super(metadata);
		this.measurement_types = new ArrayList<>();
	}

	/**
	 * Creates a new MeasurementType report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public MeasurementTypesReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.measurement_types = new ArrayList<>();
	}

	/**
	 * Creates a new MeasurementType report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public MeasurementTypesReport(String api_version, String trial) {
		super(api_version, trial);
		this.measurement_types = new ArrayList<>();
	}

	/**
	 * Adds a MeasurementType to the report
	 * 
	 * @param mt
	 *            The MeasurementType object to add
	 * @return The index of the MeasurementType object added
	 */
	public int add(MeasurementType mt) {
		this.getValues().add(mt);
		return this.getValues().size() - 1;
	}

	public List<MeasurementType> getValues() {
		return measurement_types;
	}

	public void setValues(List<MeasurementType> values) {
		this.measurement_types = values;
	}

}
