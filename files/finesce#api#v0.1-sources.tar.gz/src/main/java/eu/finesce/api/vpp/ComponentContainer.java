/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.vpp;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "component_container")
public abstract class ComponentContainer {

	List<Component>	components;

	/**
	 * Creates an empty components container
	 */
	public ComponentContainer() {
		this.components = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a components container with a list of components attached
	 * 
	 * @param components
	 *            The list of components to be attached
	 */
	public ComponentContainer(List<Component> components) {
		super();
		this.components = components;
	}

	public List<Component> getComponents() {
		return components;
	}

	public void setComponents(List<Component> components) {
		this.components = components;
	}

	/**
	 * Adds a component to the list of componets
	 * 
	 * @param c
	 *            The component to add
	 * @return The component container object containing the new component
	 */
	public ComponentContainer add(Component c) {
		this.getComponents().add(c);
		return this;
	}
}
