/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.measurements.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.measurements.EnergyConsumptionMeasurement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "energy_consumption_report")
public class EnergyConsumptionReport extends FinesceApi {

	private List<EnergyConsumptionMeasurement>	measurements;

	/**
	 * Creates an empty energy consumption report
	 */
	public EnergyConsumptionReport() {
		this.measurements = new ArrayList<>();
	}

	/**
	 * Creates a new energy consumption report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public EnergyConsumptionReport(Metadata metadata) {
		super(metadata);
		this.measurements = new ArrayList<>();
	}

	/**
	 * Creates a new energy consumption report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public EnergyConsumptionReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.measurements = new ArrayList<>();
	}

	/**
	 * Creates a new energy consumption report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public EnergyConsumptionReport(String api_version, String trial) {
		super(api_version, trial);
		this.measurements = new ArrayList<>();
	}

	/**
	 * Adds an energy consumption value to the report
	 * 
	 * @param ec
	 *            The energy consumption object to add
	 * @return The index of the energy consumption object added
	 */
	public int add(EnergyConsumptionMeasurement ec) {
		this.getValues().add(ec);
		return this.getValues().size();
	}

	public List<EnergyConsumptionMeasurement> getValues() {
		return measurements;
	}

	public void setValues(List<EnergyConsumptionMeasurement> energy_consumption_values) {
		this.measurements = energy_consumption_values;
	}

}
