/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.authentication;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "auth_request")
public class AuthRequest {
	private String	authorization_id;
	private String	password;

	/**
	 * Creates an empty authentication request object
	 */
	public AuthRequest() {
	}

	/**
	 * Creates a new authentication request object
	 * 
	 * @param authorization_id
	 *            The authorization_id of the user
	 * @param password
	 *            The password of the user
	 */
	public AuthRequest(String authorization_id, String password) {
		this.authorization_id = authorization_id;
		this.password = password;
	}

	public String getAuthorization_id() {
		return authorization_id;
	}

	public void setAuthorization_id(String authorization_id) {
		this.authorization_id = authorization_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
