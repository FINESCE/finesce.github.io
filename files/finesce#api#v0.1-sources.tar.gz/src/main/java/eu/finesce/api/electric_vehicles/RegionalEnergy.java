/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "regional_energy")
public class RegionalEnergy {

	private String	id;
	private double	generated_energy;
	private double	aggregated_energy;
	private double	requested_energy;
	private double	actual_energy;
	private double	forecasted_energy;
	private String	region_id;
	private String	timelslot_id;

	/**
	 * Creates a report containing information about regional energy use
	 */
	public RegionalEnergy() {
	}

	/**
	 * Creates a report containing information about regional energy use
	 * 
	 * @param id
	 *            The id of the report
	 * @param generated_energy
	 *            The generated energy (in kWh)
	 * @param aggregated_energy
	 *            The aggregated energy (in kWh)
	 * @param requested_energy
	 *            The requested energy (in kWh)
	 * @param actual_energy
	 *            The actual energy (in kWh)
	 * @param forecasted_energy
	 *            The forecasted energy (in kWh)
	 * @param region_id
	 *            The region id
	 * @param timelslot_id
	 *            The timeslot id
	 */
	public RegionalEnergy(String id, double generated_energy, double aggregated_energy, double requested_energy, double actual_energy, double forecasted_energy, String region_id, String timelslot_id) {
		super();
		this.id = id;
		this.generated_energy = generated_energy;
		this.aggregated_energy = aggregated_energy;
		this.requested_energy = requested_energy;
		this.actual_energy = actual_energy;
		this.forecasted_energy = forecasted_energy;
		this.region_id = region_id;
		this.timelslot_id = timelslot_id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getGenerated_energy() {
		return generated_energy;
	}

	public void setGenerated_energy(double generated_energy) {
		this.generated_energy = generated_energy;
	}

	public double getAggregated_energy() {
		return aggregated_energy;
	}

	public void setAggregated_energy(double aggregated_energy) {
		this.aggregated_energy = aggregated_energy;
	}

	public double getRequested_energy() {
		return requested_energy;
	}

	public void setRequested_energy(double requested_energy) {
		this.requested_energy = requested_energy;
	}

	public double getActual_energy() {
		return actual_energy;
	}

	public void setActual_energy(double actual_energy) {
		this.actual_energy = actual_energy;
	}

	public double getForecasted_energy() {
		return forecasted_energy;
	}

	public void setForecasted_energy(double forecasted_energy) {
		this.forecasted_energy = forecasted_energy;
	}

	public String getRegion_id() {
		return region_id;
	}

	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}

	public String getTimelslot_id() {
		return timelslot_id;
	}

	public void setTimelslot_id(String timelslot_id) {
		this.timelslot_id = timelslot_id;
	}
}
