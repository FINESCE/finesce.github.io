/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.optimisation.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.optimisation.Algoweight;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "algoweight_report")
public class AlgoweightReport extends FinesceApi {

	private List<Algoweight>	algoweights;

	/**
	 * 
	 */
	public AlgoweightReport() {
		this.algoweights = new ArrayList<>();
	}

	/**
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public AlgoweightReport(Metadata metadata) {
		super(metadata);
		this.algoweights = new ArrayList<>();
	}

	/**
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public AlgoweightReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.algoweights = new ArrayList<>();
	}

	/**
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public AlgoweightReport(String api_version, String trial) {
		super(api_version, trial);
		this.algoweights = new ArrayList<>();
	}

	/**
	 * Adds an algoweight object into the list
	 * 
	 * @param aw
	 *            The object to add
	 * @return The list index of the inserted object
	 */
	public int add(Algoweight aw) {
		this.getAlgoweight_list().add(aw);
		return this.getAlgoweight_list().size() - 1;
	}

	public List<Algoweight> getAlgoweight_list() {
		return algoweights;
	}

	public void setAlgoweight_list(List<Algoweight> algoweight_list) {
		this.algoweights = algoweight_list;
	}

}
