/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.demand_response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlSeeAlso(DemandResponseAction.class)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "contract_action")
public class ContractAction extends IPAction {

	private String	customer_approval;

	/**
	 * 
	 */
	public ContractAction() {
		super();
	}

	public ContractAction(String target, String type, String value, String start_time, String end_time, String offer, String customer_approval) {
		super(target, type, value, start_time, end_time, offer);
		this.customer_approval = customer_approval;
	}

	public ContractAction(String target, String type, String value, String start_time, String end_time, String offer) {
		super(target, type, value, start_time, end_time, offer);
	}

	public ContractAction(String target, String type, String value, String start_time, String end_time) {
		super(target, type, value, start_time, end_time);
	}

	public String getCustomer_approval() {
		return customer_approval;
	}

	public void setCustomer_approval(String customer_approval) {
		this.customer_approval = customer_approval;
	}

}
