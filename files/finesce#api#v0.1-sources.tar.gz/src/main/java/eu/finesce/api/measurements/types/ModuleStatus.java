package eu.finesce.api.measurements.types;

import eu.finesce.api.generic.MeasurementType;

public class ModuleStatus extends MeasurementType {

	public ModuleStatus() {
		super();
		super.setId(null);
		super.setName("Status");
		super.setDescription("Current module status");
		super.setType("Status");
		super.setUnit("-");
	}

	public ModuleStatus(String id, String name, String description, String type, String unit) {
		super(id, name, description, type, unit);
	}

}
