/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.demand_response;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlSeeAlso(DemandResponseAction.class)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "issue_resolution_plan")
public class IssueResolutionPlan {

	String						id;
	String						time;
	String						snapshot_filename;
	String						sector;
	@XmlElementWrapper(name = "actions")
	@XmlElement(name = "action")
	List<DemandResponseAction>	actions;
	String						state;
	String						aggregator_notes;
	String						dso_notes;
	String						author;
	String						author_email;

	/**
	 * Creates an empty IRP
	 */
	public IssueResolutionPlan() {
		this.actions = new ArrayList<DemandResponseAction>();
	}

	/**
	 * @param id
	 *            The id of the IRP
	 * @param time
	 *            The time the IRP was issued in iso8601 format
	 * @param snapshot_filename
	 *            The filename of the snapshot uploaded to the Object Storage
	 * @param sector
	 *            The sector the IRP refers to
	 * @param actions
	 *            The set of actions that will implement the IRP
	 * @param status
	 *            The status of the IRP (approved, rejected, pending)
	 * @param aggregator_notes
	 *            The notes made by the aggregator (if any)
	 * @param dso_notes
	 *            The notes made by the DSO (if any)
	 * @param author
	 *            The author of this IRP
	 * @param author_email
	 *            The email of the author
	 */
	public IssueResolutionPlan(String id, String time, String snapshot_filename, String sector, List<DemandResponseAction> irp_actions, String state, String aggregator_notes, String dso_notes, String author, String author_email) {
		super();
		this.id = id;
		this.time = time;
		this.snapshot_filename = snapshot_filename;
		this.sector = sector;
		this.actions = irp_actions;
		this.state = state;
		this.aggregator_notes = aggregator_notes;
		this.dso_notes = dso_notes;
		this.author = author;
		this.author_email = author_email;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getSnapshot_filename() {
		return snapshot_filename;
	}

	public void setSnapshot_filename(String snapshot_filename) {
		this.snapshot_filename = snapshot_filename;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public List<DemandResponseAction> getActions() {
		return actions;
	}

	public void setActions(List<DemandResponseAction> irp_actions) {
		this.actions = irp_actions;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAggregator_notes() {
		return aggregator_notes;
	}

	public void setAggregator_notes(String aggregator_notes) {
		this.aggregator_notes = aggregator_notes;
	}

	public String getDso_notes() {
		return dso_notes;
	}

	public void setDso_notes(String dso_notes) {
		this.dso_notes = dso_notes;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthor_email() {
		return author_email;
	}

	public void setAuthor_email(String author_email) {
		this.author_email = author_email;
	}

	public void add(DemandResponseAction dra) {
		if (this.getActions() == null) {
			actions = new ArrayList<DemandResponseAction>();
		}
		this.getActions().add(dra);
		return;
	}

}
