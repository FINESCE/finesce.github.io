/*
 * Copyright 2014 Artemis Voulkidis <voulkidis@synelixis.com>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.metering;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "meters_report")
public class MetersReport extends FinesceApi {

	private List<Meter>	meters;

	/**
	 * Creates a new meter list
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param meters
	 *            The list of meters
	 */
	public MetersReport(String api_version, String trial, List<Meter> meters) {
		super(api_version, trial);
		this.meters = meters;
	}

	/**
	 * Creates an empty meter list
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public MetersReport(String api_version, String trial) {
		super(api_version, trial);
		this.meters = new ArrayList<>();
	}

	/**
	 * Creates a new meter list.
	 * 
	 * @param meters
	 *            The list of meters
	 */
	public MetersReport(List<Meter> meters) {
		super();
		this.meters = meters;
	}

	/**
	 * Creates an empty list of meters
	 */
	public MetersReport() {
		super();
		this.meters = new ArrayList<>();
	}

	/**
	 * Adds a meter to the list
	 * 
	 * @param me
	 *            The meter to add
	 * @return The index of the added meter
	 */
	public int add(Meter me) {
		this.getMeters().add(me);
		return this.getMeters().size() - 1;
	}

	public List<Meter> getMeters() {
		return meters;
	}

	public void setMeters(List<Meter> meters) {
		this.meters = meters;
	}

}
