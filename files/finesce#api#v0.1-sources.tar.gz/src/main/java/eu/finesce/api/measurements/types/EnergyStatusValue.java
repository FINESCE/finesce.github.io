/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.measurements.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;

import eu.finesce.api.generic.Value;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso(EnergyStatusSingleton.class)
public class EnergyStatusValue extends Value<EnergyStatusSingleton> {

	/**
	 * Creates an empty combined energy-status value
	 */
	public EnergyStatusValue() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a new combined energy-status value
	 * 
	 * @param datetime
	 *            The datetime of the measurements
	 * @param value
	 *            The combined energy-status value
	 */
	public EnergyStatusValue(String datetime, EnergyStatusSingleton value) {
		super(datetime, value);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a new combined energy-status value
	 * 
	 * @param id
	 *            The id of the measurements
	 * @param datetime
	 *            The datetime of the measurements
	 * @param value
	 *            The combined energy-status value
	 */
	public EnergyStatusValue(String id, String datetime, EnergyStatusSingleton value) {
		super(id, datetime, value);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a new combined energy-status value
	 * 
	 * @param datetime
	 *            The datetime of the measurements
	 * @param status
	 *            The status of the machine
	 * @param consumption
	 *            The energy consumption of the machine
	 */
	public EnergyStatusValue(String datetime, String status, long consumption) {
		super(datetime, new EnergyStatusSingleton(status, consumption));
	}
}
