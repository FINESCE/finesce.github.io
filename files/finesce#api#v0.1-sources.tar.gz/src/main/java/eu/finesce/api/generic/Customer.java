/*
 * Copyright 2014 Artemis Voulkidis <voulkidis@synelixis.com>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.generic;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Customer {
	@XmlElement
	private String			identifier;
	@XmlElement
	private String			firstName;
	@XmlElement
	private String			lastName;
	@XmlElementWrapper(name = "relatedEntities")
	@XmlElement(name = "entity")
	private List<String>	relatedEntities;

	public Customer() {
		this.relatedEntities = new ArrayList<>();
	}

	public Customer(String identifier, String firstName, String lastName, List<String> relatedEntities) {
		this.identifier = identifier;
		this.firstName = firstName;
		this.lastName = lastName;
		this.relatedEntities = relatedEntities;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public List<String> getRelatedEntities() {
		return relatedEntities;
	}

	public void setRelatedEntities(List<String> relatedEntities) {
		this.relatedEntities = relatedEntities;
	}

}
