/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.vpp.reports;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.vpp.ComponentData;
import eu.finesce.api.vpp.ComponentDataContainer;
import eu.finesce.api.vpp.ComponentDataType;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "component_data_report")
public class ComponentDataReport extends FinesceApi {

	ComponentDataContainer	predictions;
	ComponentDataContainer	measurements;

	/**
	 * Creates an empty ComponentData report
	 */
	public ComponentDataReport() {
		this.predictions = new ComponentDataContainer();
		this.measurements = new ComponentDataContainer();
	}

	/**
	 * Creates an empty ComponentData report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public ComponentDataReport(Metadata metadata) {
		super(metadata);
		this.predictions = new ComponentDataContainer();
		this.measurements = new ComponentDataContainer();
	}

	/**
	 * Creates an empty ComponentData report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public ComponentDataReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.predictions = new ComponentDataContainer();
		this.measurements = new ComponentDataContainer();
	}

	/**
	 * Creates an empty ComponentData report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public ComponentDataReport(String api_version, String trial) {
		super(api_version, trial);
		this.predictions = new ComponentDataContainer();
		this.measurements = new ComponentDataContainer();
	}

	/**
	 * Adds a component data object to the report
	 * 
	 * @param cdt
	 *            The type of the component data object
	 * @param cd
	 *            The type of the
	 * @return
	 */
	public int add(ComponentDataType cdt, ComponentData cd) {
		int ret = -1;
		switch (cdt) {
			case measurements:
				this.getMeasurements().getData().add(cd);
				ret = this.getMeasurements().getData().size() - 1;
				break;
			case predictions:
				this.getPredictions().getData().add(cd);
				ret = this.getMeasurements().getData().size() - 1;
				break;
			default:
				break;
		}
		return ret;
	}

	public ComponentDataContainer getPredictions() {
		return predictions;
	}

	public void setPredictions(ComponentDataContainer predictions) {
		this.predictions = predictions;
	}

	public ComponentDataContainer getMeasurements() {
		return measurements;
	}

	public void setMeasurements(ComponentDataContainer measurements) {
		this.measurements = measurements;
	}
}
