/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.regional.reports;

import java.util.List;
import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.regional.Region;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "region_report")
public class RegionsReport extends FinesceApi {

	private List<Region>	regions;

	/**
	 * Creates a new regions of regions report
	 */
	public RegionsReport() {
		this.regions = new ArrayList<>();
	}

	/**
	 * Creates a new regions of regions report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public RegionsReport(Metadata metadata) {
		super(metadata);
		this.regions = new ArrayList<>();
	}

	/**
	 * Creates a new regions of regions report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public RegionsReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.regions = new ArrayList<>();
	}

	/**
	 * Creates a new regions of regions report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public RegionsReport(String api_version, String trial) {
		super(api_version, trial);
		this.regions = new ArrayList<>();
	}

	public int add(Region r) {
		this.getRegions().add(r);
		return this.getRegions().size() - 1;
	}

	public Region getRegion(int index) {
		return this.getRegions().get(index);
	}

	public List<Region> getRegions() {
		return regions;
	}

	public void setRegions(List<Region> regions) {
		this.regions = regions;
	}

}
