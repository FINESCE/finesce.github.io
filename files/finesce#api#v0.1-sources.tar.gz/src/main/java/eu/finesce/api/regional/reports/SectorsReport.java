/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.regional.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.regional.Sector;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "sectors_report")
public class SectorsReport extends FinesceApi {

	private List<Sector>	sectors;

	/**
	 * Creates a new sectors of sectors
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO8601 CET)
	 */
	public SectorsReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.sectors = new ArrayList<>();
	}

	/**
	 * Creates an empty sectors of sectors
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public SectorsReport(String api_version, String trial) {
		super(api_version, trial);
		this.sectors = new ArrayList<>();
	}

	/**
	 * Creates a new sectors of sectors
	 * 
	 * @param list
	 *            The sectors of sectors
	 */
	public SectorsReport(List<Sector> sectors) {
		this.sectors = sectors;
	}

	/**
	 * Creates an empty sectors of sectors
	 */
	public SectorsReport() {
		this.sectors = new ArrayList<>();
	}

	/**
	 * Adds a sector to the sectors
	 * 
	 * @param se
	 *            The sector to add to the sectors
	 * @return The index of the inserted sector
	 */
	public int add(Sector se) {
		this.getSectors().add(se);
		return this.getSectors().size() - 1;
	}

	public List<Sector> getSectors() {
		return sectors;
	}

	public void setSectors(List<Sector> sectors) {
		this.sectors = sectors;
	}
}
