package eu.finesce.api.measurements;

import java.util.List;

import eu.finesce.api.generic.Measurement;
import eu.finesce.api.generic.MeasurementType;
import eu.finesce.api.measurements.types.ModuleStatus;

public class ModuleStatusMeasurement extends Measurement {

	public ModuleStatusMeasurement(String identifier, String type, List values, String start_time, String end_time) {
		super(identifier, type, values, start_time, end_time);
		// TODO Auto-generated constructor stub
	}

	public ModuleStatusMeasurement(String identifier, MeasurementType type, List values) {
		super(identifier, type, values);
		// TODO Auto-generated constructor stub
	}

	public ModuleStatusMeasurement(String identifier, String type) {
		super(identifier, type);
		// TODO Auto-generated constructor stub
	}

	public ModuleStatusMeasurement(String identifier, MeasurementType type) {
		super(identifier, type);
		// TODO Auto-generated constructor stub
	}

	public ModuleStatusMeasurement(MeasurementType type) {
		super(type);
		// TODO Auto-generated constructor stub
	}

	public ModuleStatusMeasurement() {
		super();
		super.setType(new ModuleStatus());
	}

}
