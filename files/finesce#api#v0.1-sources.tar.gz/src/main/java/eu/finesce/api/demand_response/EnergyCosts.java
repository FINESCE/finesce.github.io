/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.demand_response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "contracted_energy_prices")
public class EnergyCosts {

	private double	der;
	private double	bulk;
	private double	sold;
	private String	start_date;
	private String	end_date;
	private String	volume;
	private String	currency;

	/**
	 * 
	 */
	public EnergyCosts() {
		this.volume = "kWh";
		this.currency = "Euro";
	}

	/**
	 * Creates a new energy prices contract object
	 * 
	 * @param der
	 *            The price of the energy produced by DER
	 * @param bulk
	 *            The price of the energy produced bulk
	 * @param sold
	 *            The price of the energy actually sold
	 * @param start_date
	 *            The start date of the validity period of the contracted prices
	 * @param end_date
	 *            The end date of the validity period of the contracted prices
	 * @param volume
	 *            The baseline volume of the energy being referred to in the
	 *            der, bulk and sold fields. Usually this should be kWh.
	 * @param currency
	 *            The currency of the energy being referred to in the der, bulk
	 *            and sold fields. Normally, this should be Euro.
	 */
	public EnergyCosts(double der, double bulk, double sold, String start_date, String end_date, String volume, String currency) {
		this.der = der;
		this.bulk = bulk;
		this.sold = sold;
		this.start_date = start_date;
		this.end_date = end_date;
		this.volume = volume;
		this.currency = currency;
	}

	public double getDer() {
		return der;
	}

	public void setDer(double der) {
		this.der = der;
	}

	public double getBulk() {
		return bulk;
	}

	public void setBulk(double bulk) {
		this.bulk = bulk;
	}

	public double getSold() {
		return sold;
	}

	public void setSold(double sold) {
		this.sold = sold;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

}
