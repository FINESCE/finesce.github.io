/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.simulation;

import eu.finesce.api.generic.Measurement;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.generic.MeasurementType;
import eu.finesce.api.generic.Value;
import eu.finesce.api.measurements.PowerSupplyMeasurement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "power_supply_prediction")
public class PowerSupplyPrediction extends Measurement<Double> {

	/**
	 * Creates an empty power supply prediction object
	 * 
	 * @param startTime
	 *            The start time of the prediction
	 * @param endTime
	 *            The end time of the prediction
	 * @param identifier
	 *            The id of the prediction
	 * @param type
	 *            The type of the prediction
	 * @param values
	 *            The values of the prediction
	 */
	public PowerSupplyPrediction(String startTime, String endTime, String identifier, String type, List<Value<Double>> values) {
		super(identifier, type, values, startTime, endTime);
	}

	/**
	 * Creates a power supply prediction object
	 * 
	 * @param identifier
	 *            The id of the prediction
	 * @param type
	 *            The type of the prediction
	 * @param values
	 *            The values of the prediction
	 */
	public PowerSupplyPrediction(String identifier, MeasurementType type, List<Value<Double>> values) {
		super(identifier, type, values);
	}

	/**
	 * Creates an empty power supply prediction object
	 * 
	 * @param identifier
	 *            The id of the prediction
	 * @param type
	 *            The type of the prediction
	 */
	public PowerSupplyPrediction(String identifier, MeasurementType type) {
		super(identifier, type);
	}

	/**
	 * Creates an empty power supply prediction object
	 */
	public PowerSupplyPrediction() {
		super();
	}

}
