/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import eu.finesce.api.regional.Region;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ev_equipment")
@XmlSeeAlso(Region.class)
public class VehicleSupplyEquipment {

	private String	id;
	private String	manufacturer;
	private String	model;
	private String	hw_version;
	private String	fw_version;
	private String	region_id;

	/**
	 * Creates a new VehicleSupplyEquipment
	 */
	public VehicleSupplyEquipment() {
	}

	/**
	 * Creates a new VehicleSupplyEquipment object
	 * 
	 * @param id
	 *            The id of the VehicleSupplyEquipment
	 * @param manufacturer
	 *            The manufacturer of the VehicleSupplyEquipment
	 * @param model
	 *            The model of the VehicleSupplyEquipment
	 * @param hw_version
	 *            The hardware version of the VehicleSupplyEquipment
	 * @param fw_version
	 *            The firmware version of the VehicleSupplyEquipment
	 * @param region_id
	 *            The id of the region of the specific VehicleSupplyEquipment
	 */
	public VehicleSupplyEquipment(String id, String manufacturer, String model, String hw_version, String fw_version, String region_id) {
		this.id = id;
		this.manufacturer = manufacturer;
		this.model = model;
		this.hw_version = hw_version;
		this.fw_version = fw_version;
		this.region_id = region_id;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the manufacturer
	 */
	public String getManufacturer() {
		return manufacturer;
	}

	/**
	 * @param manufacturer
	 *            the manufacturer to set
	 */
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model
	 *            the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the hw_version
	 */
	public String getHw_version() {
		return hw_version;
	}

	/**
	 * @param hw_version
	 *            the hw_version to set
	 */
	public void setHw_version(String hw_version) {
		this.hw_version = hw_version;
	}

	/**
	 * @return the fw_version
	 */
	public String getFw_version() {
		return fw_version;
	}

	/**
	 * @param fw_version
	 *            the fw_version to set
	 */
	public void setFw_version(String fw_version) {
		this.fw_version = fw_version;
	}

	/**
	 * @return the region_id
	 */
	public String getRegion() {
		return region_id;
	}

	/**
	 * @param region_id
	 *            the region_id to set
	 */
	public void setRegion(String region) {
		this.region_id = region;
	}
}
