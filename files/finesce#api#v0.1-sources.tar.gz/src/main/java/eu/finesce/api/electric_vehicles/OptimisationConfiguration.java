/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "optimisation_configuration")
public class OptimisationConfiguration {
	private String	id;
	private double	renewables_percentage;
	private double	energy_interconnect_percentage;
	private double	market_specific_percentage;
	private String	timeslot_id;
	private String	region_id;

	/**
	 * Creates an empty optimisation configuration report
	 */
	public OptimisationConfiguration() {
	}

	/**
	 * Creates a new optimisation configuration report
	 * 
	 * @param id
	 *            The id of the optimisation report
	 * @param renewables_percentage
	 *            The percentage of renewables optimised by the algorithm
	 *            applied
	 * @param energy_interconnect_percentage
	 *            The percentage of energy flows between regions which is
	 *            optimised by the algorithm applied
	 * @param market_specific_percentage
	 *            The percentage of energy by market requirements optimised by
	 *            the algorithm applied
	 * @param timeslot_id
	 *            The id of the timelslot
	 * @param region_id
	 *            The id of the region
	 */
	public OptimisationConfiguration(String id, double renewables_percentage, double energy_interconnect_percentage, double market_specific_percentage, String timeslot_id, String region_id) {
		this.id = id;
		this.renewables_percentage = renewables_percentage;
		this.energy_interconnect_percentage = energy_interconnect_percentage;
		this.market_specific_percentage = market_specific_percentage;
		this.timeslot_id = timeslot_id;
		this.region_id = region_id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getRenewables_percentage() {
		return renewables_percentage;
	}

	public void setRenewables_percentage(double renewables_percentage) {
		this.renewables_percentage = renewables_percentage;
	}

	public double getEnergy_interconnect_percentage() {
		return energy_interconnect_percentage;
	}

	public void setEnergy_interconnect_percentage(double energy_interconnect_percentage) {
		this.energy_interconnect_percentage = energy_interconnect_percentage;
	}

	public double getMarket_specific_percentage() {
		return market_specific_percentage;
	}

	public void setMarket_specific_percentage(double market_specific_percentage) {
		this.market_specific_percentage = market_specific_percentage;
	}

	public String getTimeslot_id() {
		return timeslot_id;
	}

	public void setTimeslot_id(String timeslot_id) {
		this.timeslot_id = timeslot_id;
	}

	public String getRegion_id() {
		return region_id;
	}

	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}

}
