/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.buildings.reports;

import java.util.ArrayList;
import java.util.List;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.buildings.BuildingZone;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class BuildingZonesReport extends FinesceApi {

	private List<BuildingZone>	building_zones;

	/**
	 * Creates an empty building zones report
	 */
	public BuildingZonesReport() {
		super();
		this.building_zones = new ArrayList<>();
	}

	/**
	 * Creates an empty building zones report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public BuildingZonesReport(Metadata metadata) {
		super(metadata);
		this.building_zones = new ArrayList<>();
	}

	/**
	 * Creates an empty building zones report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public BuildingZonesReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.building_zones = new ArrayList<>();
	}

	/**
	 * Creates an empty building zones report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public BuildingZonesReport(String api_version, String trial) {
		super(api_version, trial);
		this.building_zones = new ArrayList<>();
	}

	/**
	 * Adds a new building zone to the report
	 * 
	 * @param bz
	 *            The id of the zone
	 * @return The list index of the building zone inserted
	 */
	public int add(BuildingZone bz) {
		this.getBuilding_zones().add(bz);
		return this.getBuilding_zones().size() - 1;
	}

	public List<BuildingZone> getBuilding_zones() {
		return building_zones;
	}

	public void setBuilding_zones(List<BuildingZone> building_zones) {
		this.building_zones = building_zones;
	}

}
