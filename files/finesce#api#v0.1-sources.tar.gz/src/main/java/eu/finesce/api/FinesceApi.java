/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class FinesceApi {
	private Metadata	metadata;

	public FinesceApi() {
	}

	/**
	 * Creates a Finesce API object
	 * 
	 * @param metadata
	 *            The metadata of the object
	 */
	public FinesceApi(Metadata metadata) {
		this.metadata = metadata;
	}

	/**
	 * Creates a Finesce API object
	 * 
	 * @param api_version
	 *            The version of the api used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The creation time of the report (in ISO 8601 format)
	 * @param updated
	 *            The update time of the report (in ISO 8601 format)
	 */
	public FinesceApi(String api_version, String trial, String created, String updated) {
		this.metadata = new Metadata(api_version, trial, created, updated);
	}

	/**
	 * Creates a new Finesce API object
	 * 
	 * @param api_version
	 *            The version of the api used
	 * @param trial
	 *            The trial ID
	 */
	public FinesceApi(String api_version, String trial) {
		this.metadata = new Metadata(api_version, trial, Utilities.now(), Utilities.now());
	}

	public Metadata getMetadata() {
		return metadata;
	}

	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}

}
