/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.external_information;

import eu.finesce.api.generic.Location;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "event")
public class SocialEvent {
	private Location	location;
	private String		type;
	private String		significance;
	private String		event_time;
	private String		register_time;

	public SocialEvent(Location location, String significance, String eventTime, String type, String storeTime) {
		this.location = location;
		this.significance = significance;
		this.event_time = eventTime;
		this.type = type;
		this.register_time = storeTime;
	}

	public SocialEvent() {
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getSignificance() {
		return significance;
	}

	public void setSignificance(String significance) {
		this.significance = significance;
	}

	public String getEventTime() {
		return event_time;
	}

	public void setEventTime(String eventTime) {
		this.event_time = eventTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStoreTime() {
		return register_time;
	}

	public void setStoreTime(String storeTime) {
		this.register_time = storeTime;
	}
}
