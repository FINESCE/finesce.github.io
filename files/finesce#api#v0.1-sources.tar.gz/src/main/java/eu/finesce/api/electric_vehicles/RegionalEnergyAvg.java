/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com> The regional aggregated
 *         energy being used by all electric vehicles in a region.
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "regional_energy_average")
public class RegionalEnergyAvg {

	private String	id;
	private double	max_possible_energy;
	private double	current_energy;
	private String	region_id;

	/**
	 * Creates an empty report regarding the regional aggregated energy being
	 * used by all ev in a region
	 */
	public RegionalEnergyAvg() {
	}

	/**
	 * Creates a new report regarding the regional aggregated energy being used
	 * by all ev in a region
	 * 
	 * @param id
	 *            The id of the report
	 * @param max_possible_energy
	 *            Maximum energy (in kWh) that could be used
	 * @param current_energy
	 *            Current energy (in kWh) being used
	 * @param region_id
	 *            The id of the region
	 */
	public RegionalEnergyAvg(String id, double max_possible_energy, double current_energy, String region_id) {
		super();
		this.id = id;
		this.max_possible_energy = max_possible_energy;
		this.current_energy = current_energy;
		this.region_id = region_id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getMax_possible_energy() {
		return max_possible_energy;
	}

	public void setMax_possible_energy(double max_possible_energy) {
		this.max_possible_energy = max_possible_energy;
	}

	public double getCurrent_energy() {
		return current_energy;
	}

	public void setCurrent_energy(double current_energy) {
		this.current_energy = current_energy;
	}

	public String getRegion_id() {
		return region_id;
	}

	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}

}
