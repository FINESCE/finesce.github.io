/*
 * Copyright 2014 Artemis Voulkidis <voulkidis@synelixis.com>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.pricing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "price")
public class Price {
	private String	id;
	private String	location_name;
	private String	start_time;
	private String	end_time;
	private String	currency;
	private String	electricity_price;
	private String	heating_price;
	private String	heating_offset;

	public Price() {
	}

	public Price(String id, String locationName, String startTime, String endTime, String currency, String electricityPrice, String heatingPrice, String heatingOffset) {
		this.id = id;
		this.location_name = locationName;
		this.start_time = startTime;
		this.end_time = endTime;
		this.currency = currency;
		this.electricity_price = electricityPrice;
		this.heating_price = heatingPrice;
		this.heating_offset = heatingOffset;
	}

	public String getIdentifier() {
		return id;
	}

	public void setIdentifier(String identifier) {
		this.id = identifier;
	}

	public String getLocationName() {
		return location_name;
	}

	public void setLocationName(String locationName) {
		this.location_name = locationName;
	}

	public String getStartTime() {
		return start_time;
	}

	public void setStartTime(String startTime) {
		this.start_time = startTime;
	}

	public String getEndTime() {
		return end_time;
	}

	public void setEndTime(String endTime) {
		this.end_time = endTime;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getElectricityPrice() {
		return electricity_price;
	}

	public void setElectricityPrice(String electricityPrice) {
		this.electricity_price = electricityPrice;
	}

	public String getHeatingPrice() {
		return heating_price;
	}

	public void setHeatingPrice(String heatingPrice) {
		this.heating_price = heatingPrice;
	}

	public String getHeatingOffset() {
		return heating_offset;
	}

	public void setHeatingOffset(String heatingOffset) {
		this.heating_offset = heatingOffset;
	}

}
