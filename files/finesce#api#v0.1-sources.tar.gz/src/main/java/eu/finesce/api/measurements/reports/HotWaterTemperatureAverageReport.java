/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.measurements.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;

import eu.finesce.api.measurements.types.HotWaterTemperatureAverage;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "hot_water_temperature_average report")
public class HotWaterTemperatureAverageReport extends FinesceApi {

	@XmlElementWrapper(name = "measurements")
	@XmlElement(name = "value")
	private List<HotWaterTemperatureAverage>	values;

	/**
	 * Creates an empty hot_water_temperature_average report
	 */
	public HotWaterTemperatureAverageReport() {
		this.values = new ArrayList<>();
	}

	/**
	 * Creates a new hot_water_temperature_average report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public HotWaterTemperatureAverageReport(Metadata metadata) {
		super(metadata);
		this.values = new ArrayList<>();
	}

	/**
	 * Creates a new hot_water_temperature_average report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public HotWaterTemperatureAverageReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.values = new ArrayList<>();
	}

	/**
	 * Creates a new hot_water_temperature_average report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public HotWaterTemperatureAverageReport(String api_version, String trial) {
		super(api_version, trial);
		this.values = new ArrayList<>();
	}

	/**
	 * Adds a HotWaterTemperatureAverage value to the report
	 * 
	 * @param hot_water_temperature_average
	 *            The HotWaterTemperatureAverage object to add
	 * @return The index of the HotWaterTemperatureAverage object added
	 */
	public int add(HotWaterTemperatureAverage hot_water_temperature_average) {
		this.getValues().add(hot_water_temperature_average);
		return this.getValues().size();
	}

	public List<HotWaterTemperatureAverage> getValues() {
		return values;
	}

	public void setValues(List<HotWaterTemperatureAverage> hot_water_temperature_average) {
		this.values = hot_water_temperature_average;
	}
}
