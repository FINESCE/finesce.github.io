package eu.finesce.api.demand_response;

public class IPAction extends DemandResponseAction {

	private String	offer;

	public IPAction() {
		super();
		setOffer("-");
	}

	public IPAction(String target, String type, String value, String start_time, String end_time, String offer) {
		super(target, type, value, start_time, end_time);
		this.offer = offer;
	}

	public IPAction(String target, String type, String value, String start_time, String end_time) {
		super(target, type, value, start_time, end_time);
		setOffer("-");
	}

	public String getOffer() {
		return offer;
	}

	public void setOffer(String offer) {
		this.offer = offer;
	}
}
