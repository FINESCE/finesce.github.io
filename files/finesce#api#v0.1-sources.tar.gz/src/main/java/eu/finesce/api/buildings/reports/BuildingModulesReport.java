package eu.finesce.api.buildings.reports;

import java.util.ArrayList;
import java.util.List;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;

public class BuildingModulesReport extends FinesceApi {

	private List<String>	modules;

	public BuildingModulesReport() {
		modules = new ArrayList<String>();
	}

	public BuildingModulesReport(Metadata metadata) {
		super(metadata);
		modules = new ArrayList<String>();
	}

	public BuildingModulesReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		modules = new ArrayList<String>();
	}

	public BuildingModulesReport(String api_version, String trial) {
		super(api_version, trial);
		modules = new ArrayList<String>();
	}

	public int add(String e) {
		getModules().add(e);
		return getModules().size() - 1;
	}

	public List<String> getModules() {
		if (modules == null) {
			modules = new ArrayList<String>();
		}
		return modules;
	}

	public void setModules(List<String> modules) {
		this.modules = modules;
	}

}
