/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.smart_factory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "machine")
public class MachineOverview {

	private String	id;
	private String	name;
	private String	process;
	private String	plc;
	private String	monitor;
	private int		resolution;
	private String	res_unit;
	private boolean	is_cumulative;
	private long	measurement;
	private String	measurement_unit;
	private String	status;

	/**
	 * Creates an empty machine representation
	 */
	public MachineOverview() {
	}

	/**
	 * Creates an empty machine representation
	 * 
	 * @param id
	 *            The id of the machine.
	 * @param name
	 *            The name of the machine.
	 * @param process
	 *            The process the machine is handling.
	 * @param plc
	 *            The controller unit deployed in the machine
	 * @param monitor
	 *            The external device used to monitor the energy consumption of
	 *            the machine.
	 * @param resolution
	 *            The time interval of the measurements.
	 * @param res_unit
	 *            The unit of the @param resolution field.
	 * @param is_cumulative
	 *            Checks whether the consumption is cumulative or not.
	 * @param measurements
	 *            The value of the consumption measurements.
	 * @param measurement_unit
	 *            The measurements unit.
	 * @param status
	 *            The status of the machine.
	 */
	public MachineOverview(String id, String name, String process, String plc, String monitor, int resolution, String res_unit, boolean is_cumulative, long measurement, String measurement_unit, String status) {
		super();
		this.id = id;
		this.name = name;
		this.process = process;
		this.plc = plc;
		this.monitor = monitor;
		this.resolution = resolution;
		this.res_unit = res_unit;
		this.is_cumulative = is_cumulative;
		this.measurement = measurement;
		this.measurement_unit = measurement_unit;
		this.status = status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	public String getPlc() {
		return plc;
	}

	public void setPlc(String plc) {
		this.plc = plc;
	}

	public String getMonitor() {
		return monitor;
	}

	public void setMonitor(String monitor) {
		this.monitor = monitor;
	}

	public int getResolution() {
		return resolution;
	}

	public void setResolution(int resolution) {
		this.resolution = resolution;
	}

	public String getRes_unit() {
		return res_unit;
	}

	public void setRes_unit(String res_unit) {
		this.res_unit = res_unit;
	}

	public boolean isIs_cumulative() {
		return is_cumulative;
	}

	public void setIs_cumulative(boolean is_cumulative) {
		this.is_cumulative = is_cumulative;
	}

	public long getMeasurement() {
		return measurement;
	}

	public void setMeasurement(long measurement) {
		this.measurement = measurement;
	}

	public String getMeasurement_unit() {
		return measurement_unit;
	}

	public void setMeasurement_unit(String measurement_unit) {
		this.measurement_unit = measurement_unit;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
