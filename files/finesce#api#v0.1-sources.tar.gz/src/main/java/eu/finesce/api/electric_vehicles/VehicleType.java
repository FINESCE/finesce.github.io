/*
 * Copyright 2014 Artemis Voulkidis <voulkidis@synelixis.com>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.electric_vehicles;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ev_type")
public class VehicleType {
	private String	id;
	private String	brand;
	private String	manufacturer;
	private double	capacity;
	private int		max_range;
	private int		min_range;

	/**
	 * Creates an empty ev type
	 */
	public VehicleType() {
	}

	/**
	 * Creates a new ev type
	 * 
	 * @param id
	 *            The id of the ev type
	 * @param brand
	 *            The brand of the ev
	 * @param manufacturer
	 *            The manufacturer of the ev
	 * @param capacity
	 *            The battery capacity of the ev
	 * @param max_range
	 *            The maximum expected range (in km) of the ev
	 * @param min_range
	 *            The minimum expected range (in km) of the ev
	 */
	public VehicleType(String id, String brand, String manufacturer, double capacity, int max_range, int min_range) {
		this.id = id;
		this.brand = brand;
		this.manufacturer = manufacturer;
		this.capacity = capacity;
		this.max_range = max_range;
		this.min_range = min_range;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @param brand
	 *            the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * @return the manufacturer
	 */
	public String getManufacturer() {
		return manufacturer;
	}

	/**
	 * @param manufacturer
	 *            the manufacturer to set
	 */
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	/**
	 * @return the capacity
	 */
	public double getCapacity() {
		return capacity;
	}

	/**
	 * @param capacity
	 *            the capacity to set
	 */
	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}

	/**
	 * @return the max_range
	 */
	public int getMax_range() {
		return max_range;
	}

	/**
	 * @param max_range
	 *            the max_range to set
	 */
	public void setMax_range(int max_range) {
		this.max_range = max_range;
	}

	/**
	 * @return the min_range
	 */
	public int getMin_range() {
		return min_range;
	}

	/**
	 * @param min_range
	 *            the min_range to set
	 */
	public void setMin_range(int min_range) {
		this.min_range = min_range;
	}
}
