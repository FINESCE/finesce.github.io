/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.pricing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "price_location")
public class PriceLocation {

	private String	id;
	private String	name;
	private String	postcode;
	private String	description;
	private String	url;
	private String	price_region;
	private String	latitude;
	private String	longitude;
	private String	timezome;

	/**
	 * Creates an empty price_location
	 */
	public PriceLocation() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a new price_location
	 * 
	 * @param id
	 *            The id of the location
	 * @param name
	 *            The name of the location
	 * @param postcode
	 *            The postcode of the location
	 * @param description
	 *            Brief description of the location
	 * @param url
	 *            Link to the location webpage
	 * @param price_region
	 *            Link to correct price object
	 * @param latitude
	 *            Geographic latitude position for location
	 * @param longitude
	 *            Geographic longitude position for location
	 * @param timezome
	 *            The timezone of the location
	 */
	public PriceLocation(String id, String name, String postcode, String description, String url, String price_region, String latitude, String longitude, String timezome) {
		super();
		this.id = id;
		this.name = name;
		this.postcode = postcode;
		this.description = description;
		this.url = url;
		this.price_region = price_region;
		this.latitude = latitude;
		this.longitude = longitude;
		this.timezome = timezome;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPrice_region() {
		return price_region;
	}

	public void setPrice_region(String price_region) {
		this.price_region = price_region;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getTimezome() {
		return timezome;
	}

	public void setTimezome(String timezome) {
		this.timezome = timezome;
	}

}
