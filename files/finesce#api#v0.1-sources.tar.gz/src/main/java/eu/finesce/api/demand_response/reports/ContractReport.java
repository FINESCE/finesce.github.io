/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.demand_response.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.demand_response.Contract;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "contract_report")
public class ContractReport extends FinesceApi {

	@XmlElementWrapper(name = "contracts")
	@XmlElement(name = "contract")
	private List<Contract>	contracts;

	/**
	 * Creates an empty contracts report
	 */
	public ContractReport() {
		this.setList(new ArrayList<Contract>());
	}

	/**
	 * Creates an empty contracts report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public ContractReport(Metadata metadata) {
		super(metadata);
		this.setList(new ArrayList<Contract>());
	}

	/**
	 * Creates an empty contracts report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public ContractReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.setList(new ArrayList<Contract>());
	}

	/**
	 * Creates an empty contracts report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public ContractReport(String api_version, String trial) {
		super(api_version, trial);
		this.setList(new ArrayList<Contract>());
	}

	public List<Contract> getList() {
		return contracts;
	}

	public void setList(List<Contract> list) {
		this.contracts = list;
	}

	/**
	 * Adds a contract to the contracts of contracts
	 * 
	 * @param c
	 *            The contract to add
	 * @return The contracts index of the contract inserted
	 */
	public int add(Contract c) {
		if (this.getList() == null) {
			this.setList(new ArrayList<Contract>());
		}
		this.getList().add(c);
		return this.getList().size() - 1;
	}

}
