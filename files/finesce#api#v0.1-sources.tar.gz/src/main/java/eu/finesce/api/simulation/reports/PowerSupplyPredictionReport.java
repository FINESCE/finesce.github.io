/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.simulation.reports;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.simulation.PowerSupplyPrediction;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "power_supply_prediction_report")
public class PowerSupplyPredictionReport extends FinesceApi {

	private List<PowerSupplyPrediction>	predicted_values;

	/**
	 * Creates an empty power supply prediction report
	 */
	public PowerSupplyPredictionReport() {
		this.predicted_values = new ArrayList<>();
	}

	/**
	 * Creates an empty power supply prediction report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public PowerSupplyPredictionReport(Metadata metadata) {
		super(metadata);
		this.predicted_values = new ArrayList<>();
	}

	/**
	 * Creates an empty power supply prediction report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public PowerSupplyPredictionReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.predicted_values = new ArrayList<>();
	}

	/**
	 * Creates an empty power supply prediction report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public PowerSupplyPredictionReport(String api_version, String trial) {
		super(api_version, trial);
		this.predicted_values = new ArrayList<>();
	}

	/**
	 * Adds a power supply prediction value to the report
	 * 
	 * @param ec
	 *            The energy consumption object to add
	 * @return The index of the energy consumption object added
	 */
	public int add(PowerSupplyPrediction pdm) {
		this.getPredicted_values().add(pdm);
		return this.getPredicted_values().size();
	}

	public List<PowerSupplyPrediction> getPredicted_values() {
		return predicted_values;
	}

	public void setPredicted_values(List<PowerSupplyPrediction> predicted_values) {
		this.predicted_values = predicted_values;
	}
}
