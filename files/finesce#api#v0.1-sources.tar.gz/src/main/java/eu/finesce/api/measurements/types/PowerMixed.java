package eu.finesce.api.measurements.types;

import eu.finesce.api.generic.MeasurementType;

public class PowerMixed extends MeasurementType {

	public PowerMixed() {
		super();
		super.setId(null);
		super.setName("PowerMixed");
		super.setDescription("Total power produced/consumed");
		super.setType("Power");
		super.setUnit("W");
	}

	public PowerMixed(String id, String name, String description, String type, String unit) {
		super(id, name, description, type, unit);
	}

}
