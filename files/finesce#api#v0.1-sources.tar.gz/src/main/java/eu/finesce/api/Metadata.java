/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Metadata {
	private String	api_version;
	private String	trial;
	private String	created;
	private String	updated;

	public Metadata() {
	}

	/**
	 * Creates a new Metadata object
	 * 
	 * @param api_version
	 *            The API version
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time when the report was created (in ISO8601 CET)
	 * @param updated
	 *            The time when the report was updated (in ISO8601 CET)
	 */
	public Metadata(String api_version, String trial, String created, String updated) {
		this.api_version = api_version;
		this.trial = trial;
		this.created = created;
		this.updated = updated;
	}

	/**
	 * Creates a new Metadata object
	 * 
	 * @param api_version
	 *            The API version
	 * @param trial
	 *            The trial ID
	 */
	public Metadata(String api_version, String trial) {
		this.api_version = api_version;
		this.trial = trial;
		this.created = Utilities.now();
		this.updated = Utilities.now();
	}

	public String getApi_version() {
		return api_version;
	}

	public void setApi_version(String api_version) {
		this.api_version = api_version;
	}

	public String getTrial() {
		return trial;
	}

	public void setTrial(String trial) {
		this.trial = trial;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getUpdated() {
		return updated;
	}

	public void setUpdated(String updated) {
		this.updated = updated;
	}

}
