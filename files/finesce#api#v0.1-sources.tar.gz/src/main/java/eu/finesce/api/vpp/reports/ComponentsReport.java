/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.vpp.reports;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import eu.finesce.api.vpp.Component;
import eu.finesce.api.vpp.ComponentTypes;
import eu.finesce.api.vpp.ConsumptionComponentContainer;
import eu.finesce.api.vpp.ProductionComponentContainer;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "components_report")
public class ComponentsReport extends FinesceApi {

	ConsumptionComponentContainer	consumption_components;
	ProductionComponentContainer	production_components;

	/**
	 * Creates an empty components report
	 */
	public ComponentsReport() {
		this.consumption_components = new ConsumptionComponentContainer();
		this.production_components = new ProductionComponentContainer();
	}

	/**
	 * Creates an empty components report
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public ComponentsReport(Metadata metadata) {
		super(metadata);
		this.consumption_components = new ConsumptionComponentContainer();
		this.production_components = new ProductionComponentContainer();
	}

	/**
	 * Creates an empty components report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 * @param created
	 *            The time the report was created (in ISO 8601 CET)
	 * @param updated
	 *            The time the report was updated (in ISO 8601 CET)
	 */
	public ComponentsReport(String api_version, String trial, String created, String updated) {
		super(api_version, trial, created, updated);
		this.consumption_components = new ConsumptionComponentContainer();
		this.production_components = new ProductionComponentContainer();
	}

	/**
	 * Creates an empty components report
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public ComponentsReport(String api_version, String trial) {
		super(api_version, trial);
		this.consumption_components = new ConsumptionComponentContainer();
		this.production_components = new ProductionComponentContainer();
	}

	/**
	 * Adds a component to the report
	 * 
	 * @param ct
	 *            The type of the component to add to
	 * @param c
	 *            The component to add
	 * @return The list index of the component added
	 */
	public int add(ComponentTypes ct, Component c) {
		int ret = -1;
		switch (ct) {
			case consumption:
				this.getConsumption_components().add(c);
				ret = this.getConsumption_components().getComponents().size() - 1;
				break;
			case production:
				this.getProduction_components().add(c);
				ret = this.getProduction_components().getComponents().size() - 1;
				break;
			default:
				break;
		}
		return ret;
	}

	public ConsumptionComponentContainer getConsumption_components() {
		return consumption_components;
	}

	public void setConsumption_components(ConsumptionComponentContainer consumption_components) {
		this.consumption_components = consumption_components;
	}

	public ProductionComponentContainer getProduction_components() {
		return production_components;
	}

	public void setProduction_components(ProductionComponentContainer production_components) {
		this.production_components = production_components;
	}
}
