/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.api.authentication;

import eu.finesce.api.FinesceApi;
import eu.finesce.api.Metadata;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "auth_response")
public class AuthResponse extends FinesceApi {
	private String	expires;
	private String	role;
	private String	token;
	private String	refresh_token;

	public AuthResponse() {
		super();
	}

	/**
	 * Creates an empty authentication response object
	 * 
	 * @param metadata
	 *            Metadata describing the API version used and the trial
	 */
	public AuthResponse(Metadata metadata) {
		super(metadata);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates an empty authentication response object
	 * 
	 * @param api_version
	 *            The API version used
	 * @param trial
	 *            The trial ID
	 */
	public AuthResponse(String api_version, String trial) {
		super(api_version, trial);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Creates a new authentication response object
	 * 
	 * @param expires
	 *            The date (iso8601 - UTC) the token expires
	 * @param role
	 *            The role of the user in the system
	 * @param token
	 *            The token assigned to the user
	 * @param refresh_token
	 *            Token to refresh the authentication token
	 */
	public AuthResponse(String expires, String role, String token, String refresh_token) {
		super();
		this.expires = expires;
		this.role = role;
		this.token = token;
		this.refresh_token = refresh_token;
	}

	public String getExpires() {
		return expires;
	}

	public void setExpires(String expires) {
		this.expires = expires;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}
}
