/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp4;

import eu.finesce.api.Utilities;
import eu.finesce.api.demand_response.Contract;
import eu.finesce.api.demand_response.ContractAction;
import eu.finesce.api.demand_response.DemandResponseAction;
import eu.finesce.api.demand_response.EnergyCosts;
import eu.finesce.api.demand_response.IPAction;
import eu.finesce.api.demand_response.IssueResolutionPlan;
import eu.finesce.api.demand_response.reports.ContractReport;
import eu.finesce.api.demand_response.reports.EnergyCostsReport;
import eu.finesce.api.demand_response.reports.IncentivePlanReport;
import eu.finesce.api.demand_response.reports.IssueResolutionPlanReport;
import eu.finesce.api.external_information.SocialEvent;
import eu.finesce.api.external_information.SocialEventsReport;
import eu.finesce.api.generic.Address;
import eu.finesce.api.generic.Location;
import eu.finesce.api.generic.Measurement;
import eu.finesce.api.generic.MeasurementReport;
import eu.finesce.api.generic.MeasurementType;
import eu.finesce.api.generic.MeasurementTypeIdentifiers;
import eu.finesce.api.generic.PredictionReport;
import eu.finesce.api.generic.Value;
import eu.finesce.api.measurements.EnergyConsumptionGridMeasurement;
import eu.finesce.api.measurements.EnergyConsumptionMeasurement;
import eu.finesce.api.measurements.EnergyProductionGridMeasurement;
import eu.finesce.api.measurements.EnergyProductionMeasurement;
import eu.finesce.api.measurements.PowerDemandGridMeasurement;
import eu.finesce.api.measurements.PowerDemandMeasurement;
import eu.finesce.api.measurements.PowerSupplyGridMeasurement;
import eu.finesce.api.measurements.PowerSupplyMeasurement;
import eu.finesce.api.measurements.reports.EnergyConsumptionReport;
import eu.finesce.api.measurements.reports.EnergyProductionReport;
import eu.finesce.api.measurements.reports.PowerDemandReport;
import eu.finesce.api.measurements.reports.PowerSupplyReport;
import eu.finesce.api.measurements.types.CloudCover;
import eu.finesce.api.measurements.types.EnergyConsumptionGrid;
import eu.finesce.api.measurements.types.EnergyConsumptionGridValue;
import eu.finesce.api.measurements.types.EnergyProductionGrid;
import eu.finesce.api.measurements.types.EnergyProductionGridValue;
import eu.finesce.api.measurements.types.MaxTemperature;
import eu.finesce.api.measurements.types.MinTemperature;
import eu.finesce.api.measurements.types.PowerDemandGrid;
import eu.finesce.api.measurements.types.PowerDemandGridValue;
import eu.finesce.api.measurements.types.PowerSupplyGrid;
import eu.finesce.api.measurements.types.SunriseTime;
import eu.finesce.api.measurements.types.SunsetTime;
import eu.finesce.api.measurements.types.Temperature;
import eu.finesce.api.measurements.types.WindSpeed;
import eu.finesce.api.metering.Meter;
import eu.finesce.api.metering.MetersReport;
import eu.finesce.api.regional.reports.SectorsReport;
import eu.finesce.api.simulation.PowerDemandPrediction;
import eu.finesce.api.simulation.PowerSupplyPrediction;
import eu.finesce.api.simulation.reports.PowerDemandPredictionReport;
import eu.finesce.api.simulation.reports.PowerSupplyPredictionReport;
import eu.finesce.api.weather.WeatherAvailableOptions;
import eu.finesce.api.weather.WeatherDetails;
import eu.finesce.trials.wp4.HistLoadData;
import eu.finesce.trials.wp4.HistLoadDataList;
import eu.finesce.trials.wp4.HistMeterData;
import eu.finesce.trials.wp4.HistMeterDataList;
import eu.finesce.trials.wp4.HistSocialEvent;
import eu.finesce.trials.wp4.HistSocialEventList;
import eu.finesce.trials.wp4.IncentivePlan;
import eu.finesce.trials.wp4.IncentivePlanList;
import eu.finesce.trials.wp4.IssueResolutionPlanData;
import eu.finesce.trials.wp4.IssueResolutionPlanDataList;
import eu.finesce.trials.wp4.LoadPrediction;
import eu.finesce.trials.wp4.MeterDetails;
import eu.finesce.trials.wp4.MeterDetailsList;
import eu.finesce.trials.wp4.Sector;
import eu.finesce.trials.wp4.SectorList;
import eu.finesce.trials.wp4.WeatherData;
import eu.finesce.trials.wp4.WeatherDataList;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.camel.Converter;
import org.apache.commons.logging.Log;

import scala.Boolean;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialService {

	public TrialService() {

	}

	/**
	 * Presents the available options for the weather report
	 * 
	 * @return The available weather report options
	 */
	public WeatherAvailableOptions weatherAvailableOptions() {
		WeatherAvailableOptions wao = new WeatherAvailableOptions(Desc.API_VERSION, Desc.NAME);
		wao.add(new Temperature());
		wao.add(new MaxTemperature());
		wao.add(new MinTemperature());
		wao.add(new CloudCover());
		wao.add(new WindSpeed());
		wao.add(new SunriseTime());
		wao.add(new SunsetTime());
		return wao;
	}

	/**
	 * Converts a WeatherData object (FINESCE-WP4) into a FINESCE API compatible
	 * one
	 * 
	 * @param weather
	 *            The weather forecast to parse
	 * @return The FINESCE API representation of the weather report
	 */
	@Converter
	public WeatherDetails weather(WeatherData weather) {

		WeatherDetails wd = new WeatherDetails(Desc.API_VERSION, Desc.NAME);
		wd.add(new Measurement<Double>(new Temperature()));
		wd.add(new Measurement<Double>(new MaxTemperature()));
		wd.add(new Measurement<Double>(new MinTemperature()));
		wd.add(new Measurement<Double>(new CloudCover()));
		wd.add(new Measurement<Double>(new WindSpeed()));
		wd.add(new Measurement<String>(new SunriseTime()));
		wd.add(new Measurement<String>(new SunsetTime()));

		if (weather != null && weather.getWeatherdataList() != null) {
			for (WeatherDataList weatherdataList : weather.getWeatherdataList()) {
				wd.add(0, new Value<Double>(Utilities.dateFromSeconds(weatherTime2Long(weatherdataList.getWeatherDateTime())), weatherdataList.getTemperature()));
				wd.add(1, new Value<Double>(Utilities.dateFromSeconds(weatherTime2Long(weatherdataList.getWeatherDateTime())), weatherdataList.getTemperatureMax()));
				wd.add(2, new Value<Double>(Utilities.dateFromSeconds(weatherTime2Long(weatherdataList.getWeatherDateTime())), weatherdataList.getTemperatureMin()));
				wd.add(3, new Value<Double>(Utilities.dateFromSeconds(weatherTime2Long(weatherdataList.getWeatherDateTime())), weatherdataList.getCloudCover()));
				wd.add(4, new Value<Double>(Utilities.dateFromSeconds(weatherTime2Long(weatherdataList.getWeatherDateTime())), weatherdataList.getWindSpeed()));
				wd.add(5, new Value<String>(Utilities.dateFromSeconds(weatherTime2Long(weatherdataList.getWeatherDateTime())), Utilities.dateFromSeconds(weatherdataList.getDailySunriseTime())));
				wd.add(6, new Value<String>(Utilities.dateFromSeconds(weatherTime2Long(weatherdataList.getWeatherDateTime())), Utilities.dateFromSeconds(weatherdataList.getDailySunsetTime())));
			}
		}
		return wd;
	}

	/**
	 * Gets a weather forecast for a specific forecast type (e.g. temperature)
	 * 
	 * @param weather
	 *            The WeatherData object (FINESCE WP4) to transform
	 * @param identifier
	 *            The type of the forecast
	 * @return
	 */
	@Converter
	public WeatherDetails weather_single_descriptor(WeatherData weather, String identifier) {
		WeatherAvailableOptions wao = weatherAvailableOptions();
		WeatherDetails wd = new WeatherDetails(Desc.API_VERSION, Desc.NAME);
		MeasurementType mt = null;
		for (int i = 0; i < wao.getDescriptors().size(); i++) {
			MeasurementType type = wao.getDescriptors().get(i);
			if ((type.getName() != null && type.getName().equalsIgnoreCase(identifier)) || (type.getId() != null && type.getId().equalsIgnoreCase(identifier))) {
				try {
					mt = type.getClass().newInstance();
				} catch (InstantiationException e) {
					e.printStackTrace();
					return wd;
				} catch (IllegalAccessException e) {
					e.printStackTrace();
					return wd;
				}
				break;
			}
		}
		if (mt == null) {
			return wd;
		}
		wd.add(new Measurement<Double>(mt));
		WeatherDetails parsedWeather = weather(weather);
		if (parsedWeather.getWeather_data() != null) {
			for (int i = 0; i < parsedWeather.getWeather_data().size(); i++) {
				if ((parsedWeather.getWeather_data().get(i).getType() != null && parsedWeather.getWeather_data().get(i).getType().equalsIgnoreCase(identifier))) {
					wd.getWeather_data().get(0).getValues().addAll(parsedWeather.getWeather_data().get(i).getValues());
				}
			}
		}
		return wd;
	}

	/**
	 * Converts a HistSocialEvent object (FINESCE-WP4) into a FINESCE API
	 * compatible one
	 * 
	 * @param socialEvents
	 *            The list of social events to parse
	 * @return The FINESCE API representation of the social events
	 */
	@Converter
	public SocialEventsReport social(HistSocialEvent socialEvents) {
		SocialEventsReport ses = new SocialEventsReport(Desc.API_VERSION, Desc.NAME);
		if (socialEvents.getSocialeventList() != null) {
			for (HistSocialEventList socialEvent : socialEvents.getSocialeventList()) {
				// Prepare a SocialEvent
				SocialEvent se = new SocialEvent();

				// Specifc for WP4
				Address address = new Address();
				address.setStreet_name(socialEvent.getSocialEventVenueAddress());

				// Fill the information in
				se.setLocation(new Location(socialEvent.getSocialEventVenueName(), null, address, null, socialEvent.getSocialEventLocationCoordLat(), socialEvent.getSocialEventLocationCoordLong()));
				se.setEventTime(Utilities.dateFromSeconds(socialTime2Long(socialEvent.getSocialEventDateTime())));
				se.setSignificance(socialEvent.getSocialEventImportancy().toString());
				se.setType(socialEvent.getSocialEventTypology());
				se.setStoreTime(Utilities.dateFromSeconds(socialEvent.getCurrentTime()));

				// Add to the list
				ses.add(se);
			}
		}
		return ses;
	}

	/**
	 * Converts a MeterDetails object (FINESCE-WP4) into a FINESCE API
	 * compatible one
	 * 
	 * @param meters
	 *            The list of meters to parse
	 * @return The FINESCE API representation of the meters
	 */
	@Converter
	public MetersReport metersReport(MeterDetails meters) {
		MetersReport ms = new MetersReport(Desc.API_VERSION, Desc.NAME);
		if (meters.getMeterdetailsList() != null) {
			for (MeterDetailsList meterdetailsList : meters.getMeterdetailsList()) {
				Meter meter = new Meter();
				meter.setCustomerId(meterdetailsList.getCustomerId());
				meter.setId(meterdetailsList.getNewMeter());
				meter.setSector(meterdetailsList.getSector());
				List<String> mti = new ArrayList<>();
				mti.add("EnergyConsumptionGrid");
				mti.add("EnergyProductionGrid");
				mti.add("PowerSupplyGrid");
				mti.add("PowerDemandGrid");
				meter.setMeteringCapabilities(mti);
				ms.add(meter);
			}
		}
		return ms;
	}

	/**
	 * Converts a Sector object (FINESCE-WP4) into a FINESCE API compatible one
	 * 
	 * @param sectors
	 *            The list of sectors to parse
	 * @return The FINESCE API representation of the sectors
	 */
	@Converter
	public SectorsReport sectors(Sector sectors) {
		SectorsReport ses = new SectorsReport(Desc.API_VERSION, Desc.NAME);
		for (SectorList sectorList : sectors.getSectorList()) {
			eu.finesce.api.regional.Sector _sector = null;
			for (eu.finesce.api.regional.Sector s : eu.finesce.api.regional.Sector.values()) {
				if (s.toString().equals(sectorList.getSector())) {
					_sector = s;
					break;
				}
			}
			if (_sector != null) {
				ses.add(_sector);
			}
		}
		return ses;
	}

	/**
	 * Converts a HistLoadData object (FINESCE WP4) refering to the energy
	 * consumption of a single user into a FINESCE API compatible one
	 * 
	 * @param data
	 *            The data to parse
	 * @return The EnergyConsumptionMeasurement report, according to the data
	 *         model defined by FINESCE API
	 */
	@SuppressWarnings("rawtypes")
	@Converter
	public MeasurementReport energyConsumption(HistLoadData data) {

		MeasurementReport<EnergyConsumptionGridMeasurement> mr = new MeasurementReport<>("EnergyConsumptionGrid", Desc.API_VERSION, Desc.NAME);
		EnergyConsumptionGridMeasurement ecgm = new EnergyConsumptionGridMeasurement();
		ecgm.setIdentifier(data.getSmType());
		ecgm.setType(new EnergyConsumptionGrid());
		ecgm.setEnd_time(Utilities.dateFromSeconds(data.getEndDateTime()));
		ecgm.setStart_time(Utilities.dateFromSeconds(data.getStartDateTime()));
		if (data.getLoaddataList() != null) {
			for (HistLoadDataList value : data.getLoaddataList()) {
				ecgm.add(new EnergyConsumptionGridValue(null, Utilities.dateFromSeconds(value.getLoadSampleDate()), value.getDownstreamActivePowerEEA()));
			}
		}
		mr.setMeasurements(ecgm);
		return mr;
	}

	/**
	 * Converts a HistLoadData object (FINESCE WP4) referring to the energy
	 * production of a single user into a FINESCE API compatible one
	 * 
	 * @param data
	 *            The data to parse
	 * @return The EnergyConsumptionMeasurement report, according to the data
	 *         model defined by FINESCE API
	 */
	@SuppressWarnings("rawtypes")
	@Converter
	public MeasurementReport energyProduction(HistLoadData data) {
		MeasurementReport<EnergyProductionGridMeasurement> mr = new MeasurementReport<>("EnergyProductionGrid", Desc.API_VERSION, Desc.NAME);
		EnergyProductionGridMeasurement ecgm = new EnergyProductionGridMeasurement();
		ecgm.setIdentifier(data.getSmType());
		ecgm.setType(new EnergyProductionGrid());
		ecgm.setEndTime(Utilities.dateFromSeconds(data.getEndDateTime()));
		ecgm.setStartTime(Utilities.dateFromSeconds(data.getStartDateTime()));
		if (data.getLoaddataList() != null) {
			for (HistLoadDataList value : data.getLoaddataList()) {
				ecgm.add(new EnergyProductionGridValue(null, Utilities.dateFromSeconds(value.getLoadSampleDate()), value.getUpstreamActivePowerEUA()));
			}
		}
		mr.setMeasurements(ecgm);
		return mr;
	}

	/**
	 * Converts a HistMeterData object (FINESCE WP4) referring to the power
	 * consumption of a single user into a FINESE API compatible one
	 * 
	 * @param hmd
	 *            The HistMeterData object to parse
	 * @return The Power Demand report, according to the data model defined by
	 *         FINESCE API
	 */
	@SuppressWarnings("rawtypes")
	@Converter
	public MeasurementReport powerDemand(HistMeterData hmd) {
		MeasurementReport<PowerDemandGridMeasurement> mr = new MeasurementReport<>("PowerDemandGrid", Desc.API_VERSION, Desc.NAME);
		PowerDemandGridMeasurement pd = new PowerDemandGridMeasurement();
		pd.setIdentifier(hmd.getSmType());
		pd.setType(new PowerDemandGrid());
		pd.setEndTime(Utilities.dateFromSeconds(Long.valueOf(hmd.getHorizonMeter().split("to")[1].trim())));
		pd.setStartTime(Utilities.dateFromSeconds(Long.valueOf(hmd.getHorizonMeter().split("to")[0].trim().split(" ")[1].trim())));
		if (hmd.getMeterdataList() != null) {
			for (HistMeterDataList hmdl : hmd.getMeterdataList()) {
				pd.add(new PowerDemandGridValue(null, Utilities.dateFromSeconds(hmdl.getMeterDate()), hmdl.getDownstream()));
			}
		}
		mr.setMeasurements(pd);
		return mr;
	}

	/**
	 * Coverts a HistMeterData object (FINESCE WP4) referring to the power
	 * consumption of a single user into a FINESE API compatible one
	 * 
	 * @param hmd
	 *            The HistMeterData object to parse
	 * @return The Power Demand report, according to the data model defined by
	 *         FINESCE API
	 */
	@SuppressWarnings("rawtypes")
	@Converter
	public MeasurementReport powerSupply(HistMeterData hmd) {
		MeasurementReport<PowerSupplyGridMeasurement> mr = new MeasurementReport<>("PowerSupplyGrid", Desc.API_VERSION, Desc.NAME);
		PowerSupplyGridMeasurement ps = new PowerSupplyGridMeasurement();
		ps.setIdentifier(hmd.getSmType());
		ps.setType(new PowerSupplyGrid());
		ps.setEndTime(Utilities.dateFromSeconds(Long.valueOf(hmd.getHorizonMeter().split("to")[1].trim())));
		ps.setStartTime(Utilities.dateFromSeconds(Long.valueOf(hmd.getHorizonMeter().split("to")[0].trim().split(" ")[1].trim())));
		if (hmd.getMeterdataList() != null) {
			for (HistMeterDataList hmdl : hmd.getMeterdataList()) {
				ps.add(new PowerDemandGridValue(null, Utilities.dateFromSeconds(hmdl.getMeterDate()), hmdl.getUpstream()));
			}
		}
		mr.setMeasurements(ps);
		return mr;
	}

	/**
	 * Converts a load prediction report of FINESCE WP4 into a FINESCE API
	 * compatible one
	 * 
	 * @param lp
	 *            The load prediction report to parse
	 * @return The load prediction report, according to the data model of the
	 *         FINESCE API
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Converter
	public PredictionReport powerDemandReport(LoadPrediction lp) {
		PredictionReport<PowerDemandGridMeasurement> pdrr = new PredictionReport("PowerDemandGrid", Desc.API_VERSION, Desc.NAME);
		long report_date = lp.getCurrentTime();
		if (lp.getMeterType() == null) {
			return pdrr;
		}
		pdrr.getPredictions().setIdentifier(lp.getMeterType());
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600), lp.getAfter1hDownstream()));
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600 * 3), lp.getAfter3hDownstream()));
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600 * 6), lp.getAfter6hDownstream()));
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600 * 12), lp.getAfter12hDownstream()));
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600 * 24), lp.getAfter24hDownstream()));
		return pdrr;
	}

	/**
	 * Converts a load prediction report of FINESCE WP4 into a FINESCE API
	 * compatible one
	 * 
	 * @param lp
	 *            The load prediction report to parse
	 * @return The load prediction report, according to the data model of the
	 *         FINESCE API
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Converter
	public PredictionReport powerSupplyReport(LoadPrediction lp) {
		PredictionReport<PowerSupplyGridMeasurement> pdrr = new PredictionReport("PowerSupplyGrid", Desc.API_VERSION, Desc.NAME);
		long report_date = lp.getCurrentTime();
		if (lp.getMeterType() == null) {
			return pdrr;
		}
		pdrr.getPredictions().setIdentifier(lp.getMeterType());
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600), lp.getAfter1hDownstream()));
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600 * 3), lp.getAfter3hDownstream()));
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600 * 6), lp.getAfter6hDownstream()));
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600 * 12), lp.getAfter12hDownstream()));
		pdrr.getPredictions().add(new Value<Double>(Utilities.dateFromSeconds(report_date + 3600 * 24), lp.getAfter24hDownstream()));
		return pdrr;
	}

	/**************************************************** Demand Response Related Converters ****************************************************/

	/**
	 * Converts an issue resolution plan list report of FINESCE WP4 into a
	 * FINESCE API compatible one
	 * 
	 * @param irpd
	 *            The issue resolution plan list to parse
	 * @return The issue resolution plan list report, according to the data
	 *         model of the FINESCE API
	 */
	@Converter
	public IssueResolutionPlanReport convertIRP(IssueResolutionPlanData irpd) {
		IssueResolutionPlanReport report = new IssueResolutionPlanReport(Desc.API_VERSION, Desc.NAME);
		if (irpd.getLoaddataList() == null) {
			return report;
		}
		for (int i = 0; i < irpd.getLoaddataList().size(); i++) {
			IssueResolutionPlanDataList cur_irp = irpd.getLoaddataList().get(i);
			IssueResolutionPlan irp = new IssueResolutionPlan();
			irp.setAggregator_notes(cur_irp.getNote_aggr());
			irp.setAuthor(cur_irp.getAuthor());
			irp.setAuthor_email(cur_irp.getAuthor_email());
			irp.setDso_notes(cur_irp.getNote_dso());
			irp.setId(cur_irp.getIrpID());
			irp.setSector(cur_irp.getSector());
			irp.setSnapshot_filename(cur_irp.getEcp_epp());
			irp.setState(cur_irp.getState());
			irp.setTime(Utilities.dateFromSeconds(cur_irp.getCurrentTime()));
			if (cur_irp.getAct1_end() != 0) {
				irp.add(new DemandResponseAction(cur_irp.getAct1_target(), cur_irp.getAct1_type(), String.valueOf(cur_irp.getAct1_value()), Utilities.dateFromSeconds(cur_irp.getAct1_start()),
						Utilities.dateFromSeconds(cur_irp.getAct1_end())));
			}
			if (cur_irp.getAct2_end() != 0) {
				irp.add(new DemandResponseAction(cur_irp.getAct2_target(), cur_irp.getAct2_type(), String.valueOf(cur_irp.getAct2_value()), Utilities.dateFromSeconds(cur_irp.getAct2_start()),
						Utilities.dateFromSeconds(cur_irp.getAct2_end())));
			}
			if (cur_irp.getAct3_end() != 0) {
				irp.add(new DemandResponseAction(cur_irp.getAct3_target(), cur_irp.getAct3_type(), String.valueOf(cur_irp.getAct3_value()), Utilities.dateFromSeconds(cur_irp.getAct3_start()),
						Utilities.dateFromSeconds(cur_irp.getAct3_end())));
			}
			if (cur_irp.getAct4_end() != 0) {
				irp.add(new DemandResponseAction(cur_irp.getAct4_target(), cur_irp.getAct4_type(), String.valueOf(cur_irp.getAct4_value()), Utilities.dateFromSeconds(cur_irp.getAct4_start()),
						Utilities.dateFromSeconds(cur_irp.getAct4_end())));
			}
			if (cur_irp.getAct5_end() != 0) {
				irp.add(new DemandResponseAction(cur_irp.getAct5_target(), cur_irp.getAct5_type(), String.valueOf(cur_irp.getAct5_value()), Utilities.dateFromSeconds(cur_irp.getAct5_start()),
						Utilities.dateFromSeconds(cur_irp.getAct5_end())));
			}
			report.add(irp);
		}
		return report;
	}

	/**
	 * Converts an incentive plan list report of FINESCE WP4 into a FINESCE API
	 * compatible one
	 * 
	 * @param irpd
	 *            The incentive plan list to parse
	 * @return The incentive plan list report, according to the data model of
	 *         the FINESCE API
	 */
	@Converter
	public IncentivePlanReport convertIP(IncentivePlan ipl) {
		IncentivePlanReport report = new IncentivePlanReport(Desc.API_VERSION, Desc.NAME);
		if (ipl.getLoaddataList() == null) {
			return report;
		}
		for (IncentivePlanList cur_ip : ipl.getLoaddataList()) {
			eu.finesce.api.demand_response.IncentivePlan ip = new eu.finesce.api.demand_response.IncentivePlan();
			ip.setAuthor(cur_ip.getAuthor());
			ip.setAuthor_email(cur_ip.getAuthor_email());
			ip.setCustomer_id(cur_ip.getCustomerId());
			ip.setDer_cost(cur_ip.getCostOfEnergyProducedByDERS());
			ip.setEnergy_cost(cur_ip.getEnergyCost());
			ip.setPrimary_energy_cost(cur_ip.getCostOfSystemTrasmissionPowerPlants());
			ip.setId(cur_ip.getIpId());
			ip.setIrp_id(cur_ip.getIrpId());
			ip.setMarket_regulator_notes(cur_ip.getNoteMarketRegulator());
			ip.setMeter_id(cur_ip.getMeterId());
			ip.setProfile_object_name(cur_ip.getCustomerProfileObjectName());
			ip.setRetailer_notes(cur_ip.getNoteRetailer());
			ip.setState(cur_ip.getState());
			ip.setTime(Utilities.dateFromSeconds(cur_ip.getCurrentTime()));
			if (cur_ip.getIp1_end() != 0) {
				ip.add(new IPAction(cur_ip.getIp1_target(), cur_ip.getIp1_type(), cur_ip.getIp1_value(), Utilities.dateFromSeconds(cur_ip.getIp1_start()), Utilities.dateFromSeconds(cur_ip.getIp1_end()), cur_ip.getIp1_offer()));
			}
			if (cur_ip.getIp2_end() != 0) {
				ip.add(new IPAction(cur_ip.getIp2_target(), cur_ip.getIp2_type(), cur_ip.getIp2_value(), Utilities.dateFromSeconds(cur_ip.getIp2_start()), Utilities.dateFromSeconds(cur_ip.getIp2_end()), cur_ip.getIp2_offer()));
			}
			if (cur_ip.getIp3_end() != 0) {
				ip.add(new IPAction(cur_ip.getIp3_target(), cur_ip.getIp3_type(), cur_ip.getIp3_value(), Utilities.dateFromSeconds(cur_ip.getIp3_start()), Utilities.dateFromSeconds(cur_ip.getIp3_end()), cur_ip.getIp3_offer()));
			}
			if (cur_ip.getIp4_end() != 0) {
				ip.add(new IPAction(cur_ip.getIp4_target(), cur_ip.getIp4_type(), cur_ip.getIp4_value(), Utilities.dateFromSeconds(cur_ip.getIp4_start()), Utilities.dateFromSeconds(cur_ip.getIp4_end()), cur_ip.getIp4_offer()));
			}
			if (cur_ip.getIp5_end() != 0) {
				ip.add(new IPAction(cur_ip.getIp5_target(), cur_ip.getIp5_type(), cur_ip.getIp5_value(), Utilities.dateFromSeconds(cur_ip.getIp5_start()), Utilities.dateFromSeconds(cur_ip.getIp5_end()), cur_ip.getIp5_offer()));
			}
			report.add(ip);
		}
		return report;
	}

	/**
	 * Converts an incentive plan list report of FINESCE WP4 into a FINESCE API
	 * compatible one
	 * 
	 * @param irpd
	 *            The incentive plan list to parse
	 * @return The incentive plan list report, according to the data model of
	 *         the FINESCE API
	 */
	@Converter
	public ContractReport convertContract(eu.finesce.trials.wp4.Contract c) {
		ContractReport report = new ContractReport(Desc.API_VERSION, Desc.NAME);
		Contract contract = new Contract();
		contract.setId(c.getContractID());
		contract.setCustomer_id(c.getCustomerID());
		contract.setIncentive_plan_id(c.getIncentivePlanID());
		contract.setState(c.getState());
		if (c.getIp1_end() != 0) {
			contract.add(new ContractAction(c.getIp1_planTarget(), c.getIp1_type(), String.valueOf(c.getIp1_value()), Utilities.dateFromSeconds(c.getIp1_start()), Utilities.dateFromSeconds(c.getIp1_end()), String.valueOf(c
					.getIp1_customerApproval())));
		}
		if (c.getIp2_end() != 0) {
			contract.add(new ContractAction(c.getIp2_planTarget(), c.getIp2_type(), String.valueOf(c.getIp2_value()), Utilities.dateFromSeconds(c.getIp2_start()), Utilities.dateFromSeconds(c.getIp2_end()), String.valueOf(c
					.getIp2_customerApproval())));
		}
		if (c.getIp3_end() != 0) {
			contract.add(new ContractAction(c.getIp3_planTarget(), c.getIp3_type(), String.valueOf(c.getIp3_value()), Utilities.dateFromSeconds(c.getIp3_start()), Utilities.dateFromSeconds(c.getIp3_end()), String.valueOf(c
					.getIp3_customerApproval())));
		}
		if (c.getIp4_end() != 0) {
			contract.add(new ContractAction(c.getIp4_planTarget(), c.getIp4_type(), String.valueOf(c.getIp4_value()), Utilities.dateFromSeconds(c.getIp4_start()), Utilities.dateFromSeconds(c.getIp4_end()), String.valueOf(c
					.getIp4_customerApproval())));
		}
		if (c.getIp5_end() != 0) {
			contract.add(new ContractAction(c.getIp5_planTarget(), c.getIp5_type(), String.valueOf(c.getIp5_value()), Utilities.dateFromSeconds(c.getIp5_start()), Utilities.dateFromSeconds(c.getIp5_end()), String.valueOf(c
					.getIp5_customerApproval())));
		}
		report.add(contract);
		return report;
	}

	@Converter
	public EnergyCostsReport convertEnergyCosts(eu.finesce.trials.wp4.ContractInformation ci) {
		EnergyCostsReport ecr = new EnergyCostsReport(Desc.API_VERSION, Desc.NAME);
		ecr.add(new EnergyCosts(ci.getCostOfEnergyProducedByDERS(), ci.getCostOfSystemTransmissionPowerPlants(), ci.getEnergyCost(), Utilities.dateFromSeconds(ci.getValidityStartDate()), Utilities.dateFromSeconds(ci.getValidityEndDate()),
				"kWh", "Euro"));
		return ecr;
	}

	/**
	 * Convert time from a YYYY-MM-DD HH:MM format to unix epoch time (seconds
	 * till 1971-01-01)
	 * 
	 * @param time
	 *            The time string to parse
	 * @return The long representation (in secs) of the time input
	 */
	private long weatherTime2Long(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
		Date date = null;
		try {
			date = sdf.parse(time);
		} catch (ParseException ex) {
		}
		return date.getTime() / 1000;
	}

	/**
	 * Convert time from a DD-MM-YYYY-HH:MM:SS format to unix epoch time
	 * (seconds till 1971-01-01)
	 * 
	 * @param time
	 *            The time string to parse
	 * @return The long representation (in secs) of the time input
	 */
	private long socialTime2Long(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-hh:mm:ss");
		Date date = null;
		try {
			date = sdf.parse(time);
		} catch (ParseException ex) {
		}
		return date.getTime() / 1000;
	}
}
