/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Converter;

import eu.finesce.api.Utilities;
import eu.finesce.api.authentication.AuthResponse;
import eu.finesce.api.generic.MeasurementReport;
import eu.finesce.api.generic.PredictionReport;
import eu.finesce.api.generic.Value;
import eu.finesce.api.measurements.EnergyConsumptionMeasurement;
import eu.finesce.api.measurements.EnergyProductionMeasurement;
import eu.finesce.api.smart_factory.MachineOverview;
import eu.finesce.api.smart_factory.MachineHistory;
import eu.finesce.api.smart_factory.reports.SingleMachineReport;
import eu.finesce.api.smart_factory.reports.MachinesReport;
import eu.finesce.api.vpp.Component;
import eu.finesce.api.vpp.ComponentData;
import eu.finesce.api.vpp.ComponentDataType;
import eu.finesce.api.vpp.ComponentTypes;
import eu.finesce.api.vpp.reports.ComponentDataReport;
import eu.finesce.api.vpp.reports.ComponentsReport;
import eu.finesce.trials.wp3.aachen.History;
import eu.finesce.trials.wp3.aachen.Machine;
import eu.finesce.trials.wp3.aachen.MachineBasic;
import eu.finesce.trials.wp3.aachen.MachineHistoryListItem;
import eu.finesce.trials.wp3.aachen.MachineWrapper;
import eu.finesce.trials.wp3.cologne.Authorization;
import eu.finesce.trials.wp3.cologne.ComponentDatum;
import eu.finesce.trials.wp3.cologne.Components;
import eu.finesce.trials.wp3.cologne.DataObj;
import eu.finesce.trials.wp3.cologne.SingleComponent;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialService {

	private enum COLOGNE_SERVICE_TYPES_URL {
		COMPONENTS, DATA
	}

	public TrialService() {

	}

	@Converter
	public AuthResponse tokens(Authorization auth) {
		AuthResponse ar = new AuthResponse(Desc.API_VERSION, Desc.NAME);
		ar.setExpires(Utilities.future(600));
		ar.setRole("read");
		ar.setToken(auth.getAuthorisation_id());
		return ar;
	}

	@Converter
	public SingleMachineReport machine(History wrapper) {
		SingleMachineReport mr = new SingleMachineReport(Desc.API_VERSION, Desc.NAME);
		MachineHistory mh = new MachineHistory();
		mh.setId(wrapper.getMachineDetails().getId());
		mh.setName(wrapper.getMachineDetails().getName());
		mh.setProcess(wrapper.getMachineDetails().getProcess());
		mh.setPlc(wrapper.getMachineDetails().getPlc());
		mh.setMonitor(wrapper.getMachineDetails().getMonitor());
		mh.setResolution(wrapper.getMachineDetails().getResolution());
		mh.setRes_unit(wrapper.getMachineDetails().getResolutionUnit());
		mh.setIs_cumulative(wrapper.getMachineDetails().getIsCumulative() == 1 ? true : false);
		for (MachineHistoryListItem l : wrapper.getHistory()) {
			mh.add(l.getTimestamp(), l.getStatus(), Long.valueOf((long) l.getEnergy()));
		}
		return mr;
	}

	@Converter
	public MachinesReport machines(Machine[] wrapper) {
		MachinesReport mr = new MachinesReport(Desc.API_VERSION, Desc.NAME);
		for (Machine m : wrapper) {
			mr.add(new MachineOverview(m.getId(), m.getName(), m.getProcess(), m.getPlc(), m.getMonitor(), m.getResolution(), m.getResolutionUnit(), (m.getIsCumulative() == 1 ? true : false), Long.valueOf((long) Math.floor(m
					.getConsumption())), m.getMeasurementUnit(), m.getStatus()));
		}
		return mr;
	}

	@Converter
	public ComponentsReport getComponentList(Components components) {
		ComponentsReport cr = new ComponentsReport(Desc.API_VERSION, Desc.NAME);
		for (SingleComponent sc : components.getConsumption()) {
			cr.add(ComponentTypes.consumption, new Component(sc.getAccess(), sc.getComponent(), convertCologneURL(sc.getUrl(), COLOGNE_SERVICE_TYPES_URL.COMPONENTS)));
		}
		for (SingleComponent sc : components.getGeneration()) {
			cr.add(ComponentTypes.production, new Component(sc.getAccess(), sc.getComponent(), convertCologneURL(sc.getUrl(), COLOGNE_SERVICE_TYPES_URL.COMPONENTS)));
		}
		return cr;
	}

	@Converter
	public ComponentDataReport getDates(eu.finesce.trials.wp3.cologne.ComponentData cd) {
		ComponentDataReport cdr = new ComponentDataReport(Desc.API_VERSION, Desc.NAME);
		if (cd.getCalculation() != null) {
			for (ComponentDatum _cd : cd.getCalculation()) {
				cdr.add(ComponentDataType.predictions, new ComponentData(convertCologneDate(_cd.getDate()), convertCologneURL(_cd.getUrl(), COLOGNE_SERVICE_TYPES_URL.DATA)));
			}
		}
		if (cd.getMeasurement() != null) {
			for (ComponentDatum _cd : cd.getMeasurement()) {
				cdr.add(ComponentDataType.measurements, new ComponentData(convertCologneDate(_cd.getDate()), convertCologneURL(_cd.getUrl(), COLOGNE_SERVICE_TYPES_URL.DATA)));
			}
		}
		return cdr;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MeasurementReport getVPPMeasurements(ComponentTypes comp_type, String date, DataObj data) throws ParseException {
		long base_date_in_millis = (new SimpleDateFormat("yyyyMMdd")).parse(date).getTime();
		MeasurementReport ret = null;
		switch (comp_type) {
			case consumption:
				ret = new MeasurementReport<EnergyConsumptionMeasurement>("EnergyConsumption", Desc.API_VERSION, Desc.NAME);
				ret.getMeasurements().setValues(convertCologneValues(base_date_in_millis, data.getData()));
				break;
			case production:
			case generation:
				ret = new MeasurementReport<EnergyProductionMeasurement>("EnergyProduction", Desc.API_VERSION, Desc.NAME);
				ret.getMeasurements().setValues(convertCologneValues(base_date_in_millis, data.getData()));
				break;
			default:
				break;
		}
		ret.getMeasurements().setStart_time(Utilities.dateFromMilliSeconds(base_date_in_millis));
		ret.getMeasurements().setEnd_time(Utilities.dateFromMilliSeconds(base_date_in_millis + 95 * 15 * 60 * 1000));
		return ret;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public PredictionReport getVPPPredictions(ComponentTypes comp_type, String date, DataObj data) throws ParseException {
		long base_date_in_millis = (new SimpleDateFormat("yyyyMMdd")).parse(date).getTime();
		PredictionReport ret = null;
		switch (comp_type) {
			case consumption:
				ret = new PredictionReport<EnergyConsumptionMeasurement>("EnergyConsumption", Desc.API_VERSION, Desc.NAME);
				ret.getPredictions().setValues(convertCologneValues(base_date_in_millis, data.getData()));
				break;
			case production:
			case generation:
				ret = new PredictionReport<EnergyProductionMeasurement>("EnergyProduction", Desc.API_VERSION, Desc.NAME);
				ret.getPredictions().setValues(convertCologneValues(base_date_in_millis, data.getData()));
				break;
			default:
				break;
		}
		ret.getPredictions().setStart_time(Utilities.dateFromMilliSeconds(base_date_in_millis));
		ret.getPredictions().setEnd_time(Utilities.dateFromMilliSeconds(base_date_in_millis + 95 * 15 * 60 * 1000));
		return ret;
	}

	// ///// Various Cologne-specific utilities ///////

	private String convertCologneDate(String date) {
		String ret = "";
		ret = date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6, 8);// +
																								// "T00:00:00+01:00";
		return ret;
	}

	private String convertCologneURL(String URL, COLOGNE_SERVICE_TYPES_URL service_type) {
		String ret = "https://130.206.82.22/finesce/api/v" + Desc.API_VERSION + "/" + Desc.NAME + "/vpp/";
		String[] url_tokens;
		switch (service_type) {
			case COMPONENTS:
				url_tokens = URL.split("/");
				String comp_type = url_tokens[url_tokens.length - 2];
				if (comp_type.equalsIgnoreCase("generation")) {
					comp_type = "production";
				}
				String comp_id = url_tokens[url_tokens.length - 1];
				ret += comp_type + "/" + comp_id + "/data";
				break;
			case DATA:
				url_tokens = URL.split("/");
				String data_comp_type = url_tokens[url_tokens.length - 4];
				if (data_comp_type.equalsIgnoreCase("generation")) {
					data_comp_type = "production";
				}
				String data_comp_id = url_tokens[url_tokens.length - 3];

				String data_comp_report_type = url_tokens[url_tokens.length - 2];
				if (data_comp_report_type.equalsIgnoreCase("calculation")) {
					data_comp_report_type = "predictions";
				} else if (data_comp_report_type.equalsIgnoreCase("measurement")) {
					data_comp_report_type = "measurements";
				}

				String data_comp_date = url_tokens[url_tokens.length - 1];
				data_comp_date = data_comp_date.substring(0, 4) + "-" + data_comp_date.substring(4, 6) + "-" + data_comp_date.substring(6, 8);

				ret += data_comp_type + "/" + data_comp_id + "/" + data_comp_report_type + "/" + data_comp_date;
				break;
			default:
				break;
		}
		return ret;
	}

	/**
	 * Converts values indicated as a string into normal list of FINESCE API
	 * values
	 * 
	 * @param date
	 *            The base date reference
	 * @param values
	 *            The values string
	 * @return The list of Value objects
	 */
	private List<Value<Double>> convertCologneValues(long date, String values) {
		ArrayList<Value<Double>> ret = new ArrayList<>();
		String tokenizer = ";";
		String[] tickers = null;
		for (String tuple : values.split(tokenizer)) {
			String[] tuples = tuple.split(",");
			if (tuples.length == 2) {
				String index = tuples[0];
				String c_value = tuples[1];
				if (index.equalsIgnoreCase("ticker")) {
					continue;
				}
				Value<Double> value = new Value<>(Utilities.dateFromMilliSeconds(date + Integer.valueOf(index) * 15 * 60 * 1000), Double.valueOf(c_value));
				ret.add(value);
			} else if (tuples.length > 2) {
				String index = tuples[0];
				if (index.equalsIgnoreCase("ticker")) {
					tickers = new String[tuples.length - 1];
				}
				for (int i = 1; i < tuples.length; i++) {
					if (index.equalsIgnoreCase("ticker")) {
						tickers[i - 1] = tuples[i];
						continue;
					}
					Value<Double> value = new Value<>(tickers[i - 1], Utilities.dateFromMilliSeconds(date + Integer.valueOf(index) * 15 * 60 * 1000), Double.valueOf(tuples[i]));
					ret.add(value);
				}
			}
		}
		return ret;
	}

}
