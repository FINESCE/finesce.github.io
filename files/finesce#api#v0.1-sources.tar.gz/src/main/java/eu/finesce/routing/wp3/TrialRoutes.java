/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp3;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http.HttpOperationFailedException;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

import eu.finesce.api.authentication.AuthRequest;
import eu.finesce.api.authentication.AuthResponse;
import eu.finesce.api.generic.MeasurementReport;
import eu.finesce.api.generic.PredictionReport;
import eu.finesce.api.smart_factory.reports.MachinesReport;
import eu.finesce.api.smart_factory.reports.SingleMachineReport;
import eu.finesce.api.vpp.reports.ComponentDataReport;
import eu.finesce.api.vpp.reports.ComponentsReport;
import eu.finesce.routing.FailureHTTPResponseProcessor;
import eu.finesce.trials.wp3.aachen.History;
import eu.finesce.trials.wp3.aachen.Machine;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialRoutes extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").bindingMode(RestBindingMode.auto).dataFormatProperty("prettyPrint", "true");

		onException(HttpOperationFailedException.class).handled(true).process(new FailureHTTPResponseProcessor());

		// TOKEN handling
		rest("/" + Desc.NAME + "/tokens").post().description("Retrieve authentication tokens").type(AuthRequest.class).outType(AuthResponse.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				AuthRequest auth = exchange.getIn().getBody(AuthRequest.class);
				if (auth == null || auth.getAuthorization_id() == null || auth.getPassword() == null) {
					auth = new AuthRequest("", "");
				}
				exchange.getOut().setHeader("authentication_id", auth.getAuthorization_id());
				exchange.getOut().setHeader("password", auth.getPassword());
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("Authentication-ID=${in.headers.authentication_id}&UserPassword=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false")).setHeader(Exchange.HTTP_METHOD, constant("POST"))
				.to(Desc.BASE_URL_COLOGNE + Desc.AUTH_URL_COLOGNE).unmarshal().json(JsonLibrary.Jackson, eu.finesce.trials.wp3.cologne.Authorization.class).to("bean:wp3Service?method=tokens").endRest();

		rest("/" + Desc.NAME + "/factory/equipment/machines")

		.get()
		.description("Provides the list of available machines of the smart factory.")
		.outType(MachinesReport.class)
		.route()
		.process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("Accept", "application/json");
			}
		})
		.to(Desc.BASE_URL_AACHEN + Desc.LIST_MACHINES_URL).unmarshal().json(JsonLibrary.Jackson, Machine[].class)
		.to("bean:wp3Service?method=machines").endRest()

		.get("{machine_id}")
			.description("Provides details related to a single machine. A valid {machine_id} can be found from the /factory/equipment/machines service.")
			.outType(SingleMachineReport.class)
			.route()
			.process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("Accept", "application/json");
				exchange.getOut().setHeader("id", exchange.getIn().getHeader("machine_id", String.class));
				}
			})
			.setHeader(Exchange.HTTP_QUERY, simple("mac=${in.headers.id}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
			.to(Desc.BASE_URL_AACHEN + Desc.LIST_MACHINES_URL).unmarshal().json(JsonLibrary.Jackson, History.class)
			.to("bean:wp3Service?method=machine").endRest();

		rest("/" + Desc.NAME + "/vpp")

				// Get the available components of the VPP
				.get("components")
				.description("Provides the list of available components of the VPP")
				.outType(ComponentsReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("authorisation_id", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("authorisation-id=${in.headers.authorisation_id}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL_COLOGNE + Desc.COMPONENTS_URL)
				.unmarshal()
				.json(JsonLibrary.Jackson, eu.finesce.trials.wp3.cologne.Components.class)
				.to("bean:wp3Service?method=getComponentList")
				.endRest()

				// Get the dates supported
				.get("{comp_type}/{comp_id}/data")
				.description("Gets the list of dates of available data for a component. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service.")
				.outType(ComponentDataReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("authorisation_id", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("comp_type", exchange.getIn().getHeader("comp_type", String.class));
						exchange.getOut().setHeader("comp_id", exchange.getIn().getHeader("comp_id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("authorisation-id=${in.headers.authorisation_id}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL_COLOGNE + "${in.headers.comp_type}/${in.headers.comp_id}/" + Desc.DATA_URL))
				.unmarshal()
				.json(JsonLibrary.Jackson, eu.finesce.trials.wp3.cologne.ComponentData.class)
				.to("bean:wp3Service?method=getDates")
				.endRest()

				// Get the predictions
				.get("{comp_type}/{comp_id}/predictions/{predictions_date}")
				.description(
						"Gets prediction data for component for a specified data and data type. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service. A valid {predictions_date} can be found from the /vpp/{comp_type}/{comp_id}/data service. ")
				.outType(PredictionReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("authorisation_id", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("comp_type", exchange.getIn().getHeader("comp_type", String.class).equals("production") ? "generation" : exchange.getIn().getHeader("comp_type", String.class));
						exchange.getOut().setHeader("comp_id", exchange.getIn().getHeader("comp_id", String.class));
						exchange.getOut().setHeader("predictions_date", exchange.getIn().getHeader("predictions_date", String.class).replace("-", ""));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("authorisation-id=${in.headers.authorisation_id}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL_COLOGNE + "${in.headers.comp_type}/${in.headers.comp_id}/calculation/${in.headers.predictions_date}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, eu.finesce.trials.wp3.cologne.DataObj.class)
				.to("bean:wp3Service?method=getVPPPredictions(${header.comp_type}, ${header.predictions_date}, ${body})")
				.endRest()

				// Get the measurements
				.get("{comp_type}/{comp_id}/measurements/{measurements_date}")
				.description(
						"Gets measurement data for component for a specified data and data type. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service. A valid {measurements_date} can be found from the /vpp/{comp_type}/{comp_id}/data service. ")
				.outType(MeasurementReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("authorisation_id", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("comp_type", exchange.getIn().getHeader("comp_type", String.class).equals("production") ? "generation" : exchange.getIn().getHeader("comp_type", String.class));
						exchange.getOut().setHeader("comp_id", exchange.getIn().getHeader("comp_id", String.class));
						exchange.getOut().setHeader("measurements_date", exchange.getIn().getHeader("measurements_date", String.class).replace("-", ""));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("authorisation-id=${in.headers.authorisation_id}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL_COLOGNE + "${in.headers.comp_type}/${in.headers.comp_id}/measurement/${in.headers.measurements_date}")).unmarshal().json(JsonLibrary.Jackson, eu.finesce.trials.wp3.cologne.DataObj.class)
				.to("bean:wp3Service?method=getVPPMeasurements(${header.comp_type}, ${header.measurements_date}, ${body})");
	}
}
