/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp2.madrid;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http.HttpOperationFailedException;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

import eu.finesce.api.Utilities;
import eu.finesce.api.buildings.reports.BuildingModulesReport;
import eu.finesce.api.buildings.reports.BuildingZonesReport;
import eu.finesce.api.generic.MeasurementReport;
import eu.finesce.api.weather.WeatherAvailableOptions;
import eu.finesce.api.weather.WeatherDetails;
import eu.finesce.routing.FailureHTTPResponseProcessor;
import eu.finesce.trials.wp2.madrid.CCEWrapper;
import eu.finesce.trials.wp2.madrid.MGWrapper;
import eu.finesce.trials.wp2.madrid.MeteoWrapper;
import eu.finesce.trials.wp2.madrid.WSNWrapper;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialRoutes extends RouteBuilder {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.camel.builder.RouteBuilder#configure()
	 */
	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").bindingMode(RestBindingMode.json_xml).dataFormatProperty("prettyPrint", "true");

		onException(HttpOperationFailedException.class).handled(true).process(new FailureHTTPResponseProcessor());

		// Weather Management
		rest("/" + Desc.NAME + "/weather")
				.get("{descriptor}/{from}/{to}")
				.description(
						"Provides weather reports for a specific timeperiod in the area of Madrid, considering a single weather descriptor (see /{version}/{trial}/weather/available_descriptors for the supported descriptor. 'Madrid' is the only trial site offering this service.")
				.outType(WeatherDetails.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("descriptor", getValidDescriptor(exchange.getIn().getHeader("descriptor", String.class)));
						exchange.getOut().setHeader("from", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("to", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("method=json&fecha_ini=${in.headers.from}&fecha_fin=${in.headers.to}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.WEATHER_URL + "/${in.headers.descriptor}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, MeteoWrapper.class)
				.to("bean:wp2MadridService?method=weather")
				.endRest()

				.get("{descriptor}/{from}/{to}/{number_of_measurements}")
				.description(
						"Provides weather reports for a specific timeperiod in the area of Madrid, considering a single weather descriptor (see /{version}/{trial}/weather/available_descriptors for the supported descriptor. 'Madrid' is the only trial site offering this service.")
				.outType(WeatherDetails.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("descriptor", getValidDescriptor(exchange.getIn().getHeader("descriptor", String.class)));
						exchange.getOut().setHeader("from", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("to", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
						exchange.getOut().setHeader("number_of_measurements", exchange.getIn().getHeader("number_of_measurements", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("method=json&fecha_ini=${in.headers.from}&fecha_fin=${in.headers.to}&last=${in.headers.number_of_measurements}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.WEATHER_URL + "/${in.headers.descriptor}")).unmarshal().json(JsonLibrary.Jackson, MeteoWrapper.class).to("bean:wp2MadridService?method=weather").endRest()

				.get("available_descriptors").description("Provides information regarding the available forecast descriptors of the trial infrastructure. 'Madrid' is the only trial site offering this service.")
				.outType(WeatherAvailableOptions.class).route().to("bean:wp2MadridService?method=weatherAvailableOptions");

		// Buildings Management
		rest("/" + Desc.NAME + "/buildings")

				.get("{id}/zones/{date}")
				.description("Provides information regarding the available zones of a specific building with id {id} at a date. 'Madrid' is the only trial site offering this service.")
				.outType(BuildingZonesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("date", Utilities.millisFromDateString(exchange.getIn().getHeader("date", String.class)) / 1000);
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("method=json&buildingid=${in.headers.id}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.WSN_URL + "/buildingzones"))
				.unmarshal()
				.json(JsonLibrary.Jackson, WSNWrapper.class)
				.to("bean:wp2MadridService?method=building_zones")
				.endRest()

				.get("{id}/zones/{zone_id}/{measurement_type}/{date}")
				.description(
						"Provides measurements of a certain type of a building zone. Valid {zone_id} values can be retrieved by invoking the /{version}/{trial}/buildings/{id}/zones/{date} service. Valid measurement types are PowerDemandGrid, EnergyConsumptionGrid, Temperature, RelativeHumidity, BatteryLevel. 'Madrid' is the only trial site offering this service.")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("zone_id", exchange.getIn().getHeader("zone_id", String.class));
						exchange.getOut().setHeader("measurement_type", getValidDescriptor(exchange.getIn().getHeader("measurement_type", String.class)));
						exchange.getOut().setHeader("date", Utilities.millisFromDateString(exchange.getIn().getHeader("date", String.class)) / 1000);
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("method=json&buildingid=${in.headers.id}&zoneid=${in.headers.zone_id}&fecha=${in.headers.date}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.WSN_URL + "/${in.headers.measurement_type}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, WSNWrapper.class)
				.to("bean:wp2MadridService?method=wsn_building_measurements")
				.endRest()

				.get("{id}/modules")
				.description("Provides the provides a list of devices or modules which status can be monitored by the Building Control Center.")
				.outType(BuildingModulesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("method=json&buildingid=${in.headers.id}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.BMS_URL + "/cceelements"))
				.unmarshal()
				.json(JsonLibrary.Jackson, CCEWrapper.class)
				.to("bean:wp2MadridService?method=building_modules")
				.endRest()

				.get("{id}/modules/{module_type}/{module_id}/status/{date}")
				.description(
						"Provides information about the status of a specific building module. The available building modules may be retrieved via the /{version}/{trial}/buildings/{id}/modules service. 'Madrid' is the only trial site offering this service.")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("module_type", exchange.getIn().getHeader("module_type", String.class));
						exchange.getOut().setHeader("module_id", exchange.getIn().getHeader("module_id", String.class));
						exchange.getOut().setHeader("date", Utilities.millisFromDateString(exchange.getIn().getHeader("date", String.class)) / 1000);
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("method=json&buildingid=${in.headers.id}&${in.headers.module_type}id=${in.headers.module_id}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.BMS_URL + "/${in.headers.module_type}status"))
				.unmarshal()
				.json(JsonLibrary.Jackson, CCEWrapper.class)
				.to("bean:wp2MadridService?method=building_modules_status")
				.endRest()

				.get("{id}/modules/inverter/*/PowerMixed/{date}")
				.description(
						"Provides measurements regarding the total power generated/consumed (mixed) from a module of a building. Currently, 'inverter' is the only module supported. 'Madrid' is the only trial site offering this service.")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("date", Utilities.millisFromDateString(exchange.getIn().getHeader("date", String.class)) / 1000);
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("method=json&buildingid=${in.headers.id}&fecha=${in.headers.date}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.MICROGRID_URL + "/invertertotalpower"))
				.unmarshal()
				.json(JsonLibrary.Jackson, MGWrapper.class)
				.to("bean:wp2MadridService?method=inverter_total_power")
				.endRest()

				.get("{id}/modules/pv/*/PowerSupply/{date}")
				.description(
						"Provides measurements regarding the total power generated/consumed (mixed) from a module of a building. Currently, 'inverter' is the only module supported. 'Madrid' is the only trial site offering this service.")
				.outType(MeasurementReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("module_id", exchange.getIn().getHeader("module_id", String.class));
						exchange.getOut().setHeader("building_id", exchange.getIn().getHeader("building_id", String.class));
						exchange.getOut().setHeader("date", Utilities.millisFromDateString(exchange.getIn().getHeader("date", String.class)) / 1000);
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("method=json&buildingid=${in.headers.id}&fecha=${in.headers.date}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.MICROGRID_URL + "/pvgenpower")).unmarshal().json(JsonLibrary.Jackson, MGWrapper.class).to("bean:wp2MadridService?method=pv_power_supply").endRest();
	}

	private String getValidDescriptor(String descriptor) {
		String ret = null;
		if (descriptor.equalsIgnoreCase("Temperature")) {
			ret = "temp";
		} else if (descriptor.equalsIgnoreCase("RelativeHumidity")) {
			ret = "humrel";
		} else if (descriptor.equalsIgnoreCase("CloudCover")) {
			ret = "cc";
		} else if (descriptor.equalsIgnoreCase("WindSpeed")) {
			ret = "modviento";
		} else if (descriptor.equalsIgnoreCase("WindDirection")) {
			ret = "dirviento";
		} else if (descriptor.equalsIgnoreCase("GlobalHorizontalIrradiance")) {
			ret = "irradiancia";
		} else if (descriptor.equalsIgnoreCase("PowerDemandGrid")) {
			ret = "activepower";
		} else if (descriptor.equalsIgnoreCase("EnergyConsumptionGrid")) {
			ret = "totalenergy";
		}
		return ret;
	}
}
