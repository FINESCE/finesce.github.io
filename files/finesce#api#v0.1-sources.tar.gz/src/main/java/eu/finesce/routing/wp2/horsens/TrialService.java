/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp2.horsens;

import org.apache.camel.Converter;

import eu.finesce.api.Utilities;
import eu.finesce.api.authentication.AuthResponse;
import eu.finesce.api.buildings.Building;
import eu.finesce.api.buildings.reports.Buildings;
import eu.finesce.api.electric_vehicles.Vehicle;
import eu.finesce.api.electric_vehicles.reports.VehiclesReport;
import eu.finesce.api.generic.Address;
import eu.finesce.api.generic.Measurement;
import eu.finesce.api.generic.MeasurementReport;
import eu.finesce.api.generic.MeasurementType;
import eu.finesce.api.generic.MeasurementTypesReport;
import eu.finesce.api.generic.Value;

import eu.finesce.trials.wp2.horsens.HorsensBuilding;
import eu.finesce.trials.wp2.horsens.HorsensBuildingsWrapper;
import eu.finesce.trials.wp2.horsens.HorsensMeasurementType;
import eu.finesce.trials.wp2.horsens.HorsensMeasurementTypesWrapper;
import eu.finesce.trials.wp2.horsens.HorsensMeasurementWrapper;
import eu.finesce.trials.wp2.horsens.HorsensValue;
import eu.finesce.trials.wp2.horsens.HorsensVehicle;
import eu.finesce.trials.wp2.horsens.HorsensVehiclesWrapper;
import eu.finesce.trials.wp2.horsens.OAuthentication;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialService {

	public TrialService() {

	}

	@Converter
	public AuthResponse tokens(OAuthentication oauth) {
		AuthResponse ar = new AuthResponse(Desc.API_VERSION, Desc.NAME);
		ar.setExpires(Utilities.future(oauth.getExpires_in() + 1));
		ar.setRole(oauth.getToken_type());
		ar.setRefresh_token(oauth.getRefresh_token());
		ar.setToken(oauth.getAccess_token());
		return ar;
	}

	@Converter
	public Buildings buildings(HorsensBuildingsWrapper wrapper) {
		Buildings ret = new Buildings(Desc.API_VERSION, Desc.NAME);
		for (HorsensBuilding h : wrapper.getBuildings()) {
			Building b = new Building();
			b.setId(h.getId());
			b.setType(h.getType());
			b.setAddress(new Address(h.getAddress().getStreet_name(), h.getAddress().getNumber(), h.getAddress().getCity(), h.getAddress().getProvince(), h.getAddress().getZip_code(), h.getAddress().getCountry()));
			b.setMeasurement_points(h.getMeasurement_points());
			if (b.getMeasurement_points().containsKey("$type")) {
				b.getMeasurement_points().remove("$type");
			}
			b.setRelated_entities_ids(h.getRelated_entities());
			if (b.getRelated_entities_ids().containsKey("$type")) {
				b.getRelated_entities_ids().remove("$type");
			}
			ret.add(b);
		}
		return ret;
	}

	@Converter
	public VehiclesReport vehicles(HorsensVehiclesWrapper wrapper) {
		VehiclesReport ret = new VehiclesReport(Desc.API_VERSION, Desc.NAME);
		for (HorsensVehicle h : wrapper.getVehicles()) {
			Vehicle v = new Vehicle();
			v.setId(h.getId());
			v.setType(h.getType());
			v.setMeasurement_points(h.getMeasurement_points());
			if (v.getMeasurement_points().containsKey("$type")) {
				v.getMeasurement_points().remove("$type");
			}
			v.setRelated_entities_ids(h.getRelated_entities());
			if (v.getRelated_entities_ids().containsKey("$type")) {
				v.getRelated_entities_ids().remove("$type");
			}
			ret.add(v);
		}
		return ret;
	}

	@Converter
	public MeasurementTypesReport measurement_types(HorsensMeasurementTypesWrapper wrapper) {
		MeasurementTypesReport mtr = new MeasurementTypesReport(Desc.API_VERSION, Desc.NAME);
		for (HorsensMeasurementType h : wrapper.getMeasurement_types()) {
			MeasurementType m = new MeasurementType() {
			};
			m.setDescription(h.getDescription());
			m.setId(h.getId());
			m.setName(h.getName());
			m.setType(h.getType());
			m.setUnit(h.getUnit());
			mtr.add(m);
		}
		return mtr;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Converter
	public MeasurementReport measurements(HorsensMeasurementWrapper wrapper) {
		MeasurementReport mr = new MeasurementReport<>();
		mr.setMeasurements(new Measurement<>());
		mr.getMeasurements().setType(wrapper.getMeasurements().getMeasurement_type());
		for (HorsensValue v : wrapper.getMeasurements().getValues()) {
			mr.getMeasurements().add(new Value(v.getId(), Utilities.fromZ(v.getDatetime()), v.getValue()));
		}
		return mr;
	}
}
