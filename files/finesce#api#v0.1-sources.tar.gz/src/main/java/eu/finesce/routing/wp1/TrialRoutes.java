/*
 * Copyright 2015 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp1;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http.HttpOperationFailedException;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

import eu.finesce.api.Utilities;
import eu.finesce.api.authentication.AuthRequest;
import eu.finesce.api.authentication.AuthResponse;
import eu.finesce.api.pricing.PriceReport;
import eu.finesce.api.pricing.reports.PriceLocationDataReport;
import eu.finesce.api.pricing.reports.PriceLocationDataValueReport;
import eu.finesce.api.pricing.reports.PriceLocationReport;
import eu.finesce.api.weather.WeatherAvailableOptions;
import eu.finesce.api.weather.WeatherDetails;
import eu.finesce.routing.FailureHTTPResponseProcessor;
import eu.finesce.trials.wp1.PriceListWrapper;
import eu.finesce.trials.wp1.WeatherWrapper;

import org.apache.commons.codec.binary.Base64;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialRoutes extends RouteBuilder {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.camel.builder.RouteBuilder#configure()
	 */
	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").bindingMode(RestBindingMode.auto).dataFormatProperty("prettyPrint", "true");

		onException(HttpOperationFailedException.class).handled(true).process(new FailureHTTPResponseProcessor());

		// TOKEN handling
		rest("/" + Desc.NAME + "/tokens").post().description("Retrieve authentication tokens").type(AuthRequest.class).outType(AuthResponse.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				AuthRequest auth = exchange.getIn().getBody(AuthRequest.class);
				if (auth == null || auth.getAuthorization_id() == null || auth.getPassword() == null) {
					auth = new AuthRequest("", "");
				}
				String authorization_code = new String(Base64.encodeBase64((auth.getAuthorization_id() + ":" + auth.getPassword()).getBytes()));
				AuthResponse response = new AuthResponse(Desc.API_VERSION, Desc.NAME);
				response.setExpires(null);
				response.setRefresh_token(null);
				response.setRole("read");
				response.setToken(authorization_code);
				exchange.getOut().setBody(response, AuthResponse.class);
			}
		}).endRest();

		// PriceReport
		rest("/" + Desc.NAME + "/prices")
				.get()
				.description("Allows a user to get information regarding the energy prices in a location")
				.outType(PriceReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Basic " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("$format=json&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.PRICES_URL)
				.unmarshal()
				.json(JsonLibrary.Jackson, PriceListWrapper.class)
				.to("bean:wp1Service?method=prices")
				.endRest()

				.get("/{name}")
				.description(
						"Allows a user to get information regarding the energy prices in a location. A valid {name} can be obtained by calling the /prices service. Currently, this is API response is hardcoded and will be updated when it is actually supported by the trial site.")
				.outType(PriceReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Basic " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("Accept", "application/json");
						exchange.getOut().setHeader("region_name", exchange.getIn().getHeader("name"));
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("$format=json&$filter=region eq '${in.headers.region_name}'&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.PRICES_URL)
				.unmarshal()
				.json(JsonLibrary.Jackson, PriceListWrapper.class)
				.to("bean:wp1Service?method=prices")
				.endRest()

				.get("/{from}/{to}")
				.description("Allows a user to get information regarding the energy prices regardless of location. Valid {from} and {to} values are expressed in ISO8601 format.")
				.outType(PriceReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Basic " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("from", date2date(exchange.getIn().getHeader("from", String.class)));
						exchange.getOut().setHeader("to", date2date(exchange.getIn().getHeader("to", String.class)));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("$format=json&$filter= dateTime gt '${in.headers.from}' and dateTime lt '${in.headers.to}'&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.PRICES_URL)
				.unmarshal()
				.json(JsonLibrary.Jackson, PriceListWrapper.class)
				.to("bean:wp1Service?method=prices")
				.endRest()

				.get("/{name}/{from}/{to}")
				.description(
						"Allows a user to get information regarding the energy prices in a location. A valid {name} can be obtained by calling the /prices service. Valid {from} and {to} values are expressed in ISO8601 format. Currently, this is API response is hardcoded and will be updated when it is actually supported by the trial site.")
				.outType(PriceReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Basic " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("from", date2date(exchange.getIn().getHeader("from", String.class)));
						exchange.getOut().setHeader("to", date2date(exchange.getIn().getHeader("to", String.class)));
						exchange.getOut().setHeader("name", exchange.getIn().getHeader("name", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("$format=json&$filter= dateTime gt '${in.headers.from}' and dateTime lt '${in.headers.to}'&$filter=region eq '${header.name}'&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.PRICES_URL)
				.unmarshal()
				.json(JsonLibrary.Jackson, PriceListWrapper.class)
				.to("bean:wp1Service?method=prices")
				.endRest()

				.get("/locations")
				.description("Allows a user to get information regarding the price locations available to the user. Currently, this is API response is hardcoded and will be updated when it is actually supported by the trial site.")
				.outType(PriceLocationReport.class)
				.route()
				.to("bean:wp1Service?method=getPriceLocations()")
				.endRest()

				.get("/locations/{name}")
				.description(
						"Allows a user to get information regarding a price location available to the user, based on the location name. A valid {name} can be obtained by calling the /prices/locations service. Currently, this is API response is hardcoded and will be updated when it is actually supported by the trial site.")
				.outType(PriceLocationReport.class)
				.route()
				.to("bean:wp1Service?method=getPriceLocations(${header.name})")
				.endRest()

				.get("/locations/data")
				.description(
						"Allows a user to get information regarding a data stream available for locations associated with the current user. Currently, this is API response is hardcoded and will be updated when it is actually supported by the trial site.")
				.outType(PriceLocationDataReport.class)
				.route()
				.to("bean:wp1Service?method=getPriceLocationsData()")
				.endRest()

				.get("/locations/data/{name}")
				.description(
						"Allows a user to get information regarding a data stream available for locations associated with the current user. A valid {name} can be obtained by calling the /prices/locations/data service. Currently, this is API response is hardcoded and will be updated when it is actually supported by the trial site.")
				.outType(PriceLocationDataReport.class)
				.route()
				.to("bean:wp1Service?method=getPriceLocationsData(${header.name})")
				.endRest()

				.get("/locations/data/{name}/values/{from}/{to}")
				.description(
						"Allows a user to get information regarding data stream values available for locations associated with the current user. A valid {name} can be obtained by calling the /prices/locations/data service. Valid {from} and {to} values are expressed in ISO8601 format. Currently, this is API response is hardcoded and will be updated when it is actually supported by the trial site.")
				.outType(PriceLocationDataValueReport.class).route().to("bean:wp1Service?method=getPriceLocationsDataValues(${header.name}, ${header.from}, ${header.to})").endRest();

		rest("/" + Desc.NAME + "/weather")

				.get("/{from}/{to}")
				.description("Provides weather reports for a specific timeperiod in the area of Terni")
				.outType(WeatherDetails.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Basic " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("from", date2date(exchange.getIn().getHeader("from", String.class)));
						exchange.getOut().setHeader("to", date2date(exchange.getIn().getHeader("to", String.class)));
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("$format=json&$filter= dateTime gt '${in.headers.from}' and dateTime lt '${in.headers.to}'&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.WEATHER_URL)
				.unmarshal()
				.json(JsonLibrary.Jackson, WeatherWrapper.class)
				.to("bean:wp1Service?method=weather_all")
				.endRest()

				.get("{descriptor}/{from}/{to}")
				.description("Provides weather reports for a specific timeperiod in the area of Terni, considering a single weather descriptor (see /weather/available_descriptor for the supported descriptor")
				.outType(WeatherDetails.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Basic " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("from", date2date(exchange.getIn().getHeader("from", String.class)));
						exchange.getOut().setHeader("to", date2date(exchange.getIn().getHeader("to", String.class)));
						exchange.getOut().setHeader("descriptor", getValidDescriptor(exchange.getIn().getHeader("descriptor", String.class)));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.setHeader(Exchange.HTTP_QUERY,
						simple("$format=json&$filter= dateTime gt '${in.headers.from}' and dateTime lt '${in.headers.to}'&$select=id,dateTime,${in.headers.descriptor}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.WEATHER_URL).unmarshal().json(JsonLibrary.Jackson, WeatherWrapper.class).to("bean:wp1Service?method=weather_single").endRest()

				.get("available_descriptors").description("Provides information regarding the available forecast descriptors of the specified trial infrastructure").outType(WeatherAvailableOptions.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Basic " + exchange.getIn().getHeader("x-auth-token"));
					}
				}).to("bean:wp1Service?method=weatherAvailableOptions").endRest();
	}

	private String date2date(String date) {
		return Utilities.dateFromMilliSeconds(Utilities.millisFromDateString(date)).substring(0, 19);
	}

	private String getValidDescriptor(String descriptor) {
		String ret = descriptor;
		if (descriptor.equalsIgnoreCase("temperature")) {
			ret = "outsideTemperature";
		} else if (descriptor.equalsIgnoreCase("cloudcover")) {
			ret = "cloudCoverage";
		} else if (descriptor.equalsIgnoreCase("precipitation")) {
			ret = "precipitation";
		} else if (descriptor.equalsIgnoreCase("windspeed")) {
			ret = "windSpeed";
		} else if (descriptor.equalsIgnoreCase("windDirection")) {
			ret = "windDirection";
		} else if (descriptor.equalsIgnoreCase("SunriseTime")) {
			ret = "sunRise";
		} else if (descriptor.equalsIgnoreCase("SunsetTime")) {
			ret = "sunSet";
		}
		return ret;
	}
}
