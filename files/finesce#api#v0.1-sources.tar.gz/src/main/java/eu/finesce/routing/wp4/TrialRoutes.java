/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp4;

import eu.finesce.api.Utilities;
import eu.finesce.api.authentication.AuthRequest;
import eu.finesce.api.authentication.AuthResponse;
import eu.finesce.api.demand_response.reports.ContractReport;
import eu.finesce.api.demand_response.reports.EnergyCostsReport;
import eu.finesce.api.demand_response.reports.IncentivePlanReport;
import eu.finesce.api.demand_response.reports.IssueResolutionPlanReport;
import eu.finesce.api.external_information.SocialEventsReport;
import eu.finesce.api.generic.MeasurementReport;
import eu.finesce.api.generic.PredictionReport;
import eu.finesce.api.metering.MetersReport;
import eu.finesce.api.regional.reports.SectorsReport;
import eu.finesce.api.weather.WeatherAvailableOptions;
import eu.finesce.api.weather.WeatherDetails;
import eu.finesce.routing.FailureHTTPResponseProcessor;
import eu.finesce.trials.wp4.WeatherData;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpOperationFailedException;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.commons.codec.binary.Base64;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialRoutes extends RouteBuilder {

	@Override
	public void configure() throws Exception {
//		 A rest interface to handle the weather services 
		restConfiguration().component("servlet").bindingMode(RestBindingMode.auto).dataFormatProperty("prettyPrint", "true");

		onException(HttpOperationFailedException.class).handled(true).process(new FailureHTTPResponseProcessor());
		onException(org.apache.camel.component.http.HttpOperationFailedException.class).handled(true).process(new FailureHTTPResponseProcessor());
		onException(NullPointerException.class).handled(true).process(new FailureHTTPResponseProcessor(400, "Bad Request. Please, check your headers for null values."));
		onException(ArrayIndexOutOfBoundsException.class).handled(true).process(new FailureHTTPResponseProcessor(401, null));

		// TOKEN handling
		rest("/" + Desc.NAME + "/tokens").post().description("Retrieve authentication tokens").type(AuthRequest.class).outType(AuthResponse.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				AuthRequest auth = exchange.getIn().getBody(AuthRequest.class);
				if (auth == null || auth.getAuthorization_id() == null || auth.getAuthorization_id().isEmpty() || auth.getPassword() == null || auth.getPassword().isEmpty()) {
					throw new HttpOperationFailedException(null, 401, "Unauthorized", null, null, null);
				}
				String authorization_code = new String(Base64.encodeBase64((auth.getAuthorization_id() + ":" + auth.getPassword()).getBytes()));
				AuthResponse response = new AuthResponse(Desc.API_VERSION, Desc.NAME);
				response.setExpires(null);
				response.setRefresh_token(null);
				response.setRole("read");
				response.setToken(authorization_code);
				exchange.getIn().setBody(response, AuthResponse.class);
			}
		}).endRest();

		rest("/" + Desc.NAME + "/weather").get("/{from}/{to}").description("Provides weather reports for a specific timeperiod in the area of Terni").outType(WeatherDetails.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("startTime", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
				exchange.getOut().setHeader("endTime", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
				String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
				exchange.getOut().setHeader("email", credentials[0]);
				exchange.getOut().setHeader("password", credentials[1]);
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("startdate=${in.headers.startTime}&enddate=${in.headers.endTime}&user=${in.headers.email}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.WEATHER_URL).to("bean:wp4Service?method=weather").endRest()

				.get("{descriptor}/{from}/{to}")
				.description("Provides weather reports for a specific timeperiod in the area of Terni, considering a single weather descriptor (see /weather/available_descriptor for the supported descriptor").outType(WeatherDetails.class)
				.route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("descriptor", exchange.getIn().getHeader("descriptor"));
						exchange.getOut().setHeader("startTime", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("endTime", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("startdate=${in.headers.startTime}&enddate=${in.headers.endTime}&user=${in.headers.email}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.WEATHER_URL).process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getIn().setBody((new TrialService()).weather_single_descriptor(exchange.getIn().getBody(WeatherData.class), exchange.getIn().getHeader("descriptor").toString()));
					}
				}).endRest()

				.get("available_descriptors").description("Provides information regarding the available forecast descriptors of the specified trial infrastructure").outType(WeatherAvailableOptions.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
					}
				}).to("bean:wp4Service?method=weatherAvailableOptions").endRest();

		// A rest interface to handle the social events
		rest("/" + Desc.NAME + "/social").get().description("Offers a list of social events that can temporarily influence the electricity consumption.").outType(SocialEventsReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
				exchange.getOut().setHeader("email", credentials[0]);
				exchange.getOut().setHeader("password", credentials[1]);
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.SOCIAL_URL).to("bean:wp4Service?method=social")
				.endRest()

				.get("/{events_number}").description("Offers a list of social events that can temporarily influence the electricity consumption.").outType(SocialEventsReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("events_number", exchange.getIn().getHeader("events_number"));
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("items=${in.headers.events_number}&user=${in.headers.email}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.SOCIAL_URL)
				.to("bean:wp4Service?method=social").endRest();

		// A rest interface to handle the meters & sectors
		rest("/" + Desc.NAME + "/meters")
				.get()
				.description("Gets a list of the available meters along with the set of their accompanying information.")
				.outType(MetersReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.METERS_URL)
				.to("bean:wp4Service?method=metersReport")
				.endRest()

				.get("/{search_options}")
				.description("Retrieves a meter based on a search string.")
				.outType(MetersReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						if (exchange.getIn().getHeader("search_options", String.class).split(":").length > 1) {
							exchange.getOut().setHeader("searchType", exchange.getIn().getHeader("search_options", String.class).split(":")[0]);
							exchange.getOut().setHeader("searchValue", exchange.getIn().getHeader("search_options", String.class).split(":")[1]);
						} else {
							exchange.getOut().setHeader("searchType", "customerId");
							exchange.getOut().setHeader("searchValue", exchange.getIn().getHeader("search_options"));
						}
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
					}
				})
				.setHeader(Exchange.HTTP_QUERY,
						simple("searchfield=${in.headers.searchType}&searchvalue=${in.headers.searchValue}&user=${in.headers.email}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.METERS_URL).to("bean:wp4Service?method=metersReport").endRest()

				.get("sectors").description("Gets a list of the sectors that the meters may be deployed into.").outType(SectorsReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.SECTORS_URL)
				.to("bean:wp4Service?method=sectors");

		// A rest interface to handle the energy consumption/production-related
		// measurements
		rest("/" + Desc.NAME + "/energy")

				// TOTAL USER consumption
				.get("/consumption/total/user/{customer_id}/{from}/{to}")
				.description("Retrieves information regarding the total energy consumption of a specific user, during a specific time period")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("customer_id", exchange.getIn().getHeader("customer_id"));
						exchange.getOut().setHeader("start_time", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("end_time", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
					}
				})
				.setHeader(
						Exchange.HTTP_QUERY,
						simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer_id}&startdate=${in.headers.start_time}&enddate=${in.headers.end_time}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.TOTAL_ENERGY_CONSUMPTION_USER_URL)

				.to("bean:wp4Service?method=energyConsumption")
				.endRest()

				// LOAD PROFILE USER
				.get("/consumption/profile/user/{customer_id}/{from}/{to}")
				.description("Retrieves information regarding the energy consumption profile of a specific user, during a specific time period")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("customer_id", exchange.getIn().getHeader("customer_id"));
						exchange.getOut().setHeader("start_time", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("end_time", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
					}
				})
				.setHeader(
						Exchange.HTTP_QUERY,
						simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer_id}&startdate=${in.headers.start_time}&enddate=${in.headers.end_time}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.LOAD_PROFILE_USER_URL)

				.to("bean:wp4Service?method=energyConsumption")
				.endRest()

				// LOAD PROFILE SECTOR
				.get("/consumption/profile/sector/{sector}/{from}/{to}")
				.description("Retrieves information regarding the energy consumption profile of a specific sector, during a specific time period")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("sector", exchange.getIn().getHeader("sector"));
						exchange.getOut().setHeader("start_time", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("end_time", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
					}
				})
				.setHeader(Exchange.HTTP_QUERY,
						simple("user=${in.headers.email}&password=${in.headers.password}&sector=${in.headers.sector}&startdate=${in.headers.start_time}&enddate=${in.headers.end_time}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.LOAD_PROFILE_SECTOR_URL)

				.to("bean:wp4Service?method=energyConsumption")
				.endRest()

				// TOTAL USER production
				.get("/production/total/user/{customer_id}/{from}/{to}")
				.description("Retrieves information regarding the energy production of a specific user, during a specific time period")
				.consumes("application/xml")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("customer_id", exchange.getIn().getHeader("customer_id"));
						exchange.getOut().setHeader("start_time", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("end_time", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
					}
				})
				.setHeader(
						Exchange.HTTP_QUERY,
						simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer_id}&startdate=${in.headers.start_time}&enddate=${in.headers.end_time}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.TOTAL_ENERGY_PRODUCTION_USER_URL)

				.to("bean:wp4Service?method=energyProduction")
				.endRest()

				// LOAD PROFILE USER production
				.get("/production/profile/user/{customer_id}/{from}/{to}")
				.description("Retrieves information regarding the energy production of a specific user, during a specific time period")
				.consumes("application/xml")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("customer_id", exchange.getIn().getHeader("customer_id"));
						exchange.getOut().setHeader("start_time", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("end_time", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
					}
				})
				.setHeader(
						Exchange.HTTP_QUERY,
						simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer_id}&startdate=${in.headers.start_time}&enddate=${in.headers.end_time}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.TOTAL_ENERGY_PRODUCTION_USER_URL)

				.to("bean:wp4Service?method=energyProduction")
				.endRest()

				// LOAD PROFILE sector production
				.get("/production/profile/sector/{sector}/{from}/{to}")
				.description("Retrieves information regarding the energy production of a specific user, during a specific time period")
				.consumes("application/xml")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("sector", exchange.getIn().getHeader("sector"));
						exchange.getOut().setHeader("start_time", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("end_time", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
					}
				})
				.setHeader(Exchange.HTTP_QUERY,
						simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.sector}&startdate=${in.headers.start_time}&enddate=${in.headers.end_time}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.LOAD_PROFILE_SECTOR_URL)

				.to("bean:wp4Service?method=energyProduction").endRest();

		// A REST interface to handle the power demand of a user during a
		// specific timeframe
		rest("/" + Desc.NAME + "/power")
				.get("/demand/user/{customer_id}/{from}/{to}")
				.description("Retrieves information regarding the power demand of a specific user, during a specific time period")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("customer_id", exchange.getIn().getHeader("customer_id"));
						exchange.getOut().setHeader("start_time", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("end_time", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
					}
				})
				.setHeader(
						Exchange.HTTP_QUERY,
						simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer_id}&startdate=${in.headers.start_time}&enddate=${in.headers.end_time}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.METERING_PROFILE_USER_URL)

				.to("bean:wp4Service?method=powerDemand")
				.endRest()

				.get("/supply/user/{customer_id}/{from}/{to}")
				.description("Retrieves information regarding the power supply of a specific user, during a specific time period")
				.outType(MeasurementReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("customer_id", exchange.getIn().getHeader("customer_id"));
						exchange.getOut().setHeader("start_time", Utilities.millisFromDateString(exchange.getIn().getHeader("from", String.class)) / 1000);
						exchange.getOut().setHeader("end_time", Utilities.millisFromDateString(exchange.getIn().getHeader("to", String.class)) / 1000);
					}
				})
				.setHeader(
						Exchange.HTTP_QUERY,
						simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer_id}&startdate=${in.headers.start_time}&enddate=${in.headers.end_time}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.METERING_PROFILE_USER_URL)

				.to("bean:wp4Service?method=powerSupply").endRest();

		// A REST interface to handle the prediction of energy consumption
		rest("/" + Desc.NAME + "/simulation")

		.get("/prediction/power/demand/user/{customer_id}")
				.description("Retrieves a predicted power demand report for a single user, based on his/her id")
//		.outType(PowerDemandPredictionReport.class)
				.outType(PredictionReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("customer_id", exchange.getIn().getHeader("customer_id"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer_id}&&bridgeEndpoint=false")).to(Desc.BASE_URL + Desc.POWER_CONSUMPTION_PREDICTION_USER_URL)

				.to("bean:wp4Service?method=powerDemandReport").endRest()

				.get("/prediction/power/demand/sector/{sector_id}").description("Retrieves a predicted power demand report for a single sector").outType(PredictionReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("sector_id", exchange.getIn().getHeader("sector_id"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&sector=${in.headers.sector_id}&&bridgeEndpoint=false")).to(Desc.BASE_URL + Desc.POWER_CONSUMPTION_PREDICTION_SECTOR_URL)

				.to("bean:wp4Service?method=powerDemandReport").endRest()

				.get("/prediction/power/supply/user/{customer_id}").description("Retrieves a predicted power supply report for a single user, based on his/her id").outType(PredictionReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("customer_id", exchange.getIn().getHeader("customer_id"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer_id}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.POWER_CONSUMPTION_PREDICTION_USER_URL)

				.to("bean:wp4Service?method=powerSupplyReport").endRest()

				.get("/prediction/power/supply/sector/{sector_id}").description("Retrieves a predicted power supply report for a single sector").outType(PredictionReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("sector_id", exchange.getIn().getHeader("sector_id"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&sector=${in.headers.sector_id}&&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.POWER_CONSUMPTION_PREDICTION_SECTOR_URL)

				.to("bean:wp4Service?method=powerSupplyReport").endRest();

		//
		// DEMAND SIDE MANAGEMENT APIs
		//
		rest("/" + Desc.NAME + "/dsm")
				//
				// ISSUE RESOLUTION PLANS
				//
				.get("/irp/author/{author}").description("Allows a user to get a list of issue resolution plans based on their name.").outType(IssueResolutionPlanReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("author", exchange.getIn().getHeader("author"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&author=${in.headers.author}&state=*&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.ISSUE_RESOLUTION_PLANS_URL)

				.to("bean:wp4Service?method=convertIRP").endRest()

				.get("/irp/state/{state}").description("Allows a user to get a list of issue resolution plans based on their state.").outType(IssueResolutionPlanReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("state", exchange.getIn().getHeader("state"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&author=*&state=${in.headers.state}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.ISSUE_RESOLUTION_PLANS_URL)

				.to("bean:wp4Service?method=convertIRP").endRest()

				.get("/irp/author/{author}/state/{state}")
				.description("Allows a user to get a list of issue resolution plans based on their state and author.")
				.outType(IssueResolutionPlanReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("author", exchange.getIn().getHeader("author"));
						exchange.getOut().setHeader("state", exchange.getIn().getHeader("state"));
					}
				})
				.setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&author=${in.headers.author}&state=${in.headers.state}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.ISSUE_RESOLUTION_PLANS_URL)

				.to("bean:wp4Service?method=convertIRP")

				.endRest()

				//
				// INCENTIVE PLANS
				//
				.get("/ip/author/{author}").description("Allows an energy retailer to get a list of incentive plans based on their name.").outType(IncentivePlanReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("author", exchange.getIn().getHeader("author"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&author=${in.headers.author}&state=*&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.INCENTIVE_PLANS_URL)

				.to("bean:wp4Service?method=convertIP").endRest()

				.get("/ip/state/{state}").description("Allows an energy retailer to get a list of incentive plans based on their state.").outType(IncentivePlanReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("state", exchange.getIn().getHeader("state"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&author=*&state=${in.headers.state}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.INCENTIVE_PLANS_URL)

				.to("bean:wp4Service?method=convertIP").endRest()

				.get("/ip/author/{author}/state/{state}").description("Allows an energy retailer to get a list of incentive plans based on their state and author.").outType(IncentivePlanReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
						exchange.getOut().setHeader("author", exchange.getIn().getHeader("author"));
						exchange.getOut().setHeader("state", exchange.getIn().getHeader("state"));
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&author=${in.headers.author}&state=${in.headers.state}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.INCENTIVE_PLANS_URL)

				.to("bean:wp4Service?method=convertIP").endRest();

		//
		// CONTRACTS
		//
		rest("/" + Desc.NAME + "/contracts").get("/customer/{customer}").description("Allows an energy retailer to get a list of contracts, regardless of their state").outType(ContractReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
				exchange.getOut().setHeader("email", credentials[0]);
				exchange.getOut().setHeader("password", credentials[1]);
				exchange.getOut().setHeader("customer", exchange.getIn().getHeader("customer"));
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer}&state=*&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.CONTRACTS_URL)

		.to("bean:wp4Service?method=convertContract").endRest()

		.get("/state/{state}").description("Allows an energy retailer to get a list of contracts, regardless of the customers they are intended for.").outType(ContractReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
				exchange.getOut().setHeader("email", credentials[0]);
				exchange.getOut().setHeader("password", credentials[1]);
				exchange.getOut().setHeader("state", exchange.getIn().getHeader("state"));
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&customer=*&state=${in.headers.state}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.CONTRACTS_URL)

		.to("bean:wp4Service?method=convertContract").endRest()

		.get("/customer/{customer}/state/{state}").description("Allows an energy retailer to get a list of contracts, based on their state and customer they are intended for.").outType(ContractReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
				exchange.getOut().setHeader("email", credentials[0]);
				exchange.getOut().setHeader("password", credentials[1]);
				exchange.getOut().setHeader("customer", exchange.getIn().getHeader("customer"));
				exchange.getOut().setHeader("state", exchange.getIn().getHeader("state"));
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&customer=${in.headers.customer}&state=${in.headers.state}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.to(Desc.BASE_URL + Desc.CONTRACTS_URL)

				.to("bean:wp4Service?method=convertContract").endRest()

				.get("prices").description("Allows a user to get the contracted prices for electricity, based on their type").outType(EnergyCostsReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String[] credentials = new String(Base64.decodeBase64(exchange.getIn().getHeader("x-auth-token", String.class)), "UTF-8").split(":");
						exchange.getOut().setHeader("email", credentials[0]);
						exchange.getOut().setHeader("password", credentials[1]);
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("user=${in.headers.email}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.COSTS_URL)

				.to("bean:wp4Service?method=convertEnergyCosts").endRest();
	}
}
