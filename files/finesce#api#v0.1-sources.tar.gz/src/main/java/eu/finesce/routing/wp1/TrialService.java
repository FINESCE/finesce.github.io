/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp1;

import org.apache.camel.Converter;

import eu.finesce.api.Utilities;
import eu.finesce.api.generic.Measurement;
import eu.finesce.api.generic.Value;
import eu.finesce.api.measurements.types.CloudCover;
import eu.finesce.api.measurements.types.Precipitation;
import eu.finesce.api.measurements.types.SunriseTime;
import eu.finesce.api.measurements.types.SunsetTime;
import eu.finesce.api.measurements.types.Temperature;
import eu.finesce.api.measurements.types.WindDirection;
import eu.finesce.api.measurements.types.WindSpeed;
import eu.finesce.api.pricing.Price;
import eu.finesce.api.pricing.PriceLocation;
import eu.finesce.api.pricing.PriceLocationData;
import eu.finesce.api.pricing.PriceLocationDataValue;
import eu.finesce.api.pricing.PriceReport;
import eu.finesce.api.pricing.reports.PriceLocationDataReport;
import eu.finesce.api.pricing.reports.PriceLocationDataValueReport;
import eu.finesce.api.pricing.reports.PriceLocationReport;
import eu.finesce.api.weather.WeatherAvailableOptions;
import eu.finesce.api.weather.WeatherDetails;

import eu.finesce.trials.wp1.MalmoPrice;
import eu.finesce.trials.wp1.MalmoWeather;
import eu.finesce.trials.wp1.PriceListWrapper;
import eu.finesce.trials.wp1.PriceSingleWrapper;
import eu.finesce.trials.wp1.WeatherWrapper;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialService {

	public TrialService() {
	}

	// Price locations
	public PriceLocationReport getPriceLocations() {
		PriceLocationReport plr = new PriceLocationReport(Desc.API_VERSION, Desc.NAME);
		plr.add(getPriceLocations("A").getPrice_locations().get(0));
		plr.add(getPriceLocations("B").getPrice_locations().get(0));
		return plr;
	}

	public PriceLocationReport getPriceLocations(String name) {
		PriceLocationReport plr = new PriceLocationReport(Desc.API_VERSION, Desc.NAME);
		if (name.equals("A") || name.equals("B")) {
			plr.add(new PriceLocation(name.equals("A") ? "1" : "2", name, name + "1234", "Description of price location " + name, "http://www.random_url.rnd/" + name, "Price Region " + name, "55.605833", "13.035833", "GMT+1"));
		}
		return plr;
	}

	// Price locations data streams
	public PriceLocationDataReport getPriceLocationsData() {
		PriceLocationDataReport pldr = new PriceLocationDataReport(Desc.API_VERSION, Desc.NAME);
		pldr.add(getPriceLocationsData("A").getList().get(0));
		pldr.add(getPriceLocationsData("B").getList().get(0));
		return pldr;
	}

	public PriceLocationDataReport getPriceLocationsData(String name) {
		PriceLocationDataReport pldr = new PriceLocationDataReport(Desc.API_VERSION, Desc.NAME);
		if (name.equals("A") || name.equals("B")) {
			pldr.add(new PriceLocationData(name, name.equals("A") ? "1" : "2", name.equals("A") ? "LocationHeatPowerDemandGrid" : "LocationHeatPowerConsumptionGrid", name.equals("A") ? "1" : "2"));
		}
		return pldr;
	}

	public PriceLocationDataValueReport getPriceLocationsDataValues(String name, String from, String to) {
		String med = Utilities.dateFromMilliSeconds((Utilities.millisFromDateString(from) + Utilities.millisFromDateString(to)) / 2);

		PriceLocationDataValueReport pldvr = new PriceLocationDataValueReport(Desc.API_VERSION, Desc.NAME);
		pldvr.add(new PriceLocationDataValue(name.equals("A") ? "1" : "4", from, "1234"));
		pldvr.add(new PriceLocationDataValue(String.valueOf(Integer.valueOf(pldvr.getPrice_location_data_values().get(0).getId()) + 1), med, "1235"));
		pldvr.add(new PriceLocationDataValue(String.valueOf(Integer.valueOf(pldvr.getPrice_location_data_values().get(1).getId()) + 1), to, "1236"));
		return pldvr;
	}

	// Prices
	@Converter
	public PriceReport prices(PriceListWrapper wrapper) {
		PriceReport pr = new PriceReport(Desc.API_VERSION, Desc.NAME);
		for (MalmoPrice m : wrapper.getD().getResults()) {
			pr.add(new Price(m.getId(), m.getRegion(), Utilities.dateFromMilliSeconds(Long.valueOf(m.getId())), m.getDateTime() + "+01:00", m.getCurrency(), m.getElectricityCost(), m.getHeatingCost(), null));
		}
		return pr;
	}

	@Converter
	public PriceReport price(PriceSingleWrapper wrapper) {
		PriceReport pr = new PriceReport(Desc.API_VERSION, Desc.NAME);
		MalmoPrice m = wrapper.getD();
		pr.add(new Price(m.getId(), m.getRegion(), Utilities.dateFromMilliSeconds(Long.valueOf(m.getId())), m.getDateTime() + "+01:00", m.getCurrency(), m.getElectricityCost(), m.getHeatingCost(), null));
		return pr;
	}

	// Weather
	/**
	 * Presents the available options for the weather report
	 * 
	 * @return The available weather report options
	 */
	public WeatherAvailableOptions weatherAvailableOptions() {
		WeatherAvailableOptions wao = new WeatherAvailableOptions(Desc.API_VERSION, Desc.NAME);
		wao.add(new Temperature());
		wao.add(new CloudCover());
		wao.add(new Precipitation());
		wao.add(new WindSpeed());
		wao.add(new WindDirection());
		wao.add(new SunriseTime());
		wao.add(new SunsetTime());
		return wao;
	}

	/**
	 * Converts a WeatherWrapper object (Malmo trial) into a FINESCE API
	 * compatible one
	 * 
	 * @param wrapper
	 *            The weather forecast to parse
	 * @return The FINESCE API representation of the weather report
	 */
	@Converter
	public WeatherDetails weather_all(WeatherWrapper wrapper) {

		WeatherDetails wd = new WeatherDetails(Desc.API_VERSION, Desc.NAME);
		wd.add(new Measurement<Double>(new Temperature()));
		wd.add(new Measurement<Double>(new CloudCover()));
		wd.add(new Measurement<Double>(new Precipitation()));
		wd.add(new Measurement<Double>(new WindSpeed()));
		wd.add(new Measurement<Double>(new WindDirection()));
		wd.add(new Measurement<String>(new SunriseTime()));
		wd.add(new Measurement<String>(new SunsetTime()));

		if (wrapper != null && !wrapper.getD().getResults().isEmpty()) {
			for (MalmoWeather m : wrapper.getD().getResults()) {
				wd.add(0, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getOutsideTemperature())));
				wd.add(1, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getCloudCoverage())));
				wd.add(2, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getPrecipitation())));
				wd.add(3, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getWindSpeed())));
				wd.add(4, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getWindDirection())));
				wd.add(5, new Value<String>(m.getDateTime() + "+01:00", m.getSunRise() + "+01:00"));
				wd.add(6, new Value<String>(m.getDateTime() + "+01:00", m.getSunSet() + "+01:00"));
			}
		}
		return wd;
	}

	/**
	 * Converts a WeatherWrapper object (Malmo trial) into a FINESCE API
	 * compatible one
	 * 
	 * @param wrapper
	 *            The weather forecast to parse
	 * @return The FINESCE API representation of the weather report
	 */
	@Converter
	public WeatherDetails weather_single(WeatherWrapper wrapper) {

		WeatherDetails wd = new WeatherDetails(Desc.API_VERSION, Desc.NAME);

		if (wrapper != null && !wrapper.getD().getResults().isEmpty()) {
			if (wd.getWeather_data() == null || wd.getWeather_data().isEmpty()) {
				if (wrapper.getD().getResults().get(0).getOutsideTemperature() != null) {
					wd.add(new Measurement<Double>(new Temperature()));
					for (MalmoWeather m : wrapper.getD().getResults()) {
						wd.add(0, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getOutsideTemperature())));
					}
				} else if (wrapper.getD().getResults().get(0).getCloudCoverage() != null) {
					wd.add(new Measurement<Double>(new CloudCover()));
					for (MalmoWeather m : wrapper.getD().getResults()) {
						wd.add(0, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getCloudCoverage())));
					}
				} else if (wrapper.getD().getResults().get(0).getPrecipitation() != null) {
					wd.add(new Measurement<Double>(new Precipitation()));
					for (MalmoWeather m : wrapper.getD().getResults()) {
						wd.add(0, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getPrecipitation())));
					}
				} else if (wrapper.getD().getResults().get(0).getWindSpeed() != null) {
					wd.add(new Measurement<Double>(new WindSpeed()));
					for (MalmoWeather m : wrapper.getD().getResults()) {
						wd.add(0, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getWindSpeed())));
					}
				} else if (wrapper.getD().getResults().get(0).getWindDirection() != null) {
					wd.add(new Measurement<Double>(new WindDirection()));
					for (MalmoWeather m : wrapper.getD().getResults()) {
						wd.add(0, new Value<Double>(m.getDateTime() + "+01:00", Double.valueOf(m.getWindDirection())));
					}
				} else if (wrapper.getD().getResults().get(0).getSunRise() != null) {
					wd.add(new Measurement<String>(new SunriseTime()));
					for (MalmoWeather m : wrapper.getD().getResults()) {
						wd.add(0, new Value<String>(m.getDateTime() + "+01:00", m.getSunRise() + "+01:00"));
					}
				} else if (wrapper.getD().getResults().get(0).getSunSet() != null) {
					wd.add(new Measurement<String>(new SunsetTime()));
					for (MalmoWeather m : wrapper.getD().getResults()) {
						wd.add(0, new Value<String>(m.getDateTime() + "+01:00", m.getSunSet() + "+01:00"));
					}
				}
			}

		}
		return wd;
	}
}
