/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp4;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class Desc {
	public static final String	NAME									= "Terni";
	public static final String	BASE_URL								= "https://130.206.85.6/rest2api/api/rest2api/";
	public static final String	API_VERSION								= "0.1";
	public static final String	TRIAL_WP								= "finesce-wp4";

	public static final String	WEATHER_URL								= "getWeatherForecast";
	public static final String	SOCIAL_URL								= "getSocialEvents";
	public static final String	METERS_URL								= "MeterDetails";
	public static final String	SECTORS_URL								= "Sectors";
	public static final String	TOTAL_ENERGY_CONSUMPTION_USER_URL		= "getIndividualElectricityConsumption";
	public static final String	TOTAL_ENERGY_PRODUCTION_USER_URL		= "getIndividualElectricityConsumption";
	public static final String	LOAD_PROFILE_USER_URL					= "historicalLoadByCustomer";
	public static final String	LOAD_PROFILE_SECTOR_URL					= "historicalLoadBySector";
	public static final String	METERING_PROFILE_USER_URL				= "historicalMeterById";
	public static final String	POWER_CONSUMPTION_PREDICTION_USER_URL	= "getReactivePowerProductionByCustomer";
	public static final String	POWER_CONSUMPTION_PREDICTION_SECTOR_URL	= "getReactivePowerProductionBySector";
	public static final String	ISSUE_RESOLUTION_PLANS_URL				= "IssueResolutionPlans";
	public static final String	INCENTIVE_PLANS_URL						= "IncentivePlans";
	public static final String	CONTRACTS_URL							= "Contract";
	public static final String	COSTS_URL								= "EnergyCosts";
}