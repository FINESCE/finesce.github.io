/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp5;

import eu.finesce.api.authentication.AuthRefresh;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http.HttpOperationFailedException;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

import eu.finesce.api.authentication.AuthRequest;
import eu.finesce.api.authentication.AuthResponse;
import eu.finesce.api.electric_vehicles.reports.ChargingModesReport;
import eu.finesce.api.electric_vehicles.reports.ChargingStatesReport;
import eu.finesce.api.electric_vehicles.reports.ConnectionStatesReport;
import eu.finesce.api.electric_vehicles.reports.ConnectionsReport;
import eu.finesce.api.electric_vehicles.reports.RegionalEnergyAvgReport;
import eu.finesce.api.electric_vehicles.reports.RegionalEnergyReport;
import eu.finesce.api.electric_vehicles.reports.TimeslotsReport;
import eu.finesce.api.electric_vehicles.reports.VehicleTypesReport;
import eu.finesce.api.electric_vehicles.reports.VehicleSupplyEquipmentReport;
import eu.finesce.api.electric_vehicles.reports.VehiclesReport;
import eu.finesce.api.optimisation.reports.AlgoweightReport;
import eu.finesce.api.regional.reports.RegionsReport;
import eu.finesce.routing.FailureHTTPResponseProcessor;
import eu.finesce.trials.wp5.wrappers.AlgoweightsWrapper;
import eu.finesce.trials.wp5.wrappers.ChargingmodesWrapper;
import eu.finesce.trials.wp5.wrappers.ChargingstatesWrapper;
import eu.finesce.trials.wp5.wrappers.ElectricvehiclesWrapper;
import eu.finesce.trials.wp5.wrappers.EvevseconnectionsWrapper;
import eu.finesce.trials.wp5.wrappers.EvevseconnectionstatesWrapper;
import eu.finesce.trials.wp5.wrappers.EvsesWrapper;
import eu.finesce.trials.wp5.wrappers.EvtypesWrapper;
import eu.finesce.trials.wp5.wrappers.RegionalaggevseenergiesWrapper;
import eu.finesce.trials.wp5.wrappers.RegionalenergiesWrapper;
import eu.finesce.trials.wp5.wrappers.RegionsWrapper;
import eu.finesce.trials.wp5.wrappers.TimeslotsWrapper;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */
public class TrialRoutes extends RouteBuilder {

	public TrialRoutes() {
	}

	public TrialRoutes(CamelContext context) {
		super(context);
	}

	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").bindingMode(RestBindingMode.auto).dataFormatProperty("prettyPrint", "true");

		onException(HttpOperationFailedException.class).handled(true).process(new FailureHTTPResponseProcessor());

		// TOKEN handling
		rest("/" + Desc.NAME + "/tokens").post().description("Retrieve authentication tokens").type(AuthRequest.class).outType(AuthResponse.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				AuthRequest auth = exchange.getIn().getBody(AuthRequest.class);
				if (auth == null || auth.getAuthorization_id() == null || auth.getPassword() == null) {
					auth = new AuthRequest("", "");
				}
				exchange.getOut().setHeader("authentication_id", auth.getAuthorization_id());
				exchange.getOut().setHeader("password", auth.getPassword());
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("email=${in.headers.authentication_id}&password=${in.headers.password}&bridgeEndpoint=false&throwExceptionOnFailure=false")).setHeader(Exchange.HTTP_METHOD, constant("POST"))
				.to(Desc.BASE_URL + Desc.AUTH_URL).unmarshal().json(JsonLibrary.Jackson, eu.finesce.trials.wp5.AuthResponse.class).to("bean:wp5Service?method=tokens").endRest()

				.post("/refresh").description("Refresh an authentication token").type(AuthRefresh.class).outType(AuthResponse.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						AuthRefresh auth = exchange.getIn().getBody(AuthRefresh.class);
						if (auth == null || auth.getRefresh_token() == "") {
							auth = new AuthRefresh("");
						}
						exchange.getOut().setHeader("refresh_token", auth.getRefresh_token());
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("refresh_token=${in.headers.refresh_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).setHeader(Exchange.HTTP_METHOD, constant("POST"))
				.recipientList(simple(Desc.BASE_URL + Desc.AUTH_URL + "/refresh")).unmarshal().json(JsonLibrary.Jackson, eu.finesce.trials.wp5.AuthResponse.class).to("bean:wp5Service?method=tokens").endRest();

		// Algorithm weights
		rest("/" + Desc.NAME + "/algoweights").get().description("Allows a user to retrieve a collection of algoweights").outType(AlgoweightReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.ALGOWEIGHTS_URL).unmarshal()
				.json(JsonLibrary.Jackson, AlgoweightsWrapper.class).to("bean:wp5Service?method=algoweights").endRest()

				.get("/{id}").description("Allows a user to retrieve an algoweights record, based on its ID. A valid {id} can be obtained by calling the /algoweights service.").outType(AlgoweightReport.class).route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.ALGOWEIGHTS_URL + "/${in.headers.id}"))
				.unmarshal().json(JsonLibrary.Jackson, AlgoweightsWrapper.class).to("bean:wp5Service?method=algoweights").endRest();

		// Charging Modes
		rest("/" + Desc.NAME + "/charging_modes").get().description("Allows a user to retrieve a collection of chargingmodes").outType(ChargingModesReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.CHARGINGMODES_URL).unmarshal()
				.json(JsonLibrary.Jackson, ChargingmodesWrapper.class).to("bean:wp5Service?method=charging_modes").endRest()

				.get("/{id}").description("Allows a user to retrieve a chargingmode based on an ID. A valid {id} can be obtained by calling the /charging_modes service.").outType(ChargingModesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.CHARGINGMODES_URL + "/${in.headers.id}"))
				.unmarshal().json(JsonLibrary.Jackson, ChargingmodesWrapper.class).to("bean:wp5Service?method=charging_modes").endRest()

				.get("{id}/evses").description("Allows a user to retrieve a collection of evses associated with a charging mode. A valid {id} can be obtained by calling the /charging_modes service.")
				.outType(VehicleSupplyEquipmentReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.CHARGINGMODES_URL + "/${in.headers.id}" + "/evses")).unmarshal().json(JsonLibrary.Jackson, EvsesWrapper.class).to("bean:wp5Service?method=evses").endRest()

				.get("{id}/evtypes").description("Allows a user to retrieve a collection of electric vehicle types associated with a charging mode. A valid {id} can be obtained by calling the /charging_modes service.")
				.outType(VehicleTypesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.CHARGINGMODES_URL + "/${in.headers.id}" + "/evtypes")).unmarshal().json(JsonLibrary.Jackson, EvtypesWrapper.class).to("bean:wp5Service?method=evtypes").endRest();

		// Charging States
		rest("/" + Desc.NAME + "/charging_states").get().description("Allows a user to retrieve a collection of chargingmodes").outType(ChargingStatesReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.CHARGINGSTATES_URL).unmarshal()
				.json(JsonLibrary.Jackson, ChargingstatesWrapper.class).to("bean:wp5Service?method=charging_states").endRest()

				.get("/{id}").description("Allows a user to retrieve a chargingmode based on an ID. A valid {id} can be obtained by calling the /charging_states service.").outType(ChargingStatesReport.class).route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.CHARGINGSTATES_URL + "/${in.headers.id}"))
				.unmarshal().json(JsonLibrary.Jackson, ChargingstatesWrapper.class).to("bean:wp5Service?method=charging_states").endRest();

		// VehiclesReport
		rest("/" + Desc.NAME + "/vehicles").get().description("Provides the list of vehicles available").outType(VehiclesReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.ELECTRICVEHICLES_URL).unmarshal()
				.json(JsonLibrary.Jackson, ElectricvehiclesWrapper.class).to("bean:wp5Service?method=electric_vehicles").endRest()

				.get("/{id}").description("Provides information regarding a single vehicle. A valid {id} can be obtained by calling the /vehicles service.").outType(VehiclesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.ELECTRICVEHICLES_URL + "/${in.headers.id}"))
				.unmarshal().json(JsonLibrary.Jackson, ElectricvehiclesWrapper.class).to("bean:wp5Service?method=electric_vehicles").endRest()

				.get("/{id}/connections").description("Allows a user to retrieve a collection of ev evse connections associated with an electric vehicle. A valid {id} can be obtained by calling the /vehicles service.")
				.outType(ConnectionsReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.ELECTRICVEHICLES_URL + "/${in.headers.id}" + "/evevseconnections")).unmarshal().json(JsonLibrary.Jackson, EvevseconnectionsWrapper.class).to("bean:wp5Service?method=connections")
				.endRest();

		// EVSES
		rest("/" + Desc.NAME + "/supply_equipment").get().description("Allows a user to retrieve a collection of electric vehicle supply equipment components").outType(VehicleSupplyEquipmentReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.EVSES_URL).unmarshal().json(JsonLibrary.Jackson, EvsesWrapper.class)
				.to("bean:wp5Service?method=evses").endRest()

				.get("/{id}").description("Allows a user to retrieve an electric vehicle supply equipment component, based on its ID. A valid {id} can be obtained by calling the /supply_equipment service.")
				.outType(VehicleSupplyEquipmentReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.EVSES_URL + "/${in.headers.id}")).unmarshal()
				.json(JsonLibrary.Jackson, EvsesWrapper.class).to("bean:wp5Service?method=evses").endRest()

				.get("/{id}/connections").description("Allows a user to retrieve a collection of ev evse connections associated with an evse. A valid {id} can be obtained by calling the /supply_equipment service.")
				.outType(ConnectionsReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.EVSES_URL + "/${in.headers.id}" + "/evevseconnections")).unmarshal().json(JsonLibrary.Jackson, EvevseconnectionsWrapper.class).to("bean:wp5Service?method=connections").endRest()

				.get("/{id}/charging_modes").description("Allows a user to retrieve a collection of charging modes associated with an evse. A valid {id} can be obtained by calling the /supply_equipment service.")
				.outType(ChargingModesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.EVSES_URL + "/${in.headers.id}" + "/chargingmodes")).unmarshal().json(JsonLibrary.Jackson, ChargingmodesWrapper.class).to("bean:wp5Service?method=charging_modes").endRest();

		// ConnectionsReport
		rest("/" + Desc.NAME + "/connections").get().description("Allows a user to retrieve a collection of ev evse connections").outType(ConnectionsReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.EVEVSECONNECTIONS_URL).unmarshal()
				.json(JsonLibrary.Jackson, EvevseconnectionsWrapper.class).to("bean:wp5Service?method=connections").endRest()

				.get("/{id}").description("Allows a user to retrieve an ev evse connection, based on its ID. A valid {id} can be obtained by calling the /connections service.").outType(ConnectionsReport.class).route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.EVEVSECONNECTIONS_URL + "/${in.headers.id}"))
				.unmarshal().json(JsonLibrary.Jackson, EvevseconnectionsWrapper.class).to("bean:wp5Service?method=connections").endRest()

				.get("/{id}/connection_state").description("Allows a user to retrieve an ev evse connection state associated with an ev evse connection. A valid {id} can be obtained by calling the /connections service.")
				.outType(ConnectionStatesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.EVEVSECONNECTIONS_URL + "/${in.headers.id}" + "/evevseconnectionstate")).unmarshal().json(JsonLibrary.Jackson, EvevseconnectionstatesWrapper.class)
				.to("bean:wp5Service?method=connection_states").endRest()

				.get("/{id}/charging_mode").description("Allows a user to retrieve a charging mode associated with an ev evse connection. A valid {id} can be obtained by calling the /connections service.")
				.outType(ChargingModesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.EVEVSECONNECTIONS_URL + "/${in.headers.id}" + "/chargingmode")).unmarshal().json(JsonLibrary.Jackson, ChargingmodesWrapper.class).to("bean:wp5Service?method=charging_modes")
				.endRest();

		// Connection States
		rest("/" + Desc.NAME + "/connection_states").get().description("Allows a user to retrieve a collection of ev evse connection states").outType(ConnectionStatesReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.EVEVSECONNECTIONSTATES_URL).unmarshal()
				.json(JsonLibrary.Jackson, EvevseconnectionstatesWrapper.class).to("bean:wp5Service?method=connection_states").endRest()

				.get("/{id}").description("Allows a user to retrieve an ev evse connection state record, based on its ID. A valid {id} can be obtained by calling the /connection_states service.").outType(ConnectionStatesReport.class)
				.route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.EVEVSECONNECTIONSTATES_URL + "/${in.headers.id}")).unmarshal().json(JsonLibrary.Jackson, EvevseconnectionstatesWrapper.class).to("bean:wp5Service?method=connection_states")
				.endRest();

		// EV VehicleTypesReport
		rest("/" + Desc.NAME + "/vehicle_types").get().description("Allows a user to retrieve a collection of electric vehicle types").outType(VehicleTypesReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.EVTYPES_URL).unmarshal().json(JsonLibrary.Jackson, EvtypesWrapper.class)
				.to("bean:wp5Service?method=evtypes").endRest()

				.get("/{id}").description("Allows a user to retrieve an electric vehicle type record, based on its ID. A valid {id} can be obtained by calling the /vehicle_types service.").outType(VehicleTypesReport.class).route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.EVTYPES_URL + "/${in.headers.id}")).unmarshal()
				.json(JsonLibrary.Jackson, EvtypesWrapper.class).to("bean:wp5Service?method=evtypes").endRest()

				.get("/{id}/vehicles").description("Allows a user to retrieve a collection of electric vehicles associated with an electric vehicle type. A valid {id} can be obtained by calling the /vehicle_types service.")
				.outType(VehiclesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.EVTYPES_URL + "/${in.headers.id}" + "/electricvehicles")).unmarshal().json(JsonLibrary.Jackson, ElectricvehiclesWrapper.class).to("bean:wp5Service?method=electric_vehicles")
				.endRest()

				.get("/{id}/charging_modes").description("Allows a user to retrieve a collection of chargingmodes associated with an electric vehicle type. A valid {id} can be obtained by calling the /vehicle_types service.")
				.outType(ChargingModesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.EVTYPES_URL + "/${in.headers.id}" + "/chargingmodes")).unmarshal().json(JsonLibrary.Jackson, ChargingmodesWrapper.class).to("bean:wp5Service?method=charging_modes").endRest();

		// Regional Energy
		rest("/" + Desc.NAME + "/energy/regional").get().description("Allows a user to retrieve a collection of regional energy records").outType(RegionalEnergyReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.REGIONALENERGIES_URL).unmarshal()
				.json(JsonLibrary.Jackson, RegionalenergiesWrapper.class).to("bean:wp5Service?method=regional_energies").endRest()

				.get("/{id}").description("Allows a user to retrieve a regional energy record. A valid {id} can be obtained by calling the /energy/regional service.").outType(RegionalEnergyReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.REGIONALENERGIES_URL + "/${in.headers.id}"))
				.unmarshal().json(JsonLibrary.Jackson, RegionalenergiesWrapper.class).to("bean:wp5Service?method=regional_energies").endRest()

				.get("/{id}/region").description("Allows a user to retrieve a region associated with a regional energy record. A valid {id} can be obtained by calling the /energy/regional service.").outType(RegionsReport.class).route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.REGIONALENERGIES_URL + "/${in.headers.id}" + "/region")).unmarshal().json(JsonLibrary.Jackson, RegionsWrapper.class).to("bean:wp5Service?method=regions").endRest()

				.get("/{id}/timeslot").description("Allows a user to retrieve a timeslot associated with a regional energy record. A valid {id} can be obtained by calling the /energy/regional service.").outType(TimeslotsReport.class)
				.route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.REGIONALENERGIES_URL + "/${in.headers.id}" + "/timeslot")).unmarshal().json(JsonLibrary.Jackson, TimeslotsWrapper.class).to("bean:wp5Service?method=timeslots").endRest()

				.get("/avg").description("Allows a user to retrieve a collection of aggregated regional evse energy records").outType(RegionalEnergyAvgReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.REGIONALAGGEVSEENERGIES_URL).unmarshal()
				.json(JsonLibrary.Jackson, RegionalaggevseenergiesWrapper.class).to("bean:wp5Service?method=regional_energies_agg").endRest()

				.get("/avg/{id}").description("Allows a user to retrieve an aggregate regional evse energy record, based on its ID").outType(RegionalEnergyAvgReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.REGIONALAGGEVSEENERGIES_URL + "/${in.headers.id}")).unmarshal().json(JsonLibrary.Jackson, RegionalaggevseenergiesWrapper.class).to("bean:wp5Service?method=regional_energies_agg")
				.endRest();

		// RegionsReport
		rest("/" + Desc.NAME + "/regions").get().description("Allows a user to retrieve a collection of region records").outType(RegionsReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.REGIONS_URL).unmarshal().json(JsonLibrary.Jackson, RegionsWrapper.class)
				.to("bean:wp5Service?method=regions").endRest()

				.get("/{id}").description("Allows a user to retrieve a region record, based on its ID. A valid {id} can be obtained by calling the /regions service.").outType(RegionsReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.REGIONS_URL + "/${in.headers.id}")).unmarshal()
				.json(JsonLibrary.Jackson, RegionsWrapper.class).to("bean:wp5Service?method=regions").endRest()

				.get("/{id}/energy").description("Allows a user to retrieve a collection of aggregated regional evse energy records. A valid {id} can be obtained by calling the /regions service.").outType(RegionalEnergyReport.class)
				.route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.REGIONS_URL + "/${in.headers.id}" + "/regionalenergies")).unmarshal().json(JsonLibrary.Jackson, RegionalenergiesWrapper.class).to("bean:wp5Service?method=regional_energies")
				.endRest()

				.get("/{id}/energy/avg")
				.description("Allows a user to retrieve a collection of aggregate regional evse energy records associated with a region, based on its ID. A valid {id} can be obtained by calling the /regions service.")
				.outType(RegionalEnergyAvgReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.REGIONS_URL + "/${in.headers.id}" + "/regionalaggevseenergies")).unmarshal().json(JsonLibrary.Jackson, RegionalaggevseenergiesWrapper.class)
				.to("bean:wp5Service?method=regional_energies_agg").endRest()

				.get("/{id}/supply_equipment").description("Allows a user to retrieve a collection of evse records associated with a region. A valid {id} can be obtained by calling the /regions service.")
				.outType(VehicleSupplyEquipmentReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.REGIONS_URL + "/${in.headers.id}" + "/evses"))
				.unmarshal().json(JsonLibrary.Jackson, EvsesWrapper.class).to("bean:wp5Service?method=evses").endRest()

				.get("/{id}/algoweights").description("Allows a user to retrieve a collection of algorithm weight records associated with a region. A valid {id} can be obtained by calling the /regions service.")
				.outType(AlgoweightReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.REGIONS_URL + "/${in.headers.id}" + "/algoweights")).unmarshal().json(JsonLibrary.Jackson, AlgoweightsWrapper.class).to("bean:wp5Service?method=algoweights").endRest();

		// TimeslotsReport
		rest("/" + Desc.NAME + "/timeslots").get().description("Allows a user to retrieve a collection of time slot records").outType(TimeslotsReport.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
				exchange.getOut().setHeader("Accept", "application/json");
			}
		}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).to(Desc.BASE_URL + Desc.TIMESLOTS_URL).unmarshal()
				.json(JsonLibrary.Jackson, TimeslotsWrapper.class).to("bean:wp5Service?method=timeslots").endRest()

				.get("/{id}").description("Allows a user to retrieve a time slot record, based on its ID. A valid {id} can be obtained by calling the /timeslots service.").outType(TimeslotsReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false")).recipientList(simple(Desc.BASE_URL + Desc.TIMESLOTS_URL + "/${in.headers.id}")).unmarshal()
				.json(JsonLibrary.Jackson, TimeslotsWrapper.class).to("bean:wp5Service?method=timeslots").endRest()

				.get("/{id}/charging_states").description("Allows a user to retrieve a collection of charging state records associated with a time slot, based on its ID. A valid {id} can be obtained by calling the /timeslots service.")
				.outType(ChargingStatesReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.TIMESLOTS_URL + "/${in.headers.id}" + "/chargingstates")).unmarshal().json(JsonLibrary.Jackson, ChargingstatesWrapper.class).to("bean:wp5Service?method=charging_states").endRest()

				.get("/{id}/energy/regional").description("Allows a user to retrieve a collection of aggregated regional evse energy records. A valid {id} can be obtained by calling the /timeslots service.")
				.outType(RegionalEnergyReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.TIMESLOTS_URL + "/${in.headers.id}" + "/regionalenergies")).unmarshal().json(JsonLibrary.Jackson, RegionalenergiesWrapper.class).to("bean:wp5Service?method=regional_energies")
				.endRest()

				.get("/{id}/algoweights").description("Allows a user to retrieve a collection of algorithm weight records associated with a time slot. A valid {id} can be obtained by calling the /timeslots service.")
				.outType(AlgoweightReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("auth_token", exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).setHeader(Exchange.HTTP_QUERY, simple("auth_token=${in.headers.auth_token}&bridgeEndpoint=false&throwExceptionOnFailure=false"))
				.recipientList(simple(Desc.BASE_URL + Desc.TIMESLOTS_URL + "/${in.headers.id}" + "/algoweights")).unmarshal().json(JsonLibrary.Jackson, AlgoweightsWrapper.class).to("bean:wp5Service?method=algoweights").endRest();
	}
}
