/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp2.madrid;

import org.apache.camel.Converter;

import eu.finesce.api.buildings.BuildingZone;
import eu.finesce.api.buildings.reports.BuildingModulesReport;
import eu.finesce.api.buildings.reports.BuildingZonesReport;
import eu.finesce.api.generic.Measurement;
import eu.finesce.api.generic.MeasurementReport;
import eu.finesce.api.generic.MeasurementType;
import eu.finesce.api.generic.Value;
import eu.finesce.api.measurements.IlluminanceMeasurement;
import eu.finesce.api.measurements.ModuleStatusMeasurement;
import eu.finesce.api.measurements.PowerDemandGridMeasurement;
import eu.finesce.api.measurements.PowerMixedMeasurement;
import eu.finesce.api.measurements.PowerSupplyMeasurement;
import eu.finesce.api.measurements.RelativeHumidityMeasurement;
import eu.finesce.api.measurements.TemperatureMeasurement;
import eu.finesce.api.measurements.types.CloudCover;
import eu.finesce.api.measurements.types.GlobalHorizontalIrradiance;
import eu.finesce.api.measurements.types.RelativeHumidity;
import eu.finesce.api.measurements.types.Temperature;
import eu.finesce.api.measurements.types.WindDirection;
import eu.finesce.api.measurements.types.WindSpeed;
import eu.finesce.api.weather.WeatherAvailableOptions;
import eu.finesce.api.weather.WeatherDetails;
import eu.finesce.routing.wp2.madrid.Desc;
import eu.finesce.trials.wp2.madrid.BasicResource;
import eu.finesce.trials.wp2.madrid.CCEWrapper;
import eu.finesce.trials.wp2.madrid.MGWrapper;
import eu.finesce.trials.wp2.madrid.MeteoWrapper;
import eu.finesce.trials.wp2.madrid.WSNWrapper;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialService {

	public TrialService() {

	}

	private String convert_date(String date) {
		String ret = date.substring(0, 10) + "T" + date.substring(11, 19) + "+01:00";
		return ret;
	}

	@SuppressWarnings("unchecked")
	@Converter
	public WeatherDetails weather(MeteoWrapper wrapper) {
		WeatherDetails ret = new WeatherDetails(Desc.API_VERSION, Desc.NAME);
		MeasurementType mt = null;
		if (wrapper.getMeteo().size() > 0) {
			switch (wrapper.getMeteo().get(0).getParameter()) {
				case "temp":
					mt = new Temperature();
					break;
				case "humrel":
					mt = new RelativeHumidity();
					break;
				case "modviento":
					mt = new WindSpeed();
					break;
				case "dirviento":
					mt = new WindDirection();
					break;
				case "cc":
					mt = new CloudCover();
					break;
				case "irrad":
					mt = new GlobalHorizontalIrradiance();
					break;
				default:
					return ret;
			}

			ret.add(new Measurement<Double>(mt));
			for (BasicResource b : wrapper.getMeteo()) {
				ret.getWeather_data().get(0).add(new Value<Double>(null, convert_date(b.getTimestamp()), Double.valueOf(b.getValue())));
			}
		}
		return ret;
	}

	public WeatherAvailableOptions weatherAvailableOptions() {
		WeatherAvailableOptions wao = new WeatherAvailableOptions(Desc.API_VERSION, Desc.NAME);
		wao.add(new Temperature());
		wao.add(new RelativeHumidity());
		wao.add(new CloudCover());
		wao.add(new WindSpeed());
		wao.add(new WindDirection());
		wao.add(new GlobalHorizontalIrradiance());
		return wao;
	}

	@Converter
	public BuildingZonesReport building_zones(WSNWrapper wrapper) {
		BuildingZonesReport bzr = new BuildingZonesReport(Desc.API_VERSION, Desc.NAME);
		for (BasicResource b : wrapper.getWsn()) {
			bzr.add(new BuildingZone(b.getValue(), convert_date(b.getTimestamp())));
		}
		return bzr;
	}

	@SuppressWarnings("rawtypes")
	@Converter
	public MeasurementReport wsn_building_measurements(WSNWrapper wrapper) {
		MeasurementReport<? extends Measurement> mrt = null;
		if (wrapper != null && !wrapper.getWsn().isEmpty()) {
			if (wrapper.getWsn().get(0).getParameter().equalsIgnoreCase("activepower")) {
				mrt = new MeasurementReport<PowerDemandGridMeasurement>("PowerDemandGrid", Desc.API_VERSION, Desc.NAME);
			} else if (wrapper.getWsn().get(0).getParameter().equalsIgnoreCase("totalenergy")) {
				mrt = new MeasurementReport<PowerMixedMeasurement>("EnergyConsumptionGrid", Desc.API_VERSION, Desc.NAME);
			} else if (wrapper.getWsn().get(0).getParameter().equalsIgnoreCase("temp")) {
				mrt = new MeasurementReport<TemperatureMeasurement>("Temperature", Desc.API_VERSION, Desc.NAME);
			} else if (wrapper.getWsn().get(0).getParameter().equalsIgnoreCase("humrel")) {
				mrt = new MeasurementReport<RelativeHumidityMeasurement>("RelativeHumidity", Desc.API_VERSION, Desc.NAME);
			} else if (wrapper.getWsn().get(0).getParameter().equalsIgnoreCase("lumin")) {
				mrt = new MeasurementReport<IlluminanceMeasurement>("Illuminance", Desc.API_VERSION, Desc.NAME);
			} else {
				mrt = null;
			}
		} else {
			return mrt;
		}
		for (BasicResource b : wrapper.getWsn()) {
			mrt.get_value_list().add(new Value<Double>(convert_date(b.getTimestamp()), Double.valueOf(b.getValue())));
		}
		return mrt;
	}

	@Converter
	public MeasurementReport<PowerMixedMeasurement> inverter_total_power(MGWrapper wrapper) {
		MeasurementReport<PowerMixedMeasurement> ret = new MeasurementReport<>("PowerMixed", Desc.API_VERSION, Desc.NAME);
		for (BasicResource b : wrapper.getMg()) {
			ret.get_value_list().add(new Value<Double>(convert_date(b.getTimestamp()), Double.valueOf(b.getValue())));
		}
		return ret;
	}

	@Converter
	public MeasurementReport<PowerSupplyMeasurement> pv_power_supply(MGWrapper wrapper) {
		MeasurementReport<PowerSupplyMeasurement> ret = new MeasurementReport<>("PowerSupply", Desc.API_VERSION, Desc.NAME);
		for (BasicResource b : wrapper.getMg()) {
			ret.get_value_list().add(new Value<Double>(convert_date(b.getTimestamp()), Double.valueOf(b.getValue())));
		}
		return ret;
	}

	@Converter
	public BuildingModulesReport building_modules(CCEWrapper wrapper) {
		BuildingModulesReport ret = new BuildingModulesReport(Desc.API_VERSION, Desc.NAME);
		for (BasicResource b : wrapper.getCce()) {
			ret.add(b.getValue());
		}
		return ret;
	}

	@Converter
	public MeasurementReport<ModuleStatusMeasurement> building_modules_status(CCEWrapper wrapper) {
		MeasurementReport<ModuleStatusMeasurement> mrt = new MeasurementReport<>("ModuleStatus", Desc.API_VERSION, Desc.NAME);
		for (BasicResource b : wrapper.getCce()) {
			mrt.get_value_list().add(new Value<Integer>(convert_date(b.getTimestamp()), Integer.valueOf(b.getValue())));
		}
		return mrt;
	}

}
