/*
 * Copyright 2015 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.routing.wp5;

import org.apache.camel.Converter;

import eu.finesce.api.authentication.AuthResponse;
import eu.finesce.api.electric_vehicles.ChargingMode;
import eu.finesce.api.electric_vehicles.ChargingState;
import eu.finesce.api.electric_vehicles.Connection;
import eu.finesce.api.electric_vehicles.ConnectionState;
import eu.finesce.api.electric_vehicles.RegionalEnergy;
import eu.finesce.api.electric_vehicles.RegionalEnergyAvg;
import eu.finesce.api.electric_vehicles.Timeslot;
import eu.finesce.api.electric_vehicles.Vehicle;
import eu.finesce.api.electric_vehicles.VehicleSupplyEquipment;
import eu.finesce.api.electric_vehicles.VehicleType;
import eu.finesce.api.electric_vehicles.reports.ChargingModesReport;
import eu.finesce.api.electric_vehicles.reports.ChargingStatesReport;
import eu.finesce.api.electric_vehicles.reports.ConnectionStatesReport;
import eu.finesce.api.electric_vehicles.reports.ConnectionsReport;
import eu.finesce.api.electric_vehicles.reports.RegionalEnergyAvgReport;
import eu.finesce.api.electric_vehicles.reports.RegionalEnergyReport;
import eu.finesce.api.electric_vehicles.reports.TimeslotsReport;
import eu.finesce.api.electric_vehicles.reports.VehicleSupplyEquipmentReport;
import eu.finesce.api.electric_vehicles.reports.VehicleTypesReport;
import eu.finesce.api.electric_vehicles.reports.VehiclesReport;
import eu.finesce.api.optimisation.Algoweight;
import eu.finesce.api.optimisation.reports.AlgoweightReport;
import eu.finesce.api.regional.Region;
import eu.finesce.api.regional.reports.RegionsReport;
import eu.finesce.trials.wp5.Algoweights;
import eu.finesce.trials.wp5.Chargingmodes;
import eu.finesce.trials.wp5.Chargingstates;
import eu.finesce.trials.wp5.Electricvehicles;
import eu.finesce.trials.wp5.Evevseconnections;
import eu.finesce.trials.wp5.Evevseconnectionstates;
import eu.finesce.trials.wp5.Evses;
import eu.finesce.trials.wp5.Evtypes;
import eu.finesce.trials.wp5.Regionalaggevseenergies;
import eu.finesce.trials.wp5.Regionalenergies;
import eu.finesce.trials.wp5.Regions;
import eu.finesce.trials.wp5.Timeslots;
import eu.finesce.trials.wp5.wrappers.AlgoweightsWrapper;
import eu.finesce.trials.wp5.wrappers.ChargingmodesWrapper;
import eu.finesce.trials.wp5.wrappers.ChargingstatesWrapper;
import eu.finesce.trials.wp5.wrappers.ElectricvehiclesWrapper;
import eu.finesce.trials.wp5.wrappers.EvevseconnectionsWrapper;
import eu.finesce.trials.wp5.wrappers.EvevseconnectionstatesWrapper;
import eu.finesce.trials.wp5.wrappers.EvsesWrapper;
import eu.finesce.trials.wp5.wrappers.EvtypesWrapper;
import eu.finesce.trials.wp5.wrappers.RegionalaggevseenergiesWrapper;
import eu.finesce.trials.wp5.wrappers.RegionalenergiesWrapper;
import eu.finesce.trials.wp5.wrappers.RegionsWrapper;
import eu.finesce.trials.wp5.wrappers.TimeslotsWrapper;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class TrialService {

	public TrialService() {

	}

	@Converter
	public AlgoweightReport algoweights(AlgoweightsWrapper wrapper) {
		AlgoweightReport ar = new AlgoweightReport(Desc.API_VERSION, Desc.NAME);
		for (Algoweights a : wrapper.getRecords()) {
			ar.add(new Algoweight(String.valueOf(a.getId()), String.valueOf(a.getRenewables()), String.valueOf(a.getInterconnect()), String.valueOf(a.getSpecific()), String.valueOf(a.getTimeslot_id()), String.valueOf(a.getRegion_id())));
		}
		return ar;
	}

	@Converter
	public ChargingModesReport charging_modes(ChargingmodesWrapper wrapper) {
		ChargingModesReport cm = new ChargingModesReport(Desc.API_VERSION, Desc.NAME);
		for (Chargingmodes c : wrapper.getRecords()) {
			cm.add(new ChargingMode(String.valueOf(c.getId()), c.getName(), c.getPower_kw()));
		}
		return cm;
	}

	@Converter
	public VehicleSupplyEquipmentReport evses(EvsesWrapper wrapper) {
		VehicleSupplyEquipmentReport vser = new VehicleSupplyEquipmentReport(Desc.API_VERSION, Desc.NAME);
		for (Evses e : wrapper.getRecords()) {
			vser.add(new VehicleSupplyEquipment(String.valueOf(e.getId()), e.getMake(), e.getModel(), e.getHardware_version(), e.getFirmware_version(), String.valueOf(e.getRegion_id())));
		}
		return vser;
	}

	@Converter
	public VehicleTypesReport evtypes(EvtypesWrapper wrapper) {
		VehicleTypesReport types = new VehicleTypesReport(Desc.API_VERSION, Desc.NAME);
		for (Evtypes e : wrapper.getRecords()) {
			types.add(new VehicleType(String.valueOf(e.getId()), e.getBrand(), e.getManufacturer(), Double.valueOf(e.getBattery_capacity_kwh()), e.getRange_max_km(), e.getRange_min_km()));
		}
		return types;
	}

	@Converter
	public ChargingStatesReport charging_states(ChargingstatesWrapper wrapper) {
		ChargingStatesReport cs = new ChargingStatesReport(Desc.API_VERSION, Desc.NAME);
		for (Chargingstates c : wrapper.getRecords()) {
			cs.add(new ChargingState(String.valueOf(c.getId()), c.isReq(), c.isResp(), c.isReq_state(), c.isIs_charging(), c.isIs_connected(), c.isBattery_full(), String.valueOf(c.getElectricvehicle_id()), String.valueOf(c.getEvse_id()),
					String.valueOf(c.getTimeslot_id()), String.valueOf(c.getChargingmode_id())));
		}
		return cs;
	}

	@Converter
	public VehiclesReport electric_vehicles(ElectricvehiclesWrapper wrapper) {
		VehiclesReport vehiclesReport = new VehiclesReport(Desc.API_VERSION, Desc.NAME);
		for (Electricvehicles e : wrapper.getRecords()) {
			vehiclesReport.add(new Vehicle(String.valueOf(e.getId()), String.valueOf(e.getEvtype_id())));
		}
		return vehiclesReport;
	}

	@Converter
	public ConnectionsReport connections(EvevseconnectionsWrapper wrapper) {
		ConnectionsReport c = new ConnectionsReport(Desc.API_VERSION, Desc.NAME);
		for (Evevseconnections e : wrapper.getRecords()) {
			c.add(new Connection(String.valueOf(e.getId()), date_convert(e.getStart()), e.getEnergy_kwh_current_min(), e.getEnergy_kwh_previous_min(), e.getDuration_s(), e.getConnection_total_kwh(), e.getRunning_total_kwh(), String
					.valueOf(e.getChargingmode_id()), String.valueOf(e.getEvse_id()), String.valueOf(e.getEvevseconnectionstate_id()), String.valueOf(e.getElectricvehicle_id())));
		}
		return c;
	}

	@Converter
	public ConnectionStatesReport connection_states(EvevseconnectionstatesWrapper wrapper) {
		ConnectionStatesReport cs = new ConnectionStatesReport(Desc.API_VERSION, Desc.NAME);
		for (Evevseconnectionstates e : wrapper.getRecords()) {
			cs.add(new ConnectionState(String.valueOf(e.getId()), e.getName(), String.valueOf(e.getCode())));
		}
		return cs;
	}

	@Converter
	public RegionalEnergyReport regional_energies(RegionalenergiesWrapper wrapper) {
		RegionalEnergyReport rer = new RegionalEnergyReport(Desc.API_VERSION, Desc.NAME);
		for (Regionalenergies r : wrapper.getRecords()) {
			rer.add(new RegionalEnergy(String.valueOf(r.getId()), Double.valueOf(r.getGenerated_energy_kwh()), Double.valueOf(r.getAggregated_energy_kwh()), Double.valueOf(r.getRequested_energy_kwh()), Double.valueOf(r
					.getActual_energy_kwh()), Double.valueOf(r.getForecasted_energy_kwh()), String.valueOf(r.getRegion_id()), String.valueOf(r.getTimeslot_id())));
		}
		return rer;
	}

	@Converter
	public RegionalEnergyAvgReport regional_energies_agg(RegionalaggevseenergiesWrapper wrapper) {
		RegionalEnergyAvgReport rear = new RegionalEnergyAvgReport(Desc.API_VERSION, Desc.NAME);
		for (Regionalaggevseenergies r : wrapper.getRecords()) {
			rear.add(new RegionalEnergyAvg(String.valueOf(r.getId()), Double.valueOf(r.getMax_possible_kwh()), Double.valueOf(r.getCurrent_kwh_in_use()), String.valueOf(r.getRegion_id())));
		}
		return rear;
	}

	@Converter
	public RegionsReport regions(RegionsWrapper wrapper) {
		RegionsReport regions = new RegionsReport(Desc.API_VERSION, Desc.NAME);
		for (Regions r : wrapper.getRecords()) {
			regions.add(new Region(String.valueOf(r.getId()), r.getName(), r.getCode(), r.getCountry()));
		}
		return regions;
	}

	@Converter
	public TimeslotsReport timeslots(TimeslotsWrapper wrapper) {
		TimeslotsReport tr = new TimeslotsReport(Desc.API_VERSION, Desc.NAME);
		for (Timeslots t : wrapper.getRecords()) {
			tr.add(new Timeslot(String.valueOf(t.getId()), date_convert(t.getStart()), t.getDuration_min()));
		}
		return tr;
	}

	@Converter
	public AuthResponse tokens(eu.finesce.trials.wp5.AuthResponse a) {
		AuthResponse ar = new AuthResponse(Desc.API_VERSION, Desc.NAME);
		ar.setExpires(token_date_convert(a.getToken_expires_at()));
		ar.setRefresh_token(a.getRefresh_token());
		ar.setRole(a.getRole());
		ar.setToken(a.getAuth_token());
		return ar;
	}

	private String token_date_convert(String date) {
		String ret = date.substring(0, 10) + "T" + date.substring(11, 19) + "+00:00";
		return ret;
	}

	private String date_convert(String date) {
		String ret = date.substring(0, 19) + "+00:00";
		return ret;
	}

}
