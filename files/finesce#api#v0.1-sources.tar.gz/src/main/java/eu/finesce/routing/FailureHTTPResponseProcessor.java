/*
 * Copyright 2015 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.routing;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.http.HttpOperationFailedException;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com> A processor to handle the
 *         errors from all trials
 */

public class FailureHTTPResponseProcessor implements Processor {

	private int		custom_http_code;
	private String	custom_http_message;

	public FailureHTTPResponseProcessor() {
		this.custom_http_code = 0;
		this.custom_http_message = null;
	}

	public FailureHTTPResponseProcessor(int custom_http_code, String custom_http_message) {
		this.custom_http_code = custom_http_code;
		this.custom_http_message = custom_http_message;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@Override
	public void process(Exchange exchange) throws Exception {
		Error error = new Error();
		try {
			HttpOperationFailedException exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, HttpOperationFailedException.class);
			error.setCode(exception.getStatusCode());
			error.setCustomMessage();
		} catch (Exception e) {
			if (this.custom_http_code != 0) {
				error.setCode(custom_http_code);
				if (this.custom_http_message != null) {
					error.setMesssage(this.custom_http_message);
				} else {
					error.setCustomMessage();
				}
			} else {
				error.setCode(401);
				error.setCustomMessage();
			}
		}
		exchange.getOut().setBody(error, Error.class);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, error.getCode());
	}

	/**
	 * @return the custom_http_code
	 */
	public int getCustom_http_code() {
		return custom_http_code;
	}

	/**
	 * @param custom_http_code
	 *            the custom_http_code to set
	 */
	public void setCustom_http_code(int custom_http_code) {
		this.custom_http_code = custom_http_code;
	}

	/**
	 * @return the custom_http_message
	 */
	public String getCustom_http_message() {
		return custom_http_message;
	}

	/**
	 * @param custom_http_message
	 *            the custom_http_message to set
	 */
	public void setCustom_http_message(String custom_http_message) {
		this.custom_http_message = custom_http_message;
	}

	/**
	 * A class to display all errors
	 * 
	 * @author Artemis Voulkidis <voulkidis@synelixis.com>
	 *
	 */
	class Error {

		private int		code;
		private String	messsage;

		public Error() {

		}

		public Error(int code, String messsage) {
			this.code = code;
			this.messsage = messsage;
		}

		public int getCode() {
			return code;
		}

		public void setCode(int code) {
			this.code = code;
		}

		public String getMesssage() {
			return messsage;
		}

		public void setMesssage(String messsage) {
			this.messsage = messsage;
		}

		public void setCustomMessage() {
			setMesssage(getCustomMessage());
		}

		public String getCustomMessage() {
			return getCustomMessage(getCode());
		}

		/**
		 * @param code
		 *            The status code to fetch information for
		 * @return A custom message to match the status code
		 */
		private String getCustomMessage(int status) {
			switch (status) {
				case 200:
					return "OK";
				case 204:
					return "No content has been returned.";
				case 400:
					return "Bad Request.";
				case 401:
					return "You do not have the permission to access this service";
				case 403:
					return "The server is refusing to respond.";
				case 404:
					return "The service you are looking for is not found in the remote service.";
				case 405:
					return "This HTTP method is not allowed for this service.";
				case 406:
					return "This Accept HTTP header is not allowed. Please check your settings.";
				case 408:
					return "The request timed out. Please try again later.";
				case 500:
					return "An internal server error occured. Please try again or contact administrator.";
				default:
					return "Error description unavailable";
			}
		}

		@Override
		public String toString() {
			return "{\n\t\"message\":\"" + this.getMesssage() + "\"\n}";
		}
	}

}
