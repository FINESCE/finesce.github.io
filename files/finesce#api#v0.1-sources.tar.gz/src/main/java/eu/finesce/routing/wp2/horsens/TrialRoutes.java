/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.routing.wp2.horsens;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http.HttpOperationFailedException;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

import eu.finesce.api.authentication.AuthRefresh;
import eu.finesce.api.authentication.AuthRequest;
import eu.finesce.api.authentication.AuthResponse;
import eu.finesce.api.buildings.reports.Buildings;
import eu.finesce.api.electric_vehicles.reports.VehiclesReport;
import eu.finesce.api.generic.MeasurementReport;
import eu.finesce.api.generic.MeasurementTypesReport;
import eu.finesce.routing.FailureHTTPResponseProcessor;
import eu.finesce.trials.wp2.horsens.HorsensBuildingsWrapper;
import eu.finesce.trials.wp2.horsens.HorsensMeasurementsList;
import eu.finesce.trials.wp2.horsens.HorsensMeasurementTypesWrapper;
import eu.finesce.trials.wp2.horsens.HorsensMeasurementWrapper;
import eu.finesce.trials.wp2.horsens.HorsensVehiclesWrapper;
import eu.finesce.trials.wp2.horsens.OAuthentication;

/**
 *
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 */
public class TrialRoutes extends RouteBuilder {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.camel.builder.RouteBuilder#configure()
	 */
	@Override
	public void configure() throws Exception {
		restConfiguration().component("servlet").bindingMode(RestBindingMode.json_xml).dataFormatProperty("prettyPrint", "true");

		onException(HttpOperationFailedException.class).handled(true).process(new FailureHTTPResponseProcessor());

		// TOKEN handling
		rest("/" + Desc.NAME + "/tokens").post().description("Retrieve authentication tokens").type(AuthRequest.class).outType(AuthResponse.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				AuthRequest auth = exchange.getIn().getBody(AuthRequest.class);
				if (auth == null || auth.getAuthorization_id() == null || auth.getPassword() == null) {
					auth = new AuthRequest("", "");
				}
				exchange.getOut().setBody(
						"grant_type=password&client_id=finesce-api&client_secret=4kYdbeNd/qIc5bcatlsid1urbHGME/zyxS3CazfaxLJRAIM6vMvPys4WoBsCTPDJom2zjntYkwWhkGtmLqslSA==" + "&username=" + auth.getAuthorization_id() + "&password="
								+ auth.getPassword(), String.class);
				exchange.getOut().setHeader("Content-Type", "application/x-www-form-urlencoded");
			}
		}).to(Desc.AUTH_URL).unmarshal().json(JsonLibrary.Jackson, OAuthentication.class).to("bean:wp2ServiceHorsens?method=tokens").endRest()

		.post("/refresh").description("Refresh an authentication token").type(AuthRefresh.class).outType(AuthResponse.class).route().process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				AuthRefresh auth = exchange.getIn().getBody(AuthRefresh.class);
				if (auth == null || auth.getRefresh_token() == "") {
					auth = new AuthRefresh("");
				}
				exchange.getOut().setBody("grant_type=refresh_token&client_id=finesce-api&client_secret=4kYdbeNd/qIc5bcatlsid1urbHGME/zyxS3CazfaxLJRAIM6vMvPys4WoBsCTPDJom2zjntYkwWhkGtmLqslSA==&refresh_token=" + auth.getRefresh_token(),
						String.class);
				exchange.getOut().setHeader("Content-Type", "application/x-www-form-urlencoded");
			}
		}).to(Desc.AUTH_URL).unmarshal().json(JsonLibrary.Jackson, OAuthentication.class).to("bean:wp2ServiceHorsens?method=tokens");

		// Buildings
		rest("/" + Desc.NAME + "/buildings")
				.get()
				.description("Provides the list of buildings available")
				.outType(Buildings.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.to(Desc.BASE_URL + Desc.BUILDINGS_URL)
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensBuildingsWrapper.class)
				.to("bean:wp2ServiceHorsens?method=buildings")
				.endRest()

				.get("/measurement_types")
				.description("Provides a detailed list of all the available building measurements types in the trial")
				.outType(MeasurementTypesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.to(Desc.BASE_URL + Desc.BUILDINGS_URL + "/measurement_types")
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementTypesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurement_types")
				.endRest()

				.get("/measurement_types/type/{type}")
				.description(
						"Provides a detailed list of all the available measurements types that match a specific measurements type. A valid {type} can be obtained by calling the /buildings/measurement_types service and check the 'type' attribute of the answer.")
				.outType(MeasurementTypesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("type", exchange.getIn().getHeader("type", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.recipientList(simple(Desc.BASE_URL + Desc.BUILDINGS_URL + "/measurement_types/type/${in.headers.type}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementTypesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurement_types")
				.endRest()

				.get("/measurement_types/id/{id}")
				.description("Provides a detailed list of all the available measurements types that match a specific measurements type name. A valid {id} can be obtained by calling the /buildings/measurement_types service.")
				.outType(MeasurementTypesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.recipientList(simple(Desc.BASE_URL + Desc.BUILDINGS_URL + "/measurement_types/id/${in.headers.id}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementTypesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurement_types")
				.endRest()

				.get("/{id}")
				.description("Provides information regarding a single building.A valid {id} can be obtained by the /buildings service.")
				.outType(Buildings.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.recipientList(simple(Desc.BASE_URL + Desc.BUILDINGS_URL + "/${in.headers.id}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensBuildingsWrapper.class)
				.to("bean:wp2ServiceHorsens?method=buildings")
				.endRest()

				.get("/{id}/measurement_types")
				.description("Provides information regarding the available measurements types for the specific building.A valid {id} can be obtained by the /buildings service.")
				.outType(MeasurementTypesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.recipientList(simple(Desc.BASE_URL + Desc.BUILDINGS_URL + "/${in.headers.id}/measurement_types"))
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementTypesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurement_types")
				.endRest()

				.get("/{id}/measurements/{type_id}/{from}/{to}")
				.description(
						"Provides information regarding the available measurements of a specific type for a specific building, during a certain period of time. A valid {id} can be obtained by calling the /buildings service. A valid {type_id} can be obtained by calling the /buildings service and check the 'measurement_points' section of the answer. Valid {from} and {to} values are expressed in ISO8601 format.")
				.outType(MeasurementReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("type_id", exchange.getIn().getHeader("type_id", String.class));
						exchange.getOut().setHeader("from", exchange.getIn().getHeader("from", String.class));
						exchange.getOut().setHeader("to", exchange.getIn().getHeader("to", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).recipientList(simple(Desc.BASE_URL + Desc.BUILDINGS_URL + "/${in.headers.id}/measurements/${in.headers.type_id}/${in.headers.from}/${in.headers.to}")).unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementWrapper.class).to("bean:wp2ServiceHorsens?method=measurements").endRest();

		// VehiclesReport
		rest("/" + Desc.NAME + "/vehicles")
				.get()
				.description("Provides the list of vehicles available")
				.outType(VehiclesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.to(Desc.BASE_URL + Desc.VEHICLES_URL)
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensVehiclesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=vehicles")
				.endRest()

				.get("/measurement_types")
				.description("Provides a detailed list of all the available vehicle measurements types in the trial")
				.outType(MeasurementTypesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.to(Desc.BASE_URL + Desc.VEHICLES_URL + "/measurement_types")
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementTypesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurement_types")
				.endRest()

				.get("/measurement_types/type/{type}")
				.description(
						"Provides a detailed list of all the available measurements types that match a specific measurements type. A valid {type} can be obtained by calling the /vehicles/measurement_types service and check the 'type' entries.")
				.outType(MeasurementTypesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("type", exchange.getIn().getHeader("type", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.recipientList(simple(Desc.BASE_URL + Desc.VEHICLES_URL + "/measurement_types/type/${in.headers.type}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementTypesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurement_types")
				.endRest()

				.get("/measurement_types/id/{id}")
				.description("Provides a detailed list of all the available measurements types that match a specific measurements type name. A valid {id} can be obtained by calling the /vehicles/measurement_types service.")
				.outType(MeasurementTypesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.recipientList(simple(Desc.BASE_URL + Desc.VEHICLES_URL + "/measurement_types/id/${in.headers.id}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementTypesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurement_types")
				.endRest()

				.get("/{id}")
				.description("Provides information regarding a single vehicle. A valid {id} can be found by calling the /vehicles service.")
				.outType(VehiclesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.recipientList(simple(Desc.BASE_URL + Desc.VEHICLES_URL + "/${in.headers.id}"))
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensVehiclesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=vehicles")
				.endRest()

				.get("/{id}/measurement_types")
				.description("Provides information regarding the available measurements types for the specific vehicle. A valid {id} can be obtained by calling the /vehicles service.")
				.outType(MeasurementTypesReport.class)
				.route()
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				})
				.recipientList(simple(Desc.BASE_URL + Desc.VEHICLES_URL + "/${in.headers.id}/measurement_types"))
				.unmarshal()
				.json(JsonLibrary.Jackson, HorsensMeasurementTypesWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurement_types")
				.endRest()

				.get("/{id}/measurements/{type_id}/{from}/{to}")
				.description(
						"Provides information regarding the available measurements of a specific type for a specific vehicle, during a certain period of time. A valid {id} can be obtained by calling the /vehicles service. A valid {type_id} can be obtained by calling the /vehicles service and check the 'measurement_points' section of the answer. Valid {from} and {to} values are expressed in ISO8601 format.")
				.outType(MeasurementReport.class).route().process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getOut().setHeader("Authorization", "Bearer " + exchange.getIn().getHeader("x-auth-token"));
						exchange.getOut().setHeader("id", exchange.getIn().getHeader("id", String.class));
						exchange.getOut().setHeader("type_id", exchange.getIn().getHeader("type_id", String.class));
						exchange.getOut().setHeader("from", exchange.getIn().getHeader("from", String.class));
						exchange.getOut().setHeader("to", exchange.getIn().getHeader("to", String.class));
						exchange.getOut().setHeader("Content-Type", "application/json");
						exchange.getOut().setHeader("Accept", "application/json");
					}
				}).recipientList(simple(Desc.BASE_URL + Desc.VEHICLES_URL + "/${in.headers.id}/measurements/${in.headers.type_id}/${in.headers.from}/${in.headers.to}")).unmarshal().json(JsonLibrary.Jackson, HorsensMeasurementWrapper.class)
				.to("bean:wp2ServiceHorsens?method=measurements").endRest();
	}
}
