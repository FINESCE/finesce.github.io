/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.trials.wp5;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class Chargingstates {

	private int		id;
	private boolean	req;
	private boolean	resp;
	private boolean	req_state;
	private boolean	is_charging;
	private boolean	is_connected;
	private boolean	battery_full;
	private int		electricvehicle_id;
	private int		evse_id;
	private int		timeslot_id;
	private int		chargingmode_id;
	private String	created_at;
	private String	updated_at;

	/**
	 * 
	 */
	public Chargingstates() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param req
	 * @param resp
	 * @param req_state
	 * @param is_charging
	 * @param is_connected
	 * @param battery_full
	 * @param electricvehicle_id
	 * @param evse_id
	 * @param timeslot_id
	 * @param chargingmode_id
	 * @param created_at
	 * @param updated_at
	 */
	public Chargingstates(int id, boolean req, boolean resp, boolean req_state, boolean is_charging, boolean is_connected, boolean battery_full, int electricvehicle_id, int evse_id, int timeslot_id, int chargingmode_id, String created_at,
			String updated_at) {
		super();
		this.id = id;
		this.req = req;
		this.resp = resp;
		this.req_state = req_state;
		this.is_charging = is_charging;
		this.is_connected = is_connected;
		this.battery_full = battery_full;
		this.electricvehicle_id = electricvehicle_id;
		this.evse_id = evse_id;
		this.timeslot_id = timeslot_id;
		this.chargingmode_id = chargingmode_id;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isReq() {
		return req;
	}

	public void setReq(boolean req) {
		this.req = req;
	}

	public boolean isResp() {
		return resp;
	}

	public void setResp(boolean resp) {
		this.resp = resp;
	}

	public boolean isReq_state() {
		return req_state;
	}

	public void setReq_state(boolean req_state) {
		this.req_state = req_state;
	}

	public boolean isIs_charging() {
		return is_charging;
	}

	public void setIs_charging(boolean is_charging) {
		this.is_charging = is_charging;
	}

	public boolean isIs_connected() {
		return is_connected;
	}

	public void setIs_connected(boolean is_connected) {
		this.is_connected = is_connected;
	}

	public boolean isBattery_full() {
		return battery_full;
	}

	public void setBattery_full(boolean battery_full) {
		this.battery_full = battery_full;
	}

	public int getElectricvehicle_id() {
		return electricvehicle_id;
	}

	public void setElectricvehicle_id(int electricvehicle_id) {
		this.electricvehicle_id = electricvehicle_id;
	}

	public int getEvse_id() {
		return evse_id;
	}

	public void setEvse_id(int evse_id) {
		this.evse_id = evse_id;
	}

	public int getTimeslot_id() {
		return timeslot_id;
	}

	public void setTimeslot_id(int timeslot_id) {
		this.timeslot_id = timeslot_id;
	}

	public int getChargingmode_id() {
		return chargingmode_id;
	}

	public void setChargingmode_id(int chargingmode_id) {
		this.chargingmode_id = chargingmode_id;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

}
