/*
 * Copyright 2015 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.trials.wp1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class MalmoPrice {

	private MalmoMetadata	__metadata;
	private String			id;
	private String			region;
	private String			nordpool_Id;
	private String			dateTime;
	private String			currency;
	private String			electricityCost;
	private String			heatingCost;
	private String			coolingCost;

	public MalmoPrice() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param __metadata
	 * @param id
	 * @param region
	 * @param nordpool_Id
	 * @param dateTime
	 * @param currency
	 * @param electricityCost
	 * @param heatingCost
	 * @param coolingCost
	 */
	public MalmoPrice(MalmoMetadata __metadata, String id, String region, String nordpool_Id, String dateTime, String currency, String electricityCost, String heatingCost, String coolingCost) {
		super();
		this.__metadata = __metadata;
		this.id = id;
		this.region = region;
		this.nordpool_Id = nordpool_Id;
		this.dateTime = dateTime;
		this.currency = currency;
		this.electricityCost = electricityCost;
		this.heatingCost = heatingCost;
		this.coolingCost = coolingCost;
	}

	public MalmoMetadata get__metadata() {
		return __metadata;
	}

	public void set__metadata(MalmoMetadata __metadata) {
		this.__metadata = __metadata;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getNordpool_Id() {
		return nordpool_Id;
	}

	public void setNordpool_Id(String nordpool_Id) {
		this.nordpool_Id = nordpool_Id;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getElectricityCost() {
		return electricityCost;
	}

	public void setElectricityCost(String electricityCost) {
		this.electricityCost = electricityCost;
	}

	public String getHeatingCost() {
		return heatingCost;
	}

	public void setHeatingCost(String heatingCost) {
		this.heatingCost = heatingCost;
	}

	public String getCoolingCost() {
		return coolingCost;
	}

	public void setCoolingCost(String coolingCost) {
		this.coolingCost = coolingCost;
	}

}
