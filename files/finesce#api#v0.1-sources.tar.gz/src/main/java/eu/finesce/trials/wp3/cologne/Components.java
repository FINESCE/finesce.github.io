package eu.finesce.trials.wp3.cologne;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Components {

	List<SingleComponent>	consumption;
	List<SingleComponent>	generation;

	public Components() {
		// TODO Auto-generated constructor stub
	}

	public List<SingleComponent> getConsumption() {
		return consumption;
	}

	public void setConsumption(List<SingleComponent> consumption) {
		this.consumption = consumption;
	}

	public List<SingleComponent> getGeneration() {
		return generation;
	}

	public void setGeneration(List<SingleComponent> generation) {
		this.generation = generation;
	}

}
