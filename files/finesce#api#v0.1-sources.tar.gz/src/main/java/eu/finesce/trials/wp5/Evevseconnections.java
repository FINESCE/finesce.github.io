/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.trials.wp5;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class Evevseconnections {

	private int		id;
	private String	start;
	private double	energy_kwh_current_min;
	private double	energy_kwh_previous_min;
	private int		duration_s;
	private double	connection_total_kwh;
	private double	running_total_kwh;
	private int		chargingmode_id;
	private int		evevseconnectionstate_id;
	private int		evse_id;
	private int		electricvehicle_id;
	private String	created_at;
	private String	updated_at;

	/**
	 * 
	 */
	public Evevseconnections() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param start
	 * @param energy_kwh_current_min
	 * @param energy_kwh_previous_min
	 * @param duration_s
	 * @param connection_total_kwh
	 * @param running_total_kwh
	 * @param chargingmode_id
	 * @param evevseconnectionstate_id
	 * @param evse_id
	 * @param electricvehicle_id
	 * @param created_at
	 * @param updated_at
	 */
	public Evevseconnections(int id, String start, double energy_kwh_current_min, double energy_kwh_previous_min, int duration_s, double connection_total_kwh, double running_total_kwh, int chargingmode_id, int evevseconnectionstate_id,
			int evse_id, int electricvehicle_id, String created_at, String updated_at) {
		super();
		this.id = id;
		this.start = start;
		this.energy_kwh_current_min = energy_kwh_current_min;
		this.energy_kwh_previous_min = energy_kwh_previous_min;
		this.duration_s = duration_s;
		this.connection_total_kwh = connection_total_kwh;
		this.running_total_kwh = running_total_kwh;
		this.chargingmode_id = chargingmode_id;
		this.evevseconnectionstate_id = evevseconnectionstate_id;
		this.evse_id = evse_id;
		this.electricvehicle_id = electricvehicle_id;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public double getEnergy_kwh_current_min() {
		return energy_kwh_current_min;
	}

	public void setEnergy_kwh_current_min(double energy_kwh_current_min) {
		this.energy_kwh_current_min = energy_kwh_current_min;
	}

	public double getEnergy_kwh_previous_min() {
		return energy_kwh_previous_min;
	}

	public void setEnergy_kwh_previous_min(double energy_kwh_previous_min) {
		this.energy_kwh_previous_min = energy_kwh_previous_min;
	}

	public int getDuration_s() {
		return duration_s;
	}

	public void setDuration_s(int duration_s) {
		this.duration_s = duration_s;
	}

	public double getConnection_total_kwh() {
		return connection_total_kwh;
	}

	public void setConnection_total_kwh(double connection_total_kwh) {
		this.connection_total_kwh = connection_total_kwh;
	}

	public double getRunning_total_kwh() {
		return running_total_kwh;
	}

	public void setRunning_total_kwh(double running_total_kwh) {
		this.running_total_kwh = running_total_kwh;
	}

	public int getChargingmode_id() {
		return chargingmode_id;
	}

	public void setChargingmode_id(int chargingmode_id) {
		this.chargingmode_id = chargingmode_id;
	}

	public int getEvevseconnectionstate_id() {
		return evevseconnectionstate_id;
	}

	public void setEvevseconnectionstate_id(int evevseconnectionstate_id) {
		this.evevseconnectionstate_id = evevseconnectionstate_id;
	}

	public int getEvse_id() {
		return evse_id;
	}

	public void setEvse_id(int evse_id) {
		this.evse_id = evse_id;
	}

	public int getElectricvehicle_id() {
		return electricvehicle_id;
	}

	public void setElectricvehicle_id(int electricvehicle_id) {
		this.electricvehicle_id = electricvehicle_id;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

}
