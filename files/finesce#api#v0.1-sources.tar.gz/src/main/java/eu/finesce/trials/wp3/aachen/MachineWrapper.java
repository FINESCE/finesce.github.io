package eu.finesce.trials.wp3.aachen;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class MachineWrapper {

	@XmlElement(name="machines")
	private List<Machine>	machines;

	public MachineWrapper() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param machines
	 */
	public MachineWrapper(List<Machine> machines) {
		super();
		this.machines = machines;
	}

	public List<Machine> getMachines() {
		return machines;
	}

	public void setMachines(List<Machine> machines) {
		this.machines = machines;
	}

}
