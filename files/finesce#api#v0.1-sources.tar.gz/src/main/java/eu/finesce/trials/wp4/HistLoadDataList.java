package eu.finesce.trials.wp4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "histLoadDataList")
@XmlAccessorType(XmlAccessType.FIELD)
public class HistLoadDataList {
	@XmlElement(required = true)
	private long	loadSampleDate;

	@XmlElement(required = true)
	private int		sampleNumber;

	@XmlElement(required = true)
	private double	upstreamActivePowerEUA;

	@XmlElement(required = true)
	private double	reactiveInductivePowerEEI;

	@XmlElement(required = true)
	private double	reactiveCapacitivePowerEEC;

	@XmlElement(required = true)
	private double	downstreamActivePowerEEA;

	@XmlElement(required = true)
	private double	reactiveInductivePowerEUI;

	@XmlElement(required = true)
	private double	reactiveCapacitivePowerEUC;

	@XmlElement(required = true)
	private String	meterID;

	public HistLoadDataList() {
	};

	public long getLoadSampleDate() {
		return loadSampleDate;
	}

	public void setLoadSampleDate(long loadSampleDate) {
		this.loadSampleDate = loadSampleDate;
	}

	public int getSampleNumber() {
		return sampleNumber;
	}

	public void setSampleNumber(int sampleNumber) {
		this.sampleNumber = sampleNumber;
	}

	public double getUpstreamActivePowerEUA() {
		return upstreamActivePowerEUA;
	}

	public void setUpstreamActivePowerEUA(double upstreamActivePowerEUA) {
		this.upstreamActivePowerEUA = upstreamActivePowerEUA;
	}

	public double getReactiveInductivePowerEEI() {
		return reactiveInductivePowerEEI;
	}

	public void setReactiveInductivePowerEEI(double reactiveInductivePowerEEI) {
		this.reactiveInductivePowerEEI = reactiveInductivePowerEEI;
	}

	public double getReactiveCapacitivePowerEEC() {
		return reactiveCapacitivePowerEEC;
	}

	public void setReactiveCapacitivePowerEEC(double reactiveCapacitivePowerEEC) {
		this.reactiveCapacitivePowerEEC = reactiveCapacitivePowerEEC;
	}

	public double getDownstreamActivePowerEEA() {
		return downstreamActivePowerEEA;
	}

	public void setDownstreamActivePowerEEA(double downstreamActivePowerEEA) {
		this.downstreamActivePowerEEA = downstreamActivePowerEEA;
	}

	public double getReactiveInductivePowerEUI() {
		return reactiveInductivePowerEUI;
	}

	public void setReactiveInductivePowerEUI(double reactiveInductivePowerEUI) {
		this.reactiveInductivePowerEUI = reactiveInductivePowerEUI;
	}

	public double getReactiveCapacitivePowerEUC() {
		return reactiveCapacitivePowerEUC;
	}

	public void setReactiveCapacitivePowerEUC(double reactiveCapacitivePowerEUC) {
		this.reactiveCapacitivePowerEUC = reactiveCapacitivePowerEUC;
	}

	/**
	 * @return the meterID
	 */
	public String getMeterID() {
		return meterID;
	}

	/**
	 * @param meterID
	 *            the meterID to set
	 */
	public void setMeterID(String meterID) {
		this.meterID = meterID;
	}
}
