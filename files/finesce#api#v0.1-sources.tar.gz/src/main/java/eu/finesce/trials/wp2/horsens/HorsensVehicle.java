/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.trials.wp2.horsens;

import java.util.Map;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class HorsensVehicle {

	private String				id;
	private String				type;
	private Map<String, String>	measurement_points;
	private Map<String, String>	related_entities;

	/**
	 * 
	 */
	public HorsensVehicle() {
		// TODO Auto-generated constructor stub
	}

	public HorsensVehicle(String id, String type, Map<String, String> measurement_points, Map<String, String> related_entities) {
		this.id = id;
		this.type = type;
		this.measurement_points = measurement_points;
		this.related_entities = related_entities;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Map<String, String> getMeasurement_points() {
		return measurement_points;
	}

	public void setMeasurement_points(Map<String, String> measurement_points) {
		this.measurement_points = measurement_points;
	}

	public Map<String, String> getRelated_entities() {
		return related_entities;
	}

	public void setRelated_entities(Map<String, String> related_entities) {
		this.related_entities = related_entities;
	}

}
