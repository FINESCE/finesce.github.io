package eu.finesce.trials.wp2.madrid;

public class BasicResourceExt extends BasicResource {

	private String	idsensor;

	public BasicResourceExt() {
		super();
	}

	/**
	 * @param parameter
	 * @param value
	 * @param timestamp
	 * @param entity
	 * @param scope
	 * @param idsensor
	 */
	public BasicResourceExt(String parameter, String value, String timestamp, String entity, String scope, String idsensor) {
		super(parameter, value, timestamp, entity, scope);
		this.idsensor = idsensor;
	}

	public String getIdsensor() {
		return this.idsensor;
	}

	public void setIdsensor(String idsensor) {
		this.idsensor = idsensor;
	}

}