package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Regionalenergies;

public class RegionalenergiesWrapper extends Wrapper<Regionalenergies> {

	/**
	 * 
	 */
	public RegionalenergiesWrapper() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param totalrecords
	 * @param records
	 */
	public RegionalenergiesWrapper(int totalrecords, List<Regionalenergies> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
