package eu.finesce.trials.wp2.madrid;

import java.util.List;

public class WSNWrapper {

	private List<BasicResourceExt>	wsn;

	public WSNWrapper() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param wsn
	 */
	public WSNWrapper(List<BasicResourceExt> wsn) {
		super();
		this.wsn = wsn;
	}

	public List<BasicResourceExt> getWsn() {
		return wsn;
	}

	public void setWsn(List<BasicResourceExt> wsn) {
		this.wsn = wsn;
	}

}
