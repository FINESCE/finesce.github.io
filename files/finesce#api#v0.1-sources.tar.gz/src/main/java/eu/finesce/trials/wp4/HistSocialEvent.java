package eu.finesce.trials.wp4;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "histSocialEvent")
@XmlAccessorType(XmlAccessType.FIELD)
public class HistSocialEvent {

	@XmlElement(required = true)
	private long				lastEventNumber;

	@XmlElement(required = true)
	private long				currentTime;

	@XmlElement(name = "HistSocialEventList", type = HistSocialEventList.class)
	List<HistSocialEventList>	socialeventList;

	public HistSocialEvent() {
	};

	/**
	 * @return the lastEventNumber
	 */
	public Long getLastEventNumber() {
		return lastEventNumber;
	}

	/**
	 * @param lastEventNumber
	 *            the lastEventNumber to set
	 */
	public void setLastEventNumber(Long lastEventNumber) {
		this.lastEventNumber = lastEventNumber;
	}

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * @return the socialeventList
	 */
	public List<HistSocialEventList> getSocialeventList() {
		return socialeventList;
	}

	/**
	 * @param socialeventList
	 *            the socialeventList to set
	 */
	public void setSocialeventList(List<HistSocialEventList> socialeventList) {
		this.socialeventList = socialeventList;
	}

}
