package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Chargingmodes;

public class ChargingmodesWrapper extends Wrapper<Chargingmodes> {

	public ChargingmodesWrapper() {
		// TODO Auto-generated constructor stub
	}

	public ChargingmodesWrapper(int totalrecords, List<Chargingmodes> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
