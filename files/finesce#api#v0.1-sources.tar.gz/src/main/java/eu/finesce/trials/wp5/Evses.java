/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.trials.wp5;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class Evses {

	private int		id;
	private String	make;
	private String	model;
	private String	hardware_version;
	private String	firmware_version;
	private int		region_id;
	private String	created_at;
	private String	updated_at;

	/**
	 * 
	 */
	public Evses() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getHardware_version() {
		return hardware_version;
	}

	public void setHardware_version(String hardware_version) {
		this.hardware_version = hardware_version;
	}

	public String getFirmware_version() {
		return firmware_version;
	}

	public void setFirmware_version(String firmware_version) {
		this.firmware_version = firmware_version;
	}

	public int getRegion_id() {
		return region_id;
	}

	public void setRegion_id(int region_id) {
		this.region_id = region_id;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

	/**
	 * @param id
	 * @param make
	 * @param model
	 * @param hardware_version
	 * @param firmware_version
	 * @param region_id
	 * @param created_at
	 * @param updated_at
	 */
	public Evses(int id, String make, String model, String hardware_version, String firmware_version, int region_id, String created_at, String updated_at) {
		super();
		this.id = id;
		this.make = make;
		this.model = model;
		this.hardware_version = hardware_version;
		this.firmware_version = firmware_version;
		this.region_id = region_id;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}

}
