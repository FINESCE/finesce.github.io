package eu.finesce.trials.wp4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "MeterDetailsListPublic")
@XmlAccessorType(XmlAccessType.FIELD)
public class MeterDetailsList {

	private String	customerId;
	private String	sector;
	private String	userPower;
	private String	producerPower;
	private boolean	isDomestic;
	private String	phase;
	private long	currentTime;
	private String	reading;
	private boolean	isRegistered;
	private int		kNewMeter;
	private String	newMeter;

	public MeterDetailsList() {
	}

	public MeterDetailsList(String customerId, String sector, String userPower, String producerPower, boolean isDomestic, String phase, long currentTime, String reading, boolean isRegistered, int kNewMeter, String newMeter) {
		this.customerId = customerId;
		this.sector = sector;
		this.userPower = userPower;
		this.producerPower = producerPower;
		this.isDomestic = isDomestic;
		this.phase = phase;
		this.currentTime = currentTime;
		this.reading = reading;
		this.isRegistered = isRegistered;
		this.kNewMeter = kNewMeter;
		this.newMeter = newMeter;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the sector
	 */
	public String getSector() {
		return sector;
	}

	/**
	 * @param sector
	 *            the sector to set
	 */
	public void setSector(String sector) {
		this.sector = sector;
	}

	/**
	 * @return the userPower
	 */
	public String getUserPower() {
		return userPower;
	}

	/**
	 * @param userPower
	 *            the userPower to set
	 */
	public void setUserPower(String userPower) {
		this.userPower = userPower;
	}

	/**
	 * @return the producerPower
	 */
	public String getProducerPower() {
		return producerPower;
	}

	/**
	 * @param producerPower
	 *            the producerPower to set
	 */
	public void setProducerPower(String producerPower) {
		this.producerPower = producerPower;
	}

	/**
	 * @return the isDomestic
	 */
	public boolean isDomestic() {
		return isDomestic;
	}

	/**
	 * @param isDomestic
	 *            the isDomestic to set
	 */
	public void setDomestic(boolean isDomestic) {
		this.isDomestic = isDomestic;
	}

	/**
	 * @return the phase
	 */
	public String getPhase() {
		return phase;
	}

	/**
	 * @param phase
	 *            the phase to set
	 */
	public void setPhase(String phase) {
		this.phase = phase;
	}

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * @return the reading
	 */
	public String getReading() {
		return reading;
	}

	/**
	 * @param reading
	 *            the reading to set
	 */
	public void setReading(String reading) {
		this.reading = reading;
	}

	/**
	 * @return the isRegistered
	 */
	public boolean isRegistered() {
		return isRegistered;
	}

	/**
	 * @param isRegistered
	 *            the isRegistered to set
	 */
	public void setRegistered(boolean isRegistered) {
		this.isRegistered = isRegistered;
	}

	/**
	 * @return the kNewMeter
	 */
	public int getkNewMeter() {
		return kNewMeter;
	}

	/**
	 * @param kNewMeter
	 *            the kNewMeter to set
	 */
	public void setkNewMeter(int kNewMeter) {
		this.kNewMeter = kNewMeter;
	}

	/**
	 * @return the newMeter
	 */
	public String getNewMeter() {
		return newMeter;
	}

	/**
	 * @param newMeter
	 *            the newMeter to set
	 */
	public void setNewMeter(String newMeter) {
		this.newMeter = newMeter;
	}
}
