package eu.finesce.trials.wp5;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Regionalaggevseenergies {

	private int		id;
	private String	max_possible_kwh;
	private String	current_kwh_in_use;
	private int		region_id;
	private String	created_at;
	private String	updated_at;

	public Regionalaggevseenergies() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param max_possible_kwh
	 * @param current_kwh_in_use
	 * @param region_id
	 * @param created_at
	 * @param updated_at
	 */
	public Regionalaggevseenergies(int id, String max_possible_kwh, String current_kwh_in_use, int region_id, String created_at, String updated_at) {
		super();
		this.id = id;
		this.max_possible_kwh = max_possible_kwh;
		this.current_kwh_in_use = current_kwh_in_use;
		this.region_id = region_id;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMax_possible_kwh() {
		return max_possible_kwh;
	}

	public void setMax_possible_kwh(String max_possible_kwh) {
		this.max_possible_kwh = max_possible_kwh;
	}

	public String getCurrent_kwh_in_use() {
		return current_kwh_in_use;
	}

	public void setCurrent_kwh_in_use(String current_kwh_in_use) {
		this.current_kwh_in_use = current_kwh_in_use;
	}

	public int getRegion_id() {
		return region_id;
	}

	public void setRegion_id(int region_id) {
		this.region_id = region_id;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

}
