package eu.finesce.trials.wp2.madrid;

import java.util.List;

public class MeteoWrapper {

	private List<BasicResource>	meteo;

	public MeteoWrapper() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param meteo
	 */
	public MeteoWrapper(List<BasicResource> meteo) {
		super();
		this.meteo = meteo;
	}

	public List<BasicResource> getMeteo() {
		return meteo;
	}

	public void setMeteo(List<BasicResource> meteo) {
		this.meteo = meteo;
	}

}
