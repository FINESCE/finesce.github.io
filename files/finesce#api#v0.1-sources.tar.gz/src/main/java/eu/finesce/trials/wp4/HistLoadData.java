package eu.finesce.trials.wp4;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "histLoadData")
@XmlAccessorType(XmlAccessType.FIELD)
public class HistLoadData {

	public HistLoadData() {
	}

//	Smart Meters Type = all; single meter; commercial; industrial
	@XmlElement(required = true)
	private String			smType;

// 	Horizon Data Load = 24H / 12H / 6H / 3H / 1H
	@XmlElement(required = true)
	private String			horizonLoad;

	@XmlElement(required = true)
	private long			startDateTime;

	@XmlElement(required = true)
	private long			endDateTime;

	@XmlElement(required = true)
	private long			currentTime;

	@XmlElement(name = "LoadDataList", type = HistLoadDataList.class)
	List<HistLoadDataList>	loaddataList;

	/**
	 * @return the smType
	 */
	public String getSmType() {
		return smType;
	}

	/**
	 * @param smType
	 *            the smType to set
	 */
	public void setSmType(String smType) {
		this.smType = smType;
	}

	/**
	 * @return the horizonLoad
	 */
	public String getHorizonLoad() {
		return horizonLoad;
	}

	/**
	 * @param horizonLoad
	 *            the horizonLoad to set
	 */
	public void setHorizonLoad(String horizonLoad) {
		this.horizonLoad = horizonLoad;
	}

	/**
	 * @return the starDateTime
	 */
	public long getStartDateTime() {
		return startDateTime;
	}

	/**
	 * @param starDateTime
	 *            the starDateTime to set
	 */
	public void setStartDateTime(long startDateTime) {
		this.startDateTime = startDateTime;
	}

	/**
	 * @return the endDateTime
	 */
	public long getEndDateTime() {
		return endDateTime;
	}

	/**
	 * @param endDateTime
	 *            the endDateTime to set
	 */
	public void setEndDateTime(long endDateTime) {
		this.endDateTime = endDateTime;
	}

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * @return the loaddataList
	 */
	public List<HistLoadDataList> getLoaddataList() {
		return loaddataList;
	}

	/**
	 * @param loaddataList
	 *            the loaddataList to set
	 */
	public void setLoaddataList(List<HistLoadDataList> loaddataList) {
		this.loaddataList = loaddataList;
	}

}
