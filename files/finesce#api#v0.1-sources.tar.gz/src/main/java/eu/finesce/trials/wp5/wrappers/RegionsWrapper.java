package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Regions;

public class RegionsWrapper extends Wrapper<Regions> {

	/**
	 * 
	 */
	public RegionsWrapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param totalrecords
	 * @param records
	 */
	public RegionsWrapper(int totalrecords, List<Regions> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
