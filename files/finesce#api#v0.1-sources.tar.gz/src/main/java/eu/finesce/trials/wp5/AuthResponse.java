/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.trials.wp5;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class AuthResponse {
	private String	auth_token;
	private String	role;
	private String	token_expires_at;
	private String	refresh_token;

	/**
	 * @param auth_token
	 * @param role
	 * @param token_expires_at
	 * @param refresh_token
	 */
	public AuthResponse(String auth_token, String role, String token_expires_at, String refresh_token) {
		this.auth_token = auth_token;
		this.role = role;
		this.token_expires_at = token_expires_at;
		this.refresh_token = refresh_token;
	}

	public AuthResponse() {
	}

	/**
	 * @return the auth_token
	 */
	public String getAuth_token() {
		return auth_token;
	}

	/**
	 * @param auth_token
	 *            the auth_token to set
	 */
	public void setAuth_token(String auth_token) {
		this.auth_token = auth_token;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role
	 *            the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @return the token_expires_at
	 */
	public String getToken_expires_at() {
		return token_expires_at;
	}

	/**
	 * @param token_expires_at
	 *            the token_expires_at to set
	 */
	public void setToken_expires_at(String token_expires_at) {
		this.token_expires_at = token_expires_at;
	}

	/**
	 * @return the refresh_token
	 */
	public String getRefresh_token() {
		return refresh_token;
	}

	/**
	 * @param refresh_token
	 *            the refresh_token to set
	 */
	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}
}
