package eu.finesce.trials.wp3.aachen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class MachineHistoryListItem {

	private double	energy;
	private String	status;
	private String	timestamp;

	public MachineHistoryListItem() {

	}

	/**
	 * @param energy
	 * @param status
	 * @param timestamp
	 */
	public MachineHistoryListItem(double energy, String status, String timestamp) {
		super();
		this.energy = energy;
		this.status = status;
		this.timestamp = timestamp;
	}

	public double getEnergy() {
		return energy;
	}

	public void setEnergy(double energy) {
		this.energy = energy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

}
