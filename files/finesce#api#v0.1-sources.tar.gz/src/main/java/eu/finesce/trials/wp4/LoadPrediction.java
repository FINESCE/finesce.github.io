package eu.finesce.trials.wp4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "LoadPrediction")
@XmlAccessorType(XmlAccessType.FIELD)
public class LoadPrediction {

	@XmlElement(required = true)
	private String	meterType;

	@XmlElement(required = true)
	private long	currentTime;

	@XmlElement(required = true)
	private Double	after1hDownstream;

	@XmlElement(required = true)
	private Double	after1hUpstream;

	@XmlElement(required = true)
	private Double	after3hDownstream;

	@XmlElement(required = true)
	private Double	after3hUpstream;

	@XmlElement(required = true)
	private Double	after6hDownstream;

	@XmlElement(required = true)
	private Double	after6hUpstream;

	@XmlElement(required = true)
	private Double	after12hDownstream;

	@XmlElement(required = true)
	private Double	after12hUpstream;

	@XmlElement(required = true)
	private Double	after24hDownstream;

	@XmlElement(required = true)
	private Double	after24hUpstream;

	/**
	 * @return the meterType
	 */
	public String getMeterType() {
		return meterType;
	}

	/**
	 * @param meterType
	 *            the meterType to set
	 */
	public void setMeterType(String meterType) {
		this.meterType = meterType;
	}

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * @return the after1hDownstream
	 */
	public Double getAfter1hDownstream() {
		return after1hDownstream;
	}

	/**
	 * @param after1hDownstream
	 *            the after1hDownstream to set
	 */
	public void setAfter1hDownstream(Double after1hDownstream) {
		this.after1hDownstream = after1hDownstream;
	}

	/**
	 * @return the after1hUpstream
	 */
	public Double getAfter1hUpstream() {
		return after1hUpstream;
	}

	/**
	 * @param after1hUpstream
	 *            the after1hUpstream to set
	 */
	public void setAfter1hUpstream(Double after1hUpstream) {
		this.after1hUpstream = after1hUpstream;
	}

	/**
	 * @return the after3hDownstream
	 */
	public Double getAfter3hDownstream() {
		return after3hDownstream;
	}

	/**
	 * @param after3hDownstream
	 *            the after3hDownstream to set
	 */
	public void setAfter3hDownstream(Double after3hDownstream) {
		this.after3hDownstream = after3hDownstream;
	}

	/**
	 * @return the after3hUpstream
	 */
	public Double getAfter3hUpstream() {
		return after3hUpstream;
	}

	/**
	 * @param after3hUpstream
	 *            the after3hUpstream to set
	 */
	public void setAfter3hUpstream(Double after3hUpstream) {
		this.after3hUpstream = after3hUpstream;
	}

	/**
	 * @return the after6hDownstream
	 */
	public Double getAfter6hDownstream() {
		return after6hDownstream;
	}

	/**
	 * @param after6hDownstream
	 *            the after6hDownstream to set
	 */
	public void setAfter6hDownstream(Double after6hDownstream) {
		this.after6hDownstream = after6hDownstream;
	}

	/**
	 * @return the after6hUpstream
	 */
	public Double getAfter6hUpstream() {
		return after6hUpstream;
	}

	/**
	 * @param after6hUpstream
	 *            the after6hUpstream to set
	 */
	public void setAfter6hUpstream(Double after6hUpstream) {
		this.after6hUpstream = after6hUpstream;
	}

	/**
	 * @return the after12hDownstream
	 */
	public Double getAfter12hDownstream() {
		return after12hDownstream;
	}

	/**
	 * @param after12hDownstream
	 *            the after12hDownstream to set
	 */
	public void setAfter12hDownstream(Double after12hDownstream) {
		this.after12hDownstream = after12hDownstream;
	}

	/**
	 * @return the after12hUpstream
	 */
	public Double getAfter12hUpstream() {
		return after12hUpstream;
	}

	/**
	 * @param after12hUpstream
	 *            the after12hUpstream to set
	 */
	public void setAfter12hUpstream(Double after12hUpstream) {
		this.after12hUpstream = after12hUpstream;
	}

	/**
	 * @return the after24hDownstream
	 */
	public Double getAfter24hDownstream() {
		return after24hDownstream;
	}

	/**
	 * @param after24hDownstream
	 *            the after24hDownstream to set
	 */
	public void setAfter24hDownstream(Double after24hDownstream) {
		this.after24hDownstream = after24hDownstream;
	}

	/**
	 * @return the after24hUpstream
	 */
	public Double getAfter24hUpstream() {
		return after24hUpstream;
	}

	/**
	 * @param after24hUpstream
	 *            the after24hUpstream to set
	 */
	public void setAfter24hUpstream(Double after24hUpstream) {
		this.after24hUpstream = after24hUpstream;
	}
}
