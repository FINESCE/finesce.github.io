package eu.finesce.trials.wp4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "HistSocialEventList")
@XmlAccessorType(XmlAccessType.FIELD)
public class HistSocialEventList {

	@XmlElement(required = true)
	private String	socialID;

	@XmlElement(required = true)
	private String	socialEventLocationCoordLat;

	@XmlElement(required = true)
	private String	socialEventLocationCoordLong;

	@XmlElement(required = true)
	private String	socialEventVenueAddress;

	@XmlElement(required = true)
	private String	socialEventVenueName;

	@XmlElement(required = true)
	private Integer	socialEventImportancy;

	@XmlElement(required = true)
	private String	socialEventDateTime;

	@XmlElement(required = true)
	private String	socialEventTypology;

	@XmlElement(required = true)
	private long	currentTime;

	public HistSocialEventList() {
	};

	/**
	 * @return the socialID
	 */
	public String getSocialID() {
		return socialID;
	}

	/**
	 * @param socialID
	 *            the socialID to set
	 */
	public void setSocialID(String socialID) {
		this.socialID = socialID;
	}

	/**
	 * @return the socialEventLocationCoordLat
	 */
	public String getSocialEventLocationCoordLat() {
		return socialEventLocationCoordLat;
	}

	/**
	 * @param socialEventLocationCoordLat
	 *            the socialEventLocationCoordLat to set
	 */
	public void setSocialEventLocationCoordLat(String socialEventLocationCoordLat) {
		this.socialEventLocationCoordLat = socialEventLocationCoordLat;
	}

	/**
	 * @return the socialEventLocationCoordLong
	 */
	public String getSocialEventLocationCoordLong() {
		return socialEventLocationCoordLong;
	}

	/**
	 * @param socialEventLocationCoordLong
	 *            the socialEventLocationCoordLong to set
	 */
	public void setSocialEventLocationCoordLong(String socialEventLocationCoordLong) {
		this.socialEventLocationCoordLong = socialEventLocationCoordLong;
	}

	/**
	 * @return the socialEventVenueAddress
	 */
	public String getSocialEventVenueAddress() {
		return socialEventVenueAddress;
	}

	/**
	 * @param socialEventVenueAddress
	 *            the socialEventVenueAddress to set
	 */
	public void setSocialEventVenueAddress(String socialEventVenueAddress) {
		this.socialEventVenueAddress = socialEventVenueAddress;
	}

	/**
	 * @return the socialEventVenueName
	 */
	public String getSocialEventVenueName() {
		return socialEventVenueName;
	}

	/**
	 * @param socialEventVenueName
	 *            the socialEventVenueName to set
	 */
	public void setSocialEventVenueName(String socialEventVenueName) {
		this.socialEventVenueName = socialEventVenueName;
	}

	/**
	 * @return the socialEventImportancy
	 */
	public Integer getSocialEventImportancy() {
		return socialEventImportancy;
	}

	/**
	 * @param socialEventImportancy
	 *            the socialEventImportancy to set
	 */
	public void setSocialEventImportancy(Integer socialEventImportancy) {
		this.socialEventImportancy = socialEventImportancy;
	}

	/**
	 * /**
	 * 
	 * @return the socialEventTypology
	 */
	public String getSocialEventTypology() {
		return socialEventTypology;
	}

	/**
	 * @return the socialEventDateTime
	 */
	public String getSocialEventDateTime() {
		return socialEventDateTime;
	}

	/**
	 * @param socialEventDateTime
	 *            the socialEventDateTime to set
	 */
	public void setSocialEventDateTime(String socialEventDateTime) {
		this.socialEventDateTime = socialEventDateTime;
	}

	/**
	 * @param socialEventTypology
	 *            the socialEventTypology to set
	 */
	public void setSocialEventTypology(String socialEventTypology) {
		this.socialEventTypology = socialEventTypology;
	}

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

}
