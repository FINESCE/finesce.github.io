package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Evevseconnections;

public class EvevseconnectionsWrapper extends Wrapper<Evevseconnections> {

	/**
	 * 
	 */
	public EvevseconnectionsWrapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param totalrecords
	 * @param records
	 */
	public EvevseconnectionsWrapper(int totalrecords, List<Evevseconnections> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
