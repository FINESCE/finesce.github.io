package eu.finesce.trials.wp4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "histMeterDataList")
@XmlAccessorType(XmlAccessType.FIELD)
public class HistMeterDataList {
	@XmlElement(required = true)
	private long	meterDate;

	@XmlElement(required = true)
	private double	upstream;

	@XmlElement(required = true)
	private double	downstream;

	@XmlElement(required = true)
	private double	rp_q1;

	@XmlElement(required = true)
	private double	rp_q2;

	@XmlElement(required = true)
	private double	rp_q3;

	@XmlElement(required = true)
	private double	rp_q4;

	public HistMeterDataList() {
	}

	/**
	 * @return the meterDate
	 */
	public long getMeterDate() {
		return meterDate;
	}

	/**
	 * @param meterDate
	 *            the meterDate to set
	 */
	public void setMeterDate(long meterDate) {
		this.meterDate = meterDate;
	}

	/**
	 * @return the upstream
	 */
	public double getUpstream() {
		return upstream;
	}

	/**
	 * @param upstream
	 *            the upstream to set
	 */
	public void setUpstream(double upstream) {
		this.upstream = upstream;
	}

	/**
	 * @return the downstream
	 */
	public double getDownstream() {
		return downstream;
	}

	/**
	 * @param downstream
	 *            the downstream to set
	 */
	public void setDownstream(double downstream) {
		this.downstream = downstream;
	}

	/**
	 * @return the rp_q1
	 */
	public double getRp_q1() {
		return rp_q1;
	}

	/**
	 * @param rp_q1
	 *            the rp_q1 to set
	 */
	public void setRp_q1(double rp_q1) {
		this.rp_q1 = rp_q1;
	}

	/**
	 * @return the rp_q2
	 */
	public double getRp_q2() {
		return rp_q2;
	}

	/**
	 * @param rp_q2
	 *            the rp_q2 to set
	 */
	public void setRp_q2(double rp_q2) {
		this.rp_q2 = rp_q2;
	}

	/**
	 * @return the rp_q3
	 */
	public double getRp_q3() {
		return rp_q3;
	}

	/**
	 * @param rp_q3
	 *            the rp_q3 to set
	 */
	public void setRp_q3(double rp_q3) {
		this.rp_q3 = rp_q3;
	}

	/**
	 * @return the rp_q4
	 */
	public double getRp_q4() {
		return rp_q4;
	}

	/**
	 * @param rp_q4
	 *            the rp_q4 to set
	 */
	public void setRp_q4(double rp_q4) {
		this.rp_q4 = rp_q4;
	}

}