package eu.finesce.trials.wp4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "weatherDataList")
@XmlAccessorType(XmlAccessType.FIELD)
public class WeatherDataList {

	@XmlElement(required = true)
	private String	weatherDateTime;

	@XmlElement(required = true)
	private long	weatherCurrentTime;

	@XmlElement(required = true)
	private double	Temperature;

	@XmlElement(required = true)
	private double	CloudCover;

	@XmlElement(required = true)
	private String	WeatherCondition;

	@XmlElement(required = true)
	private double	WindSpeed;

	@XmlElement(required = true)
	private long	dailySunriseTime;

	@XmlElement(required = true)
	private long	dailySunsetTime;

	@XmlElement(required = true)
	private double	temperatureMin;

	@XmlElement(required = true)
	private double	temperatureMax;

	public WeatherDataList() {
	}

	/**
	 * @return the weatherDateTime
	 */
	public String getWeatherDateTime() {
		return weatherDateTime;
	}

	/**
	 * @param weatherDateTime
	 *            the weatherDateTime to set
	 */
	public void setWeatherDateTime(String weatherDateTime) {
		this.weatherDateTime = weatherDateTime;
	}

	/**
	 * @return the weatherCurrentTime
	 */
	public long getWeatherCurrentTime() {
		return weatherCurrentTime;
	}

	/**
	 * @param weatherCurrentTime
	 *            the weatherCurrentTime to set
	 */
	public void setWeatherCurrentTime(long weatherCurrentTime) {
		this.weatherCurrentTime = weatherCurrentTime;
	}

	/**
	 * @return the temperature
	 */
	public double getTemperature() {
		return Temperature;
	}

	/**
	 * @param temperature
	 *            the temperature to set
	 */
	public void setTemperature(double temperature) {
		Temperature = temperature;
	}

	/**
	 * @return the cloudCover
	 */
	public double getCloudCover() {
		return CloudCover;
	}

	/**
	 * @param cloudCover
	 *            the cloudCover to set
	 */
	public void setCloudCover(double cloudCover) {
		CloudCover = cloudCover;
	}

	/**
	 * @return the weatherCondition
	 */
	public String getWeatherCondition() {
		return WeatherCondition;
	}

	/**
	 * @param weatherCondition
	 *            the weatherCondition to set
	 */
	public void setWeatherCondition(String weatherCondition) {
		WeatherCondition = weatherCondition;
	}

	/**
	 * @return the windSpeed
	 */
	public double getWindSpeed() {
		return WindSpeed;
	}

	/**
	 * @param windSpeed
	 *            the windSpeed to set
	 */
	public void setWindSpeed(double windSpeed) {
		WindSpeed = windSpeed;
	}

	/**
	 * @return the dailySunriseTime
	 */
	public long getDailySunriseTime() {
		return dailySunriseTime;
	}

	/**
	 * @param dailySunriseTime
	 *            the dailySunriseTime to set
	 */
	public void setDailySunriseTime(long dailySunriseTime) {
		this.dailySunriseTime = dailySunriseTime;
	}

	/**
	 * @return the dailySunsetTime
	 */
	public long getDailySunsetTime() {
		return dailySunsetTime;
	}

	/**
	 * @param dailySunsetTime
	 *            the dailySunsetTime to set
	 */
	public void setDailySunsetTime(long dailySunsetTime) {
		this.dailySunsetTime = dailySunsetTime;
	}

	/**
	 * @return the temperatureMin
	 */
	public double getTemperatureMin() {
		return temperatureMin;
	}

	/**
	 * @param temperatureMin
	 *            the temperatureMin to set
	 */
	public void setTemperatureMin(double temperatureMin) {
		this.temperatureMin = temperatureMin;
	}

	/**
	 * @return the temperatureMax
	 */
	public double getTemperatureMax() {
		return temperatureMax;
	}

	/**
	 * @param temperatureMax
	 *            the temperatureMax to set
	 */
	public void setTemperatureMax(double temperatureMax) {
		this.temperatureMax = temperatureMax;
	}

}
