package eu.finesce.trials.wp2.madrid;

import java.util.List;

public class MGWrapper {

	private List<BasicResource>	mg;

	public MGWrapper() {
		// TODO Auto-generated constructor stub
	}

	public List<BasicResource> getMg() {
		return mg;
	}

	public void setMg(List<BasicResource> mg) {
		this.mg = mg;
	}

	/**
	 * @param mg
	 */
	public MGWrapper(List<BasicResource> mg) {
		super();
		this.mg = mg;
	}

}
