package eu.finesce.trials.wp2.madrid;

public class BasicResource {

	private String	parameter;
	private String	value;
	private String	timestamp;
	private String	entity;
	private String	scope;

	public BasicResource() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param parameter
	 * @param value
	 * @param timestamp
	 * @param entity
	 * @param scope
	 */
	public BasicResource(String parameter, String value, String timestamp, String entity, String scope) {
		super();
		this.parameter = parameter;
		this.value = value;
		this.timestamp = timestamp;
		this.entity = entity;
		this.scope = scope;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

}
