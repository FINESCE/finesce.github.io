package eu.finesce.trials.wp5;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Regionalenergies {

	private int		id;
	private String	generated_energy_kwh;
	private String	aggregated_energy_kwh;
	private String	requested_energy_kwh;
	private String	actual_energy_kwh;
	private String	forecasted_energy_kwh;
	private int		region_id;
	private int		timeslot_id;
	private String	created_at;
	private String	updated_at;

	public Regionalenergies() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param generated_energy_kwh
	 * @param aggregated_energy_kwh
	 * @param requested_energy_kwh
	 * @param actual_energy_kwh
	 * @param forecasted_energy_kwh
	 * @param region_id
	 * @param timeslot_id
	 * @param created_at
	 * @param updated_at
	 */
	public Regionalenergies(int id, String generated_energy_kwh, String aggregated_energy_kwh, String requested_energy_kwh, String actual_energy_kwh, String forecasted_energy_kwh, int region_id, int timeslot_id, String created_at,
			String updated_at) {
		super();
		this.id = id;
		this.generated_energy_kwh = generated_energy_kwh;
		this.aggregated_energy_kwh = aggregated_energy_kwh;
		this.requested_energy_kwh = requested_energy_kwh;
		this.actual_energy_kwh = actual_energy_kwh;
		this.forecasted_energy_kwh = forecasted_energy_kwh;
		this.region_id = region_id;
		this.timeslot_id = timeslot_id;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getGenerated_energy_kwh() {
		return generated_energy_kwh;
	}

	public void setGenerated_energy_kwh(String generated_energy_kwh) {
		this.generated_energy_kwh = generated_energy_kwh;
	}

	public String getAggregated_energy_kwh() {
		return aggregated_energy_kwh;
	}

	public void setAggregated_energy_kwh(String aggregated_energy_kwh) {
		this.aggregated_energy_kwh = aggregated_energy_kwh;
	}

	public String getRequested_energy_kwh() {
		return requested_energy_kwh;
	}

	public void setRequested_energy_kwh(String requested_energy_kwh) {
		this.requested_energy_kwh = requested_energy_kwh;
	}

	public String getActual_energy_kwh() {
		return actual_energy_kwh;
	}

	public void setActual_energy_kwh(String actual_energy_kwh) {
		this.actual_energy_kwh = actual_energy_kwh;
	}

	public String getForecasted_energy_kwh() {
		return forecasted_energy_kwh;
	}

	public void setForecasted_energy_kwh(String forecasted_energy_kwh) {
		this.forecasted_energy_kwh = forecasted_energy_kwh;
	}

	public int getRegion_id() {
		return region_id;
	}

	public void setRegion_id(int region_id) {
		this.region_id = region_id;
	}

	public int getTimeslot_id() {
		return timeslot_id;
	}

	public void setTimeslot_id(int timeslot_id) {
		this.timeslot_id = timeslot_id;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

}
