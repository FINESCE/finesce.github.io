package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Chargingstates;

public class ChargingstatesWrapper extends Wrapper<Chargingstates> {

	/**
	 * 
	 */
	public ChargingstatesWrapper() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param totalrecords
	 * @param records
	 */
	public ChargingstatesWrapper(int totalrecords, List<Chargingstates> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
