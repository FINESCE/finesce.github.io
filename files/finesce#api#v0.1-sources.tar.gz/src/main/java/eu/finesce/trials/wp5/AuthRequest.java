package eu.finesce.trials.wp5;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class AuthRequest {

	private String	token_expires_at;
	private String	role;
	private String	auth_token;
	private String	refresh_token;

	public AuthRequest() {
	}

	/**
	 * @param token_expires_at
	 * @param role
	 * @param auth_token
	 * @param refresh_token
	 */
	public AuthRequest(String token_expires_at, String role, String auth_token, String refresh_token) {
		super();
		this.token_expires_at = token_expires_at;
		this.role = role;
		this.auth_token = auth_token;
		this.refresh_token = refresh_token;
	}

	public String getToken_expires_at() {
		return token_expires_at;
	}

	public void setToken_expires_at(String token_expires_at) {
		this.token_expires_at = token_expires_at;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getAuth_token() {
		return auth_token;
	}

	public void setAuth_token(String auth_token) {
		this.auth_token = auth_token;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}

}
