package eu.finesce.trials.wp3.cologne;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Authorization {

	@XmlElement(name = "authorisation-id")
	private String	authorisation_id;

	public Authorization() {

	}

	public String getAuthorisation_id() {
		return authorisation_id;
	}

	public void setAuthorisation_id(String authorisation_id) {
		this.authorisation_id = authorisation_id;
	}
}
