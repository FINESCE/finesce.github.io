package eu.finesce.trials.wp3.aachen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Machine extends MachineBasic {

	private String	status;

	public Machine() {
		// TODO Auto-generated constructor stub
	}

	public Machine(double consumption, String id, int isCumulative, String measurementUnit, String monitor, String name, String plc, String process, int resolution, String resolutionUnit) {
		super(consumption, id, isCumulative, measurementUnit, monitor, name, plc, process, resolution, resolutionUnit);
	}

	public Machine(double consumption, String id, int isCumulative, String measurementUnit, String monitor, String name, String plc, String process, int resolution, String resolutionUnit, String status) {
		super(consumption, id, isCumulative, measurementUnit, monitor, name, plc, process, resolution, resolutionUnit);
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
