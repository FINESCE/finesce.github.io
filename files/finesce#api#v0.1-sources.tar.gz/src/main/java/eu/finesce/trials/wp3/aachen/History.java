package eu.finesce.trials.wp3.aachen;

import java.util.List;

public class History {

	private List<MachineHistoryListItem>	history;
	private MachineBasic					machineDetails;

	public History() {
	}

	/**
	 * @param history
	 * @param machineDetails
	 */
	public History(List<MachineHistoryListItem> history, MachineBasic machineDetails) {
		super();
		this.history = history;
		this.machineDetails = machineDetails;
	}

	public List<MachineHistoryListItem> getHistory() {
		return history;
	}

	public void setHistory(List<MachineHistoryListItem> history) {
		this.history = history;
	}

	public MachineBasic getMachineDetails() {
		return machineDetails;
	}

	public void setMachineDetails(MachineBasic machineDetails) {
		this.machineDetails = machineDetails;
	}

}
