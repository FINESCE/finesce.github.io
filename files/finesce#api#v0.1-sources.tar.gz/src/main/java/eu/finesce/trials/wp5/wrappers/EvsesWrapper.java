package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Evses;

public class EvsesWrapper extends Wrapper<Evses> {

	public EvsesWrapper() {
		// TODO Auto-generated constructor stub
	}

	public EvsesWrapper(int totalrecords, List<Evses> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
