package eu.finesce.trials.wp3.aachen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class MachineBasic {

	private double	consumption;
	private String	id;
	private int		isCumulative;
	private String	measurementUnit;
	private String	monitor;
	private String	name;
	private String	plc;
	private String	process;
	private int		resolution;
	private String	resolutionUnit;

	public MachineBasic() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param consumption
	 * @param id
	 * @param isCumulative
	 * @param measurementUnit
	 * @param monitor
	 * @param name
	 * @param plc
	 * @param process
	 * @param resolution
	 * @param resolutionUnit
	 */
	public MachineBasic(double consumption, String id, int isCumulative, String measurementUnit, String monitor, String name, String plc, String process, int resolution, String resolutionUnit) {
		super();
		this.consumption = consumption;
		this.id = id;
		this.isCumulative = isCumulative;
		this.measurementUnit = measurementUnit;
		this.monitor = monitor;
		this.name = name;
		this.plc = plc;
		this.process = process;
		this.resolution = resolution;
		this.resolutionUnit = resolutionUnit;
	}

	public double getConsumption() {
		return consumption;
	}

	public void setConsumption(double consumption) {
		this.consumption = consumption;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getIsCumulative() {
		return isCumulative;
	}

	public void setIsCumulative(int isCumulative) {
		this.isCumulative = isCumulative;
	}

	public String getMeasurementUnit() {
		return measurementUnit;
	}

	public void setMeasurementUnit(String measurementUnit) {
		this.measurementUnit = measurementUnit;
	}

	public String getMonitor() {
		return monitor;
	}

	public void setMonitor(String monitor) {
		this.monitor = monitor;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlc() {
		return plc;
	}

	public void setPlc(String plc) {
		this.plc = plc;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	public int getResolution() {
		return resolution;
	}

	public void setResolution(int resolution) {
		this.resolution = resolution;
	}

	public String getResolutionUnit() {
		return resolutionUnit;
	}

	public void setResolutionUnit(String resolutionUnit) {
		this.resolutionUnit = resolutionUnit;
	}

}
