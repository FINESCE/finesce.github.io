/*
 * Copyright 2014 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eu.finesce.trials.wp5;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

public class Electricvehicles {

	private int		id;
	private int		evtype_id;
	private String	created_at;
	private String	updated_at;

	/**
	 * 
	 */
	public Electricvehicles() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param evtype_id
	 * @param created_at
	 * @param updated_at
	 */
	public Electricvehicles(int id, int evtype_id, String created_at, String updated_at) {
		super();
		this.id = id;
		this.evtype_id = evtype_id;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEvtype_id() {
		return evtype_id;
	}

	public void setEvtype_id(int evtype_id) {
		this.evtype_id = evtype_id;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

}
