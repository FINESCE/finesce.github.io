package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Electricvehicles;

public class ElectricvehiclesWrapper extends Wrapper<Electricvehicles> {

	public ElectricvehiclesWrapper() {
		// TODO Auto-generated constructor stub
	}

	public ElectricvehiclesWrapper(int totalrecords, List<Electricvehicles> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
