package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Evevseconnectionstates;

public class EvevseconnectionstatesWrapper extends Wrapper<Evevseconnectionstates> {

	public EvevseconnectionstatesWrapper() {
		// TODO Auto-generated constructor stub
	}

	public EvevseconnectionstatesWrapper(int totalrecords, List<Evevseconnectionstates> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
