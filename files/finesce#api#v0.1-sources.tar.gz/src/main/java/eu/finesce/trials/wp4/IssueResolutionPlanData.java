/*
Copyright (C) 2014 FINESCE-WP4 
 
This file is part of emarketplace-domain.

Emarketplace-domain is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Emarketplace-domain is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Emarketplace-domain.  If not, see <http://www.gnu.org/licenses/>. */
package eu.finesce.trials.wp4;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

// TODO: Auto-generated Javadoc
/**
 * The Class IssueResolutionPlanData.
 */
@XmlRootElement(name = "irpData")
@XmlAccessorType(XmlAccessType.FIELD)
public class IssueResolutionPlanData {

	/** The Entity type. */
	@XmlElement(required = true)
	private String						EntityType;

	/** The current time. */
	@XmlElement(required = true)
	private long						currentTime;

	/** The loaddata list. */
	@XmlElement(name = "IssueResolutionPlanDataList", type = IssueResolutionPlanDataList.class)
	List<IssueResolutionPlanDataList>	loaddataList;

	/**
	 * Gets the entity type.
	 *
	 * @return the entityType
	 */
	public String getEntityType() {
		return EntityType;
	}

	/**
	 * Sets the entity type.
	 *
	 * @param entityType
	 *            the entityType to set
	 */
	public void setEntityType(String entityType) {
		EntityType = entityType;
	}

	/**
	 * Gets the current time.
	 *
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * Sets the current time.
	 *
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * Gets the loaddata list.
	 *
	 * @return the loaddataList
	 */
	public List<IssueResolutionPlanDataList> getLoaddataList() {
		return loaddataList;
	}

	/**
	 * Sets the loaddata list.
	 *
	 * @param loaddataList
	 *            the loaddataList to set
	 */
	public void setLoaddataList(List<IssueResolutionPlanDataList> loaddataList) {
		this.loaddataList = loaddataList;
	}

}
