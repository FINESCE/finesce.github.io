package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Timeslots;

public class TimeslotsWrapper extends Wrapper<Timeslots> {

	public TimeslotsWrapper() {
		// TODO Auto-generated constructor stub
	}

	public TimeslotsWrapper(int totalrecords, List<Timeslots> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
