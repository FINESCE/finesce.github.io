package eu.finesce.trials.wp5;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Evtypes {

	private int		id;
	private String	manufacturer;
	private String	brand;
	private String	battery_capacity_kwh;
	private int		range_min_km;
	private int		range_max_km;
	private String	created_at;
	private String	updated_at;

	public Evtypes() {
	}

	/**
	 * @param id
	 * @param manufacturer
	 * @param brand
	 * @param battery_capacity_kwh
	 * @param range_min_km
	 * @param range_max_km
	 * @param created_at
	 * @param updated_at
	 */
	public Evtypes(int id, String manufacturer, String brand, String battery_capacity_kwh, int range_min_km, int range_max_km, String created_at, String updated_at) {
		super();
		this.id = id;
		this.manufacturer = manufacturer;
		this.brand = brand;
		this.battery_capacity_kwh = battery_capacity_kwh;
		this.range_min_km = range_min_km;
		this.range_max_km = range_max_km;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getBattery_capacity_kwh() {
		return battery_capacity_kwh;
	}

	public void setBattery_capacity_kwh(String battery_capacity_kwh) {
		this.battery_capacity_kwh = battery_capacity_kwh;
	}

	public int getRange_min_km() {
		return range_min_km;
	}

	public void setRange_min_km(int range_min_km) {
		this.range_min_km = range_min_km;
	}

	public int getRange_max_km() {
		return range_max_km;
	}

	public void setRange_max_km(int range_max_km) {
		this.range_max_km = range_max_km;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

}
