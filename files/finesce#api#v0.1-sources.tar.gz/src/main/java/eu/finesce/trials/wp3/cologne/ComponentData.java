package eu.finesce.trials.wp3.cologne;

import java.util.List;

public class ComponentData {

	private List<ComponentDatum>	calculation;
	private List<ComponentDatum>	measurement;

	public ComponentData() {
		// TODO Auto-generated constructor stub
	}

	public List<ComponentDatum> getCalculation() {
		return calculation;
	}

	public void setCalculation(List<ComponentDatum> calculation) {
		this.calculation = calculation;
	}

	public List<ComponentDatum> getMeasurement() {
		return measurement;
	}

	public void setMeasurement(List<ComponentDatum> measurement) {
		this.measurement = measurement;
	}

}
