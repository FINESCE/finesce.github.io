package eu.finesce.trials.wp5;

public class Timeslots {

	private int		id;
	private String	start;
	private int		duration_min;
	private String	created_at;
	private String	updated_at;

	public Timeslots() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param start
	 * @param duration_min
	 * @param created_at
	 * @param updated_at
	 */
	public Timeslots(int id, String start, int duration_min, String created_at, String updated_at) {
		super();
		this.id = id;
		this.start = start;
		this.duration_min = duration_min;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public int getDuration_min() {
		return duration_min;
	}

	public void setDuration_min(int duration_min) {
		this.duration_min = duration_min;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

}
