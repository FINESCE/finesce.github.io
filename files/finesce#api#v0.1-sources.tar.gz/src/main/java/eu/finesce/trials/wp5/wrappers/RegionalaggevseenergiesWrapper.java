package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Regionalaggevseenergies;

public class RegionalaggevseenergiesWrapper extends Wrapper<Regionalaggevseenergies> {

	/**
	 * 
	 */
	public RegionalaggevseenergiesWrapper() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param totalrecords
	 * @param records
	 */
	public RegionalaggevseenergiesWrapper(int totalrecords, List<Regionalaggevseenergies> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
