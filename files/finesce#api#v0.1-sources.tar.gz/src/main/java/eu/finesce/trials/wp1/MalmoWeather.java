/*
 * Copyright 2015 Synelixis Solutions Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package eu.finesce.trials.wp1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Artemis Voulkidis <voulkidis@synelixis.com>
 *
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class MalmoWeather {

	private MalmoMetadata	__metadata;
	private String			id;
	private String			location;
	private String			latitude;
	private String			longitude;
	private String			dateTime;
	private String			outsideTemperature;
	private String			cloudCoverage;
	private String			precipitation;
	private String			windSpeed;
	private String			windDirection;
	private String			sunRise;
	private String			sunSet;
	private String			source;

	public MalmoWeather() {
	}

	public MalmoWeather(MalmoMetadata __metadata, String id, String location, String latitude, String longitude, String dateTime, String outsideTemperature, String cloudCoverage, String precipitation, String windSpeed,
			String windDirection, String sunRise, String sunSet, String source) {
		this.__metadata = __metadata;
		this.id = id;
		this.location = location;
		this.latitude = latitude;
		this.longitude = longitude;
		this.dateTime = dateTime;
		this.outsideTemperature = outsideTemperature;
		this.cloudCoverage = cloudCoverage;
		this.precipitation = precipitation;
		this.windSpeed = windSpeed;
		this.windDirection = windDirection;
		this.sunRise = sunRise;
		this.sunSet = sunSet;
		this.source = source;
	}

	public MalmoMetadata get__metadata() {
		return __metadata;
	}

	public void set__metadata(MalmoMetadata __metadata) {
		this.__metadata = __metadata;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getOutsideTemperature() {
		return outsideTemperature;
	}

	public void setOutsideTemperature(String outsideTemperature) {
		this.outsideTemperature = outsideTemperature;
	}

	public String getCloudCoverage() {
		return cloudCoverage;
	}

	public void setCloudCoverage(String cloudCoverage) {
		this.cloudCoverage = cloudCoverage;
	}

	public String getPrecipitation() {
		return precipitation;
	}

	public void setPrecipitation(String precipitation) {
		this.precipitation = precipitation;
	}

	public String getWindSpeed() {
		return windSpeed;
	}

	public void setWindSpeed(String windSpeed) {
		this.windSpeed = windSpeed;
	}

	public String getWindDirection() {
		return windDirection;
	}

	public void setWindDirection(String windDirection) {
		this.windDirection = windDirection;
	}

	public String getSunRise() {
		return sunRise;
	}

	public void setSunRise(String sunRise) {
		this.sunRise = sunRise;
	}

	public String getSunSet() {
		return sunSet;
	}

	public void setSunSet(String sunSet) {
		this.sunSet = sunSet;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
