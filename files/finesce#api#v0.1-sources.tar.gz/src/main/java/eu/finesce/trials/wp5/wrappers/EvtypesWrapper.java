package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Evtypes;

public class EvtypesWrapper extends Wrapper<Evtypes> {

	public EvtypesWrapper() {
		// TODO Auto-generated constructor stub
	}

	public EvtypesWrapper(int totalrecords, List<Evtypes> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
