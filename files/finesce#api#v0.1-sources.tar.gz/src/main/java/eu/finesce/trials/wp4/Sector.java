package eu.finesce.trials.wp4;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "sector")
@XmlAccessorType(XmlAccessType.FIELD)
public class Sector {

	@XmlElement(required = true)
	private long		currentTime;

	@XmlElement(name = "SectorList", type = SectorList.class)
	List<SectorList>	sectorList;

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	public Sector() {
	}

	/**
	 * @return the sectorList
	 */
	public List<SectorList> getSectorList() {
		return sectorList;
	}

	/**
	 * @param sectorList
	 *            the sectorList to set
	 */
	public void setSectorList(List<SectorList> sectorList) {
		this.sectorList = sectorList;
	}

}
