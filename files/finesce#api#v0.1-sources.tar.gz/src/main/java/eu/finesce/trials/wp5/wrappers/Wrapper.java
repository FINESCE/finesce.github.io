package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Wrapper<T> {

	private int		totalrecords;
	private List<T>	records;

	public Wrapper() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param totalrecords
	 * @param records
	 */
	public Wrapper(int totalrecords, List<T> records) {
		super();
		this.totalrecords = totalrecords;
		this.records = records;
	}

	public int getTotalrecords() {
		return totalrecords;
	}

	public void setTotalrecords(int totalrecords) {
		this.totalrecords = totalrecords;
	}

	public List<T> getRecords() {
		return records;
	}

	public void setRecords(List<T> records) {
		this.records = records;
	}

}
