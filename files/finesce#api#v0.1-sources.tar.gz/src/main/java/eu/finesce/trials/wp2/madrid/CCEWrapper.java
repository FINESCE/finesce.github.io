package eu.finesce.trials.wp2.madrid;

import java.util.List;

public class CCEWrapper {

	private List<BasicResource>	cce;

	public CCEWrapper() {
		// TODO Auto-generated constructor stub
	}

	public List<BasicResource> getCce() {
		return cce;
	}

	public void setCce(List<BasicResource> cce) {
		this.cce = cce;
	}

	/**
	 * @param cce
	 */
	public CCEWrapper(List<BasicResource> cce) {
		super();
		this.cce = cce;
	}

}
