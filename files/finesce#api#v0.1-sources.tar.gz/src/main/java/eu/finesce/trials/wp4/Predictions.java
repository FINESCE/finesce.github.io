package eu.finesce.trials.wp4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "meter")
@XmlAccessorType(XmlAccessType.FIELD)
public class Predictions {

	@XmlAttribute(required = true)
	private String	meterId;

	@XmlElement(required = true)
	private long	loadPredictionsTime;

	@XmlElement(required = true)
	private long	currentTime;

	@XmlElement(required = true)
	private double	after1hDownstreamActivePower;

	@XmlElement(required = true)
	private double	after1hUpstreamActivePower;

	@XmlElement(required = true)
	private double	after3hDownstreamActivePower;

	@XmlElement(required = true)
	private double	after3hUpstreamActivePower;

	@XmlElement(required = true)
	private double	after6hDownstreamActivePower;

	@XmlElement(required = true)
	private double	after6hUpstreamActivePower;

	@XmlElement(required = true)
	private double	after12hDownstreamActivePower;

	@XmlElement(required = true)
	private double	after12hUpstreamActivePower;

	@XmlElement(required = true)
	private double	after24hDownstreamActivePower;

	@XmlElement(required = true)
	private double	after24hUpstreamActivePower;

	public Predictions() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Predictions(String meterId, long loadPredictionsTime, long currentTime, double after1hDownstreamActivePower, double after1hUpstreamActivePower, double after3hDownstreamActivePower, double after3hUpstreamActivePower,
			double after6hDownstreamActivePower, double after6hUpstreamActivePower, double after12hDownstreamActivePower, double after12hUpstreamActivePower, double after24hDownstreamActivePower, double after24hUpstreamActivePower) {
		super();
		this.meterId = meterId;
		this.loadPredictionsTime = loadPredictionsTime;
		this.currentTime = currentTime;
		this.after1hDownstreamActivePower = after1hDownstreamActivePower;
		this.after1hUpstreamActivePower = after1hUpstreamActivePower;
		this.after3hDownstreamActivePower = after3hDownstreamActivePower;
		this.after3hUpstreamActivePower = after3hUpstreamActivePower;
		this.after6hDownstreamActivePower = after6hDownstreamActivePower;
		this.after6hUpstreamActivePower = after6hUpstreamActivePower;
		this.after12hDownstreamActivePower = after12hDownstreamActivePower;
		this.after12hUpstreamActivePower = after12hUpstreamActivePower;
		this.after24hDownstreamActivePower = after24hDownstreamActivePower;
		this.after24hUpstreamActivePower = after24hUpstreamActivePower;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Predictions [meterId=" + meterId + ", time=" + loadPredictionsTime + ", currentTime=" + currentTime + ", after1hDownstreamActivePower=" + after1hDownstreamActivePower + ", after1hUpstreamActivePower="
				+ after1hUpstreamActivePower + ", after3hDownstreamActivePower=" + after3hDownstreamActivePower + ", after3hUpstreamActivePower=" + after3hUpstreamActivePower + ", after6hDownstreamActivePower="
				+ after6hDownstreamActivePower + ", after6hUpstreamActivePower=" + after6hUpstreamActivePower + ", after12hDownstreamActivePower=" + after12hDownstreamActivePower + ", after12hUpstreamActivePower="
				+ after12hUpstreamActivePower + ", after24hDownstreamActivePower=" + after24hDownstreamActivePower + ", after24hUpstreamActivePower=" + after24hUpstreamActivePower + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(after12hDownstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after12hUpstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after1hDownstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after1hUpstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after24hDownstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after24hUpstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after3hDownstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after3hUpstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after6hDownstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(after6hUpstreamActivePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (int) (currentTime ^ (currentTime >>> 32));
		result = prime * result + (int) (loadPredictionsTime ^ (loadPredictionsTime >>> 32));
		result = prime * result + ((meterId == null) ? 0 : meterId.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Predictions other = (Predictions) obj;
		if (Double.doubleToLongBits(after12hDownstreamActivePower) != Double.doubleToLongBits(other.after12hDownstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after12hUpstreamActivePower) != Double.doubleToLongBits(other.after12hUpstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after1hDownstreamActivePower) != Double.doubleToLongBits(other.after1hDownstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after1hUpstreamActivePower) != Double.doubleToLongBits(other.after1hUpstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after24hDownstreamActivePower) != Double.doubleToLongBits(other.after24hDownstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after24hUpstreamActivePower) != Double.doubleToLongBits(other.after24hUpstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after3hDownstreamActivePower) != Double.doubleToLongBits(other.after3hDownstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after3hUpstreamActivePower) != Double.doubleToLongBits(other.after3hUpstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after6hDownstreamActivePower) != Double.doubleToLongBits(other.after6hDownstreamActivePower))
			return false;
		if (Double.doubleToLongBits(after6hUpstreamActivePower) != Double.doubleToLongBits(other.after6hUpstreamActivePower))
			return false;
		if (currentTime != other.currentTime)
			return false;
		if (loadPredictionsTime != other.loadPredictionsTime)
			return false;
		if (meterId == null) {
			if (other.meterId != null)
				return false;
		} else if (!meterId.equals(other.meterId))
			return false;
		return true;
	}

	/**
	 * @return the meterId
	 */
	public String getMeterId() {
		return meterId;
	}

	/**
	 * @param meterId
	 *            the meterId to set
	 */
	public void setMeterId(String meterId) {
		this.meterId = meterId;
	}

	/**
	 * @return the loadPredictionsTime
	 */
	public long getLoadPredictionsTime() {
		return loadPredictionsTime;
	}

	/**
	 * @param loadPredictionsTime
	 *            the loadPredictionsTime to set
	 */
	public void setLoadPredictionsTime(long loadPredictionsTime) {
		this.loadPredictionsTime = loadPredictionsTime;
	}

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * @return the after1hDownstreamActivePower
	 */
	public double getAfter1hDownstreamActivePower() {
		return after1hDownstreamActivePower;
	}

	/**
	 * @param after1hDownstreamActivePower
	 *            the after1hDownstreamActivePower to set
	 */
	public void setAfter1hDownstreamActivePower(double after1hDownstreamActivePower) {
		this.after1hDownstreamActivePower = after1hDownstreamActivePower;
	}

	/**
	 * @return the after1hUpstreamActivePower
	 */
	public double getAfter1hUpstreamActivePower() {
		return after1hUpstreamActivePower;
	}

	/**
	 * @param after1hUpstreamActivePower
	 *            the after1hUpstreamActivePower to set
	 */
	public void setAfter1hUpstreamActivePower(double after1hUpstreamActivePower) {
		this.after1hUpstreamActivePower = after1hUpstreamActivePower;
	}

	/**
	 * @return the after3hDownstreamActivePower
	 */
	public double getAfter3hDownstreamActivePower() {
		return after3hDownstreamActivePower;
	}

	/**
	 * @param after3hDownstreamActivePower
	 *            the after3hDownstreamActivePower to set
	 */
	public void setAfter3hDownstreamActivePower(double after3hDownstreamActivePower) {
		this.after3hDownstreamActivePower = after3hDownstreamActivePower;
	}

	/**
	 * @return the after3hUpstreamActivePower
	 */
	public double getAfter3hUpstreamActivePower() {
		return after3hUpstreamActivePower;
	}

	/**
	 * @param after3hUpstreamActivePower
	 *            the after3hUpstreamActivePower to set
	 */
	public void setAfter3hUpstreamActivePower(double after3hUpstreamActivePower) {
		this.after3hUpstreamActivePower = after3hUpstreamActivePower;
	}

	/**
	 * @return the after6hDownstreamActivePower
	 */
	public double getAfter6hDownstreamActivePower() {
		return after6hDownstreamActivePower;
	}

	/**
	 * @param after6hDownstreamActivePower
	 *            the after6hDownstreamActivePower to set
	 */
	public void setAfter6hDownstreamActivePower(double after6hDownstreamActivePower) {
		this.after6hDownstreamActivePower = after6hDownstreamActivePower;
	}

	/**
	 * @return the after6hUpstreamActivePower
	 */
	public double getAfter6hUpstreamActivePower() {
		return after6hUpstreamActivePower;
	}

	/**
	 * @param after6hUpstreamActivePower
	 *            the after6hUpstreamActivePower to set
	 */
	public void setAfter6hUpstreamActivePower(double after6hUpstreamActivePower) {
		this.after6hUpstreamActivePower = after6hUpstreamActivePower;
	}

	/**
	 * @return the after12hDownstreamActivePower
	 */
	public double getAfter12hDownstreamActivePower() {
		return after12hDownstreamActivePower;
	}

	/**
	 * @param after12hDownstreamActivePower
	 *            the after12hDownstreamActivePower to set
	 */
	public void setAfter12hDownstreamActivePower(double after12hDownstreamActivePower) {
		this.after12hDownstreamActivePower = after12hDownstreamActivePower;
	}

	/**
	 * @return the after12hUpstreamActivePower
	 */
	public double getAfter12hUpstreamActivePower() {
		return after12hUpstreamActivePower;
	}

	/**
	 * @param after12hUpstreamActivePower
	 *            the after12hUpstreamActivePower to set
	 */
	public void setAfter12hUpstreamActivePower(double after12hUpstreamActivePower) {
		this.after12hUpstreamActivePower = after12hUpstreamActivePower;
	}

	/**
	 * @return the after24hDownstreamActivePower
	 */
	public double getAfter24hDownstreamActivePower() {
		return after24hDownstreamActivePower;
	}

	/**
	 * @param after24hDownstreamActivePower
	 *            the after24hDownstreamActivePower to set
	 */
	public void setAfter24hDownstreamActivePower(double after24hDownstreamActivePower) {
		this.after24hDownstreamActivePower = after24hDownstreamActivePower;
	}

	/**
	 * @return the after24hUpstreamActivePower
	 */
	public double getAfter24hUpstreamActivePower() {
		return after24hUpstreamActivePower;
	}

	/**
	 * @param after24hUpstreamActivePower
	 *            the after24hUpstreamActivePower to set
	 */
	public void setAfter24hUpstreamActivePower(double after24hUpstreamActivePower) {
		this.after24hUpstreamActivePower = after24hUpstreamActivePower;
	};

}
