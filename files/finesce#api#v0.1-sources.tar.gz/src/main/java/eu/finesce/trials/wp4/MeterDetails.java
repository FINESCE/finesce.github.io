package eu.finesce.trials.wp4;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "meterDetails")
@XmlAccessorType(XmlAccessType.FIELD)
public class MeterDetails {

	@XmlElement(required = true)
	private String			searchfield;

	@XmlElement(required = true)
	private String			searchfieldvalue;

	@XmlElement(required = true)
	private long			currentTime;

	@XmlElement(name = "MeterDetailsListPublic", type = MeterDetailsList.class)
	List<MeterDetailsList>	meterdetailsList;

	/**
	 * @return the searchfield
	 */
	public String getSearchfield() {
		return searchfield;
	}

	/**
	 * @param searchfield
	 *            the searchfield to set
	 */
	public void setSearchfield(String searchfield) {
		this.searchfield = searchfield;
	}

	/**
	 * @return the searchfieldvalue
	 */
	public String getSearchfieldvalue() {
		return searchfieldvalue;
	}

	/**
	 * @param searchfieldvalue
	 *            the searchfieldvalue to set
	 */
	public void setSearchfieldvalue(String searchfieldvalue) {
		this.searchfieldvalue = searchfieldvalue;
	}

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	public MeterDetails() {
	}

	/**
	 * @return the meterdetailsList
	 */
	public List<MeterDetailsList> getMeterdetailsList() {
		return meterdetailsList;
	}

	/**
	 * @param meterdetailsList
	 *            the meterdetailsList to set
	 */
	public void setMeterdetailsList(List<MeterDetailsList> meterdetailsList) {
		this.meterdetailsList = meterdetailsList;
	}

}
