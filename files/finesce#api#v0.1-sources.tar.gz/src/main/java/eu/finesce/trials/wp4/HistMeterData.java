package eu.finesce.trials.wp4;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "histMeterData")
@XmlAccessorType(XmlAccessType.FIELD)
public class HistMeterData {

//	Smart Meters Type = all; single meter; commercial; industrial
	@XmlElement(required = true)
	private String			smType;

// 	Horizon Data Meter = 24H / 12H / 6H / 3H / 1H
	@XmlElement(required = true)
	private String			horizonMeter;

	@XmlElement(required = true)
	private long			currentTime;

	@XmlElement(name = "MeterDataList", type = HistMeterDataList.class)
	List<HistMeterDataList>	meterdataList;

	public HistMeterData() {
	};

	public String getSmType() {
		return smType;
	}

	public void setSmType(String smType) {
		this.smType = smType;
	}

	public String getHorizonMeter() {
		return horizonMeter;
	}

	public void setHorizonLoad(String horizonMeter) {
		this.horizonMeter = horizonMeter;
	}

	public long getCurrentTime() {
		return currentTime;
	}

	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	public List<HistMeterDataList> getMeterdataList() {
		return meterdataList;
	}

	public void setMeterdataList(List<HistMeterDataList> meterdataList) {
		this.meterdataList = meterdataList;
	}
}