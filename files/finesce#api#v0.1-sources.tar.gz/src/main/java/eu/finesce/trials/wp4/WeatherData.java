package eu.finesce.trials.wp4;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "weatherData")
@XmlAccessorType(XmlAccessType.FIELD)
public class WeatherData {

	@XmlElement(required = true)
	private String			weatherID;

	@XmlElement(required = true)
	private long			currentTime;

	@XmlElement(required = true)
	private long			startDateTime;

	@XmlElement(required = true)
	private long			endDateTime;

	@XmlElement(name = "WeatherDataList", type = WeatherDataList.class)
	List<WeatherDataList>	weatherdataList;

	public WeatherData() {
	}

	/**
	 * @return the weatherID
	 */
	public String getWeatherID() {
		return weatherID;
	}

	/**
	 * @param weatherID
	 *            the weatherID to set
	 */
	public void setWeatherID(String weatherID) {
		this.weatherID = weatherID;
	}

	/**
	 * @return the currentTime
	 */
	public long getCurrentTime() {
		return currentTime;
	}

	/**
	 * @param currentTime
	 *            the currentTime to set
	 */
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * @return the startDateTime
	 */
	public long getStartDateTime() {
		return startDateTime;
	}

	/**
	 * @param startDateTime
	 *            the startDateTime to set
	 */
	public void setStartDateTime(long startDateTime) {
		this.startDateTime = startDateTime;
	}

	/**
	 * @return the endDateTime
	 */
	public long getEndDateTime() {
		return endDateTime;
	}

	/**
	 * @param endDateTime
	 *            the endDateTime to set
	 */
	public void setEndDateTime(long endDateTime) {
		this.endDateTime = endDateTime;
	}

	/**
	 * @return the weatherdataList
	 */
	public List<WeatherDataList> getWeatherdataList() {
		return weatherdataList;
	}

	/**
	 * @param weatherdataList
	 *            the weatherdataList to set
	 */
	public void setWeatherdataList(List<WeatherDataList> weatherdataList) {
		this.weatherdataList = weatherdataList;
	}

}
