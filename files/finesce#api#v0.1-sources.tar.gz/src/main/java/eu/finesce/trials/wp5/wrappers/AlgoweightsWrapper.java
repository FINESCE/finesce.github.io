package eu.finesce.trials.wp5.wrappers;

import java.util.List;

import eu.finesce.trials.wp5.Algoweights;

public class AlgoweightsWrapper extends Wrapper<Algoweights> {

	public AlgoweightsWrapper() {
	}

	/**
	 * @param totalrecords
	 * @param records
	 */
	public AlgoweightsWrapper(int totalrecords, List<Algoweights> records) {
		super(totalrecords, records);
		// TODO Auto-generated constructor stub
	}

}
