


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.DriverManager;

public class Prueba {

	/**
	 * @param args
	 */
	public static void PruebaMain() {
		// TODO Auto-generated method stub
		System.out.println("Prueba en el main de la clase.");
	}

}
