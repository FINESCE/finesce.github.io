

import org.acciona.hive.HiveClient;
import org.acciona.hive.*;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Prueba.");
		HiveClient.ejecutaQuery();
		System.out.println("Fin del programa.");
	}


}
