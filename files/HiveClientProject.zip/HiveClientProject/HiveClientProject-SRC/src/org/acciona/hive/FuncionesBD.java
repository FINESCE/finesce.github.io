package org.acciona.hive;

import java.sql.*;
import java.util.*;

public class FuncionesBD extends Bd {

	static final String insertar_mensaje_hive = "insert into FINESCE_hiveResults (fecha, mensaje) values (?,?)";
    

    public FuncionesBD() {

		super("ip", "MeteoTICs", "user", "pass");
        
    }

    
    public boolean insertarMensajeHive(Calendar fecha_param, String mensaje) {

        java.sql.Timestamp fecha = null;
        if (fecha_param != null)
            fecha = new java.sql.Timestamp(fecha_param.getTimeInMillis());

        PreparedStatement stm = preparar(insertar_mensaje_hive);
        try {
        	stm.setTimestamp(1, fecha);
            stm.setString(2, mensaje);
            stm.executeUpdate();
            System.out.println("Inserto correctamente: " + fecha.toString());
            return (true);
        } catch (SQLException e) {
            e.printStackTrace();
            return (false);
        }
    }    

}