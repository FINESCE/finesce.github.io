package org.acciona.hive;

/*import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.DriverManager;*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.HashMap;
import java.util.logging.*;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.logging.Log;


public class HiveClient {
   // JDBC driver required for Hive connections
   private static String driverName = "org.apache.hadoop.hive.jdbc.HiveDriver";
   private static String cosmos_username = "finesce";
   private static String cosmos_password = "temporal";
   private static String cosmos_hostname = "130.206.80.46";
   private static String cosmos_port = "10000";
   
   //private static final String user = "root";
   //private static final String host = "87.106.173.189";
   //private static final Integer port = 22;
   //private static final String pass = "yCj2bgQ5";
   //private static final String ruta = "/var/www/vhosts/gestionidiacciona.com/httpdocs/";
   
   // Datos de conexi�n al servidor de 1&1
   private static final String user = "Administrator";
   private static final String host = "82.165.27.170";
   private static final Integer port = 25;
   private static final String pass = "pxD3f32j";
   private static final String ruta = "C:\\inetpub\\vhosts\\s414608724.mialojamiento.es\\httpdocs\\FINESCE\\datos_hive\\";

   private static final float coeficiente_tolerancia = 0.9f;
   // 3600 * 1000 -> 1 hora
   //private static final int intervalo_hilo = 3600000;
   private static final int intervalo_hilo = 3600000;
   
   private static final Boolean inserto_en_bbdd = true;
   private static final Boolean trazas_num_reg_totales = false;
   private static final Boolean trazas_listar_registros = false;
   
   // Datos de conexi�n a la base de datos de 1&1
   //private static final String bbdd_name = "finesce_demo";
   //private static final String bbdd_user = "finesce";
   //private static final String bbdd_pass = "finesce@2014";
   //private static final String bbdd_port = "1433";
   
   private static final String QUERY_NUM_REG_TOTALES = "select count(*) from finesce_meteo";
   private static final String QUERY_LISTAR_REGISTROS = "select * from finesce_meteo order by ts_ms asc";
   private static final String QUERY_ULTIMO_VALOR = "select max(ts_ms), ts, value from finesce_meteo where attribute_name = 'temp' group by ts, value sort by ts desc limit 6";
   
   public static Connection con;

   
   private static Connection getConnection(String ip, String port, String user, String password) {
      try {
         // dynamically load the Hive JDBC driver
         Class.forName(driverName);
      } catch (ClassNotFoundException e) {
         System.out.println(e.getMessage());
         return null;
      } // try catch
     
      try {
         // return a connection based on the Hive JDBC driver
         return DriverManager.getConnection("jdbc:hive://" + ip + ":" + port
            + "/default?user=" + user + "&password=" + password);
      } catch (SQLException e) {
         System.out.println(e.getMessage());
         return null;
      } // try catch
   } // getConnection

   	private static void doQuery() {
		FuncionesBD basedatos = new FuncionesBD();
		Boolean trazas = true;

   		try {
   			Calendar cal = Calendar.getInstance();
   			System.out.println("Timestamp: " + cal.get(Calendar.DATE) + "-" + cal.get(Calendar.MONTH) + "-" + cal.get(Calendar.YEAR));
   			
   			if (trazas) System.out.println("-------------------------------------------");
   			if (trazas) System.out.println("Inicio doQuery");
   			

   			basedatos.abrirConexion();
			// from here on, everything is SQL!
   			
   			System.out.println("Conexion abierta.");
   			
			Statement stmt = con.createStatement();
			//ResultSet res = stmt.executeQuery("select column1,column2,otherColumns "
			//   + "from mytable where column1='whatever' and columns2 like '%whatever%'");
			 
			//ResultSet res = stmt.executeQuery("select sum(diffs.diff)/(1*5) from (select t1.ts as ts,t1.per50-t2.per50 as diff from (select ts,per50 from finesce_meteo where type='temp' and hour(ts)=12 and day(ts) > 13 order by ts limit 5) t1 join (select ts,per50 from finesce_meteo where type='temp' and hour(ts)=12 and day(ts) > 13 order by ts limit 5) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1) diffs");
			//ResultSet res = stmt.executeQuery("select t1.ts,t1.per50,t2.ts,t2.per50 from (select ts,per50 from finesce_meteo_orioncb where type='temp' and hour(ts)=12 and day(ts) > 13 order by ts limit 5) t1 join (select ts,per50 from finesce_meteo_orioncb where type='temp' and hour(ts)=12 and day(ts) > 13 order by ts limit 5) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1");
			//ResultSet res = stmt.executeQuery("select sqrt(select sum(sumatorio.potencia) / (1*5) power(2,(select t1.ts as ts, t1.per50 - t2.per50 as diff from (select ts,per50 from finesce_meteo_orioncb where type='temp' and hour(ts)=12 and day(ts) > 13 order by ts limit 5) t1 join (select ts,per50 from finesce_meteo_orioncb where type='temp' and hour(ts)=12 and day(ts) > 13 order by ts limit 5) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1)- (select sum(diffs.diff)/(1*5) from (   select t1.ts as ts, t1.per50 - t2.per50 as diff from (select ts, per50 from finesce_meteo_orioncb where type='temp' and hour(ts)=12 and day(ts) > 13 order by ts limit 5) t1 join (select ts, per50 from finesce_meteo_orioncb where type='temp' and hour(ts)=12 and day(ts) > 13 order by ts limit 5) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1) diffs) potencia) sumatorio)");
			//ResultSet res = stmt.executeQuery("select count(*) from finesce_meteo");         
	         
	        //System.out.println("paso 1");
			
			/*
			// iterate on the result
			while (res.next()) {
				String column1 = res.getString(1);
				Integer column2 = res.getInt(2);
				// whatever you want to do with this row, here
			} // while
			*/
	
			if (trazas_num_reg_totales) {
				ResultSet query = stmt.executeQuery(QUERY_NUM_REG_TOTALES);
				while (query.next()) {
					System.out.println("Num registros totales: " + query.getFloat(query.getMetaData().getColumnCount()));
				}
			}
			
			if (trazas_listar_registros) {
				ResultSet query = stmt.executeQuery(QUERY_LISTAR_REGISTROS);
				int contador_registros = 0;
				while (query.next()) {
					System.out.println("Registro " + contador_registros + ": " + query.getString(1));
					System.out.println(" -- " + query.getString(1) + " -- " + query.getString(2) + " -- " + query.getString(3) + " -- " + query.getString(4) + " -- " + query.getString(5) + " -- " + query.getString(6) + " -- " + query.getString(7));
					contador_registros++;
				}
			}
			
			
			int i = 0;
			// Trozo de c�digo que debe quedar activo
			HashMap mapa = new HashMap();
			
	        //System.out.println("paso 2");

			// hacemos N querys
			
			// N�mero de a�os considerados
			int N = 2;
			float media_i = 0;
			float media_i_abs = 0.0f;
			for (int cont=1; cont<=N; cont++) {
				
				// query funciona
				// Sacamos las variaciones de temperatura de un d�a con los anteriores hasta 5
				//String queryStr = "select t1.ts as ts,t1.value-t2.value as diff from (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts, 'T', ' '))=12 and day(ts) > " + (cal.get(Calendar.DAY_OF_MONTH) - cont) + " order by ts limit 5) t1 join (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts, 'T', ' '))=12 and day(ts) > " + (cal.get(Calendar.DAY_OF_MONTH) - cont) + " order by ts limit 5) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1";
				
				// Query correo paco
				//String queryStr = "select sum(diffs.diff)/(1*5) from (select t1.ts,t1.value-t2.value as diff from (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts,'T',' '))=12 and day(ts)>" + (cal.get(Calendar.DAY_OF_MONTH)) + " order by ts limit 5) t1 join (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts,'T',' '))=12 and day(ts)>" + (cal.get(Calendar.DAY_OF_MONTH)) + " order by ts limit 5) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1) diffs";
				// query buena
				//String queryStr = "select sum(diffs.diff)/(1*5) from (select t1.ts,t1.value-t2.value as diff from (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts,'T',' '))=12 and day(ts)>23 order by ts limit 5) t1 join (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts,'T',' '))=12 and day(ts)>23 order by ts limit 5) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1) diffs";

				String queryStr = "select sum(diffs.diff)/(1*5) from (select t1.ts,t1.value-t2.value as diff from (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts,'T',' '))=12 and (ts_ms > " + ((Calendar.getInstance().getTimeInMillis() / 1000) - 15*86400) + ") order by ts limit 31) t1 join (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts,'T',' '))=12 and (ts_ms > " + ((Calendar.getInstance().getTimeInMillis() / 1000) - 15*86400) + ") order by ts limit 31) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1) diffs";
				
				
				ResultSet query = stmt.executeQuery(queryStr);
				
				if (trazas) System.out.println("Query: " + queryStr);
				
				if (trazas) System.out.println("Mod d�a: " + (cal.get(Calendar.DAY_OF_MONTH)) % 31);
				if (trazas) System.out.println(Calendar.getInstance().getTimeInMillis() / 1000);
				
				//ResultSet query = stmt.executeQuery("select count(*) from finesce_meteo");
				
				// funciona con resta de un literal
				//ResultSet query = stmt.executeQuery("select subquery2.campo - 10 from (select sum(diffs.diff)/(1*31) campo from (select t1.ts as ts,t1.value-t2.value as diff from (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts, 'T', ' '))=12 and day(ts) > 13 order by ts limit 31) t1 join (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts, 'T', ' '))=12 and day(ts) > 13 order by ts limit 31) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1) diffs) subquery2");

				
				while (query.next()) {
					media_i = query.getFloat(query.getMetaData().getColumnCount());
				}
				//media_i = (val / (cont * 31));
				//media_i = val;
				media_i_abs = media_i;
				if (media_i < 0) media_i_abs = -media_i;
				mapa.put(i, media_i_abs);
				i++;
			}
			

			
			
			System.out.println("Mapa: " + mapa.toString());
			
			// n querys del pen�ltimo paso y luego dividir todo por N*31.
			// luego un bucle para todo Delta_i
			// Definici�n de la query
			

			// Sacaremos ahora la �ltima predicci�n a la que tenegamos acceso
			// Si esa predicci�n (que ser� para el d�a siguiente) dista en m�s del triple de la media de las variaciones anteriores, marcaremos ese valor como posiblemente err�neo de alguna menra.
			ResultSet queryUltimoValor = stmt.executeQuery(QUERY_ULTIMO_VALOR);
			                                              //select max(ts_ms), ts, value from finesce_meteo group by ts, value sort by ts desc limit 1;
//			ResultSet queryUltimoValor = stmt.executeQuery("select * from finesce_meteo");
			float valor_1 = 0;
			float valor_2 = 0;
			int j = 0;
			while (queryUltimoValor.next()) {
				if (j == 0) valor_1 = queryUltimoValor.getFloat(3);
				if (j == 3) valor_2 = queryUltimoValor.getFloat(3);
				j++;
			}
			
			
			if (trazas) System.out.println("Valor 1: " + valor_1);
			if (trazas) System.out.println("Valor 2: " + valor_2);
			if (trazas) System.out.println("Media: " + media_i);
			
			// Calculamos la desviaci�n media
			ResultSet queryStr2 = stmt.executeQuery("select sqrt(sum(diffs.diff*diffs.diff)/(1*31)) from (select t1.ts,t1.value-t2.value- " + media_i + " as diff from (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts,'T',' '))=12 and (ts_ms > " + ((Calendar.getInstance().getTimeInMillis() / 1000) - 15*86400) + ") order by ts limit 31) t1 join (select ts,value from finesce_meteo where attribute_name='temp' and hour(regexp_replace(ts,'T',' '))=12 and (ts_ms > " + ((Calendar.getInstance().getTimeInMillis() / 1000) - 15*86400) + ") order by ts limit 31) t2 on year(t1.ts)=year(t2.ts) and month(t1.ts)=month(t2.ts) and day(t1.ts)=day(t2.ts)+1) diffs");
			float desviacion_media = 0.0f;
			while (queryStr2.next()) {
				//desviacion_media = queryStr2.getFloat(queryStr2.getMetaData().getColumnCount());
				desviacion_media = queryStr2.getFloat(1);
			}
			
			System.out.println("Desviaci�n media: " + desviacion_media);

			
			// La diferencia de los �ltimos dos valores no puede exceder del triple de la desviaci�n media.
			float diff = (valor_1 - valor_2);
			float diff_abs = diff;
			if (diff < 0) diff_abs = -diff;
			int correcto = 0;
			System.out.println(" ----- ");
			float diff_media_i = diff_abs - media_i_abs;
			if (diff_media_i < 0) diff_media_i = -diff_media_i;
			if ((diff_media_i) < (coeficiente_tolerancia * desviacion_media)) {
				System.out.println("�ltima predicci�n correcta.");
				System.out.println("Diff_media_i: " + (diff_media_i));
				System.out.println("Media: " + (coeficiente_tolerancia * desviacion_media) + "(coeficiente_tolerancia " + coeficiente_tolerancia + ", desviacion_media " + desviacion_media + ")");
				correcto = 1;
			}
			else {
				System.out.println("Fallo: se ha encontrado una �ltima medici�n fallida.");
				System.out.println("Diff_media_i: " + (diff_media_i));
				System.out.println("Media: " + (coeficiente_tolerancia * desviacion_media));
			}
			
			
			
			System.out.println("");
			
			try {
				// mensaje:  "time$timestamp$param$media$diff$correcto$ult_prediccion$coef_tol*desviacion_media"
				// predicci�n correcto: correcto=1
				// predicci�n susceptible de ser err�nea: correcto=0
				Calendar calendario = Calendar.getInstance();
				String mensaje = calendario.getTime() + "$" + calendario.getTimeInMillis() + "$" + "temp" + "$" + media_i + "$" + diff + "$" + correcto + "$" + valor_1 + "$" + coeficiente_tolerancia * desviacion_media;
				if (inserto_en_bbdd) basedatos.insertarMensajeHive(Calendar.getInstance(), mensaje);
				System.out.println("Traza a bbdd: " + mensaje);
			}
			catch (Exception e) {
				System.out.println("Error en la inserci�n en base de datos");
				basedatos.cerrarConexion();
			}
			finally {
				basedatos.cerrarConexion();
			}
			
			/*
	     	FileWriter fichero = null;
	        PrintWriter pw = null;
	
	        try {
				fichero = new FileWriter("prueba.txt");
				pw = new PrintWriter(fichero);
				
				int j = 0;
				
				// iterate on the result
				while (res.next()) {
					String s = "";
					for (int i = 1; i < res.getMetaData().getColumnCount(); i++) {
						s += res.getString(i) + ",";
						//pw.println("Linea " + i + ": " + res.getString(i));
					} // for
					s += res.getString(res.getMetaData().getColumnCount());
					pw.println(s);
					//if (j < 10)
						//basedatos.insertarMensajeHive(Calendar.getInstance(), s);
					System.out.println(s);
					j++;
				} // while
				
	        } catch (Exception e) {
	        	e.printStackTrace();
	        } finally {
				try {
					// Nuevamente aprovechamos el finally para 
					// asegurarnos que se cierra el fichero.
					if (null != fichero)
						fichero.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
		    }         
	        */ 
	         // -------------------------------------------------------------------------
	
	        //System.out.println("Traza del archivo.");
	        
	        
	        /*
	        System.out.println("------------------- INICIO");
	 
	        JSch jsch = new JSch();
	        try {
	            Session session = jsch.getSession(user, host, port);
	            UserInfo ui = new SUserInfo(pass, null);
	
	            session.setUserInfo(ui);
	            session.setPassword(pass);
	            session.connect();
	
	            ChannelSftp sftp = (ChannelSftp)session.openChannel("sftp");
	            sftp.connect();
	
	            sftp.cd("");
	            System.out.println("Subiendo c:/ejemplo.txt ...");
	            sftp.put("prueba.txt", "ejemplo.txt");
	
	            System.out.println("Archivos subidos.");
	
	            sftp.exit();
	            sftp.disconnect();
	            session.disconnect();
	        }
	        catch (Exception e) {
	            
	        }
	        System.out.println("----------------- FIN");
	        */
		  
        	// -------------------------------------------------------------------------
         
			// close everything
			//res.close();
			stmt.close();
			con.close();
			basedatos.cerrarConexion();
   			if (trazas) System.out.println("Fin doQuery");
   			if (trazas) System.out.println("-------------------------------------------");

		} catch (SQLException ex) {
			basedatos.cerrarConexion();
			System.out.println("Error doQuery");
			System.out.println(ex.getMessage());
			System.exit(0);
		} finally {
			basedatos.cerrarConexion();
		} // try catch
		
   	} // doQuery

	public static void main(String[] args) {
		// get a connection to the Hive server running on the specified IP address, listening on 10000/TCP port
		// authenticate using my credentials
		//con = getConnection("130.206.80.46", "10000", cosmos_username, cosmos_password);
		
		final Timer temp = new Timer();
		temp.scheduleAtFixedRate(new TimerTask() {
			public void run() {
				//doQuery();
				con = getConnection(cosmos_hostname, cosmos_port, cosmos_username, cosmos_password);
				System.out.println("Ejecuci�n del algoritmo.");
				// do a query, querying the Hive server will automatically imply the execution of one or more MapReduce jobs
				doQuery();
			}
		}, 1, intervalo_hilo);
		
	} // main

	public static void ejecutaQuery() {
		final Timer temp = new Timer();
		temp.scheduleAtFixedRate(new TimerTask() {
			public void run() {
				// get a connection to the Hive server running on the specified IP
				// address, listening on 10000/TCP port
				// authenticate using my credentials
				con = getConnection(cosmos_hostname, cosmos_port, cosmos_username, cosmos_password);
		
				// do a query, querying the Hive server will automatically imply the
				// execution of one or more MapReduce jobs
				doQuery();
			}
		}, 1, intervalo_hilo);
	} // main
   
} // HiveClient
