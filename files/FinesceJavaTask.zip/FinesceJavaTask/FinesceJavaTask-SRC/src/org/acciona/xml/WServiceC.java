package org.acciona.xml;


/**
 *
 * @author wsnacciona 
 */
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

import org.acciona.auxiliares.FilenameFactory;
import org.acciona.bd.FuncionesBD;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
/*import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
*/

public class WServiceC {
    
    String endpUrl = "";
    QName serviceName;
    QName portName;
    Service service;
    Dispatch<SOAPMessage> dispatch;
    MessageFactory mf;
    String elementos_Inico[]={"Id","Data","Timestamp","DataType"};
    
    public WServiceC(String endpointUrl,String service_name, String port_name) throws SOAPException{
        endpUrl = endpointUrl;
        serviceName = new QName(endpUrl, service_name);
        portName = new QName(endpUrl, port_name);
        
        service = Service.create(serviceName);
        service.addPort(portName, SOAPBinding.SOAP12HTTP_BINDING, endpUrl);
        /** Create a Dispatch instance from a service.**/ 
        //dispatch = service.createDispatch(portName, SOAPMessage.class, Service.Mode.MESSAGE);             
        
        //mf = MessageFactory.newInstance(SOAPConstants.SOAP_1_2_PROTOCOL);    
        
        
    }
    
    

      
      
    public SOAPMessage creaMsgFinesce(String valores[]) throws SOAPException {
        
        
        
        /*
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            DOMImplementation implementation = builder.getDOMImplementation();
            Document document = implementation.createDocument(null, "documento", null);
            document.setXmlVersion("1.0");

            Element raiz = document.getDocumentElement();
        
            Element nodoNombreCampo = document.createElement("ElementoHijoDeLaRa�z"); //creamos un nuevo elemento
            Text nodoValorCampo = document.createTextNode("contenido del elemento hijo"); //Ingresamos la info				
            nodoNombreCampo.appendChild(nodoValorCampo); 						
            raiz.appendChild(nodoNombreCampo); //pegamos el elemento a la raiz "Documento"
            
            
            Source source = new DOMSource(document);
            Result result = new StreamResult(new java.io.File("resultado.xml"));//nombre del archivo
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(source, result);


            
            
            
            System.out.println(result);
        }
        catch (Exception e) {
            System.out.println("");
        }

        */
        
        
        // ----------------------------------------------------------------------
        // ----- Inicio de ejemplo de construcci�n xml
        /*
        // Create a message.  This example works with the SOAPPART.
        SOAPMessage request = mf.createMessage();
        SOAPPart part = request.getSOAPPart();

        // Obtain the SOAPEnvelope and header and body elements.
        SOAPEnvelope env = part.getEnvelope();
        env.addNamespaceDeclaration("wsa", "http://schemas.xmlsoap.org/ws/2004/08/addressing");
        SOAPHeader header = env.getHeader();

        SOAPElement op = header.addChildElement("Action", "wsa");
        op.addTextNode("http://www.plantcockpit.eu/acc/s/ADPServicePortType/ADPActionRequest");


        SOAPBody body = env.getBody();
        // Construct the message payload.
        SOAPElement operation = body.addChildElement("ADPActionRequestMsg", "n0", "http://www.plantcockpit.eu/acc/s");
        
        //Aseguramos que no nos pasamos de elementos en el array
        int largo = Math.min(elementos_Inico.length,valores.length);
                
        for (int i=0;i<largo;i++){ 
            operation.addChildElement(elementos_Inico[i],"n0").addTextNode(valores[i]);      
        }*/
        // ----- Fin de ejemplo de construcci�n xml
        // ----------------------------------------------------------------------
        
        
        // Create a message.  This example works with the SOAPPART.
        SOAPMessage request = mf.createMessage();
        SOAPPart part = request.getSOAPPart();
        

        //Node n;
        //part.appendChild(n);
                
        // Obtain the SOAPEnvelope and header and body elements.
        SOAPEnvelope env = part.getEnvelope();
        //env.addNamespaceDeclaration("wsa", "http://schemas.xmlsoap.org/ws/2004/08/addressing");
        //SOAPHeader header = env.getHeader();

        //SOAPElement op = header.addChildElement("Action", "wsa");
        //op.addTextNode("http://www.plantcockpit.eu/acc/s/ADPServicePortType/ADPActionRequest");


        
        //SOAPEnvelope envelope = part.getEnvelope();
        //SOAPElement userNameToken = env.getHeader().addChildElement("Usernametoken", "prefijo", "ns");
        //SOAPElement user = userNameToken.addChildElement("UserName", "prefijo", "ns");
        
        
        SOAPBody body = env.getBody();
        
        
        // Construct the message payload.
        //SOAPElement operation = body.addChildElement("ADPActionRequestMsg", "", "http://www.plantcockpit.eu/acc/s");
        SOAPElement updctxreq = body.addChildElement("updateContextRequest");
        SOAPElement ctxelelist = updctxreq.addChildElement("contextElementList");
        SOAPElement ctxele = ctxelelist.addChildElement("contextElement");
        
        /**
         * Creaci�n de la siguiente parte del c�digo
         * <entityId isPattern="false" type="finesce_wsn">
         * <id>finesce_wsn</id>
         * </entityId>
         **/
        SOAPElement entityid = ctxele.addChildElement("entityId");
        QName qname_type = new QName("type");
        entityid.addAttribute(qname_type, "finesce_wsn");
        QName qname_ispattern = new QName("isPattern");
        entityid.addAttribute(qname_ispattern, "false");
        SOAPElement entityid_id = entityid.addChildElement("id").addTextNode("finesce_wsn");
        
        /**
         * Creaci�n de contextAttributeList
         */
        SOAPElement contextattributelist = ctxele.addChildElement("contextAttributeList");

        SOAPElement contextattribute = contextattributelist.addChildElement("contextattribute");

        
        //Aseguramos que no nos pasamos de elementos en el array
        int largo = Math.min(elementos_Inico.length,valores.length);
                
        for (int i=0;i<largo;i++){ 
            contextattribute.addChildElement(elementos_Inico[i]).addTextNode(valores[i]);      
        }
        
        
        
        
        
        request.saveChanges();
        return (request);
    }//del creaMsgInico
      
    /**
     * Funci�n que dado un array de 4 valores devuelve un String en formato XML 
     * listo para enviar a OrionCB (130.206.80.144).
     * Referencia: http://www.mkyong.com/java/how-to-create-xml-file-in-java-dom/
     * @param valores
     * @return xml
     */
    
    public String crearMensajeXMLBigData(String valores[]) {

        try {

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // root elements
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("updateContextRequest");
            doc.appendChild(rootElement);

            // contextElementList elements
            Element contextElementList = doc.createElement("contextElementList");
            rootElement.appendChild(contextElementList);

            // contextElementList elements
            Element contextElement = doc.createElement("contextElement");
            contextElementList.appendChild(contextElement);
            
            // entityId elements
            Element entityId = doc.createElement("entityId");
            Attr attr1 = doc.createAttribute("type");
            attr1.setValue("finesce_wsn");
            entityId.setAttributeNode(attr1);
            Attr attr2 = doc.createAttribute("isPattern");
            attr2.setValue("false");
            entityId.setAttributeNode(attr2);
            Element id = doc.createElement("id");
            id.appendChild(doc.createTextNode("finesce_wsn"));
            entityId.appendChild(id);
            contextElement.appendChild(entityId);

            
            Element contextAttributeList = doc.createElement("contextAttributeList");
            contextElement.appendChild(contextAttributeList);
            
            // Inicio del parseo de los atributos
            
            // - Medida

            // --> name
            Element contextAttribute_medida = doc.createElement("contextAttribute");
            contextAttributeList.appendChild(contextAttribute_medida);
            
            Element name_medida = doc.createElement("name");
            name_medida.appendChild(doc.createTextNode("medida"));
            contextAttribute_medida.appendChild(name_medida);
            // --> type
            Element type_medida = doc.createElement("type");
            type_medida.appendChild(doc.createTextNode("string"));
            contextAttribute_medida.appendChild(type_medida);
            // --> contextValue
            Element contextValue_medida = doc.createElement("contextValue");
            contextValue_medida.appendChild(doc.createTextNode(valores[0]));
            contextAttribute_medida.appendChild(contextValue_medida);

            // - Magnitud

            // --> name
            Element contextAttribute_magnitud = doc.createElement("contextAttribute");
            contextAttributeList.appendChild(contextAttribute_magnitud);
            
            Element name_magnitud = doc.createElement("name");
            name_magnitud.appendChild(doc.createTextNode("magnitud"));
            contextAttribute_magnitud.appendChild(name_magnitud);
            // --> type
            Element type_magnitud = doc.createElement("type");
            type_magnitud.appendChild(doc.createTextNode("string"));
            contextAttribute_magnitud.appendChild(type_magnitud);
            // --> contextValue
            Element contextValue_magnitud = doc.createElement("contextValue");
            contextValue_magnitud.appendChild(doc.createTextNode(valores[1]));
            contextAttribute_magnitud.appendChild(contextValue_magnitud);
            
            // - Valor

            // --> name
            Element contextAttribute_valor = doc.createElement("contextAttribute");
            contextAttributeList.appendChild(contextAttribute_valor);
            
            Element name_valor = doc.createElement("name");
            name_valor.appendChild(doc.createTextNode("valor"));
            contextAttribute_valor.appendChild(name_valor);
            // --> type
            Element type_valor = doc.createElement("type");
            type_valor.appendChild(doc.createTextNode("float"));
            contextAttribute_valor.appendChild(type_valor);
            // --> contextValue
            Element contextValue_valor = doc.createElement("contextValue");
            contextValue_valor.appendChild(doc.createTextNode(valores[2]));
            contextAttribute_valor.appendChild(contextValue_valor);
           
            // - Timestamp

            // --> name
            Element contextAttribute_timestamp = doc.createElement("contextAttribute");
            contextAttributeList.appendChild(contextAttribute_timestamp);
            
            Element name_timestamp = doc.createElement("name");
            name_timestamp.appendChild(doc.createTextNode("timestamp"));
            contextAttribute_timestamp.appendChild(name_timestamp);
            // --> type
            Element type_timestamp = doc.createElement("type");
            type_timestamp.appendChild(doc.createTextNode("s"));
            contextAttribute_timestamp.appendChild(type_timestamp);
            // --> contextValue
            Element contextValue_timestamp = doc.createElement("contextValue");
            contextValue_timestamp.appendChild(doc.createTextNode(String.valueOf(Calendar.getInstance().getTimeInMillis()/1000)));
            contextAttribute_timestamp.appendChild(contextValue_timestamp);
            
            
            // - IdSensor

            // --> name
            Element contextAttribute_idsensor = doc.createElement("contextAttribute");
            contextAttributeList.appendChild(contextAttribute_idsensor);
            
            Element name_idsensor = doc.createElement("name");
            name_idsensor.appendChild(doc.createTextNode("idsensor"));
            contextAttribute_idsensor.appendChild(name_idsensor);
            // --> type
            Element type_idsensor = doc.createElement("type");
            type_idsensor.appendChild(doc.createTextNode("int"));
            contextAttribute_idsensor.appendChild(type_idsensor);
            // --> contextValue
            Element contextValue_idsensor = doc.createElement("contextValue");
            contextValue_idsensor.appendChild(doc.createTextNode(valores[3]));
            contextAttribute_idsensor.appendChild(contextValue_idsensor);

            
            // Fin del parseo de los atributos
            
            // updateAction
            Element updateAction = doc.createElement("updateAction");
            updateAction.appendChild(doc.createTextNode("APPEND"));
            rootElement.appendChild(updateAction);
            
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);

            // write the content into xml file
            //StreamResult result = new StreamResult(new File("C:\\fichero_xml_prueba.xml"));
            //transformer.transform(source, result);

            // Output to console for testing
            //StreamResult result_output = new StreamResult(System.out);
            //transformer.transform(source, result_output);
            System.out.println("File created BigData!");
            
            System.out.println("XML BigData:");
            System.out.println(convertDocumentToString(doc));
            
            return convertDocumentToString(doc);
            
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }
        return "";
    
    }

    public String crearMensajeXMLRenew(int subscriptionId) {

        boolean trazas = true;
        
        try {

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // root elements
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("contextQL");
            doc.appendChild(rootElement);

            // contextElementList elements
            Element ctxQuery = doc.createElement("ctxQuery");
            rootElement.appendChild(ctxQuery);

            // action elements
            Element action = doc.createElement("action");
            Attr attr1 = doc.createAttribute("type");
            attr1.setValue("SUBSCRIBE");
            action.setAttributeNode(attr1);
            ctxQuery.appendChild(action);
            
            Element validity = doc.createElement("validity");
            validity.appendChild(doc.createTextNode("14440"));
            ctxQuery.appendChild(validity);

            Element subId = doc.createElement("subId");
            subId.appendChild(doc.createTextNode("" + subscriptionId));
            ctxQuery.appendChild(subId);
            
            
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);

            // write the content into xml file
            //StreamResult result = new StreamResult(new File("C:\\fichero_xml_prueba.xml"));
            //transformer.transform(source, result);

            System.out.println("File created XMLRenew!");
           
            System.out.println("XML Renew:");
            System.out.println(convertDocumentToString(doc));

            String prefix = "cqlReq=<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            return (prefix + convertDocumentToString(doc));
            
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }
        finally {
            // Release current connection to the connection pool
            // once you are done**
            //post.releaseConnection();

        }
        return null;
    
    }
        
    
    public void sendMsg(SOAPMessage m){
        SOAPMessage response = dispatch.invoke(m);
    }
    
    
    /**
     * Funci�n que env�a un xml dado a un servicio web especificado por los datos
     * pasados por par�metro.
     * @param hostname
     * @param port
     * @param service_name
     * @param xml 
     */
    public int sendXML(String hostname, int port, String service_name, String contentType, String xml) {

        int result = 0;
        boolean trazas = true;

        // Create request xml**
        //Element request = new Element("request");
        // Create PostMethod specifying service url**
        String serviceUrl = "http://" + hostname + service_name;
        if (port != 0)
            serviceUrl = "http://" + hostname + ":" + port + service_name;
        

        if (trazas) System.out.println("Service_url: " + serviceUrl);

        PostMethod post = new PostMethod(serviceUrl);

        try {
            //String postData = Xml.getString(new Document(request));
            String postData = xml;

            // Set post data, mime-type and encoding**
            post.setRequestEntity(new StringRequestEntity(postData, contentType, "UTF8"));

            // Send request**
            HttpClient httpclient = new HttpClient();
            result = httpclient.executeMethod(post);

            // Display status code**
            System.out.println("Response status code: " + result);

            String response = post.getResponseBodyAsString();
            
            if (contentType == "application/x-www-form-urlencoded") {
            	result = getSubIdFromResponse(response);
            }
            
            // Display response**
            System.out.println("Response body (id " + result + "): ");
            System.out.println(response);

        } catch (Exception ex) {
        	result = -1;
            ex.printStackTrace();

        } finally {
            // Release current connection to the connection pool
            // once you are done**
            post.releaseConnection();
        }
        return result;
    }

    public int getSubIdFromResponse(String response) {
    	int result = 0;
    	String cadena_inicio = "";
    	String cadena_fin = "";
    	
    	if (response.indexOf("<subId>") != -1) {
    		cadena_inicio = "<subId>";
    		cadena_fin = "</subId>";
    	}
    	if (response.indexOf("<subid>") != -1) {
    		cadena_inicio = "<subid>";
    		cadena_fin = "</subid>";
    	}
    	
    	
    	
    	System.out.println("indexof : " + response);
    	
    	String[] s1 = response.split(cadena_inicio);
    	String[] s2 = s1[1].split(cadena_fin);
    	result = Integer.parseInt(s2[0]);
    	return result;
    }
    
    public void sendXMLRenew(String hostname, String service_name, String xml) {

        
        boolean trazas = true;


        // Create request xml**
        //Element request = new Element("request");
        // Create PostMethod specifying service url**
        String serviceUrl = "http://" + hostname + service_name + xml.toString();

        if (trazas) System.out.println("serviceUrl : " + serviceUrl);

        PostMethod post = new PostMethod(serviceUrl);

        try {
            //String postData = Xml.getString(new Document(request));
            String postData = "";

            // Set post data, mime-type and encoding**
            post.setRequestEntity(new StringRequestEntity(xml, "application/xml", "UTF8"));

            // Send request**
            HttpClient httpclient = new HttpClient();
            int result = httpclient.executeMethod(post);

            // Display status code**
            System.out.println("Response status code: " + result);

            // Display response**
            System.out.println("Response body: ");
            System.out.println(post.getResponseBodyAsString());

        } catch (Exception ex) {
            ex.printStackTrace();

        } finally {
            // Release current connection to the connection pool
            // once you are done**
            post.releaseConnection();
        }
    }
    
    public String crearMensajeXMLPubSubSubscribe(ResultSet rs, int idtemp) {

    	Calendar cal = Calendar.getInstance();
        FilenameFactory ff = new FilenameFactory();
        
        try {

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            // root elements
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("contextQL");

            Element ctxQuery = doc.createElement("ctxQuery");
            rootElement.appendChild(ctxQuery);
            
            Element action = doc.createElement("action");
            // attr1
            Attr attr1_contextProvider = doc.createAttribute("type");
            attr1_contextProvider.setValue("SUBSCRIBE");
            action.setAttributeNode(attr1_contextProvider);            
            ctxQuery.appendChild(action);
            
            Element entity = doc.createElement("entity");
            entity.appendChild(doc.createTextNode("imei|123456789123"));
            ctxQuery.appendChild(entity);
            
            Element scope = doc.createElement("scope");
            scope.appendChild(doc.createTextNode("cell"));
            ctxQuery.appendChild(scope);
            
            Element conds = doc.createElement("conds");
            ctxQuery.appendChild(conds);
            
            // cond type="ONVALUE"
            Element cond = doc.createElement("cond");
            Attr attr1_type = doc.createAttribute("type");
            attr1_type.setValue("ONVALUE");
            cond.setAttributeNode(attr1_type); 
            conds.appendChild(cond);
            
            // logical op="AND"
            Element logical = doc.createElement("logical");
            Attr attr2_op = doc.createAttribute("op");
            attr2_op.setValue("AND");
            logical.setAttributeNode(attr2_op);
            cond.appendChild(logical);
            
            while (rs.next()) {
            	
            	System.out.println("Encuentro un par�metro.");
            	
            	Element constraint = doc.createElement("constraint");
            	// param
                Attr attr1_param = doc.createAttribute("param");
                attr1_param.setValue("cell." + rs.getString(1).trim());
                constraint.setAttributeNode(attr1_param); 

            	// op
                Attr attr1_op = doc.createAttribute("op");
                attr1_op.setValue(rs.getString(2).toUpperCase().trim());
                constraint.setAttributeNode(attr1_op); 

                // value
                Attr attr1_value = doc.createAttribute("value");
                attr1_value.setValue(rs.getString(3).trim());
                constraint.setAttributeNode(attr1_value); 

                logical.appendChild(constraint);
            }
            
            doc.appendChild(rootElement);
            
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            
            System.out.println("XML PubSub create subscription:");
            String prefix = "cqlReq=<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            return (prefix + convertDocumentToString(doc) + "&callbackUrl=http://212.49.136.67/FINESCE_WS/Service.asmx/NotificationsListener");
            
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return "";
    	
    }
    

    /**
     * Funci�n que dado un array de 4 valores devuelve un String en formato XML 
     * listo para enviar a OrionCB (130.206.80.144).
     * Referencia: http://www.mkyong.com/java/how-to-create-xml-file-in-java-dom/
     * @param valores
     * @return xml
     */
    
    public String crearMensajeXMLPubSub(String[] valores) {

        Calendar cal = Calendar.getInstance();
        FilenameFactory ff = new FilenameFactory();
        

        try {

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // root elements
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("contextML");
            // attr1
            Attr attr1_contextML = doc.createAttribute("xmlns");
            attr1_contextML.setValue("http://ContextML/1.7");
            rootElement.setAttributeNode(attr1_contextML);
            // attr2
            Attr attr2_contextML = doc.createAttribute("xmlns:xsi");
            attr2_contextML.setValue("http://www.w3.org/2001/XMLSchema-instance");
            rootElement.setAttributeNode(attr2_contextML);
            // attr3
            Attr attr3_contextML = doc.createAttribute("xsi:schemaLocation");
            attr3_contextML.setValue("http://ContextML/1.7 ../ContextML-1.7.xsd");
            rootElement.setAttributeNode(attr3_contextML);
            doc.appendChild(rootElement);

            // cxtEls elements
            Element ctxEls = doc.createElement("ctxEls");
            rootElement.appendChild(ctxEls);

            // cxtEl elements
            Element ctxEl = doc.createElement("ctxEl");
            ctxEls.appendChild(ctxEl);

            // contextProvider elements
            Element contextProvider = doc.createElement("contextProvider");
            // attr1
            Attr attr1_contextProvider = doc.createAttribute("id");
            attr1_contextProvider.setValue("MyClient");
            contextProvider.setAttributeNode(attr1_contextProvider);
            // attr2
            Attr attr2_contextProvider = doc.createAttribute("v");
            attr2_contextProvider.setValue("1.2.1");
            contextProvider.setAttributeNode(attr2_contextProvider);

            ctxEl.appendChild(contextProvider);            
            

            // entity elements
            Element entity = doc.createElement("entity");
            // attr1
            Attr attr1_entity = doc.createAttribute("id");
            attr1_entity.setValue("1234567891234");
            entity.setAttributeNode(attr1_entity);
            // attr2
            Attr attr2_entity = doc.createAttribute("type");
            attr2_entity.setValue("wsn");
            entity.setAttributeNode(attr2_entity);

            ctxEl.appendChild(entity);            
            
            Element scope = doc.createElement("scope");
            scope.appendChild(doc.createTextNode("cell"));
            ctxEl.appendChild(scope);   
            
            Element timestamp = doc.createElement("timestamp");
            timestamp.appendChild(doc.createTextNode(cal.get(Calendar.YEAR) + "-" + ff.rellenaCeros(String.valueOf(cal.get(Calendar.DAY_OF_MONTH)),2) + "-" + ff.rellenaCeros(String.valueOf(cal.get(Calendar.MONTH) + 1),2) + "T" + ff.rellenaCeros(String.valueOf(cal.get(Calendar.HOUR)),2) + ":" + ff.rellenaCeros(String.valueOf(cal.get(Calendar.MINUTE)),2) + ":" + (ff.rellenaCeros(String.valueOf(cal.get(Calendar.SECOND)),2) + "+01:00")));
            ctxEl.appendChild(timestamp);            

            Element expires = doc.createElement("expires");
            expires.appendChild(doc.createTextNode("2020-01-01T10:10:10+01:00"));
            ctxEl.appendChild(expires);            
              

            Element datapart = doc.createElement("dataPart");
            ctxEl.appendChild(datapart);
            
            // medida
            Element par_medida = doc.createElement("par");
            Attr attr1_medida = doc.createAttribute("n");
            attr1_medida.setValue("medida");
            par_medida.setAttributeNode(attr1_medida);
            par_medida.appendChild(doc.createTextNode(valores[0]));
            datapart.appendChild(par_medida);
            
            // magnitud
            Element par_magnitud = doc.createElement("par");
            Attr attr1_magnitud = doc.createAttribute("n");
            attr1_magnitud.setValue("magnitud");
            par_magnitud.setAttributeNode(attr1_magnitud);
            par_magnitud.appendChild(doc.createTextNode(valores[1]));
            datapart.appendChild(par_magnitud);
            
            // valor
            Element par_valor = doc.createElement("par");
            Attr attr1_valor = doc.createAttribute("n");
            attr1_valor.setValue("valor");
            par_valor.setAttributeNode(attr1_valor);
            par_valor.appendChild(doc.createTextNode(valores[2]));
            datapart.appendChild(par_valor);
            
            // fecha
            Element par_fecha = doc.createElement("par");
            Attr attr1_fecha = doc.createAttribute("n");
            attr1_fecha.setValue("fecha");
            par_fecha.setAttributeNode(attr1_fecha);
            par_fecha.appendChild(doc.createTextNode("" + (Calendar.getInstance().getTimeInMillis() / 1000)));
            datapart.appendChild(par_fecha);              

            // idsensor
            Element par_idsensor = doc.createElement("par");
            Attr attr1_idsensor = doc.createAttribute("n");
            attr1_idsensor.setValue("idsensor");
            par_idsensor.setAttributeNode(attr1_idsensor);
            par_idsensor.appendChild(doc.createTextNode(valores[3]));
            datapart.appendChild(par_idsensor);            
            
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);

            // write the content into xml file
            //StreamResult result = new StreamResult(new File("C:\\fichero_xml_prueba.xml"));
            //transformer.transform(source, result);

            // Output to console for testing
            //StreamResult result_output = new StreamResult(System.out);
            //transformer.transform(source, result_output);
            //System.out.println("File created!");

            System.out.println("XML PubSub:");
            System.out.println(convertDocumentToString(doc));
            
            return convertDocumentToString(doc);
            
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }
        return "";
    }

    
    /**
     * Funci�n que convierte una variable de tipo Document en un String con el contenido del mismo.
     * http://www.journaldev.com/1237/java-convert-string-to-xml-document-and-xml-document-to-string
     * @param doc
     * @return 
     */
    private static String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
            e.printStackTrace();
        }
         
        return null;
    }    
    
}

