package org.acciona.bd;

import java.sql.*;

public class Bd {

   private String url; //= "jdbc:postgresql://localhost/sensado";
   Connection con;
   Statement stn;
   ResultSet rs;
   String usuario, passw;

   public Bd(String servidor, String bd, String user, String pass) {
       // Cadena para lanzar el programa desde OrionCB
	   //url = "jdbc:sqlserver://" + servidor + ":1433;";///databaseName=" + bd + ";user=" + user + ";password=" + pass + ";";
       // Cadena para lanzar el programa desde Eclipse Juno
       url = "jdbc:sqlserver://" + servidor + ":14333";///databaseName=" + bd + ";user=" + user + ";password=" + pass + ";";
       usuario = user;
       passw = pass;

       try {
           Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

       } catch (Exception e) {
           e.printStackTrace();
           System.out.println("ERRRO");
       }
   }

   /**
    * Crea una conexi�n a la base de datos
    * @return Valor l�gico que indica si se ha podido realizar la conexi�n.
    */
   public boolean abrirConexion() {
       try {
           if ((stn == null) || (stn.isClosed())) {
               con = DriverManager.getConnection(url, usuario, passw);
               stn = con.createStatement();
               return (true);
           }
       } catch (SQLException ex) {
           ex.printStackTrace();
           return (false);
       }
       return (true);
   }

   /**
    * Cierra una conexi�n a la base de datos
    * @return Valor l�gico que indica si se ha podido cerrar la conexi�n.
    */
   public boolean cerrarConexion() {
       try {
           if (!stn.isClosed()) {
               con.close();
               stn.close();
           }
       } catch (SQLException ex) {
           ex.printStackTrace();
           return (false);
       }
       return (true);
   }

   /**
    * Funci�n para realizar consultas pas�ndole directamente la cadena de texto
    * con la query.
    * @param query Cadena de texto con la query para la base de datos
    * @return Resultset de la consulta
    */
   public ResultSet consulta(String query) {
       try {
           if (stn.isClosed() == true) {
               abrirConexion();
           }
           rs = stn.executeQuery(query);
           //cerrarConexion();
           return (rs);
       } catch (SQLException ex) {
           //cerrarConexion();
           return ((null));
       }
   }

   /**
    * Funci�n para realizar inserciones y actualizaciones
    * @param orden Cadena de texto con la inserci�n o la actualizaci�n
    * @return Valor l�gico que indica si se ha podido realizar la actualizaci�n o inserci�n
    */
   public boolean insercionActualizacion(String orden) {
       try {
           if (stn.isClosed() == true) {
               abrirConexion();
           }
           stn.executeUpdate(orden);
           //cerrarConexion();
           return (true);
       } catch (SQLException ex) {
           //cerrarConexion();
           return (false);
       }
   }

   /**
    * Funci�n que crea un comando de consulta preparado para insertarle a posteriori los par�metros.
    * @param orden Cadena de texto con la consulta
    * @return Un objeto PreparedStatement con la consulta preparada
    */
   public PreparedStatement preparar(String orden) {
       PreparedStatement stm;
       try {
           stm = con.prepareStatement(orden);
           return (stm);
       } catch (Exception e) {
           return (null);
       }
   }

   /**
    * Funci�n que ejecuta una consulta con el comando preparado pasado como par�metro.
    * @param stnprp Objeto PreparedStatement a utilizar
    * @return ResultSet de la consulta
    */
   public ResultSet queryPreparado(PreparedStatement stnprp) {
       ResultSet rs2;

       try {
           if (stn.isClosed()) {
               abrirConexion();
           }
           rs2 = stnprp.executeQuery();
           //cerrarConexion();
           return (rs2);
       } catch (Exception e) {
           //cerrarConexion();
           return (null);
       }
   }

   /**
    * Funci�n que ejecuta una actualizaci�n, borrado o inserci�n con el comando preparado pasado como par�metro.
    * @param stnprp Objeto PreparedStatement a utilizar
    * @return Valor l�gico indicando si se ha podido realizar o no la acci�n
    */
   public boolean nonqueryPreparado(PreparedStatement stnprp) {

       try {
           if (stn.isClosed()) {
               abrirConexion();
           }
           stnprp.executeUpdate();
           return (true);
       } catch (Exception e) {
           //cerrarConexion();
           return (false);
       }

   }

   /**
    * Funci�n que ejecuta un array de �rdenes en una misma transacci�n, devolviendo el
    * valor de la �ltima query, que ser� obligatoriamente una consulta. El resto son
    * inserciones o actualizaciones.
    * @param ordenes Vector de cadenas de caracteres con los comandos a ejecutar
    * @return ResultSet de la consulta
    */
   public ResultSet queryTransaccion(String ordenes[]) {
       int largo = ordenes.length;
       ResultSet rs_q;

       try {
           con.setAutoCommit(false);

           for (int i = 0; i < largo - 1; i++) {
               stn.executeUpdate(ordenes[i]);
           }
           con.commit();

           if (largo > 0) {
               rs_q = stn.executeQuery(ordenes[largo - 1]);
               con.commit();
               con.setAutoCommit(true);
               return (rs_q);
           }
           con.setAutoCommit(true);
           return (null);
       } catch (SQLException e) {
           try {
               con.rollback();
               con.setAutoCommit(true);
               return (null);
           } catch (SQLException e2) {
               try {
                   con.setAutoCommit(true);
                   return (null);
               } catch (SQLException e3) {
                   return (null);
               }
           }
       }
   }

   /**
    * Funci�n que ejecuta un array de �rdenes en una misma transacci�n, devolviendo el
    * valor de la �ltima query, que ser� obligatoriamente una consulta. El resto son
    * inserciones o actualizaciones.
    * @param ordenes Vector de objetos PreparedStatement con los comandos a ejecutar
    * @return ResultSet de la consulta
    */
   public ResultSet queryTransaccion(PreparedStatement ordenes[]) {
       int largo = ordenes.length;
       ResultSet rs;

       try {
           con.setAutoCommit(false);
           for (int i = 0; i < largo - 1; i++) {
               ordenes[i].executeUpdate();
           }
           con.commit();

           if (largo > 0) {
               rs = ordenes[largo - 1].executeQuery();
               con.commit();
               con.setAutoCommit(true);
               return (rs);
           }
           con.setAutoCommit(true);
           return (null);

       } catch (SQLException e) {
           try {
               con.rollback();
               con.setAutoCommit(true);
               return (null);
           } catch (SQLException e2) {
               try {
                   con.setAutoCommit(true);
                   return (null);
               } catch (SQLException e3) {
                   return (null);
               }
           }
       }

   }
}
