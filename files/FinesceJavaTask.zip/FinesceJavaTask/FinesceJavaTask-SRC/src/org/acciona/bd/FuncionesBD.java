package org.acciona.bd;

import java.sql.*;
import java.util.*;

public class FuncionesBD extends Bd {

	static final String insertar_mensaje_hive = "insert into FINESCE_hiveResults (fecha, mensaje) values (?,?)";
	
    static final String consultar_pubsub_suscripciones_para_crear = "SELECT idsubscriptions, name, subid, date_timestamp, idtemp FROM FINESCE_Subscriptions WHERE subid = '0' ORDER BY date_timestamp;";
    static final String consultar_pubsub_suscripciones_params = "SELECT param_name, param_condition, param_value, param_order FROM FINESCE_SubscriptionsParams WHERE idtemp = ? ORDER BY param_order;";
    static final String consultar_pubsub_suscripciones_para_renovar = "SELECT idsubscriptions, name, subid, date_timestamp, idtemp FROM FINESCE_Subscriptions ORDER BY date_timestamp;";

    static final String actualiza_pubsub_subid = "UPDATE FINESCE_Subscriptions SET subid = ? WHERE (idtemp = ?)";
    static final String actualiza_pubsub_subid_params = "UPDATE FINESCE_SubscriptionsParams SET subid = ? WHERE (idtemp = ?)";
    static final String actualiza_pubsub_renovacion = "UPDATE FINESCE_Subscriptions SET fecharenovacion = ? WHERE (subid = ?)";

    
    public FuncionesBD() {

		super("ip", "MeteoTICs", "user", "pass");
    	
    }

    /**
     * Funci�n que devuelve la suscripciones que est�n creadas en la base de datos
     * pero todav�a no est�n creadas realmente en PubSub
     * Las suscripciones que tengo que devolver son las que tienen un 0 como subid,
     * que significa que todav�a no se han lanzado, o ha habido un error al lanzarlas
     * @return ResultSet
     */
    public ResultSet consultarPubsubSuscripcionesParaCrear() {
        PreparedStatement stm = preparar(consultar_pubsub_suscripciones_para_crear);
        ResultSet rs;

        try {
            rs = stm.executeQuery();

            return (rs);

        } catch (SQLException e) {
            return (null);
        }
    }
    
    public ResultSet consultarPubsubSuscripcionesParams(int idtemp) {
        PreparedStatement stm = preparar(consultar_pubsub_suscripciones_params);
        ResultSet rs;

        try {
        	stm.setInt(1, idtemp);
            rs = stm.executeQuery();

            return (rs);

        } catch (SQLException e) {
            return (null);
        }
    }

    public ResultSet consultarPubsubSuscripcionesParaRenovar() {
    	PreparedStatement stm = preparar(consultar_pubsub_suscripciones_para_renovar);
        ResultSet rs;

        try {
        	//stm.setInt(1, subid);
            rs = stm.executeQuery();

            return (rs);

        } catch (SQLException e) {
            return (null);
        }
    }
    
    public boolean actualizaSubId(int idtemp, int subid) {
		PreparedStatement stm = preparar(actualiza_pubsub_subid);
		
		try{
			stm.setInt(1, subid);
			stm.setInt(2, idtemp);
			stm.executeUpdate();
			return (true);
		}
			catch (Exception e){
			return (false);
		}
    
    }
    
    public boolean actualizaSubIdParams(int idtemp, int subid) {
		PreparedStatement stm = preparar(actualiza_pubsub_subid_params);
		
		try{
			stm.setInt(1, subid);
			stm.setInt(2, idtemp);
			stm.executeUpdate();
			return (true);
		}
			catch (Exception e){
			return (false);
		}
    
    }
    
    public boolean actualizaRenovacion(int subid, long fecharenovacion) {
		PreparedStatement stm = preparar(actualiza_pubsub_renovacion);
		
		try{
			stm.setLong(1, fecharenovacion);
			stm.setInt(2, subid);
			stm.executeUpdate();
			return (true);
		}
			catch (Exception e){
			return (false);
		}
    	
    }
    
    
    /**
     * Funci�n que inserta datos en la tabla registros_bruto. Registro de mensajes JMS en bruto
     * @param id_tarjeta entero que es el id de la tarjeta
     * @param id_puntoacceso entero que es el id del punto de acceso
     * @param date_out_start timestamp que es el 
     * @param date_in_start
     * @param date_last_update
     * @return Valor l�gico indicando si se ha podido realizar o no la acci�n
     */
    public boolean insertarMensajeHive(Calendar fecha_param, String mensaje) {

        java.sql.Timestamp fecha = null;
        if (fecha_param != null)
            fecha = new java.sql.Timestamp(fecha_param.getTimeInMillis());

        PreparedStatement stm = preparar(insertar_mensaje_hive);
        try {
        	stm.setTimestamp(1, fecha);
            stm.setString(2, mensaje);
            stm.executeUpdate();
            System.out.println("Inserto correctamente: " + fecha.toString());
            return (true);
        } catch (SQLException e) {
            e.printStackTrace();
            return (false);
        }
    }    
    
    
}