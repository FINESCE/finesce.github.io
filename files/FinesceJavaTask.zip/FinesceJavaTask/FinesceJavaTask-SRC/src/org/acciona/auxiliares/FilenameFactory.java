package org.acciona.auxiliares;

/*
 * Clase encargada de proporcionar nombres de fichero seg�n determinados patrones
 * que se definan.
 */

/**
 *
 * @author WSN Group: AVR
 * R&D Acciona 
 */

import java.util.Calendar;


public class FilenameFactory {

    
    /**
     * Funci�n que genera un nombre de archivo que contiene un prefijo, una fecha y una extensi�n
     * @param prefix Texto que va antes de la fecha
     * @param extension Extensi�n del nombre del archivo
     * @return Cadena de texto con el nombre creado 
     */
    public static String fileName_prefix_date_extension(String prefix, String extension, String separator){
        Calendar d = Calendar.getInstance();
        String tmp_fecha = String.valueOf(d.get(Calendar.YEAR)) + separator + rellenaCeros (String.valueOf(d.get(Calendar.MONTH)+1),2) + separator + rellenaCeros (String.valueOf(d.get(Calendar.DAY_OF_MONTH)),2) + separator + rellenaCeros (String.valueOf(d.get(Calendar.HOUR_OF_DAY)),2) + separator + rellenaCeros (String.valueOf(d.get(Calendar.MINUTE)),2);
        
        return (prefix + tmp_fecha + extension); 
    }//dataName

            
    
    /**
     * Funci�n que genera una cadena de texto con el valor de un entero. Fija un n�mero de d�gitos y rellena con ceros por la izquierda
     * hasta completar.
     * @param cadena Cadena de texto con el n�mero 
     * @param posiciones N�mero de elementos de la cadena
     * @return Cadena de texto con ceros a la izquierda hasta llegar al n�mero de posiciones determinado.
     */
        public static String rellenaCeros(String cadena, int posiciones) {
        int largo = cadena.length();

        for (int i = largo; i < posiciones; i++) {
            cadena = "0" + cadena;
        }
        return cadena;
    }//funcion
    
}//Clase

