package org.acciona.main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import javax.xml.soap.SOAPException;

import org.acciona.bd.FuncionesBD;
import org.acciona.xml.*;


public class Main {

	
	public static Connection con;
	
	
	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		
		final Timer temp = new Timer();
		
		final int intervalo_hilo_creacion = 20 * 1000;
		final int intervalo_hilo_renovacion = 10 * 1000;
		
		//renovarSuscripciones();
		
		System.out.println("Inicio del crear suscripciones");
        temp.scheduleAtFixedRate(new TimerTask() {
            public void run() {
            	crearSuscripciones();
            }
        }, 1, intervalo_hilo_creacion);
		System.out.println("Fin de crear suscripciones");

		System.out.println("Inicio de renovar suscripciones");		
		temp.scheduleAtFixedRate(new TimerTask() {
            public void run() {
            	renovarSuscripciones();
            }
        }, 1, intervalo_hilo_renovacion);
		System.out.println("Fin de renovar suscripciones");
	}
	
	public static void crearSuscripciones() {
		
		FuncionesBD basedatos = new FuncionesBD();
		
		// -----------------------------------------------------------
		// Inicio de c�digo para crear suscripciones
		
		basedatos.abrirConexion();
		//Statement stmt = con.createStatement();
		//ResultSet query = stmt.executeQuery("select * from finesce_meteo order by ts_ms asc");
		ResultSet query = basedatos.consultarPubsubSuscripcionesParaCrear();
		int contador_registros = 0;
		try {
			while (query.next()) {
				System.out.println("Registro " + contador_registros + ": " + query.getString(1));
				System.out.println(" -- " + query.getString(5));

				int idtemp = Integer.parseInt(query.getString(5));
				
				ResultSet queryParams = basedatos.consultarPubsubSuscripcionesParams(idtemp);
				
				int contador_registros_params = 1;
				/*
				while (queryParams.next()) {
					System.out.println(queryParams.getString(1) + queryParams.getString(2) + queryParams.getString(3));
					contador_registros_params++;
				} // fin while queryParams.next
				*/
				// Si no tengo par�metros ni condiciones no construyo el XML
				if (contador_registros_params > 0) {
				
					// ---------------------------------------------------
					// Configuraci�n PubSub para renovar las suscripciones
					String url = "pubsub.testbed.fi-ware.eu";
					String service_name = "/CB/ContextBroker/getContextQL";
					String port = "0";
					   
					System.out.println("Traza de Finesce.");
					String xml_bigdata = "";
					String xml_pubsub = "";
					String xml_renew = "";
					String contentTypeXML = "application/xml";
					String contentTypeWWWForm = "application/x-www-form-urlencoded";
					   
					try {
						WServiceC wservicec = new WServiceC(url, service_name, port);
						       

						xml_pubsub = wservicec.crearMensajeXMLPubSubSubscribe(queryParams, idtemp);
						//wservicec.sendXML(url, Integer.parseInt(port), service_name, contentTypeXML, xml_pubsub);
						
						System.out.println("Traza en main: " + xml_pubsub);
						
						//xml_renew = wservicec.crearMensajeXMLRenew(119);
						int subId = wservicec.sendXML(url, 0, service_name, contentTypeWWWForm, xml_pubsub);

						// si se ha dado de alta la suscripci�n con normalidad
						if (subId > 0) {
							System.out.println("ID devuelto:" + subId);
							// actualizo el subid en la base de datos
							basedatos.actualizaSubId(idtemp, subId);
							basedatos.actualizaSubIdParams(idtemp, subId);
						}
						
					}
					catch (Exception e) {
						System.out.println("Error al crear y enviar el XML con los datos.");
						System.out.println(xml_bigdata);
					}
					// ---------------------------------------------------

				}

				contador_registros++;
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // fin  while query.next() consultarPubsubSuscripcionesParaCrear
		basedatos.cerrarConexion();
		
		// Fin de c�digo para crear suscripciones
		// -----------------------------------------------------------		
	}
	
	public static void renovarSuscripciones() {
		
		FuncionesBD basedatos = new FuncionesBD();
		
		// -----------------------------------------------------------
		// Inicio de c�digo para renovar suscripciones
		
		basedatos.abrirConexion();
		
		ResultSet queryRenovar = basedatos.consultarPubsubSuscripcionesParaRenovar(); 
		int contador_registros_renovar = 0;
		try {
			while (queryRenovar.next()) {
				System.out.println("Registro : " + queryRenovar.getString(1));
				System.out.println(" -- " + queryRenovar.getString(5));

				// ---------------------------------------------------
				// Configuraci�n PubSub para renovar las suscripciones
				String url = "pubsub.testbed.fi-ware.eu";
				String service_name = "/CB/ContextBroker/getContextQL";
				String port = "0";
				   
				System.out.println("Traza de Finesce.");
				String xml_bigdata = "";
				String xml_pubsub = "";
				String xml_renew = "";
				String contentTypeXML = "application/xml";
				String contentTypeWWWForm = "application/x-www-form-urlencoded";
				
				WServiceC wservicec;
				try {
					wservicec = new WServiceC(url, service_name, port);
					xml_renew = wservicec.crearMensajeXMLRenew(queryRenovar.getInt(3));
					int subId = wservicec.sendXML(url, 0, service_name, contentTypeWWWForm, xml_renew);
					
					// si se ha dado de alta la suscripci�n con normalidad
					if (subId > 0) {
						System.out.println("Renovaci�n correcta del id: " + subId);
						// actualizo el subid en la base de datos
						basedatos.actualizaRenovacion(subId, Calendar.getInstance().getTimeInMillis()/1000);
					}
					
				} catch (SOAPException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		basedatos.cerrarConexion();
		
		// Fin de c�digo para renovar suscripciones
		// -----------------------------------------------------------
		
	}

}
