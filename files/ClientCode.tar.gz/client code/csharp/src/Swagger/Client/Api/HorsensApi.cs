  using System;
  using System.Collections.Generic;
  using Swagger.Client.Common;
  using Swagger.Client.Model;
  namespace Swagger.Client.Api {
    public class HorsensApi {
      string basePath;
      private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

      public HorsensApi(String basePath = "http://192.168.1.80/finesce/api/v0.1")
      {
        this.basePath = basePath;
      }

      public ApiInvoker getInvoker() {
        return apiInvoker;
      }

      // Sets the endpoint base url for the services being accessed
      public void setBasePath(string basePath) {
        this.basePath = basePath;
      }

      // Gets the endpoint base url for the services being accessed
      public String getBasePath() {
        return basePath;
      }

      /// <summary>
      /// Retrieve authentication tokens 
      /// </summary>
      /// <param name="body"></param>
      /// <returns></returns>
      public auth_response postHorsensTokens (auth_request body) {
        // create path and map variables
        var path = "/Horsens/tokens".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (body == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(auth_response) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as auth_response;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (auth_response) ApiInvoker.deserialize(response, typeof(auth_response));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Refresh an authentication token 
      /// </summary>
      /// <param name="body"></param>
      /// <returns></returns>
      public auth_response postHorsensTokensRefresh (auth_refresh body) {
        // create path and map variables
        var path = "/Horsens/tokens/refresh".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (body == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(auth_response) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as auth_response;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (auth_response) ApiInvoker.deserialize(response, typeof(auth_response));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides the list of vehicles available 
      /// </summary>
      /// <returns></returns>
      public vehicles_report getHorsensVehicles () {
        // create path and map variables
        var path = "/Horsens/vehicles".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(vehicles_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as vehicles_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (vehicles_report) ApiInvoker.deserialize(response, typeof(vehicles_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding a single vehicle. A valid {id} can be found by calling the /vehicles service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public vehicles_report getHorsensVehiclesId (string id) {
        // create path and map variables
        var path = "/Horsens/vehicles/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(vehicles_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as vehicles_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (vehicles_report) ApiInvoker.deserialize(response, typeof(vehicles_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding the available measurements types for the specific vehicle. A valid {id} can be obtained by calling the /vehicles service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public measurement_types_report getHorsensVehiclesIdMeasurement_types (string id) {
        // create path and map variables
        var path = "/Horsens/vehicles/{id}/measurement_types".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurement_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurement_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurement_types_report) ApiInvoker.deserialize(response, typeof(measurement_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding the available measurements of a specific type for a specific vehicle, during a certain period of time. A valid {id} can be obtained by calling the /vehicles service. A valid {type_id} can be obtained by calling the /vehicles service and check the 'measurement_points' section of the answer. Valid {from} and {to} values are expressed in ISO8601 format. 
      /// </summary>
      /// <param name="id"></param>
      /// <param name="type_id"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getHorsensVehiclesIdMeasurementsType_idFromTo (string id, string type_id, string from, string to) {
        // create path and map variables
        var path = "/Horsens/vehicles/{id}/measurements/{type_id}/{from}/{to}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString())).Replace("{" + "type_id" + "}", apiInvoker.escapeString(type_id.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null || type_id == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides a detailed list of all the available vehicle measurements types in the trial 
      /// </summary>
      /// <returns></returns>
      public measurement_types_report getHorsensVehiclesMeasurement_types () {
        // create path and map variables
        var path = "/Horsens/vehicles/measurement_types".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(measurement_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurement_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurement_types_report) ApiInvoker.deserialize(response, typeof(measurement_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides a detailed list of all the available measurements types that match a specific measurements type name. A valid {id} can be obtained by calling the /vehicles/measurement_types service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public measurement_types_report getHorsensVehiclesMeasurement_typesIdId (string id) {
        // create path and map variables
        var path = "/Horsens/vehicles/measurement_types/id/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurement_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurement_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurement_types_report) ApiInvoker.deserialize(response, typeof(measurement_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides a detailed list of all the available measurements types that match a specific measurements type. A valid {type} can be obtained by calling the /vehicles/measurement_types service and check the 'type' entries. 
      /// </summary>
      /// <param name="type"></param>
      /// <returns></returns>
      public measurement_types_report getHorsensVehiclesMeasurement_typesTypeType (string type) {
        // create path and map variables
        var path = "/Horsens/vehicles/measurement_types/type/{type}".Replace("{format}","json").Replace("{" + "type" + "}", apiInvoker.escapeString(type.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (type == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurement_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurement_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurement_types_report) ApiInvoker.deserialize(response, typeof(measurement_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides the list of buildings available 
      /// </summary>
      /// <returns></returns>
      public buildings_report getHorsensBuildings () {
        // create path and map variables
        var path = "/Horsens/buildings".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(buildings_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as buildings_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (buildings_report) ApiInvoker.deserialize(response, typeof(buildings_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding a single building.A valid {id} can be obtained by the /buildings service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public buildings_report getHorsensBuildingsId (string id) {
        // create path and map variables
        var path = "/Horsens/buildings/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(buildings_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as buildings_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (buildings_report) ApiInvoker.deserialize(response, typeof(buildings_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding the available measurements types for the specific building.A valid {id} can be obtained by the /buildings service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public measurement_types_report getHorsensBuildingsIdMeasurement_types (string id) {
        // create path and map variables
        var path = "/Horsens/buildings/{id}/measurement_types".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurement_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurement_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurement_types_report) ApiInvoker.deserialize(response, typeof(measurement_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding the available measurements of a specific type for a specific building, during a certain period of time. A valid {id} can be obtained by calling the /buildings service. A valid {type_id} can be obtained by calling the /buildings service and check the 'measurement_points' section of the answer. Valid {from} and {to} values are expressed in ISO8601 format. 
      /// </summary>
      /// <param name="id"></param>
      /// <param name="type_id"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getHorsensBuildingsIdMeasurementsType_idFromTo (string id, string type_id, string from, string to) {
        // create path and map variables
        var path = "/Horsens/buildings/{id}/measurements/{type_id}/{from}/{to}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString())).Replace("{" + "type_id" + "}", apiInvoker.escapeString(type_id.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null || type_id == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides a detailed list of all the available building measurements types in the trial 
      /// </summary>
      /// <returns></returns>
      public measurement_types_report getHorsensBuildingsMeasurement_types () {
        // create path and map variables
        var path = "/Horsens/buildings/measurement_types".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(measurement_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurement_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurement_types_report) ApiInvoker.deserialize(response, typeof(measurement_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides a detailed list of all the available measurements types that match a specific measurements type name. A valid {id} can be obtained by calling the /buildings/measurement_types service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public measurement_types_report getHorsensBuildingsMeasurement_typesIdId (string id) {
        // create path and map variables
        var path = "/Horsens/buildings/measurement_types/id/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurement_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurement_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurement_types_report) ApiInvoker.deserialize(response, typeof(measurement_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides a detailed list of all the available measurements types that match a specific measurements type. A valid {type} can be obtained by calling the /buildings/measurement_types service and check the 'type' attribute of the answer. 
      /// </summary>
      /// <param name="type"></param>
      /// <returns></returns>
      public measurement_types_report getHorsensBuildingsMeasurement_typesTypeType (string type) {
        // create path and map variables
        var path = "/Horsens/buildings/measurement_types/type/{type}".Replace("{format}","json").Replace("{" + "type" + "}", apiInvoker.escapeString(type.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (type == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurement_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurement_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurement_types_report) ApiInvoker.deserialize(response, typeof(measurement_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      }
    }
