  using System;
  using System.Collections.Generic;
  using Swagger.Client.Common;
  using Swagger.Client.Model;
  namespace Swagger.Client.Api {
    public class MalmoApi {
      string basePath;
      private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

      public MalmoApi(String basePath = "http://192.168.1.80/finesce/api/v0.1")
      {
        this.basePath = basePath;
      }

      public ApiInvoker getInvoker() {
        return apiInvoker;
      }

      // Sets the endpoint base url for the services being accessed
      public void setBasePath(string basePath) {
        this.basePath = basePath;
      }

      // Gets the endpoint base url for the services being accessed
      public String getBasePath() {
        return basePath;
      }

      /// <summary>
      /// Retrieve authentication tokens 
      /// </summary>
      /// <param name="body"></param>
      /// <returns></returns>
      public auth_response postMalmoTokens (auth_request body) {
        // create path and map variables
        var path = "/Malmo/tokens".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (body == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(auth_response) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as auth_response;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (auth_response) ApiInvoker.deserialize(response, typeof(auth_response));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Refresh an authentication token 
      /// </summary>
      /// <param name="body"></param>
      /// <returns></returns>
      public auth_response postMalmoTokensRefresh (auth_refresh body) {
        // create path and map variables
        var path = "/Malmo/tokens/refresh".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (body == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(auth_response) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as auth_response;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (auth_response) ApiInvoker.deserialize(response, typeof(auth_response));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding the energy prices in a location 
      /// </summary>
      /// <returns></returns>
      public price_report getMalmoPrices () {
        // create path and map variables
        var path = "/Malmo/prices".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(price_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_report) ApiInvoker.deserialize(response, typeof(price_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding the energy prices regardless of location. Valid {from} and {to} values are expressed in ISO8601 format. 
      /// </summary>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public price_report getMalmoPricesFromTo (string from, string to) {
        // create path and map variables
        var path = "/Malmo/prices/{from}/{to}".Replace("{format}","json").Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(price_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_report) ApiInvoker.deserialize(response, typeof(price_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding the energy prices in a location. A valid {name} can be obtained by calling the /prices service. 
      /// </summary>
      /// <param name="name"></param>
      /// <returns></returns>
      public price_report getMalmoPricesName (string name) {
        // create path and map variables
        var path = "/Malmo/prices/{name}".Replace("{format}","json").Replace("{" + "name" + "}", apiInvoker.escapeString(name.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (name == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(price_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_report) ApiInvoker.deserialize(response, typeof(price_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding the energy prices in a location. A valid {name} can be obtained by calling the /prices service. Valid {from} and {to} values are expressed in ISO8601 format. 
      /// </summary>
      /// <param name="name"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public price_report getMalmoPricesNameFromTo (string name, string from, string to) {
        // create path and map variables
        var path = "/Malmo/prices/{name}/{from}/{to}".Replace("{format}","json").Replace("{" + "name" + "}", apiInvoker.escapeString(name.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (name == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(price_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_report) ApiInvoker.deserialize(response, typeof(price_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding the price locations available to the user. 
      /// </summary>
      /// <returns></returns>
      public price_location_report getMalmoPricesLocations () {
        // create path and map variables
        var path = "/Malmo/prices/locations".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(price_location_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_location_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_location_report) ApiInvoker.deserialize(response, typeof(price_location_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding a price location available to the user, based on the location name. A valid {name} can be obtained by calling the /prices/locations service. 
      /// </summary>
      /// <param name="name"></param>
      /// <returns></returns>
      public price_location_report getMalmoPricesLocationsName (string name) {
        // create path and map variables
        var path = "/Malmo/prices/locations/{name}".Replace("{format}","json").Replace("{" + "name" + "}", apiInvoker.escapeString(name.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (name == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(price_location_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_location_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_location_report) ApiInvoker.deserialize(response, typeof(price_location_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding a data stream available for locations associated with the current user. 
      /// </summary>
      /// <returns></returns>
      public price_location_data_report getMalmoPricesLocationsData () {
        // create path and map variables
        var path = "/Malmo/prices/locations/data".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(price_location_data_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_location_data_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_location_data_report) ApiInvoker.deserialize(response, typeof(price_location_data_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding a data stream available for locations associated with the current user. A valid {name} can be obtained by calling the /prices/locations/data service. 
      /// </summary>
      /// <param name="name"></param>
      /// <returns></returns>
      public price_location_data_report getMalmoPricesLocationsDataName (string name) {
        // create path and map variables
        var path = "/Malmo/prices/locations/data/{name}".Replace("{format}","json").Replace("{" + "name" + "}", apiInvoker.escapeString(name.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (name == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(price_location_data_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_location_data_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_location_data_report) ApiInvoker.deserialize(response, typeof(price_location_data_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get information regarding data stream values available for locations associated with the current user. A valid {name} can be obtained by calling the /prices/locations/data service. Valid {from} and {to} values are expressed in ISO8601 format. 
      /// </summary>
      /// <param name="name"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public price_location_data_values_report getMalmoPricesLocationsDataNameValuesFromTo (string name, string from, string to) {
        // create path and map variables
        var path = "/Malmo/prices/locations/data/{name}/values/{from}/{to}".Replace("{format}","json").Replace("{" + "name" + "}", apiInvoker.escapeString(name.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (name == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(price_location_data_values_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as price_location_data_values_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (price_location_data_values_report) ApiInvoker.deserialize(response, typeof(price_location_data_values_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      }
    }
