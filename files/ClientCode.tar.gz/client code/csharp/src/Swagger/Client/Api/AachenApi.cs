  using System;
  using System.Collections.Generic;
  using Swagger.Client.Common;
  using Swagger.Client.Model;
  namespace Swagger.Client.Api {
    public class AachenApi {
      string basePath;
      private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

      public AachenApi(String basePath = "http://192.168.1.80/finesce/api/v0.1")
      {
        this.basePath = basePath;
      }

      public ApiInvoker getInvoker() {
        return apiInvoker;
      }

      // Sets the endpoint base url for the services being accessed
      public void setBasePath(string basePath) {
        this.basePath = basePath;
      }

      // Gets the endpoint base url for the services being accessed
      public String getBasePath() {
        return basePath;
      }

      /// <summary>
      /// Retrieve authentication tokens 
      /// </summary>
      /// <param name="body"></param>
      /// <returns></returns>
      public auth_response postAachenTokens (auth_request body) {
        // create path and map variables
        var path = "/Aachen/tokens".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (body == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(auth_response) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as auth_response;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (auth_response) ApiInvoker.deserialize(response, typeof(auth_response));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Refresh an authentication token 
      /// </summary>
      /// <param name="body"></param>
      /// <returns></returns>
      public auth_response postAachenTokensRefresh (auth_refresh body) {
        // create path and map variables
        var path = "/Aachen/tokens/refresh".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (body == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(auth_response) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as auth_response;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (auth_response) ApiInvoker.deserialize(response, typeof(auth_response));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides the list of available machines of the smart factory. 
      /// </summary>
      /// <returns></returns>
      public machines_report getAachenFactoryEquipmentMachines () {
        // create path and map variables
        var path = "/Aachen/factory/equipment/machines".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(machines_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as machines_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (machines_report) ApiInvoker.deserialize(response, typeof(machines_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides details related to a single machine. A valid {machine_id} can be found from the /factory/equipment/machines service. 
      /// </summary>
      /// <param name="machine_id"></param>
      /// <returns></returns>
      public machine_details getAachenFactoryEquipmentMachinesMachine_id (string machine_id) {
        // create path and map variables
        var path = "/Aachen/factory/equipment/machines/{machine_id}".Replace("{format}","json").Replace("{" + "machine_id" + "}", apiInvoker.escapeString(machine_id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (machine_id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(machine_details) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as machine_details;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (machine_details) ApiInvoker.deserialize(response, typeof(machine_details));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Gets the list of dates of available data for a component. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service. 
      /// </summary>
      /// <param name="comp_type"></param>
      /// <param name="comp_id"></param>
      /// <returns></returns>
      public component_data_report getAachenVppComp_typeComp_idData (string comp_type, string comp_id) {
        // create path and map variables
        var path = "/Aachen/vpp/{comp_type}/{comp_id}/data".Replace("{format}","json").Replace("{" + "comp_type" + "}", apiInvoker.escapeString(comp_type.ToString())).Replace("{" + "comp_id" + "}", apiInvoker.escapeString(comp_id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (comp_type == null || comp_id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(component_data_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as component_data_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (component_data_report) ApiInvoker.deserialize(response, typeof(component_data_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Gets measurement data for component for a specified data and data type. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service. A valid {date} can be found from the /vpp/{comp_type}/{comp_id}/data service.  
      /// </summary>
      /// <param name="comp_type"></param>
      /// <param name="comp_id"></param>
      /// <param name="date"></param>
      /// <returns></returns>
      public measurements_report getAachenVppComp_typeComp_idMeasurementsDate (string comp_type, string comp_id, string date) {
        // create path and map variables
        var path = "/Aachen/vpp/{comp_type}/{comp_id}/measurements/{date}".Replace("{format}","json").Replace("{" + "comp_type" + "}", apiInvoker.escapeString(comp_type.ToString())).Replace("{" + "comp_id" + "}", apiInvoker.escapeString(comp_id.ToString())).Replace("{" + "date" + "}", apiInvoker.escapeString(date.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (comp_type == null || comp_id == null || date == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Gets prediction data for component for a specified data and data type. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service. A valid {date} can be found from the /vpp/{comp_type}/{comp_id}/data service.  
      /// </summary>
      /// <param name="comp_type"></param>
      /// <param name="comp_id"></param>
      /// <param name="date"></param>
      /// <returns></returns>
      public measurements_report getAachenVppComp_typeComp_idPredictionsDate (string comp_type, string comp_id, string date) {
        // create path and map variables
        var path = "/Aachen/vpp/{comp_type}/{comp_id}/predictions/{date}".Replace("{format}","json").Replace("{" + "comp_type" + "}", apiInvoker.escapeString(comp_type.ToString())).Replace("{" + "comp_id" + "}", apiInvoker.escapeString(comp_id.ToString())).Replace("{" + "date" + "}", apiInvoker.escapeString(date.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (comp_type == null || comp_id == null || date == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides the list of available components of the VPP 
      /// </summary>
      /// <returns></returns>
      public components_report getAachenVppComponents () {
        // create path and map variables
        var path = "/Aachen/vpp/components".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(components_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as components_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (components_report) ApiInvoker.deserialize(response, typeof(components_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      }
    }
