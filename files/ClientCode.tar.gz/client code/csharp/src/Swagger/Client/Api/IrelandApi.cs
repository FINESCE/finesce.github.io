  using System;
  using System.Collections.Generic;
  using Swagger.Client.Common;
  using Swagger.Client.Model;
  namespace Swagger.Client.Api {
    public class IrelandApi {
      string basePath;
      private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

      public IrelandApi(String basePath = "http://192.168.1.80/finesce/api/v0.1")
      {
        this.basePath = basePath;
      }

      public ApiInvoker getInvoker() {
        return apiInvoker;
      }

      // Sets the endpoint base url for the services being accessed
      public void setBasePath(string basePath) {
        this.basePath = basePath;
      }

      // Gets the endpoint base url for the services being accessed
      public String getBasePath() {
        return basePath;
      }

      /// <summary>
      /// Allows a user to retrieve a collection of algoweights 
      /// </summary>
      /// <returns></returns>
      public algoweight_report getIrelandAlgoweights () {
        // create path and map variables
        var path = "/Ireland/algoweights".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(algoweight_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as algoweight_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (algoweight_report) ApiInvoker.deserialize(response, typeof(algoweight_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve an algoweights record, based on its ID. A valid {id} can be obtained by calling the /algoweights service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public algoweight_report getIrelandAlgoweightsId (string id) {
        // create path and map variables
        var path = "/Ireland/algoweights/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(algoweight_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as algoweight_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (algoweight_report) ApiInvoker.deserialize(response, typeof(algoweight_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of ev evse connections 
      /// </summary>
      /// <returns></returns>
      public connections getIrelandConnections () {
        // create path and map variables
        var path = "/Ireland/connections".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(connections) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as connections;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (connections) ApiInvoker.deserialize(response, typeof(connections));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve an ev evse connection, based on its ID. A valid {id} can be obtained by calling the /connections service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public connections getIrelandConnectionsId (string id) {
        // create path and map variables
        var path = "/Ireland/connections/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(connections) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as connections;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (connections) ApiInvoker.deserialize(response, typeof(connections));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a charging mode associated with an ev evse connection. A valid {id} can be obtained by calling the /connections service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public charging_modes getIrelandConnectionsIdCharging_mode (string id) {
        // create path and map variables
        var path = "/Ireland/connections/{id}/charging_mode".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(charging_modes) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as charging_modes;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (charging_modes) ApiInvoker.deserialize(response, typeof(charging_modes));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve an ev evse connection state associated with an ev evse connection. A valid {id} can be obtained by calling the /connections service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public connection_states_report getIrelandConnectionsIdConnection_state (string id) {
        // create path and map variables
        var path = "/Ireland/connections/{id}/connection_state".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(connection_states_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as connection_states_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (connection_states_report) ApiInvoker.deserialize(response, typeof(connection_states_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of regional energy records 
      /// </summary>
      /// <returns></returns>
      public regional_energy_report getIrelandEnergyRegional () {
        // create path and map variables
        var path = "/Ireland/energy/regional".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(regional_energy_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as regional_energy_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (regional_energy_report) ApiInvoker.deserialize(response, typeof(regional_energy_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a regional energy record. A valid {id} can be obtained by calling the /energy/regional service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public regional_energy_report getIrelandEnergyRegionalId (string id) {
        // create path and map variables
        var path = "/Ireland/energy/regional/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(regional_energy_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as regional_energy_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (regional_energy_report) ApiInvoker.deserialize(response, typeof(regional_energy_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a region associated with a regional energy record. A valid {id} can be obtained by calling the /energy/regional service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public region_report getIrelandEnergyRegionalIdRegion (string id) {
        // create path and map variables
        var path = "/Ireland/energy/regional/{id}/region".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(region_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as region_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (region_report) ApiInvoker.deserialize(response, typeof(region_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a timeslot associated with a regional energy record. A valid {id} can be obtained by calling the /energy/regional service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public timeslots getIrelandEnergyRegionalIdTimeslot (string id) {
        // create path and map variables
        var path = "/Ireland/energy/regional/{id}/timeslot".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(timeslots) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as timeslots;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (timeslots) ApiInvoker.deserialize(response, typeof(timeslots));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of aggregated regional evse energy records 
      /// </summary>
      /// <returns></returns>
      public regional_energy_average_report getIrelandEnergyRegionalAvg () {
        // create path and map variables
        var path = "/Ireland/energy/regional/avg".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(regional_energy_average_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as regional_energy_average_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (regional_energy_average_report) ApiInvoker.deserialize(response, typeof(regional_energy_average_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve an aggregate regional evse energy record, based on its ID 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public regional_energy_average_report getIrelandEnergyRegionalAvgId (string id) {
        // create path and map variables
        var path = "/Ireland/energy/regional/avg/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(regional_energy_average_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as regional_energy_average_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (regional_energy_average_report) ApiInvoker.deserialize(response, typeof(regional_energy_average_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of time slot records 
      /// </summary>
      /// <returns></returns>
      public timeslots getIrelandTimeslots () {
        // create path and map variables
        var path = "/Ireland/timeslots".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(timeslots) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as timeslots;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (timeslots) ApiInvoker.deserialize(response, typeof(timeslots));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a time slot record, based on its ID. A valid {id} can be obtained by calling the /timeslots service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public timeslots getIrelandTimeslotsId (string id) {
        // create path and map variables
        var path = "/Ireland/timeslots/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(timeslots) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as timeslots;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (timeslots) ApiInvoker.deserialize(response, typeof(timeslots));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of algorithm weight records associated with a time slot. A valid {id} can be obtained by calling the /timeslots service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public algoweight_report getIrelandTimeslotsIdAlgoweights (string id) {
        // create path and map variables
        var path = "/Ireland/timeslots/{id}/algoweights".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(algoweight_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as algoweight_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (algoweight_report) ApiInvoker.deserialize(response, typeof(algoweight_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of charging state records associated with a time slot, based on its ID. A valid {id} can be obtained by calling the /timeslots service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public charging_states_report getIrelandTimeslotsIdCharging_states (string id) {
        // create path and map variables
        var path = "/Ireland/timeslots/{id}/charging_states".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(charging_states_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as charging_states_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (charging_states_report) ApiInvoker.deserialize(response, typeof(charging_states_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of aggregated regional evse energy records. A valid {id} can be obtained by calling the /timeslots service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public regional_energy_report getIrelandTimeslotsIdEnergyRegional (string id) {
        // create path and map variables
        var path = "/Ireland/timeslots/{id}/energy/regional".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(regional_energy_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as regional_energy_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (regional_energy_report) ApiInvoker.deserialize(response, typeof(regional_energy_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieve authentication tokens 
      /// </summary>
      /// <param name="body"></param>
      /// <returns></returns>
      public auth_response postIrelandTokens (auth_request body) {
        // create path and map variables
        var path = "/Ireland/tokens".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (body == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(auth_response) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as auth_response;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (auth_response) ApiInvoker.deserialize(response, typeof(auth_response));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Refresh an authentication token 
      /// </summary>
      /// <param name="body"></param>
      /// <returns></returns>
      public auth_response postIrelandTokensRefresh (auth_refresh body) {
        // create path and map variables
        var path = "/Ireland/tokens/refresh".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (body == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(auth_response) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as auth_response;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (auth_response) ApiInvoker.deserialize(response, typeof(auth_response));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides the list of vehicles available 
      /// </summary>
      /// <returns></returns>
      public vehicles_report getIrelandVehicles () {
        // create path and map variables
        var path = "/Ireland/vehicles/".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(vehicles_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as vehicles_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (vehicles_report) ApiInvoker.deserialize(response, typeof(vehicles_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding a single vehicle. A valid {id} can be obtained by calling the /vehicles service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public vehicles_report getIrelandVehiclesId (string id) {
        // create path and map variables
        var path = "/Ireland/vehicles/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(vehicles_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as vehicles_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (vehicles_report) ApiInvoker.deserialize(response, typeof(vehicles_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of ev evse connections associated with an electric vehicle. A valid {id} can be obtained by calling the /vehicles service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public connections getIrelandVehiclesIdConnections (string id) {
        // create path and map variables
        var path = "/Ireland/vehicles/{id}/connections".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(connections) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as connections;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (connections) ApiInvoker.deserialize(response, typeof(connections));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of ev evse connection states 
      /// </summary>
      /// <returns></returns>
      public connection_states_report getIrelandConnection_states () {
        // create path and map variables
        var path = "/Ireland/connection_states".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(connection_states_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as connection_states_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (connection_states_report) ApiInvoker.deserialize(response, typeof(connection_states_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve an ev evse connection state record, based on its ID. A valid {id} can be obtained by calling the /connection_states service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public connection_states_report getIrelandConnection_statesId (string id) {
        // create path and map variables
        var path = "/Ireland/connection_states/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(connection_states_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as connection_states_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (connection_states_report) ApiInvoker.deserialize(response, typeof(connection_states_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of electric vehicle supply equipment components 
      /// </summary>
      /// <returns></returns>
      public ev_equipment_report getIrelandSupply_equipment () {
        // create path and map variables
        var path = "/Ireland/supply_equipment".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(ev_equipment_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as ev_equipment_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (ev_equipment_report) ApiInvoker.deserialize(response, typeof(ev_equipment_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve an electric vehicle supply equipment component, based on its ID. A valid {id} can be obtained by calling the /supply_equipment service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public ev_equipment_report getIrelandSupply_equipmentId (string id) {
        // create path and map variables
        var path = "/Ireland/supply_equipment/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(ev_equipment_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as ev_equipment_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (ev_equipment_report) ApiInvoker.deserialize(response, typeof(ev_equipment_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of charging modes associated with an evse. A valid {id} can be obtained by calling the /supply_equipment service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public charging_modes getIrelandSupply_equipmentIdCharging_modes (string id) {
        // create path and map variables
        var path = "/Ireland/supply_equipment/{id}/charging_modes".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(charging_modes) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as charging_modes;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (charging_modes) ApiInvoker.deserialize(response, typeof(charging_modes));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of ev evse connections associated with an evse. A valid {id} can be obtained by calling the /supply_equipment service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public connections getIrelandSupply_equipmentIdConnections (string id) {
        // create path and map variables
        var path = "/Ireland/supply_equipment/{id}/connections".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(connections) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as connections;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (connections) ApiInvoker.deserialize(response, typeof(connections));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of chargingmodes 
      /// </summary>
      /// <returns></returns>
      public charging_modes getIrelandCharging_modes () {
        // create path and map variables
        var path = "/Ireland/charging_modes".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(charging_modes) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as charging_modes;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (charging_modes) ApiInvoker.deserialize(response, typeof(charging_modes));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a chargingmode based on an ID. A valid {id} can be obtained by calling the /charging_modes service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public charging_modes getIrelandCharging_modesId (string id) {
        // create path and map variables
        var path = "/Ireland/charging_modes/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(charging_modes) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as charging_modes;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (charging_modes) ApiInvoker.deserialize(response, typeof(charging_modes));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of evses associated with a charging mode. A valid {id} can be obtained by calling the /charging_modes service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public ev_equipment_report getIrelandCharging_modesIdEvses (string id) {
        // create path and map variables
        var path = "/Ireland/charging_modes/{id}/evses".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(ev_equipment_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as ev_equipment_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (ev_equipment_report) ApiInvoker.deserialize(response, typeof(ev_equipment_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of electric vehicle types associated with a charging mode. A valid {id} can be obtained by calling the /charging_modes service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public ev_types_report getIrelandCharging_modesIdEvtypes (string id) {
        // create path and map variables
        var path = "/Ireland/charging_modes/{id}/evtypes".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(ev_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as ev_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (ev_types_report) ApiInvoker.deserialize(response, typeof(ev_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of chargingmodes 
      /// </summary>
      /// <returns></returns>
      public charging_states_report getIrelandCharging_states () {
        // create path and map variables
        var path = "/Ireland/charging_states".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(charging_states_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as charging_states_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (charging_states_report) ApiInvoker.deserialize(response, typeof(charging_states_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a chargingmode based on an ID. A valid {id} can be obtained by calling the /charging_states service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public charging_states_report getIrelandCharging_statesId (string id) {
        // create path and map variables
        var path = "/Ireland/charging_states/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(charging_states_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as charging_states_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (charging_states_report) ApiInvoker.deserialize(response, typeof(charging_states_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of electric vehicle types 
      /// </summary>
      /// <returns></returns>
      public ev_types_report getIrelandVehicle_types () {
        // create path and map variables
        var path = "/Ireland/vehicle_types".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(ev_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as ev_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (ev_types_report) ApiInvoker.deserialize(response, typeof(ev_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve an electric vehicle type record, based on its ID. A valid {id} can be obtained by calling the /vehicle_types service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public ev_types_report getIrelandVehicle_typesId (string id) {
        // create path and map variables
        var path = "/Ireland/vehicle_types/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(ev_types_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as ev_types_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (ev_types_report) ApiInvoker.deserialize(response, typeof(ev_types_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of electric vehicles associated with an electric vehicle type. A valid {id} can be obtained by calling the /vehicle_types service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public vehicles_report getIrelandVehicle_typesIdVehicles (string id) {
        // create path and map variables
        var path = "/Ireland/vehicle_types/{id}/vehicles".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(vehicles_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as vehicles_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (vehicles_report) ApiInvoker.deserialize(response, typeof(vehicles_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of region records 
      /// </summary>
      /// <returns></returns>
      public region_report getIrelandRegions () {
        // create path and map variables
        var path = "/Ireland/regions".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(region_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as region_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (region_report) ApiInvoker.deserialize(response, typeof(region_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a region record, based on its ID. A valid {id} can be obtained by calling the /regions service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public region_report getIrelandRegionsId (string id) {
        // create path and map variables
        var path = "/Ireland/regions/{id}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(region_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as region_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (region_report) ApiInvoker.deserialize(response, typeof(region_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of algorithm weight records associated with a region. A valid {id} can be obtained by calling the /regions service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public algoweight_report getIrelandRegionsIdAlgoweights (string id) {
        // create path and map variables
        var path = "/Ireland/regions/{id}/algoweights".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(algoweight_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as algoweight_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (algoweight_report) ApiInvoker.deserialize(response, typeof(algoweight_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of aggregated regional evse energy records. A valid {id} can be obtained by calling the /regions service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public regional_energy_report getIrelandRegionsIdEnergy (string id) {
        // create path and map variables
        var path = "/Ireland/regions/{id}/energy".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(regional_energy_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as regional_energy_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (regional_energy_report) ApiInvoker.deserialize(response, typeof(regional_energy_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of aggregate regional evse energy records associated with a region, based on its ID. A valid {id} can be obtained by calling the /regions service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public regional_energy_average_report getIrelandRegionsIdEnergyAvg (string id) {
        // create path and map variables
        var path = "/Ireland/regions/{id}/energy/avg".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(regional_energy_average_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as regional_energy_average_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (regional_energy_average_report) ApiInvoker.deserialize(response, typeof(regional_energy_average_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to retrieve a collection of evse records associated with a region. A valid {id} can be obtained by calling the /regions service. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public ev_equipment_report getIrelandRegionsIdSupply_equipment (string id) {
        // create path and map variables
        var path = "/Ireland/regions/{id}/supply_equipment".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(ev_equipment_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as ev_equipment_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (ev_equipment_report) ApiInvoker.deserialize(response, typeof(ev_equipment_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      }
    }
