  using System;
  using System.Collections.Generic;
  using Swagger.Client.Common;
  using Swagger.Client.Model;
  namespace Swagger.Client.Api {
    public class MadridApi {
      string basePath;
      private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

      public MadridApi(String basePath = "http://192.168.1.80/finesce/api/v0.1")
      {
        this.basePath = basePath;
      }

      public ApiInvoker getInvoker() {
        return apiInvoker;
      }

      // Sets the endpoint base url for the services being accessed
      public void setBasePath(string basePath) {
        this.basePath = basePath;
      }

      // Gets the endpoint base url for the services being accessed
      public String getBasePath() {
        return basePath;
      }

      /// <summary>
      /// Provides measurements regarding the total power generated/consumed (mixed) from a module of a building. Currently, 'inverter' is the only module supported. 'Madrid' is the only trial site offering this service. 
      /// </summary>
      /// <param name="module_id"></param>
      /// <param name="building_id"></param>
      /// <param name="date"></param>
      /// <returns></returns>
      public measurements_report getMadridPowerMixedModulesModule_idBuilding_idDate (string module_id, string building_id, string date) {
        // create path and map variables
        var path = "/Madrid/power/mixed/modules/{module_id}/{building_id}/{date}".Replace("{format}","json").Replace("{" + "module_id" + "}", apiInvoker.escapeString(module_id.ToString())).Replace("{" + "building_id" + "}", apiInvoker.escapeString(building_id.ToString())).Replace("{" + "date" + "}", apiInvoker.escapeString(date.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (module_id == null || building_id == null || date == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides measurements regarding the power generated from a module of a building. Currently, 'pv' is the only module supported. 'Madrid' is the only trial site offering this service. 
      /// </summary>
      /// <param name="module_id"></param>
      /// <param name="building_id"></param>
      /// <param name="date"></param>
      /// <returns></returns>
      public measurements_report getMadridPowerSupplyModulesModule_idBuilding_idDate (string module_id, string building_id, string date) {
        // create path and map variables
        var path = "/Madrid/power/supply/modules/{module_id}/{building_id}/{date}".Replace("{format}","json").Replace("{" + "module_id" + "}", apiInvoker.escapeString(module_id.ToString())).Replace("{" + "building_id" + "}", apiInvoker.escapeString(building_id.ToString())).Replace("{" + "date" + "}", apiInvoker.escapeString(date.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (module_id == null || building_id == null || date == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides weather reports for a specific timeperiod in the area of Madrid, considering a single weather descriptor (see /{version}/{trial}/weather/available_descriptors for the supported descriptor. 'Madrid' is the only trial site offering this service. 
      /// </summary>
      /// <param name="descriptor"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <param name="number_of_measurements"></param>
      /// <returns></returns>
      public weather_forecast getMadridWeatherDescriptorFromToNumber_of_measurements (string descriptor, string from, string to, string number_of_measurements) {
        // create path and map variables
        var path = "/Madrid/weather/{descriptor}/{from}/{to}/{number_of_measurements}".Replace("{format}","json").Replace("{" + "descriptor" + "}", apiInvoker.escapeString(descriptor.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString())).Replace("{" + "number_of_measurements" + "}", apiInvoker.escapeString(number_of_measurements.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (descriptor == null || from == null || to == null || number_of_measurements == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(weather_forecast) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as weather_forecast;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (weather_forecast) ApiInvoker.deserialize(response, typeof(weather_forecast));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding the available forecast descriptors of the trial infrastructure. 'Madrid' is the only trial site offering this service. 
      /// </summary>
      /// <returns></returns>
      public weather_descriptors getMadridWeatherAvailable_descriptors () {
        // create path and map variables
        var path = "/Madrid/weather/available_descriptors".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(weather_descriptors) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as weather_descriptors;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (weather_descriptors) ApiInvoker.deserialize(response, typeof(weather_descriptors));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides the provides a list of devices or modules which status can be monitored by the Building Control Center. 
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public BuildingModulesReport getMadridBuildingsIdModules (string id) {
        // create path and map variables
        var path = "/Madrid/buildings/{id}/modules".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(BuildingModulesReport) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as BuildingModulesReport;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (BuildingModulesReport) ApiInvoker.deserialize(response, typeof(BuildingModulesReport));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information about the status of a specific building module. The available building modules may be retrieved via the /{version}/{trial}/buildings/{id}/modules service. 'Madrid' is the only trial site offering this service. 
      /// </summary>
      /// <param name="id"></param>
      /// <param name="module_id"></param>
      /// <param name="date"></param>
      /// <returns></returns>
      public measurements_report getMadridBuildingsIdModulesModule_idStatusDate (string id, string module_id, string date) {
        // create path and map variables
        var path = "/Madrid/buildings/{id}/modules/{module_id}/status/{date}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString())).Replace("{" + "module_id" + "}", apiInvoker.escapeString(module_id.ToString())).Replace("{" + "date" + "}", apiInvoker.escapeString(date.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null || module_id == null || date == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding the available zones of a specific building at a date. 'Madrid' is the only trial site offering this service. 
      /// </summary>
      /// <param name="id"></param>
      /// <param name="date"></param>
      /// <returns></returns>
      public BuildingZonesReport getMadridBuildingsIdZonesDate (string id, string date) {
        // create path and map variables
        var path = "/Madrid/buildings/{id}/zones/{date}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString())).Replace("{" + "date" + "}", apiInvoker.escapeString(date.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null || date == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(BuildingZonesReport) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as BuildingZonesReport;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (BuildingZonesReport) ApiInvoker.deserialize(response, typeof(BuildingZonesReport));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides measurements of a certain type of a building zone. Valid {zone_id} values can be retrieved by invoking the /{version}/{trial}/buildings/{id}/zones/{date} service. Valid measurement types are PowerDemandGrid, EnergyConsumptionGrid, Temperature, RelativeHumidity, BatteryLevel. 'Madrid' is the only trial site offering this service. 
      /// </summary>
      /// <param name="id"></param>
      /// <param name="zone_id"></param>
      /// <param name="measurement_type"></param>
      /// <param name="date"></param>
      /// <returns></returns>
      public measurements_report getMadridBuildingsIdZonesZone_idMeasurement_typeDate (string id, string zone_id, string measurement_type, string date) {
        // create path and map variables
        var path = "/Madrid/buildings/{id}/zones/{zone_id}/{measurement_type}/{date}".Replace("{format}","json").Replace("{" + "id" + "}", apiInvoker.escapeString(id.ToString())).Replace("{" + "zone_id" + "}", apiInvoker.escapeString(zone_id.ToString())).Replace("{" + "measurement_type" + "}", apiInvoker.escapeString(measurement_type.ToString())).Replace("{" + "date" + "}", apiInvoker.escapeString(date.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (id == null || zone_id == null || measurement_type == null || date == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      }
    }
