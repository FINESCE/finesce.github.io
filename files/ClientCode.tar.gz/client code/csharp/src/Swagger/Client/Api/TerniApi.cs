  using System;
  using System.Collections.Generic;
  using Swagger.Client.Common;
  using Swagger.Client.Model;
  namespace Swagger.Client.Api {
    public class TerniApi {
      string basePath;
      private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

      public TerniApi(String basePath = "http://192.168.1.80/finesce/api/v0.1")
      {
        this.basePath = basePath;
      }

      public ApiInvoker getInvoker() {
        return apiInvoker;
      }

      // Sets the endpoint base url for the services being accessed
      public void setBasePath(string basePath) {
        this.basePath = basePath;
      }

      // Gets the endpoint base url for the services being accessed
      public String getBasePath() {
        return basePath;
      }

      /// <summary>
      /// Provides weather reports for a specific timeperiod in the area of Terni 
      /// </summary>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public weather_forecast getTerniWeatherFromTo (string from, string to) {
        // create path and map variables
        var path = "/Terni/weather/{from}/{to}".Replace("{format}","json").Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(weather_forecast) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as weather_forecast;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (weather_forecast) ApiInvoker.deserialize(response, typeof(weather_forecast));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides weather reports for a specific timeperiod in the area of Terni, considering a single weather descriptor (see /weather/available_descriptor for the supported descriptor 
      /// </summary>
      /// <param name="descriptor"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public weather_forecast getTerniWeatherDescriptorFromTo (string descriptor, string from, string to) {
        // create path and map variables
        var path = "/Terni/weather/{descriptor}/{from}/{to}".Replace("{format}","json").Replace("{" + "descriptor" + "}", apiInvoker.escapeString(descriptor.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (descriptor == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(weather_forecast) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as weather_forecast;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (weather_forecast) ApiInvoker.deserialize(response, typeof(weather_forecast));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Provides information regarding the available forecast descriptors of the specified trial infrastructure 
      /// </summary>
      /// <returns></returns>
      public weather_descriptors getTerniWeatherAvailable_descriptors () {
        // create path and map variables
        var path = "/Terni/weather/available_descriptors".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(weather_descriptors) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as weather_descriptors;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (weather_descriptors) ApiInvoker.deserialize(response, typeof(weather_descriptors));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves a predicted power demand report for a single sector 
      /// </summary>
      /// <param name="sector_id"></param>
      /// <returns></returns>
      public measurements_report getTerniSimulationPredictionPowerDemandSectorSector_id (string sector_id) {
        // create path and map variables
        var path = "/Terni/simulation/prediction/power/demand/sector/{sector_id}".Replace("{format}","json").Replace("{" + "sector_id" + "}", apiInvoker.escapeString(sector_id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (sector_id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves a predicted power demand report for a single user, based on his/her id 
      /// </summary>
      /// <param name="customer_id"></param>
      /// <returns></returns>
      public measurements_report getTerniSimulationPredictionPowerDemandUserCustomer_id (string customer_id) {
        // create path and map variables
        var path = "/Terni/simulation/prediction/power/demand/user/{customer_id}".Replace("{format}","json").Replace("{" + "customer_id" + "}", apiInvoker.escapeString(customer_id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer_id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves a predicted power supply report for a single sector 
      /// </summary>
      /// <param name="sector_id"></param>
      /// <returns></returns>
      public measurements_report getTerniSimulationPredictionPowerSupplySectorSector_id (string sector_id) {
        // create path and map variables
        var path = "/Terni/simulation/prediction/power/supply/sector/{sector_id}".Replace("{format}","json").Replace("{" + "sector_id" + "}", apiInvoker.escapeString(sector_id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (sector_id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves a predicted power supply report for a single user, based on his/her id 
      /// </summary>
      /// <param name="customer_id"></param>
      /// <returns></returns>
      public measurements_report getTerniSimulationPredictionPowerSupplyUserCustomer_id (string customer_id) {
        // create path and map variables
        var path = "/Terni/simulation/prediction/power/supply/user/{customer_id}".Replace("{format}","json").Replace("{" + "customer_id" + "}", apiInvoker.escapeString(customer_id.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer_id == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Offers a list of social events that can temporarily influence the electricity consumption. 
      /// </summary>
      /// <returns></returns>
      public social_events_report getTerniSocial () {
        // create path and map variables
        var path = "/Terni/social".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(social_events_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as social_events_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (social_events_report) ApiInvoker.deserialize(response, typeof(social_events_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Offers a list of social events that can temporarily influence the electricity consumption. 
      /// </summary>
      /// <param name="events_number"></param>
      /// <returns></returns>
      public social_events_report getTerniSocialEvents_number (string events_number) {
        // create path and map variables
        var path = "/Terni/social/{events_number}".Replace("{format}","json").Replace("{" + "events_number" + "}", apiInvoker.escapeString(events_number.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (events_number == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(social_events_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as social_events_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (social_events_report) ApiInvoker.deserialize(response, typeof(social_events_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Gets a list of the available meters along with the set of their accompanying information. 
      /// </summary>
      /// <returns></returns>
      public meters_report getTerniMeters () {
        // create path and map variables
        var path = "/Terni/meters".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(meters_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as meters_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (meters_report) ApiInvoker.deserialize(response, typeof(meters_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves a meter based on a search string. 
      /// </summary>
      /// <param name="search_options"></param>
      /// <returns></returns>
      public meters_report getTerniMetersSearch_options (string search_options) {
        // create path and map variables
        var path = "/Terni/meters/{search_options}".Replace("{format}","json").Replace("{" + "search_options" + "}", apiInvoker.escapeString(search_options.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (search_options == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(meters_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as meters_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (meters_report) ApiInvoker.deserialize(response, typeof(meters_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Gets a list of the sectors that the meters may be deployed into. 
      /// </summary>
      /// <returns></returns>
      public sectors_report getTerniMetersSectors () {
        // create path and map variables
        var path = "/Terni/meters/sectors".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(sectors_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as sectors_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (sectors_report) ApiInvoker.deserialize(response, typeof(sectors_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows an energy retailer to get a list of incentive plans based on their name. 
      /// </summary>
      /// <param name="author"></param>
      /// <returns></returns>
      public incentive_plans_report getTerniDsmIpAuthorAuthor (string author) {
        // create path and map variables
        var path = "/Terni/dsm/ip/author/{author}".Replace("{format}","json").Replace("{" + "author" + "}", apiInvoker.escapeString(author.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (author == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(incentive_plans_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as incentive_plans_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (incentive_plans_report) ApiInvoker.deserialize(response, typeof(incentive_plans_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows an energy retailer to get a list of incentive plans based on their state and author. 
      /// </summary>
      /// <param name="author"></param>
      /// <param name="state"></param>
      /// <returns></returns>
      public incentive_plans_report getTerniDsmIpAuthorAuthorStateState (string author, string state) {
        // create path and map variables
        var path = "/Terni/dsm/ip/author/{author}/state/{state}".Replace("{format}","json").Replace("{" + "author" + "}", apiInvoker.escapeString(author.ToString())).Replace("{" + "state" + "}", apiInvoker.escapeString(state.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (author == null || state == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(incentive_plans_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as incentive_plans_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (incentive_plans_report) ApiInvoker.deserialize(response, typeof(incentive_plans_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows an energy retailer to get a list of incentive plans based on their state. 
      /// </summary>
      /// <param name="state"></param>
      /// <returns></returns>
      public incentive_plans_report getTerniDsmIpStateState (string state) {
        // create path and map variables
        var path = "/Terni/dsm/ip/state/{state}".Replace("{format}","json").Replace("{" + "state" + "}", apiInvoker.escapeString(state.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (state == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(incentive_plans_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as incentive_plans_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (incentive_plans_report) ApiInvoker.deserialize(response, typeof(incentive_plans_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get a list of issue resolution plans based on their name. 
      /// </summary>
      /// <param name="author"></param>
      /// <returns></returns>
      public issue_resolution_plans_report getTerniDsmIrpAuthorAuthor (string author) {
        // create path and map variables
        var path = "/Terni/dsm/irp/author/{author}".Replace("{format}","json").Replace("{" + "author" + "}", apiInvoker.escapeString(author.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (author == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(issue_resolution_plans_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as issue_resolution_plans_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (issue_resolution_plans_report) ApiInvoker.deserialize(response, typeof(issue_resolution_plans_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get a list of issue resolution plans based on their state and author. 
      /// </summary>
      /// <param name="author"></param>
      /// <param name="state"></param>
      /// <returns></returns>
      public issue_resolution_plans_report getTerniDsmIrpAuthorAuthorStateState (string author, string state) {
        // create path and map variables
        var path = "/Terni/dsm/irp/author/{author}/state/{state}".Replace("{format}","json").Replace("{" + "author" + "}", apiInvoker.escapeString(author.ToString())).Replace("{" + "state" + "}", apiInvoker.escapeString(state.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (author == null || state == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(issue_resolution_plans_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as issue_resolution_plans_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (issue_resolution_plans_report) ApiInvoker.deserialize(response, typeof(issue_resolution_plans_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get a list of issue resolution plans based on their state. 
      /// </summary>
      /// <param name="state"></param>
      /// <returns></returns>
      public issue_resolution_plans_report getTerniDsmIrpStateState (string state) {
        // create path and map variables
        var path = "/Terni/dsm/irp/state/{state}".Replace("{format}","json").Replace("{" + "state" + "}", apiInvoker.escapeString(state.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (state == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(issue_resolution_plans_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as issue_resolution_plans_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (issue_resolution_plans_report) ApiInvoker.deserialize(response, typeof(issue_resolution_plans_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves information regarding the power demand of a specific user, during a specific time period 
      /// </summary>
      /// <param name="customer_id"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getTerniPowerDemandUserCustomer_idFromTo (string customer_id, string from, string to) {
        // create path and map variables
        var path = "/Terni/power/demand/user/{customer_id}/{from}/{to}".Replace("{format}","json").Replace("{" + "customer_id" + "}", apiInvoker.escapeString(customer_id.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer_id == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves information regarding the power supply of a specific user, during a specific time period 
      /// </summary>
      /// <param name="customer_id"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getTerniPowerSupplyUserCustomer_idFromTo (string customer_id, string from, string to) {
        // create path and map variables
        var path = "/Terni/power/supply/user/{customer_id}/{from}/{to}".Replace("{format}","json").Replace("{" + "customer_id" + "}", apiInvoker.escapeString(customer_id.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer_id == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows an energy retailer to get a list of contracts, regardless of their state 
      /// </summary>
      /// <param name="customer"></param>
      /// <returns></returns>
      public contract_report getTerniContractsCustomerCustomer (string customer) {
        // create path and map variables
        var path = "/Terni/contracts/customer/{customer}".Replace("{format}","json").Replace("{" + "customer" + "}", apiInvoker.escapeString(customer.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(contract_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as contract_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (contract_report) ApiInvoker.deserialize(response, typeof(contract_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows an energy retailer to get a list of contracts, based on their state and customer they are intended for. 
      /// </summary>
      /// <param name="customer"></param>
      /// <param name="state"></param>
      /// <returns></returns>
      public contract_report getTerniContractsCustomerCustomerStateState (string customer, string state) {
        // create path and map variables
        var path = "/Terni/contracts/customer/{customer}/state/{state}".Replace("{format}","json").Replace("{" + "customer" + "}", apiInvoker.escapeString(customer.ToString())).Replace("{" + "state" + "}", apiInvoker.escapeString(state.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer == null || state == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(contract_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as contract_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (contract_report) ApiInvoker.deserialize(response, typeof(contract_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows an energy retailer to get a list of contracts, regardless of the customers they are intended for. 
      /// </summary>
      /// <param name="state"></param>
      /// <returns></returns>
      public contract_report getTerniContractsStateState (string state) {
        // create path and map variables
        var path = "/Terni/contracts/state/{state}".Replace("{format}","json").Replace("{" + "state" + "}", apiInvoker.escapeString(state.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (state == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(contract_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as contract_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (contract_report) ApiInvoker.deserialize(response, typeof(contract_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Allows a user to get the contracted prices for electricity, based on their type 
      /// </summary>
      /// <returns></returns>
      public contracted_energy_prices_report getTerniContractsPrices () {
        // create path and map variables
        var path = "/Terni/contracts/prices".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        try {
          if (typeof(contracted_energy_prices_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as contracted_energy_prices_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (contracted_energy_prices_report) ApiInvoker.deserialize(response, typeof(contracted_energy_prices_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves information regarding the energy consumption profile of a specific sector, during a specific time period 
      /// </summary>
      /// <param name="sector"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getTerniEnergyConsumptionProfileSectorSectorFromTo (string sector, string from, string to) {
        // create path and map variables
        var path = "/Terni/energy/consumption/profile/sector/{sector}/{from}/{to}".Replace("{format}","json").Replace("{" + "sector" + "}", apiInvoker.escapeString(sector.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (sector == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves information regarding the energy consumption profile of a specific user, during a specific time period 
      /// </summary>
      /// <param name="customer_id"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getTerniEnergyConsumptionProfileUserCustomer_idFromTo (string customer_id, string from, string to) {
        // create path and map variables
        var path = "/Terni/energy/consumption/profile/user/{customer_id}/{from}/{to}".Replace("{format}","json").Replace("{" + "customer_id" + "}", apiInvoker.escapeString(customer_id.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer_id == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves information regarding the total energy consumption of a specific user, during a specific time period 
      /// </summary>
      /// <param name="customer_id"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getTerniEnergyConsumptionTotalUserCustomer_idFromTo (string customer_id, string from, string to) {
        // create path and map variables
        var path = "/Terni/energy/consumption/total/user/{customer_id}/{from}/{to}".Replace("{format}","json").Replace("{" + "customer_id" + "}", apiInvoker.escapeString(customer_id.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer_id == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves information regarding the energy production of a specific user, during a specific time period 
      /// </summary>
      /// <param name="sector"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getTerniEnergyProductionProfileSectorSectorFromTo (string sector, string from, string to) {
        // create path and map variables
        var path = "/Terni/energy/production/profile/sector/{sector}/{from}/{to}".Replace("{format}","json").Replace("{" + "sector" + "}", apiInvoker.escapeString(sector.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (sector == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves information regarding the energy production of a specific user, during a specific time period 
      /// </summary>
      /// <param name="customer_id"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getTerniEnergyProductionProfileUserCustomer_idFromTo (string customer_id, string from, string to) {
        // create path and map variables
        var path = "/Terni/energy/production/profile/user/{customer_id}/{from}/{to}".Replace("{format}","json").Replace("{" + "customer_id" + "}", apiInvoker.escapeString(customer_id.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer_id == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      /// Retrieves information regarding the energy production of a specific user, during a specific time period 
      /// </summary>
      /// <param name="customer_id"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <returns></returns>
      public measurements_report getTerniEnergyProductionTotalUserCustomer_idFromTo (string customer_id, string from, string to) {
        // create path and map variables
        var path = "/Terni/energy/production/total/user/{customer_id}/{from}/{to}".Replace("{format}","json").Replace("{" + "customer_id" + "}", apiInvoker.escapeString(customer_id.ToString())).Replace("{" + "from" + "}", apiInvoker.escapeString(from.ToString())).Replace("{" + "to" + "}", apiInvoker.escapeString(to.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (customer_id == null || from == null || to == null ) {
           throw new ApiException(400, "missing required params");
        }
        try {
          if (typeof(measurements_report) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as measurements_report;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (measurements_report) ApiInvoker.deserialize(response, typeof(measurements_report));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      }
    }
