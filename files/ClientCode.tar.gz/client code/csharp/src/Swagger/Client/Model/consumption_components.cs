using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Consumption_components {
    public List<Component> components { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Consumption_components {\n");
      sb.Append("  components: ").Append(components).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
