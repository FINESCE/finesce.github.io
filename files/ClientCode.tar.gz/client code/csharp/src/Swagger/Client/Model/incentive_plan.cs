using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Incentive_plan {
    public string id { get; set; }

    public string time { get; set; }

    public string customer_id { get; set; }

    public string meter_id { get; set; }

    public string profile_object_name { get; set; }

    public string irp_id { get; set; }

    public List<IPAction> actions { get; set; }

    public double? der_cost { get; set; }

    public double? primary_energy_cost { get; set; }

    public double? energy_cost { get; set; }

    public string state { get; set; }

    public string retailer_notes { get; set; }

    public string market_regulator_notes { get; set; }

    public string author { get; set; }

    public string author_email { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Incentive_plan {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  time: ").Append(time).Append("\n");
      sb.Append("  customer_id: ").Append(customer_id).Append("\n");
      sb.Append("  meter_id: ").Append(meter_id).Append("\n");
      sb.Append("  profile_object_name: ").Append(profile_object_name).Append("\n");
      sb.Append("  irp_id: ").Append(irp_id).Append("\n");
      sb.Append("  actions: ").Append(actions).Append("\n");
      sb.Append("  der_cost: ").Append(der_cost).Append("\n");
      sb.Append("  primary_energy_cost: ").Append(primary_energy_cost).Append("\n");
      sb.Append("  energy_cost: ").Append(energy_cost).Append("\n");
      sb.Append("  state: ").Append(state).Append("\n");
      sb.Append("  retailer_notes: ").Append(retailer_notes).Append("\n");
      sb.Append("  market_regulator_notes: ").Append(market_regulator_notes).Append("\n");
      sb.Append("  author: ").Append(author).Append("\n");
      sb.Append("  author_email: ").Append(author_email).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
