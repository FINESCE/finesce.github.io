using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Location {
    public string name { get; set; }

    public string description { get; set; }

    public address address { get; set; }

    public string url { get; set; }

    public string latitude { get; set; }

    public string longitude { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Location {\n");
      sb.Append("  name: ").Append(name).Append("\n");
      sb.Append("  description: ").Append(description).Append("\n");
      sb.Append("  address: ").Append(address).Append("\n");
      sb.Append("  url: ").Append(url).Append("\n");
      sb.Append("  latitude: ").Append(latitude).Append("\n");
      sb.Append("  longitude: ").Append(longitude).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
