using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Regional_energy {
    public string id { get; set; }

    public double? generated_energy { get; set; }

    public double? aggregated_energy { get; set; }

    public double? requested_energy { get; set; }

    public double? actual_energy { get; set; }

    public double? forecasted_energy { get; set; }

    public string region_id { get; set; }

    public string timelslot_id { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Regional_energy {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  generated_energy: ").Append(generated_energy).Append("\n");
      sb.Append("  aggregated_energy: ").Append(aggregated_energy).Append("\n");
      sb.Append("  requested_energy: ").Append(requested_energy).Append("\n");
      sb.Append("  actual_energy: ").Append(actual_energy).Append("\n");
      sb.Append("  forecasted_energy: ").Append(forecasted_energy).Append("\n");
      sb.Append("  region_id: ").Append(region_id).Append("\n");
      sb.Append("  timelslot_id: ").Append(timelslot_id).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
