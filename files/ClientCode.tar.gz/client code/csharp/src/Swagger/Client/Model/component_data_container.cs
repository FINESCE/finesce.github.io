using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Component_data_container {
    public List<data> data { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Component_data_container {\n");
      sb.Append("  data: ").Append(data).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
