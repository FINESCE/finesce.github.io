using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Contracted_energy_prices {
    public double? der { get; set; }

    public double? bulk { get; set; }

    public double? sold { get; set; }

    public string start_date { get; set; }

    public string end_date { get; set; }

    public string volume { get; set; }

    public string currency { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Contracted_energy_prices {\n");
      sb.Append("  der: ").Append(der).Append("\n");
      sb.Append("  bulk: ").Append(bulk).Append("\n");
      sb.Append("  sold: ").Append(sold).Append("\n");
      sb.Append("  start_date: ").Append(start_date).Append("\n");
      sb.Append("  end_date: ").Append(end_date).Append("\n");
      sb.Append("  volume: ").Append(volume).Append("\n");
      sb.Append("  currency: ").Append(currency).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
