using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Algoweight {
    public string id { get; set; }

    public string renewables { get; set; }

    public string interconnect { get; set; }

    public string specific { get; set; }

    public string timeslot_id { get; set; }

    public string region_id { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Algoweight {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  renewables: ").Append(renewables).Append("\n");
      sb.Append("  interconnect: ").Append(interconnect).Append("\n");
      sb.Append("  specific: ").Append(specific).Append("\n");
      sb.Append("  timeslot_id: ").Append(timeslot_id).Append("\n");
      sb.Append("  region_id: ").Append(region_id).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
