using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Ev_supply_equipment_connection_state {
    public string id { get; set; }

    public string name { get; set; }

    public string code { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Ev_supply_equipment_connection_state {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  name: ").Append(name).Append("\n");
      sb.Append("  code: ").Append(code).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
