using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Charging_state {
    public string id { get; set; }

    public bool? change_requested { get; set; }

    public bool? responded { get; set; }

    public bool? requested_state_is_on { get; set; }

    public bool? is_charging { get; set; }

    public bool? is_connected { get; set; }

    public bool? battery_full { get; set; }

    public string ev_id { get; set; }

    public string ev_supply_equipment_id { get; set; }

    public string timeslot_id { get; set; }

    public string charging_mode_id { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Charging_state {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  change_requested: ").Append(change_requested).Append("\n");
      sb.Append("  responded: ").Append(responded).Append("\n");
      sb.Append("  requested_state_is_on: ").Append(requested_state_is_on).Append("\n");
      sb.Append("  is_charging: ").Append(is_charging).Append("\n");
      sb.Append("  is_connected: ").Append(is_connected).Append("\n");
      sb.Append("  battery_full: ").Append(battery_full).Append("\n");
      sb.Append("  ev_id: ").Append(ev_id).Append("\n");
      sb.Append("  ev_supply_equipment_id: ").Append(ev_supply_equipment_id).Append("\n");
      sb.Append("  timeslot_id: ").Append(timeslot_id).Append("\n");
      sb.Append("  charging_mode_id: ").Append(charging_mode_id).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
