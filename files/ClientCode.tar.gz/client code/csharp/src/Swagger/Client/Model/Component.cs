using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Component {
    public string access { get; set; }

    public string id { get; set; }

    public string url { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Component {\n");
      sb.Append("  access: ").Append(access).Append("\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  url: ").Append(url).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
