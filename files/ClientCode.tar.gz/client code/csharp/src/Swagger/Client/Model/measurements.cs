using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Measurements {
    public List<eu.finesce.api.generic.Value<T>> values { get; set; }

    public string start_time { get; set; }

    public string end_time { get; set; }

    public string type { get; set; }

    public string identifier { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Measurements {\n");
      sb.Append("  values: ").Append(values).Append("\n");
      sb.Append("  start_time: ").Append(start_time).Append("\n");
      sb.Append("  end_time: ").Append(end_time).Append("\n");
      sb.Append("  type: ").Append(type).Append("\n");
      sb.Append("  identifier: ").Append(identifier).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
