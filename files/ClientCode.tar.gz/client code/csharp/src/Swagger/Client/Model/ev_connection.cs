using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Ev_connection {
    public string id { get; set; }

    public string start { get; set; }

    public double? energy_current { get; set; }

    public double? energy_previous { get; set; }

    public int? duration { get; set; }

    public double? total_energy_per_connection { get; set; }

    public double? total_energy { get; set; }

    public string charging_mode_id { get; set; }

    public string ev_supply_equipment_id { get; set; }

    public string ev_supply_equipment_connection_state_id { get; set; }

    public string ev_id { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Ev_connection {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  start: ").Append(start).Append("\n");
      sb.Append("  energy_current: ").Append(energy_current).Append("\n");
      sb.Append("  energy_previous: ").Append(energy_previous).Append("\n");
      sb.Append("  duration: ").Append(duration).Append("\n");
      sb.Append("  total_energy_per_connection: ").Append(total_energy_per_connection).Append("\n");
      sb.Append("  total_energy: ").Append(total_energy).Append("\n");
      sb.Append("  charging_mode_id: ").Append(charging_mode_id).Append("\n");
      sb.Append("  ev_supply_equipment_id: ").Append(ev_supply_equipment_id).Append("\n");
      sb.Append("  ev_supply_equipment_connection_state_id: ").Append(ev_supply_equipment_connection_state_id).Append("\n");
      sb.Append("  ev_id: ").Append(ev_id).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
