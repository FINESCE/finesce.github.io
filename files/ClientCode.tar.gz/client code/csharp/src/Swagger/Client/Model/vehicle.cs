using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Vehicle {
    public string id { get; set; }

    public string type { get; set; }

    public Map<string,string> measurement_points { get; set; }

    public Map<string,string> related_entities_ids { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Vehicle {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  type: ").Append(type).Append("\n");
      sb.Append("  measurement_points: ").Append(measurement_points).Append("\n");
      sb.Append("  related_entities_ids: ").Append(related_entities_ids).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
