using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Data {
    public string date { get; set; }

    public string url { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Data {\n");
      sb.Append("  date: ").Append(date).Append("\n");
      sb.Append("  url: ").Append(url).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
