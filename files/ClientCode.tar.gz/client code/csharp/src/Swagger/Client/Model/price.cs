using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Price {
    public string currency { get; set; }

    public string locationName { get; set; }

    public string electricityPrice { get; set; }

    public string heatingPrice { get; set; }

    public string heatingOffset { get; set; }

    public string startTime { get; set; }

    public string endTime { get; set; }

    public string identifier { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Price {\n");
      sb.Append("  currency: ").Append(currency).Append("\n");
      sb.Append("  locationName: ").Append(locationName).Append("\n");
      sb.Append("  electricityPrice: ").Append(electricityPrice).Append("\n");
      sb.Append("  heatingPrice: ").Append(heatingPrice).Append("\n");
      sb.Append("  heatingOffset: ").Append(heatingOffset).Append("\n");
      sb.Append("  startTime: ").Append(startTime).Append("\n");
      sb.Append("  endTime: ").Append(endTime).Append("\n");
      sb.Append("  identifier: ").Append(identifier).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
