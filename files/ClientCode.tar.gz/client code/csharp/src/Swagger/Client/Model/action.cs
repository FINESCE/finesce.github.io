using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Action {
    public string target { get; set; }

    public string type { get; set; }

    public string value { get; set; }

    public string start_time { get; set; }

    public string end_time { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Action {\n");
      sb.Append("  target: ").Append(target).Append("\n");
      sb.Append("  type: ").Append(type).Append("\n");
      sb.Append("  value: ").Append(value).Append("\n");
      sb.Append("  start_time: ").Append(start_time).Append("\n");
      sb.Append("  end_time: ").Append(end_time).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
