using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Metadata {
    public string api_version { get; set; }

    public string trial { get; set; }

    public string created { get; set; }

    public string updated { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Metadata {\n");
      sb.Append("  api_version: ").Append(api_version).Append("\n");
      sb.Append("  trial: ").Append(trial).Append("\n");
      sb.Append("  created: ").Append(created).Append("\n");
      sb.Append("  updated: ").Append(updated).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
