using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Value {
    public string id { get; set; }

    public string datetime { get; set; }

    public T value { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Value {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  datetime: ").Append(datetime).Append("\n");
      sb.Append("  value: ").Append(value).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
