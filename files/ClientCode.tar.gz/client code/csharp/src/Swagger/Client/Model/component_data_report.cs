using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Component_data_report {
    public component_data_container measurements { get; set; }

    public component_data_container predictions { get; set; }

    public Metadata metadata { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Component_data_report {\n");
      sb.Append("  measurements: ").Append(measurements).Append("\n");
      sb.Append("  predictions: ").Append(predictions).Append("\n");
      sb.Append("  metadata: ").Append(metadata).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
