using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Timeslot {
    public string id { get; set; }

    public string start { get; set; }

    public int? duration { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Timeslot {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  start: ").Append(start).Append("\n");
      sb.Append("  duration: ").Append(duration).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
