using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Ev_type {
    public string id { get; set; }

    public string brand { get; set; }

    public string manufacturer { get; set; }

    public double? capacity { get; set; }

    public int? max_range { get; set; }

    public int? min_range { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Ev_type {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  brand: ").Append(brand).Append("\n");
      sb.Append("  manufacturer: ").Append(manufacturer).Append("\n");
      sb.Append("  capacity: ").Append(capacity).Append("\n");
      sb.Append("  max_range: ").Append(max_range).Append("\n");
      sb.Append("  min_range: ").Append(min_range).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
