using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Price_location_data {
    public string id { get; set; }

    public string name { get; set; }

    public string location_id { get; set; }

    public string measurement_type { get; set; }

    public string value_id { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Price_location_data {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  name: ").Append(name).Append("\n");
      sb.Append("  location_id: ").Append(location_id).Append("\n");
      sb.Append("  measurement_type: ").Append(measurement_type).Append("\n");
      sb.Append("  value_id: ").Append(value_id).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
