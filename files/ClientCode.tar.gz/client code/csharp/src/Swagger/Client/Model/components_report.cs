using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Components_report {
    public consumption_components consumption_components { get; set; }

    public production_components production_components { get; set; }

    public Metadata metadata { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Components_report {\n");
      sb.Append("  consumption_components: ").Append(consumption_components).Append("\n");
      sb.Append("  production_components: ").Append(production_components).Append("\n");
      sb.Append("  metadata: ").Append(metadata).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
