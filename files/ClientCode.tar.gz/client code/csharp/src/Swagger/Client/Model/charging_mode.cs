using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Charging_mode {
    public string id { get; set; }

    public string name { get; set; }

    public double? power { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Charging_mode {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  name: ").Append(name).Append("\n");
      sb.Append("  power: ").Append(power).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
