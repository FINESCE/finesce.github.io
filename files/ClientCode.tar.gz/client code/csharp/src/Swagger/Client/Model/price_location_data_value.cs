using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Price_location_data_value {
    public string id { get; set; }

    public string time { get; set; }

    public string value { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Price_location_data_value {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  time: ").Append(time).Append("\n");
      sb.Append("  value: ").Append(value).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
