using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Contract {
    public string id { get; set; }

    public string incentive_plan_id { get; set; }

    public string customer_id { get; set; }

    public string state { get; set; }

    public List<contract_action> action { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Contract {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  incentive_plan_id: ").Append(incentive_plan_id).Append("\n");
      sb.Append("  customer_id: ").Append(customer_id).Append("\n");
      sb.Append("  state: ").Append(state).Append("\n");
      sb.Append("  action: ").Append(action).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
