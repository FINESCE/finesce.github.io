using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Address {
    public string street_name { get; set; }

    public int? number { get; set; }

    public string city { get; set; }

    public string province { get; set; }

    public int? zip_code { get; set; }

    public string country { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Address {\n");
      sb.Append("  street_name: ").Append(street_name).Append("\n");
      sb.Append("  number: ").Append(number).Append("\n");
      sb.Append("  city: ").Append(city).Append("\n");
      sb.Append("  province: ").Append(province).Append("\n");
      sb.Append("  zip_code: ").Append(zip_code).Append("\n");
      sb.Append("  country: ").Append(country).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
