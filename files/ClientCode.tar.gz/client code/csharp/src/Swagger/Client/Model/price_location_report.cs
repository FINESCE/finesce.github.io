using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Price_location_report {
    public List<price_location> price_locations { get; set; }

    public Metadata metadata { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Price_location_report {\n");
      sb.Append("  price_locations: ").Append(price_locations).Append("\n");
      sb.Append("  metadata: ").Append(metadata).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
