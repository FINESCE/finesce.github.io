using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Auth_response {
    public string expires { get; set; }

    public string role { get; set; }

    public string token { get; set; }

    public string refresh_token { get; set; }

    public Metadata metadata { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Auth_response {\n");
      sb.Append("  expires: ").Append(expires).Append("\n");
      sb.Append("  role: ").Append(role).Append("\n");
      sb.Append("  token: ").Append(token).Append("\n");
      sb.Append("  refresh_token: ").Append(refresh_token).Append("\n");
      sb.Append("  metadata: ").Append(metadata).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
