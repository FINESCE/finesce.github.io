using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Machines_report {
    public List<machine> machines { get; set; }

    public Metadata metadata { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Machines_report {\n");
      sb.Append("  machines: ").Append(machines).Append("\n");
      sb.Append("  metadata: ").Append(metadata).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
