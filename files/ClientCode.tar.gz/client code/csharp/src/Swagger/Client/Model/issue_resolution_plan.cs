using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Issue_resolution_plan {
    public string time { get; set; }

    public string sector { get; set; }

    public string author { get; set; }

    public string author_email { get; set; }

    public string snapshot_filename { get; set; }

    public string aggregator_notes { get; set; }

    public string dso_notes { get; set; }

    public List<action> action { get; set; }

    public string id { get; set; }

    public string state { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Issue_resolution_plan {\n");
      sb.Append("  time: ").Append(time).Append("\n");
      sb.Append("  sector: ").Append(sector).Append("\n");
      sb.Append("  author: ").Append(author).Append("\n");
      sb.Append("  author_email: ").Append(author_email).Append("\n");
      sb.Append("  snapshot_filename: ").Append(snapshot_filename).Append("\n");
      sb.Append("  aggregator_notes: ").Append(aggregator_notes).Append("\n");
      sb.Append("  dso_notes: ").Append(dso_notes).Append("\n");
      sb.Append("  action: ").Append(action).Append("\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  state: ").Append(state).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
