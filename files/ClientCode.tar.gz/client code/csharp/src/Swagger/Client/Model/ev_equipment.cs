using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Ev_equipment {
    public string id { get; set; }

    public string manufacturer { get; set; }

    public string model { get; set; }

    public string hw_version { get; set; }

    public string fw_version { get; set; }

    public string region { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Ev_equipment {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  manufacturer: ").Append(manufacturer).Append("\n");
      sb.Append("  model: ").Append(model).Append("\n");
      sb.Append("  hw_version: ").Append(hw_version).Append("\n");
      sb.Append("  fw_version: ").Append(fw_version).Append("\n");
      sb.Append("  region: ").Append(region).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
