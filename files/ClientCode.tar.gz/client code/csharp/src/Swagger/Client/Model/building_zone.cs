using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Building_zone {
    public string id { get; set; }

    public string date { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Building_zone {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  date: ").Append(date).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
