using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Regional_energy_average {
    public string id { get; set; }

    public double? max_possible_energy { get; set; }

    public double? current_energy { get; set; }

    public string region_id { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Regional_energy_average {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  max_possible_energy: ").Append(max_possible_energy).Append("\n");
      sb.Append("  current_energy: ").Append(current_energy).Append("\n");
      sb.Append("  region_id: ").Append(region_id).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
