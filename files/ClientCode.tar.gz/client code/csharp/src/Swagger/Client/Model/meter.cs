using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Meter {
    public string id { get; set; }

    public string sector { get; set; }

    public address address { get; set; }

    public string latitude { get; set; }

    public string longitude { get; set; }

    public string customerId { get; set; }

    public string sampleIdentifier { get; set; }

    public List<string> meteringCapabilities { get; set; }

    public List<string> relatedEntities { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Meter {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  sector: ").Append(sector).Append("\n");
      sb.Append("  address: ").Append(address).Append("\n");
      sb.Append("  latitude: ").Append(latitude).Append("\n");
      sb.Append("  longitude: ").Append(longitude).Append("\n");
      sb.Append("  customerId: ").Append(customerId).Append("\n");
      sb.Append("  sampleIdentifier: ").Append(sampleIdentifier).Append("\n");
      sb.Append("  meteringCapabilities: ").Append(meteringCapabilities).Append("\n");
      sb.Append("  relatedEntities: ").Append(relatedEntities).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
