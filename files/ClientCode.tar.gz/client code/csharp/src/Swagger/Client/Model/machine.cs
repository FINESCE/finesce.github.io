using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Machine {
    public string id { get; set; }

    public string name { get; set; }

    public string process { get; set; }

    public string plc { get; set; }

    public string monitor { get; set; }

    public int? resolution { get; set; }

    public string res_unit { get; set; }

    public bool? is_cumulative { get; set; }

    public long? measurement { get; set; }

    public string measurement_unit { get; set; }

    public string status { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Machine {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  name: ").Append(name).Append("\n");
      sb.Append("  process: ").Append(process).Append("\n");
      sb.Append("  plc: ").Append(plc).Append("\n");
      sb.Append("  monitor: ").Append(monitor).Append("\n");
      sb.Append("  resolution: ").Append(resolution).Append("\n");
      sb.Append("  res_unit: ").Append(res_unit).Append("\n");
      sb.Append("  is_cumulative: ").Append(is_cumulative).Append("\n");
      sb.Append("  measurement: ").Append(measurement).Append("\n");
      sb.Append("  measurement_unit: ").Append(measurement_unit).Append("\n");
      sb.Append("  status: ").Append(status).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
