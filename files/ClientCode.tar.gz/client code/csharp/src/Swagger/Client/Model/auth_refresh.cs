using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Auth_refresh {
    public string refresh_token { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Auth_refresh {\n");
      sb.Append("  refresh_token: ").Append(refresh_token).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
