using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Auth_request {
    public string authorization_id { get; set; }

    public string password { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Auth_request {\n");
      sb.Append("  authorization_id: ").Append(authorization_id).Append("\n");
      sb.Append("  password: ").Append(password).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
