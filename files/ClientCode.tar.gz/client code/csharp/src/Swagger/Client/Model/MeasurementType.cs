using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class MeasurementType {
    public string id { get; set; }

    public string name { get; set; }

    public string description { get; set; }

    public string type { get; set; }

    public string unit { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class MeasurementType {\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  name: ").Append(name).Append("\n");
      sb.Append("  description: ").Append(description).Append("\n");
      sb.Append("  type: ").Append(type).Append("\n");
      sb.Append("  unit: ").Append(unit).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
