using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Charging_modes {
    public List<charging_mode> charging_modes { get; set; }

    public Metadata metadata { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Charging_modes {\n");
      sb.Append("  charging_modes: ").Append(charging_modes).Append("\n");
      sb.Append("  metadata: ").Append(metadata).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
