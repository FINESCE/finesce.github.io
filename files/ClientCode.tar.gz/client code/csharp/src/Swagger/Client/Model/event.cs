using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Swagger.Client.Model {
  public class Event {
    public location location { get; set; }

    public string type { get; set; }

    public string significance { get; set; }

    public string eventTime { get; set; }

    public string storeTime { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Event {\n");
      sb.Append("  location: ").Append(location).Append("\n");
      sb.Append("  type: ").Append(type).Append("\n");
      sb.Append("  significance: ").Append(significance).Append("\n");
      sb.Append("  eventTime: ").Append(eventTime).Append("\n");
      sb.Append("  storeTime: ").Append(storeTime).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
