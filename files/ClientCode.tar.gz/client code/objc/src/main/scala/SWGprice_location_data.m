#import "SWGDate.h"
#import "SWGPrice_location_data.h"

@implementation SWGPrice_location_data

-(id)_id: (NSString*) _id
    name: (NSString*) name
    location_id: (NSString*) location_id
    measurement_type: (NSString*) measurement_type
    value_id: (NSString*) value_id
{
  __id = _id;
  _name = name;
  _location_id = location_id;
  _measurement_type = measurement_type;
  _value_id = value_id;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _name = dict[@"name"]; 
        _location_id = dict[@"location_id"]; 
        _measurement_type = dict[@"measurement_type"]; 
        _value_id = dict[@"value_id"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_name != nil) dict[@"name"] = _name ;
        if(_location_id != nil) dict[@"location_id"] = _location_id ;
        if(_measurement_type != nil) dict[@"measurement_type"] = _measurement_type ;
        if(_value_id != nil) dict[@"value_id"] = _value_id ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

