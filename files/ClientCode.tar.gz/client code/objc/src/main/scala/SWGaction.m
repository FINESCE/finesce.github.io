#import "SWGDate.h"
#import "SWGAction.h"

@implementation SWGAction

-(id)target: (NSString*) target
    type: (NSString*) type
    value: (NSString*) value
    start_time: (NSString*) start_time
    end_time: (NSString*) end_time
{
  _target = target;
  _type = type;
  _value = value;
  _start_time = start_time;
  _end_time = end_time;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _target = dict[@"target"]; 
        _type = dict[@"type"]; 
        _value = dict[@"value"]; 
        _start_time = dict[@"start_time"]; 
        _end_time = dict[@"end_time"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_target != nil) dict[@"target"] = _target ;
        if(_type != nil) dict[@"type"] = _type ;
        if(_value != nil) dict[@"value"] = _value ;
        if(_start_time != nil) dict[@"start_time"] = _start_time ;
        if(_end_time != nil) dict[@"end_time"] = _end_time ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

