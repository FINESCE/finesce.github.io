#import "SWGDate.h"
#import "SWGIPAction.h"

@implementation SWGIPAction

-(id)offer: (NSString*) offer
    start_time: (NSString*) start_time
    end_time: (NSString*) end_time
    value: (NSString*) value
    type: (NSString*) type
    target: (NSString*) target
{
  _offer = offer;
  _start_time = start_time;
  _end_time = end_time;
  _value = value;
  _type = type;
  _target = target;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _offer = dict[@"offer"]; 
        _start_time = dict[@"start_time"]; 
        _end_time = dict[@"end_time"]; 
        _value = dict[@"value"]; 
        _type = dict[@"type"]; 
        _target = dict[@"target"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_offer != nil) dict[@"offer"] = _offer ;
        if(_start_time != nil) dict[@"start_time"] = _start_time ;
        if(_end_time != nil) dict[@"end_time"] = _end_time ;
        if(_value != nil) dict[@"value"] = _value ;
        if(_type != nil) dict[@"type"] = _type ;
        if(_target != nil) dict[@"target"] = _target ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

