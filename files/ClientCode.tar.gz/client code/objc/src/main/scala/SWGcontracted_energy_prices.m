#import "SWGDate.h"
#import "SWGContracted_energy_prices.h"

@implementation SWGContracted_energy_prices

-(id)der: (NSNumber*) der
    bulk: (NSNumber*) bulk
    sold: (NSNumber*) sold
    start_date: (NSString*) start_date
    end_date: (NSString*) end_date
    volume: (NSString*) volume
    currency: (NSString*) currency
{
  _der = der;
  _bulk = bulk;
  _sold = sold;
  _start_date = start_date;
  _end_date = end_date;
  _volume = volume;
  _currency = currency;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _der = dict[@"der"]; 
        _bulk = dict[@"bulk"]; 
        _sold = dict[@"sold"]; 
        _start_date = dict[@"start_date"]; 
        _end_date = dict[@"end_date"]; 
        _volume = dict[@"volume"]; 
        _currency = dict[@"currency"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_der != nil) dict[@"der"] = _der ;
        if(_bulk != nil) dict[@"bulk"] = _bulk ;
        if(_sold != nil) dict[@"sold"] = _sold ;
        if(_start_date != nil) dict[@"start_date"] = _start_date ;
        if(_end_date != nil) dict[@"end_date"] = _end_date ;
        if(_volume != nil) dict[@"volume"] = _volume ;
        if(_currency != nil) dict[@"currency"] = _currency ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

