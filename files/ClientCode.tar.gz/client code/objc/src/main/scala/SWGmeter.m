#import "SWGDate.h"
#import "SWGMeter.h"

@implementation SWGMeter

-(id)_id: (NSString*) _id
    sector: (NSString*) sector
    address: (SWGAddress*) address
    latitude: (NSString*) latitude
    longitude: (NSString*) longitude
    customerId: (NSString*) customerId
    sampleIdentifier: (NSString*) sampleIdentifier
    meteringCapabilities: (NSArray*) meteringCapabilities
    relatedEntities: (NSArray*) relatedEntities
{
  __id = _id;
  _sector = sector;
  _address = address;
  _latitude = latitude;
  _longitude = longitude;
  _customerId = customerId;
  _sampleIdentifier = sampleIdentifier;
  _meteringCapabilities = meteringCapabilities;
  _relatedEntities = relatedEntities;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _sector = dict[@"sector"]; 
        id address_dict = dict[@"address"];
        if(address_dict != nil)
            _address = [[SWGAddress alloc]initWithValues:address_dict];
        _latitude = dict[@"latitude"]; 
        _longitude = dict[@"longitude"]; 
        _customerId = dict[@"customerId"]; 
        _sampleIdentifier = dict[@"sampleIdentifier"]; 
        id meteringCapabilities_dict = dict[@"meteringCapabilities"];
        if([meteringCapabilities_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)meteringCapabilities_dict count]];

            if([(NSArray*)meteringCapabilities_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)meteringCapabilities_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _meteringCapabilities = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _meteringCapabilities = [[NSArray alloc] init];
            }
        }
        else {
            _meteringCapabilities = [[NSArray alloc] init];
        }
        id relatedEntities_dict = dict[@"relatedEntities"];
        if([relatedEntities_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)relatedEntities_dict count]];

            if([(NSArray*)relatedEntities_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)relatedEntities_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _relatedEntities = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _relatedEntities = [[NSArray alloc] init];
            }
        }
        else {
            _relatedEntities = [[NSArray alloc] init];
        }
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_sector != nil) dict[@"sector"] = _sector ;
        if(_address != nil){
        if([_address isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGAddress *address in (NSArray*)_address) {
                [array addObject:[(SWGObject*)address asDictionary]];
            }
            dict[@"address"] = array;
        }
        else if(_address && [_address isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_address toString];
            if(dateString){
                dict[@"address"] = dateString;
            }
        }
        else {
        if(_address != nil) dict[@"address"] = [(SWGObject*)_address asDictionary];
        }
    }
    if(_latitude != nil) dict[@"latitude"] = _latitude ;
        if(_longitude != nil) dict[@"longitude"] = _longitude ;
        if(_customerId != nil) dict[@"customerId"] = _customerId ;
        if(_sampleIdentifier != nil) dict[@"sampleIdentifier"] = _sampleIdentifier ;
        if(_meteringCapabilities != nil){
        if([_meteringCapabilities isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *meteringCapabilities in (NSArray*)_meteringCapabilities) {
                [array addObject:[(SWGObject*)meteringCapabilities asDictionary]];
            }
            dict[@"meteringCapabilities"] = array;
        }
        else if(_meteringCapabilities && [_meteringCapabilities isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_meteringCapabilities toString];
            if(dateString){
                dict[@"meteringCapabilities"] = dateString;
            }
        }
        else {
        if(_meteringCapabilities != nil) dict[@"meteringCapabilities"] = [(SWGObject*)_meteringCapabilities asDictionary];
        }
    }
    if(_relatedEntities != nil){
        if([_relatedEntities isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *relatedEntities in (NSArray*)_relatedEntities) {
                [array addObject:[(SWGObject*)relatedEntities asDictionary]];
            }
            dict[@"relatedEntities"] = array;
        }
        else if(_relatedEntities && [_relatedEntities isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_relatedEntities toString];
            if(dateString){
                dict[@"relatedEntities"] = dateString;
            }
        }
        else {
        if(_relatedEntities != nil) dict[@"relatedEntities"] = [(SWGObject*)_relatedEntities asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

