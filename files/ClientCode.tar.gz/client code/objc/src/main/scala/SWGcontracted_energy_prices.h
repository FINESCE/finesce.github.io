#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGContracted_energy_prices : SWGObject

@property(nonatomic) NSNumber* der;  

@property(nonatomic) NSNumber* bulk;  

@property(nonatomic) NSNumber* sold;  

@property(nonatomic) NSString* start_date;  

@property(nonatomic) NSString* end_date;  

@property(nonatomic) NSString* volume;  

@property(nonatomic) NSString* currency;  

- (id) der: (NSNumber*) der
     bulk: (NSNumber*) bulk
     sold: (NSNumber*) sold
     start_date: (NSString*) start_date
     end_date: (NSString*) end_date
     volume: (NSString*) volume
     currency: (NSString*) currency;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

