#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGAlgoweight_report : SWGObject

@property(nonatomic) NSArray* algoweight_list;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) algoweight_list: (NSArray*) algoweight_list
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

