#import "SWGDate.h"
#import "SWGAddress.h"

@implementation SWGAddress

-(id)street_name: (NSString*) street_name
    number: (NSNumber*) number
    city: (NSString*) city
    province: (NSString*) province
    zip_code: (NSNumber*) zip_code
    country: (NSString*) country
{
  _street_name = street_name;
  _number = number;
  _city = city;
  _province = province;
  _zip_code = zip_code;
  _country = country;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _street_name = dict[@"street_name"]; 
        _number = dict[@"number"]; 
        _city = dict[@"city"]; 
        _province = dict[@"province"]; 
        _zip_code = dict[@"zip_code"]; 
        _country = dict[@"country"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_street_name != nil) dict[@"street_name"] = _street_name ;
        if(_number != nil) dict[@"number"] = _number ;
        if(_city != nil) dict[@"city"] = _city ;
        if(_province != nil) dict[@"province"] = _province ;
        if(_zip_code != nil) dict[@"zip_code"] = _zip_code ;
        if(_country != nil) dict[@"country"] = _country ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

