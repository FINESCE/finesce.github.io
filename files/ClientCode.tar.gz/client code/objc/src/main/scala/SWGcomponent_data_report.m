#import "SWGDate.h"
#import "SWGComponent_data_report.h"

@implementation SWGComponent_data_report

-(id)measurements: (SWGComponent_data_container*) measurements
    predictions: (SWGComponent_data_container*) predictions
    metadata: (SWGMetadata*) metadata
{
  _measurements = measurements;
  _predictions = predictions;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id measurements_dict = dict[@"measurements"];
        if(measurements_dict != nil)
            _measurements = [[SWGComponent_data_container alloc]initWithValues:measurements_dict];
        id predictions_dict = dict[@"predictions"];
        if(predictions_dict != nil)
            _predictions = [[SWGComponent_data_container alloc]initWithValues:predictions_dict];
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_measurements != nil){
        if([_measurements isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGComponent_data_container *measurements in (NSArray*)_measurements) {
                [array addObject:[(SWGObject*)measurements asDictionary]];
            }
            dict[@"measurements"] = array;
        }
        else if(_measurements && [_measurements isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_measurements toString];
            if(dateString){
                dict[@"measurements"] = dateString;
            }
        }
        else {
        if(_measurements != nil) dict[@"measurements"] = [(SWGObject*)_measurements asDictionary];
        }
    }
    if(_predictions != nil){
        if([_predictions isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGComponent_data_container *predictions in (NSArray*)_predictions) {
                [array addObject:[(SWGObject*)predictions asDictionary]];
            }
            dict[@"predictions"] = array;
        }
        else if(_predictions && [_predictions isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_predictions toString];
            if(dateString){
                dict[@"predictions"] = dateString;
            }
        }
        else {
        if(_predictions != nil) dict[@"predictions"] = [(SWGObject*)_predictions asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

