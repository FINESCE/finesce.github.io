#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGMachine_details : SWGObject

@property(nonatomic) NSArray* machines;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) machines: (NSArray*) machines
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

