#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGIPAction : SWGObject

@property(nonatomic) NSString* offer;  

@property(nonatomic) NSString* start_time;  

@property(nonatomic) NSString* end_time;  

@property(nonatomic) NSString* value;  

@property(nonatomic) NSString* type;  

@property(nonatomic) NSString* target;  

- (id) offer: (NSString*) offer
     start_time: (NSString*) start_time
     end_time: (NSString*) end_time
     value: (NSString*) value
     type: (NSString*) type
     target: (NSString*) target;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

