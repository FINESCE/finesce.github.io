#import "SWGDate.h"
#import "SWGMeasurements_report.h"

@implementation SWGMeasurements_report

-(id)measurements: (SWGT*) measurements
    _value_list: (NSArray*) _value_list
    metadata: (SWGMetadata*) metadata
{
  _measurements = measurements;
  __value_list = _value_list;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id measurements_dict = dict[@"measurements"];
        if(measurements_dict != nil)
            _measurements = [[SWGT alloc]initWithValues:measurements_dict];
        id _value_list_dict = dict[@"_value_list"];
        if([_value_list_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)_value_list_dict count]];

            if([(NSArray*)_value_list_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)_value_list_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                __value_list = [[NSArray alloc] initWithArray:objs];
            }
            else {
                __value_list = [[NSArray alloc] init];
            }
        }
        else {
            __value_list = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_measurements != nil){
        if([_measurements isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGT *measurements in (NSArray*)_measurements) {
                [array addObject:[(SWGObject*)measurements asDictionary]];
            }
            dict[@"measurements"] = array;
        }
        else if(_measurements && [_measurements isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_measurements toString];
            if(dateString){
                dict[@"measurements"] = dateString;
            }
        }
        else {
        if(_measurements != nil) dict[@"measurements"] = [(SWGObject*)_measurements asDictionary];
        }
    }
    if(__value_list != nil){
        if([__value_list isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *_value_list in (NSArray*)__value_list) {
                [array addObject:[(SWGObject*)_value_list asDictionary]];
            }
            dict[@"_value_list"] = array;
        }
        else if(__value_list && [__value_list isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)__value_list toString];
            if(dateString){
                dict[@"_value_list"] = dateString;
            }
        }
        else {
        if(__value_list != nil) dict[@"_value_list"] = [(SWGObject*)__value_list asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

