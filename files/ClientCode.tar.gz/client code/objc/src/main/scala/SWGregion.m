#import "SWGDate.h"
#import "SWGRegion.h"

@implementation SWGRegion

-(id)_id: (NSString*) _id
    name: (NSString*) name
    code: (NSString*) code
    country: (NSString*) country
{
  __id = _id;
  _name = name;
  _code = code;
  _country = country;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _name = dict[@"name"]; 
        _code = dict[@"code"]; 
        _country = dict[@"country"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_name != nil) dict[@"name"] = _name ;
        if(_code != nil) dict[@"code"] = _code ;
        if(_country != nil) dict[@"country"] = _country ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

