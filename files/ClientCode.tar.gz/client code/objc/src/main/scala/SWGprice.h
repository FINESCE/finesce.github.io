#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGPrice : SWGObject

@property(nonatomic) NSString* currency;  

@property(nonatomic) NSString* locationName;  

@property(nonatomic) NSString* electricityPrice;  

@property(nonatomic) NSString* heatingPrice;  

@property(nonatomic) NSString* heatingOffset;  

@property(nonatomic) NSString* startTime;  

@property(nonatomic) NSString* endTime;  

@property(nonatomic) NSString* identifier;  

- (id) currency: (NSString*) currency
     locationName: (NSString*) locationName
     electricityPrice: (NSString*) electricityPrice
     heatingPrice: (NSString*) heatingPrice
     heatingOffset: (NSString*) heatingOffset
     startTime: (NSString*) startTime
     endTime: (NSString*) endTime
     identifier: (NSString*) identifier;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

