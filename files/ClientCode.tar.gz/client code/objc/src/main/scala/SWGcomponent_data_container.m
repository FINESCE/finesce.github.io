#import "SWGDate.h"
#import "SWGComponent_data_container.h"

@implementation SWGComponent_data_container

-(id)data: (NSArray*) data
{
  _data = data;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id data_dict = dict[@"data"];
        if([data_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)data_dict count]];

            if([(NSArray*)data_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)data_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _data = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _data = [[NSArray alloc] init];
            }
        }
        else {
            _data = [[NSArray alloc] init];
        }
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_data != nil){
        if([_data isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *data in (NSArray*)_data) {
                [array addObject:[(SWGObject*)data asDictionary]];
            }
            dict[@"data"] = array;
        }
        else if(_data && [_data isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_data toString];
            if(dateString){
                dict[@"data"] = dateString;
            }
        }
        else {
        if(_data != nil) dict[@"data"] = [(SWGObject*)_data asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

