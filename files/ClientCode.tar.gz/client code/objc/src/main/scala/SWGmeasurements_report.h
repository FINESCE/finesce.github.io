#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGT.h"
#import "SWGMetadata.h"


@interface SWGMeasurements_report : SWGObject

@property(nonatomic) SWGT* measurements;  

@property(nonatomic) NSArray* _value_list;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) measurements: (SWGT*) measurements
     _value_list: (NSArray*) _value_list
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

