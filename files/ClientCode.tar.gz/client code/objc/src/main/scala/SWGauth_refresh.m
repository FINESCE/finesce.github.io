#import "SWGDate.h"
#import "SWGAuth_refresh.h"

@implementation SWGAuth_refresh

-(id)refresh_token: (NSString*) refresh_token
{
  _refresh_token = refresh_token;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _refresh_token = dict[@"refresh_token"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_refresh_token != nil) dict[@"refresh_token"] = _refresh_token ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

