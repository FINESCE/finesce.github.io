#import <Foundation/Foundation.h>
#import "SWGAuth_response.h"
#import "SWGAuth_refresh.h"
#import "SWGVehicles_report.h"
#import "SWGBuildings_report.h"
#import "SWGMeasurement_types_report.h"
#import "SWGAuth_request.h"
#import "SWGMeasurements_report.h"



@interface SWGHorsensApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGHorsensApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 Retrieve authentication tokens
 
 @param body 
 */
-(NSNumber*) postHorsensTokensWithCompletionBlock :(SWGAuth_request*) body 
        completionHandler : (void (^)(SWGAuth_response* output, NSError* error))completionBlock;

/**

 Refresh an authentication token
 
 @param body 
 */
-(NSNumber*) postHorsensTokensRefreshWithCompletionBlock :(SWGAuth_refresh*) body 
        completionHandler : (void (^)(SWGAuth_response* output, NSError* error))completionBlock;

/**

 Provides the list of vehicles available
 
 */
-(NSNumber*) getHorsensVehiclesWithCompletionBlock :(void (^)(SWGVehicles_report* output, NSError* error))completionBlock;

/**

 Provides information regarding a single vehicle. A valid {id} can be found by calling the /vehicles service.
 
 @param _id 
 */
-(NSNumber*) getHorsensVehiclesIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGVehicles_report* output, NSError* error))completionBlock;

/**

 Provides information regarding the available measurements types for the specific vehicle. A valid {id} can be obtained by calling the /vehicles service.
 
 @param _id 
 */
-(NSNumber*) getHorsensVehiclesIdMeasurement_typesWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGMeasurement_types_report* output, NSError* error))completionBlock;

/**

 Provides information regarding the available measurements of a specific type for a specific vehicle, during a certain period of time. A valid {id} can be obtained by calling the /vehicles service. A valid {type_id} can be obtained by calling the /vehicles service and check the 'measurement_points' section of the answer. Valid {from} and {to} values are expressed in ISO8601 format.
 
 @param _id 
 @param type_id 
 @param from 
 @param to 
 */
-(NSNumber*) getHorsensVehiclesIdMeasurementsType_idFromToWithCompletionBlock :(NSString*) _id 
        type_id:(NSString*) type_id 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Provides a detailed list of all the available vehicle measurements types in the trial
 
 */
-(NSNumber*) getHorsensVehiclesMeasurement_typesWithCompletionBlock :(void (^)(SWGMeasurement_types_report* output, NSError* error))completionBlock;

/**

 Provides a detailed list of all the available measurements types that match a specific measurements type name. A valid {id} can be obtained by calling the /vehicles/measurement_types service.
 
 @param _id 
 */
-(NSNumber*) getHorsensVehiclesMeasurement_typesIdIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGMeasurement_types_report* output, NSError* error))completionBlock;

/**

 Provides a detailed list of all the available measurements types that match a specific measurements type. A valid {type} can be obtained by calling the /vehicles/measurement_types service and check the 'type' entries.
 
 @param type 
 */
-(NSNumber*) getHorsensVehiclesMeasurement_typesTypeTypeWithCompletionBlock :(NSString*) type 
        completionHandler : (void (^)(SWGMeasurement_types_report* output, NSError* error))completionBlock;

/**

 Provides the list of buildings available
 
 */
-(NSNumber*) getHorsensBuildingsWithCompletionBlock :(void (^)(SWGBuildings_report* output, NSError* error))completionBlock;

/**

 Provides information regarding a single building.A valid {id} can be obtained by the /buildings service.
 
 @param _id 
 */
-(NSNumber*) getHorsensBuildingsIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGBuildings_report* output, NSError* error))completionBlock;

/**

 Provides information regarding the available measurements types for the specific building.A valid {id} can be obtained by the /buildings service.
 
 @param _id 
 */
-(NSNumber*) getHorsensBuildingsIdMeasurement_typesWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGMeasurement_types_report* output, NSError* error))completionBlock;

/**

 Provides information regarding the available measurements of a specific type for a specific building, during a certain period of time. A valid {id} can be obtained by calling the /buildings service. A valid {type_id} can be obtained by calling the /buildings service and check the 'measurement_points' section of the answer. Valid {from} and {to} values are expressed in ISO8601 format.
 
 @param _id 
 @param type_id 
 @param from 
 @param to 
 */
-(NSNumber*) getHorsensBuildingsIdMeasurementsType_idFromToWithCompletionBlock :(NSString*) _id 
        type_id:(NSString*) type_id 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Provides a detailed list of all the available building measurements types in the trial
 
 */
-(NSNumber*) getHorsensBuildingsMeasurement_typesWithCompletionBlock :(void (^)(SWGMeasurement_types_report* output, NSError* error))completionBlock;

/**

 Provides a detailed list of all the available measurements types that match a specific measurements type name. A valid {id} can be obtained by calling the /buildings/measurement_types service.
 
 @param _id 
 */
-(NSNumber*) getHorsensBuildingsMeasurement_typesIdIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGMeasurement_types_report* output, NSError* error))completionBlock;

/**

 Provides a detailed list of all the available measurements types that match a specific measurements type. A valid {type} can be obtained by calling the /buildings/measurement_types service and check the 'type' attribute of the answer.
 
 @param type 
 */
-(NSNumber*) getHorsensBuildingsMeasurement_typesTypeTypeWithCompletionBlock :(NSString*) type 
        completionHandler : (void (^)(SWGMeasurement_types_report* output, NSError* error))completionBlock;

@end
