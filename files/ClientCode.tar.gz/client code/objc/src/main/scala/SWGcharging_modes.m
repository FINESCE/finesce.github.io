#import "SWGDate.h"
#import "SWGCharging_modes.h"

@implementation SWGCharging_modes

-(id)charging_modes: (NSArray*) charging_modes
    metadata: (SWGMetadata*) metadata
{
  _charging_modes = charging_modes;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id charging_modes_dict = dict[@"charging_modes"];
        if([charging_modes_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)charging_modes_dict count]];

            if([(NSArray*)charging_modes_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)charging_modes_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _charging_modes = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _charging_modes = [[NSArray alloc] init];
            }
        }
        else {
            _charging_modes = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_charging_modes != nil){
        if([_charging_modes isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *charging_modes in (NSArray*)_charging_modes) {
                [array addObject:[(SWGObject*)charging_modes asDictionary]];
            }
            dict[@"charging_modes"] = array;
        }
        else if(_charging_modes && [_charging_modes isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_charging_modes toString];
            if(dateString){
                dict[@"charging_modes"] = dateString;
            }
        }
        else {
        if(_charging_modes != nil) dict[@"charging_modes"] = [(SWGObject*)_charging_modes asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

