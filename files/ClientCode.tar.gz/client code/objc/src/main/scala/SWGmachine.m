#import "SWGDate.h"
#import "SWGMachine.h"

@implementation SWGMachine

-(id)_id: (NSString*) _id
    name: (NSString*) name
    process: (NSString*) process
    plc: (NSString*) plc
    monitor: (NSString*) monitor
    resolution: (NSNumber*) resolution
    res_unit: (NSString*) res_unit
    is_cumulative: (NSNumber*) is_cumulative
    measurement: (NSNumber*) measurement
    measurement_unit: (NSString*) measurement_unit
    status: (NSString*) status
{
  __id = _id;
  _name = name;
  _process = process;
  _plc = plc;
  _monitor = monitor;
  _resolution = resolution;
  _res_unit = res_unit;
  _is_cumulative = is_cumulative;
  _measurement = measurement;
  _measurement_unit = measurement_unit;
  _status = status;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _name = dict[@"name"]; 
        _process = dict[@"process"]; 
        _plc = dict[@"plc"]; 
        _monitor = dict[@"monitor"]; 
        _resolution = dict[@"resolution"]; 
        _res_unit = dict[@"res_unit"]; 
        _is_cumulative = dict[@"is_cumulative"]; 
        _measurement = dict[@"measurement"]; 
        _measurement_unit = dict[@"measurement_unit"]; 
        _status = dict[@"status"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_name != nil) dict[@"name"] = _name ;
        if(_process != nil) dict[@"process"] = _process ;
        if(_plc != nil) dict[@"plc"] = _plc ;
        if(_monitor != nil) dict[@"monitor"] = _monitor ;
        if(_resolution != nil) dict[@"resolution"] = _resolution ;
        if(_res_unit != nil) dict[@"res_unit"] = _res_unit ;
        if(_is_cumulative != nil) dict[@"is_cumulative"] = _is_cumulative ;
        if(_measurement != nil) dict[@"measurement"] = _measurement ;
        if(_measurement_unit != nil) dict[@"measurement_unit"] = _measurement_unit ;
        if(_status != nil) dict[@"status"] = _status ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

