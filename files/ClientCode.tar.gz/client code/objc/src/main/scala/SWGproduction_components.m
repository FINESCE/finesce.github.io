#import "SWGDate.h"
#import "SWGProduction_components.h"

@implementation SWGProduction_components

-(id)components: (NSArray*) components
{
  _components = components;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id components_dict = dict[@"components"];
        if([components_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)components_dict count]];

            if([(NSArray*)components_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)components_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _components = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _components = [[NSArray alloc] init];
            }
        }
        else {
            _components = [[NSArray alloc] init];
        }
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_components != nil){
        if([_components isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *components in (NSArray*)_components) {
                [array addObject:[(SWGObject*)components asDictionary]];
            }
            dict[@"components"] = array;
        }
        else if(_components && [_components isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_components toString];
            if(dateString){
                dict[@"components"] = dateString;
            }
        }
        else {
        if(_components != nil) dict[@"components"] = [(SWGObject*)_components asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

