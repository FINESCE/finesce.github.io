#import "SWGDate.h"
#import "SWGMachines_report.h"

@implementation SWGMachines_report

-(id)machines: (NSArray*) machines
    metadata: (SWGMetadata*) metadata
{
  _machines = machines;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id machines_dict = dict[@"machines"];
        if([machines_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)machines_dict count]];

            if([(NSArray*)machines_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)machines_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _machines = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _machines = [[NSArray alloc] init];
            }
        }
        else {
            _machines = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_machines != nil){
        if([_machines isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *machines in (NSArray*)_machines) {
                [array addObject:[(SWGObject*)machines asDictionary]];
            }
            dict[@"machines"] = array;
        }
        else if(_machines && [_machines isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_machines toString];
            if(dateString){
                dict[@"machines"] = dateString;
            }
        }
        else {
        if(_machines != nil) dict[@"machines"] = [(SWGObject*)_machines asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

