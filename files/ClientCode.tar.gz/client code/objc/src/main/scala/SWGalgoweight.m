#import "SWGDate.h"
#import "SWGAlgoweight.h"

@implementation SWGAlgoweight

-(id)_id: (NSString*) _id
    renewables: (NSString*) renewables
    interconnect: (NSString*) interconnect
    specific: (NSString*) specific
    timeslot_id: (NSString*) timeslot_id
    region_id: (NSString*) region_id
{
  __id = _id;
  _renewables = renewables;
  _interconnect = interconnect;
  _specific = specific;
  _timeslot_id = timeslot_id;
  _region_id = region_id;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _renewables = dict[@"renewables"]; 
        _interconnect = dict[@"interconnect"]; 
        _specific = dict[@"specific"]; 
        _timeslot_id = dict[@"timeslot_id"]; 
        _region_id = dict[@"region_id"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_renewables != nil) dict[@"renewables"] = _renewables ;
        if(_interconnect != nil) dict[@"interconnect"] = _interconnect ;
        if(_specific != nil) dict[@"specific"] = _specific ;
        if(_timeslot_id != nil) dict[@"timeslot_id"] = _timeslot_id ;
        if(_region_id != nil) dict[@"region_id"] = _region_id ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

