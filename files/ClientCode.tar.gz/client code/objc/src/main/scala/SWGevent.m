#import "SWGDate.h"
#import "SWGEvent.h"

@implementation SWGEvent

-(id)location: (SWGLocation*) location
    type: (NSString*) type
    significance: (NSString*) significance
    eventTime: (NSString*) eventTime
    storeTime: (NSString*) storeTime
{
  _location = location;
  _type = type;
  _significance = significance;
  _eventTime = eventTime;
  _storeTime = storeTime;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id location_dict = dict[@"location"];
        if(location_dict != nil)
            _location = [[SWGLocation alloc]initWithValues:location_dict];
        _type = dict[@"type"]; 
        _significance = dict[@"significance"]; 
        _eventTime = dict[@"eventTime"]; 
        _storeTime = dict[@"storeTime"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_location != nil){
        if([_location isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGLocation *location in (NSArray*)_location) {
                [array addObject:[(SWGObject*)location asDictionary]];
            }
            dict[@"location"] = array;
        }
        else if(_location && [_location isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_location toString];
            if(dateString){
                dict[@"location"] = dateString;
            }
        }
        else {
        if(_location != nil) dict[@"location"] = [(SWGObject*)_location asDictionary];
        }
    }
    if(_type != nil) dict[@"type"] = _type ;
        if(_significance != nil) dict[@"significance"] = _significance ;
        if(_eventTime != nil) dict[@"eventTime"] = _eventTime ;
        if(_storeTime != nil) dict[@"storeTime"] = _storeTime ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

