#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGContracted_energy_prices_report : SWGObject

@property(nonatomic) NSArray* contracted_energy_cost;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) contracted_energy_cost: (NSArray*) contracted_energy_cost
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

