#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGAuth_request : SWGObject

@property(nonatomic) NSString* authorization_id;  

@property(nonatomic) NSString* password;  

- (id) authorization_id: (NSString*) authorization_id
     password: (NSString*) password;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

