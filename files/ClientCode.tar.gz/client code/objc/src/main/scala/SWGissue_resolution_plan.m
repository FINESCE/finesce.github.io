#import "SWGDate.h"
#import "SWGIssue_resolution_plan.h"

@implementation SWGIssue_resolution_plan

-(id)time: (NSString*) time
    sector: (NSString*) sector
    author: (NSString*) author
    author_email: (NSString*) author_email
    snapshot_filename: (NSString*) snapshot_filename
    aggregator_notes: (NSString*) aggregator_notes
    dso_notes: (NSString*) dso_notes
    action: (NSArray*) action
    _id: (NSString*) _id
    state: (NSString*) state
{
  _time = time;
  _sector = sector;
  _author = author;
  _author_email = author_email;
  _snapshot_filename = snapshot_filename;
  _aggregator_notes = aggregator_notes;
  _dso_notes = dso_notes;
  _action = action;
  __id = _id;
  _state = state;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _time = dict[@"time"]; 
        _sector = dict[@"sector"]; 
        _author = dict[@"author"]; 
        _author_email = dict[@"author_email"]; 
        _snapshot_filename = dict[@"snapshot_filename"]; 
        _aggregator_notes = dict[@"aggregator_notes"]; 
        _dso_notes = dict[@"dso_notes"]; 
        id action_dict = dict[@"action"];
        if([action_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)action_dict count]];

            if([(NSArray*)action_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)action_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _action = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _action = [[NSArray alloc] init];
            }
        }
        else {
            _action = [[NSArray alloc] init];
        }
        __id = dict[@"id"]; 
        _state = dict[@"state"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_time != nil) dict[@"time"] = _time ;
        if(_sector != nil) dict[@"sector"] = _sector ;
        if(_author != nil) dict[@"author"] = _author ;
        if(_author_email != nil) dict[@"author_email"] = _author_email ;
        if(_snapshot_filename != nil) dict[@"snapshot_filename"] = _snapshot_filename ;
        if(_aggregator_notes != nil) dict[@"aggregator_notes"] = _aggregator_notes ;
        if(_dso_notes != nil) dict[@"dso_notes"] = _dso_notes ;
        if(_action != nil){
        if([_action isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *action in (NSArray*)_action) {
                [array addObject:[(SWGObject*)action asDictionary]];
            }
            dict[@"action"] = array;
        }
        else if(_action && [_action isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_action toString];
            if(dateString){
                dict[@"action"] = dateString;
            }
        }
        else {
        if(_action != nil) dict[@"action"] = [(SWGObject*)_action asDictionary];
        }
    }
    if(__id != nil) dict[@"id"] = __id ;
        if(_state != nil) dict[@"state"] = _state ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

