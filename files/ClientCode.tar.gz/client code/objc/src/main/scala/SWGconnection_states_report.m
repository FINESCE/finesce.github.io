#import "SWGDate.h"
#import "SWGConnection_states_report.h"

@implementation SWGConnection_states_report

-(id)connection_states: (NSArray*) connection_states
    metadata: (SWGMetadata*) metadata
{
  _connection_states = connection_states;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id connection_states_dict = dict[@"connection_states"];
        if([connection_states_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)connection_states_dict count]];

            if([(NSArray*)connection_states_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)connection_states_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _connection_states = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _connection_states = [[NSArray alloc] init];
            }
        }
        else {
            _connection_states = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_connection_states != nil){
        if([_connection_states isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *connection_states in (NSArray*)_connection_states) {
                [array addObject:[(SWGObject*)connection_states asDictionary]];
            }
            dict[@"connection_states"] = array;
        }
        else if(_connection_states && [_connection_states isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_connection_states toString];
            if(dateString){
                dict[@"connection_states"] = dateString;
            }
        }
        else {
        if(_connection_states != nil) dict[@"connection_states"] = [(SWGObject*)_connection_states asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

