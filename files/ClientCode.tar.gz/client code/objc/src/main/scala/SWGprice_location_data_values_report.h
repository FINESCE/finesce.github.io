#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGPrice_location_data_values_report : SWGObject

@property(nonatomic) NSArray* price_location_data_values;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) price_location_data_values: (NSArray*) price_location_data_values
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

