#import "SWGDate.h"
#import "SWGEv_equipment.h"

@implementation SWGEv_equipment

-(id)_id: (NSString*) _id
    manufacturer: (NSString*) manufacturer
    model: (NSString*) model
    hw_version: (NSString*) hw_version
    fw_version: (NSString*) fw_version
    region: (NSString*) region
{
  __id = _id;
  _manufacturer = manufacturer;
  _model = model;
  _hw_version = hw_version;
  _fw_version = fw_version;
  _region = region;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _manufacturer = dict[@"manufacturer"]; 
        _model = dict[@"model"]; 
        _hw_version = dict[@"hw_version"]; 
        _fw_version = dict[@"fw_version"]; 
        _region = dict[@"region"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_manufacturer != nil) dict[@"manufacturer"] = _manufacturer ;
        if(_model != nil) dict[@"model"] = _model ;
        if(_hw_version != nil) dict[@"hw_version"] = _hw_version ;
        if(_fw_version != nil) dict[@"fw_version"] = _fw_version ;
        if(_region != nil) dict[@"region"] = _region ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

