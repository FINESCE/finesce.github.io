#import <Foundation/Foundation.h>
#import "SWGAuth_response.h"
#import "SWGAuth_refresh.h"
#import "SWGPrice_location_data_report.h"
#import "SWGAuth_request.h"
#import "SWGPrice_location_data_values_report.h"
#import "SWGPrice_location_report.h"
#import "SWGPrice_report.h"



@interface SWGMalmoApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGMalmoApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 Retrieve authentication tokens
 
 @param body 
 */
-(NSNumber*) postMalmoTokensWithCompletionBlock :(SWGAuth_request*) body 
        completionHandler : (void (^)(SWGAuth_response* output, NSError* error))completionBlock;

/**

 Refresh an authentication token
 
 @param body 
 */
-(NSNumber*) postMalmoTokensRefreshWithCompletionBlock :(SWGAuth_refresh*) body 
        completionHandler : (void (^)(SWGAuth_response* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding the energy prices in a location
 
 */
-(NSNumber*) getMalmoPricesWithCompletionBlock :(void (^)(SWGPrice_report* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding the energy prices regardless of location. Valid {from} and {to} values are expressed in ISO8601 format.
 
 @param from 
 @param to 
 */
-(NSNumber*) getMalmoPricesFromToWithCompletionBlock :(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGPrice_report* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding the energy prices in a location. A valid {name} can be obtained by calling the /prices service.
 
 @param name 
 */
-(NSNumber*) getMalmoPricesNameWithCompletionBlock :(NSString*) name 
        completionHandler : (void (^)(SWGPrice_report* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding the energy prices in a location. A valid {name} can be obtained by calling the /prices service. Valid {from} and {to} values are expressed in ISO8601 format.
 
 @param name 
 @param from 
 @param to 
 */
-(NSNumber*) getMalmoPricesNameFromToWithCompletionBlock :(NSString*) name 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGPrice_report* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding the price locations available to the user.
 
 */
-(NSNumber*) getMalmoPricesLocationsWithCompletionBlock :(void (^)(SWGPrice_location_report* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding a price location available to the user, based on the location name. A valid {name} can be obtained by calling the /prices/locations service.
 
 @param name 
 */
-(NSNumber*) getMalmoPricesLocationsNameWithCompletionBlock :(NSString*) name 
        completionHandler : (void (^)(SWGPrice_location_report* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding a data stream available for locations associated with the current user.
 
 */
-(NSNumber*) getMalmoPricesLocationsDataWithCompletionBlock :(void (^)(SWGPrice_location_data_report* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding a data stream available for locations associated with the current user. A valid {name} can be obtained by calling the /prices/locations/data service.
 
 @param name 
 */
-(NSNumber*) getMalmoPricesLocationsDataNameWithCompletionBlock :(NSString*) name 
        completionHandler : (void (^)(SWGPrice_location_data_report* output, NSError* error))completionBlock;

/**

 Allows a user to get information regarding data stream values available for locations associated with the current user. A valid {name} can be obtained by calling the /prices/locations/data service. Valid {from} and {to} values are expressed in ISO8601 format.
 
 @param name 
 @param from 
 @param to 
 */
-(NSNumber*) getMalmoPricesLocationsDataNameValuesFromToWithCompletionBlock :(NSString*) name 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGPrice_location_data_values_report* output, NSError* error))completionBlock;

@end
