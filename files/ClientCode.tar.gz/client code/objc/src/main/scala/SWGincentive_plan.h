#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGIncentive_plan : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* time;  

@property(nonatomic) NSString* customer_id;  

@property(nonatomic) NSString* meter_id;  

@property(nonatomic) NSString* profile_object_name;  

@property(nonatomic) NSString* irp_id;  

@property(nonatomic) NSArray* actions;  

@property(nonatomic) NSNumber* der_cost;  

@property(nonatomic) NSNumber* primary_energy_cost;  

@property(nonatomic) NSNumber* energy_cost;  

@property(nonatomic) NSString* state;  

@property(nonatomic) NSString* retailer_notes;  

@property(nonatomic) NSString* market_regulator_notes;  

@property(nonatomic) NSString* author;  

@property(nonatomic) NSString* author_email;  

- (id) _id: (NSString*) _id
     time: (NSString*) time
     customer_id: (NSString*) customer_id
     meter_id: (NSString*) meter_id
     profile_object_name: (NSString*) profile_object_name
     irp_id: (NSString*) irp_id
     actions: (NSArray*) actions
     der_cost: (NSNumber*) der_cost
     primary_energy_cost: (NSNumber*) primary_energy_cost
     energy_cost: (NSNumber*) energy_cost
     state: (NSString*) state
     retailer_notes: (NSString*) retailer_notes
     market_regulator_notes: (NSString*) market_regulator_notes
     author: (NSString*) author
     author_email: (NSString*) author_email;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

