#import <Foundation/Foundation.h>
#import "SWGMeasurements_report.h"
#import "SWGMeters_report.h"
#import "SWGIncentive_plans_report.h"
#import "SWGContract_report.h"
#import "SWGContracted_energy_prices_report.h"
#import "SWGSocial_events_report.h"
#import "SWGWeather_forecast.h"
#import "SWGIssue_resolution_plans_report.h"
#import "SWGSectors_report.h"
#import "SWGWeather_descriptors.h"



@interface SWGTerniApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGTerniApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 Provides weather reports for a specific timeperiod in the area of Terni
 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniWeatherFromToWithCompletionBlock :(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGWeather_forecast* output, NSError* error))completionBlock;

/**

 Provides weather reports for a specific timeperiod in the area of Terni, considering a single weather descriptor (see /weather/available_descriptor for the supported descriptor
 
 @param descriptor 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniWeatherDescriptorFromToWithCompletionBlock :(NSString*) descriptor 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGWeather_forecast* output, NSError* error))completionBlock;

/**

 Provides information regarding the available forecast descriptors of the specified trial infrastructure
 
 */
-(NSNumber*) getTerniWeatherAvailable_descriptorsWithCompletionBlock :(void (^)(SWGWeather_descriptors* output, NSError* error))completionBlock;

/**

 Retrieves a predicted power demand report for a single sector
 
 @param sector_id 
 */
-(NSNumber*) getTerniSimulationPredictionPowerDemandSectorSector_idWithCompletionBlock :(NSString*) sector_id 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves a predicted power demand report for a single user, based on his/her id
 
 @param customer_id 
 */
-(NSNumber*) getTerniSimulationPredictionPowerDemandUserCustomer_idWithCompletionBlock :(NSString*) customer_id 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves a predicted power supply report for a single sector
 
 @param sector_id 
 */
-(NSNumber*) getTerniSimulationPredictionPowerSupplySectorSector_idWithCompletionBlock :(NSString*) sector_id 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves a predicted power supply report for a single user, based on his/her id
 
 @param customer_id 
 */
-(NSNumber*) getTerniSimulationPredictionPowerSupplyUserCustomer_idWithCompletionBlock :(NSString*) customer_id 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Offers a list of social events that can temporarily influence the electricity consumption.
 
 */
-(NSNumber*) getTerniSocialWithCompletionBlock :(void (^)(SWGSocial_events_report* output, NSError* error))completionBlock;

/**

 Offers a list of social events that can temporarily influence the electricity consumption.
 
 @param events_number 
 */
-(NSNumber*) getTerniSocialEvents_numberWithCompletionBlock :(NSString*) events_number 
        completionHandler : (void (^)(SWGSocial_events_report* output, NSError* error))completionBlock;

/**

 Gets a list of the available meters along with the set of their accompanying information.
 
 */
-(NSNumber*) getTerniMetersWithCompletionBlock :(void (^)(SWGMeters_report* output, NSError* error))completionBlock;

/**

 Retrieves a meter based on a search string.
 
 @param search_options 
 */
-(NSNumber*) getTerniMetersSearch_optionsWithCompletionBlock :(NSString*) search_options 
        completionHandler : (void (^)(SWGMeters_report* output, NSError* error))completionBlock;

/**

 Gets a list of the sectors that the meters may be deployed into.
 
 */
-(NSNumber*) getTerniMetersSectorsWithCompletionBlock :(void (^)(SWGSectors_report* output, NSError* error))completionBlock;

/**

 Allows an energy retailer to get a list of incentive plans based on their name.
 
 @param author 
 */
-(NSNumber*) getTerniDsmIpAuthorAuthorWithCompletionBlock :(NSString*) author 
        completionHandler : (void (^)(SWGIncentive_plans_report* output, NSError* error))completionBlock;

/**

 Allows an energy retailer to get a list of incentive plans based on their state and author.
 
 @param author 
 @param state 
 */
-(NSNumber*) getTerniDsmIpAuthorAuthorStateStateWithCompletionBlock :(NSString*) author 
        state:(NSString*) state 
        completionHandler : (void (^)(SWGIncentive_plans_report* output, NSError* error))completionBlock;

/**

 Allows an energy retailer to get a list of incentive plans based on their state.
 
 @param state 
 */
-(NSNumber*) getTerniDsmIpStateStateWithCompletionBlock :(NSString*) state 
        completionHandler : (void (^)(SWGIncentive_plans_report* output, NSError* error))completionBlock;

/**

 Allows a user to get a list of issue resolution plans based on their name.
 
 @param author 
 */
-(NSNumber*) getTerniDsmIrpAuthorAuthorWithCompletionBlock :(NSString*) author 
        completionHandler : (void (^)(SWGIssue_resolution_plans_report* output, NSError* error))completionBlock;

/**

 Allows a user to get a list of issue resolution plans based on their state and author.
 
 @param author 
 @param state 
 */
-(NSNumber*) getTerniDsmIrpAuthorAuthorStateStateWithCompletionBlock :(NSString*) author 
        state:(NSString*) state 
        completionHandler : (void (^)(SWGIssue_resolution_plans_report* output, NSError* error))completionBlock;

/**

 Allows a user to get a list of issue resolution plans based on their state.
 
 @param state 
 */
-(NSNumber*) getTerniDsmIrpStateStateWithCompletionBlock :(NSString*) state 
        completionHandler : (void (^)(SWGIssue_resolution_plans_report* output, NSError* error))completionBlock;

/**

 Retrieves information regarding the power demand of a specific user, during a specific time period
 
 @param customer_id 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniPowerDemandUserCustomer_idFromToWithCompletionBlock :(NSString*) customer_id 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves information regarding the power supply of a specific user, during a specific time period
 
 @param customer_id 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniPowerSupplyUserCustomer_idFromToWithCompletionBlock :(NSString*) customer_id 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Allows an energy retailer to get a list of contracts, regardless of their state
 
 @param customer 
 */
-(NSNumber*) getTerniContractsCustomerCustomerWithCompletionBlock :(NSString*) customer 
        completionHandler : (void (^)(SWGContract_report* output, NSError* error))completionBlock;

/**

 Allows an energy retailer to get a list of contracts, based on their state and customer they are intended for.
 
 @param customer 
 @param state 
 */
-(NSNumber*) getTerniContractsCustomerCustomerStateStateWithCompletionBlock :(NSString*) customer 
        state:(NSString*) state 
        completionHandler : (void (^)(SWGContract_report* output, NSError* error))completionBlock;

/**

 Allows an energy retailer to get a list of contracts, regardless of the customers they are intended for.
 
 @param state 
 */
-(NSNumber*) getTerniContractsStateStateWithCompletionBlock :(NSString*) state 
        completionHandler : (void (^)(SWGContract_report* output, NSError* error))completionBlock;

/**

 Allows a user to get the contracted prices for electricity, based on their type
 
 */
-(NSNumber*) getTerniContractsPricesWithCompletionBlock :(void (^)(SWGContracted_energy_prices_report* output, NSError* error))completionBlock;

/**

 Retrieves information regarding the energy consumption profile of a specific sector, during a specific time period
 
 @param sector 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniEnergyConsumptionProfileSectorSectorFromToWithCompletionBlock :(NSString*) sector 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves information regarding the energy consumption profile of a specific user, during a specific time period
 
 @param customer_id 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniEnergyConsumptionProfileUserCustomer_idFromToWithCompletionBlock :(NSString*) customer_id 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves information regarding the total energy consumption of a specific user, during a specific time period
 
 @param customer_id 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniEnergyConsumptionTotalUserCustomer_idFromToWithCompletionBlock :(NSString*) customer_id 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves information regarding the energy production of a specific user, during a specific time period
 
 @param sector 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniEnergyProductionProfileSectorSectorFromToWithCompletionBlock :(NSString*) sector 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves information regarding the energy production of a specific user, during a specific time period
 
 @param customer_id 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniEnergyProductionProfileUserCustomer_idFromToWithCompletionBlock :(NSString*) customer_id 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Retrieves information regarding the energy production of a specific user, during a specific time period
 
 @param customer_id 
 @param from 
 @param to 
 */
-(NSNumber*) getTerniEnergyProductionTotalUserCustomer_idFromToWithCompletionBlock :(NSString*) customer_id 
        from:(NSString*) from 
        to:(NSString*) to 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

@end
