#import "SWGDate.h"
#import "SWGContract.h"

@implementation SWGContract

-(id)_id: (NSString*) _id
    incentive_plan_id: (NSString*) incentive_plan_id
    customer_id: (NSString*) customer_id
    state: (NSString*) state
    action: (NSArray*) action
{
  __id = _id;
  _incentive_plan_id = incentive_plan_id;
  _customer_id = customer_id;
  _state = state;
  _action = action;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _incentive_plan_id = dict[@"incentive_plan_id"]; 
        _customer_id = dict[@"customer_id"]; 
        _state = dict[@"state"]; 
        id action_dict = dict[@"action"];
        if([action_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)action_dict count]];

            if([(NSArray*)action_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)action_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _action = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _action = [[NSArray alloc] init];
            }
        }
        else {
            _action = [[NSArray alloc] init];
        }
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_incentive_plan_id != nil) dict[@"incentive_plan_id"] = _incentive_plan_id ;
        if(_customer_id != nil) dict[@"customer_id"] = _customer_id ;
        if(_state != nil) dict[@"state"] = _state ;
        if(_action != nil){
        if([_action isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *action in (NSArray*)_action) {
                [array addObject:[(SWGObject*)action asDictionary]];
            }
            dict[@"action"] = array;
        }
        else if(_action && [_action isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_action toString];
            if(dateString){
                dict[@"action"] = dateString;
            }
        }
        else {
        if(_action != nil) dict[@"action"] = [(SWGObject*)_action asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

