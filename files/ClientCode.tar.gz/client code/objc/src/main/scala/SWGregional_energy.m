#import "SWGDate.h"
#import "SWGRegional_energy.h"

@implementation SWGRegional_energy

-(id)_id: (NSString*) _id
    generated_energy: (NSNumber*) generated_energy
    aggregated_energy: (NSNumber*) aggregated_energy
    requested_energy: (NSNumber*) requested_energy
    actual_energy: (NSNumber*) actual_energy
    forecasted_energy: (NSNumber*) forecasted_energy
    region_id: (NSString*) region_id
    timelslot_id: (NSString*) timelslot_id
{
  __id = _id;
  _generated_energy = generated_energy;
  _aggregated_energy = aggregated_energy;
  _requested_energy = requested_energy;
  _actual_energy = actual_energy;
  _forecasted_energy = forecasted_energy;
  _region_id = region_id;
  _timelslot_id = timelslot_id;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _generated_energy = dict[@"generated_energy"]; 
        _aggregated_energy = dict[@"aggregated_energy"]; 
        _requested_energy = dict[@"requested_energy"]; 
        _actual_energy = dict[@"actual_energy"]; 
        _forecasted_energy = dict[@"forecasted_energy"]; 
        _region_id = dict[@"region_id"]; 
        _timelslot_id = dict[@"timelslot_id"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_generated_energy != nil) dict[@"generated_energy"] = _generated_energy ;
        if(_aggregated_energy != nil) dict[@"aggregated_energy"] = _aggregated_energy ;
        if(_requested_energy != nil) dict[@"requested_energy"] = _requested_energy ;
        if(_actual_energy != nil) dict[@"actual_energy"] = _actual_energy ;
        if(_forecasted_energy != nil) dict[@"forecasted_energy"] = _forecasted_energy ;
        if(_region_id != nil) dict[@"region_id"] = _region_id ;
        if(_timelslot_id != nil) dict[@"timelslot_id"] = _timelslot_id ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

