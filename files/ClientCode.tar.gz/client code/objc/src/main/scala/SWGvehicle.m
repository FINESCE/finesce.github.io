#import "SWGDate.h"
#import "SWGVehicle.h"

@implementation SWGVehicle

-(id)_id: (NSString*) _id
    type: (NSString*) type
    measurement_points: (NSArray*) measurement_points
    related_entities_ids: (NSArray*) related_entities_ids
{
  __id = _id;
  _type = type;
  _measurement_points = measurement_points;
  _related_entities_ids = related_entities_ids;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _type = dict[@"type"]; 
        id measurement_points_dict = dict[@"measurement_points"];
        if([measurement_points_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)measurement_points_dict count]];

            if([(NSArray*)measurement_points_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)measurement_points_dict) {
                    SWGMap[string,string]* d = [[SWGMap[string,string] alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _measurement_points = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _measurement_points = [[NSArray alloc] init];
            }
        }
        else {
            _measurement_points = [[NSArray alloc] init];
        }
        id related_entities_ids_dict = dict[@"related_entities_ids"];
        if([related_entities_ids_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)related_entities_ids_dict count]];

            if([(NSArray*)related_entities_ids_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)related_entities_ids_dict) {
                    SWGMap[string,string]* d = [[SWGMap[string,string] alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _related_entities_ids = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _related_entities_ids = [[NSArray alloc] init];
            }
        }
        else {
            _related_entities_ids = [[NSArray alloc] init];
        }
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_type != nil) dict[@"type"] = _type ;
        if(_measurement_points != nil){
        if([_measurement_points isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMap[string,string] *measurement_points in (NSArray*)_measurement_points) {
                [array addObject:[(SWGObject*)measurement_points asDictionary]];
            }
            dict[@"measurement_points"] = array;
        }
        else if(_measurement_points && [_measurement_points isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_measurement_points toString];
            if(dateString){
                dict[@"measurement_points"] = dateString;
            }
        }
        else {
        if(_measurement_points != nil) dict[@"measurement_points"] = [(SWGObject*)_measurement_points asDictionary];
        }
    }
    if(_related_entities_ids != nil){
        if([_related_entities_ids isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMap[string,string] *related_entities_ids in (NSArray*)_related_entities_ids) {
                [array addObject:[(SWGObject*)related_entities_ids asDictionary]];
            }
            dict[@"related_entities_ids"] = array;
        }
        else if(_related_entities_ids && [_related_entities_ids isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_related_entities_ids toString];
            if(dateString){
                dict[@"related_entities_ids"] = dateString;
            }
        }
        else {
        if(_related_entities_ids != nil) dict[@"related_entities_ids"] = [(SWGObject*)_related_entities_ids asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

