#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"
#import "SWGComponent_data_container.h"


@interface SWGComponent_data_report : SWGObject

@property(nonatomic) SWGComponent_data_container* measurements;  

@property(nonatomic) SWGComponent_data_container* predictions;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) measurements: (SWGComponent_data_container*) measurements
     predictions: (SWGComponent_data_container*) predictions
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

