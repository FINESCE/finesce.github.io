#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGSectors_report : SWGObject

@property(nonatomic) NSArray* sectors;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) sectors: (NSArray*) sectors
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

