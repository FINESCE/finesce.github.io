#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGRegion : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* name;  

@property(nonatomic) NSString* code;  

@property(nonatomic) NSString* country;  

- (id) _id: (NSString*) _id
     name: (NSString*) name
     code: (NSString*) code
     country: (NSString*) country;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

