#import "SWGDate.h"
#import "SWGMeasurement_types_report.h"

@implementation SWGMeasurement_types_report

-(id)values: (NSArray*) values
    metadata: (SWGMetadata*) metadata
{
  _values = values;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id values_dict = dict[@"values"];
        if([values_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)values_dict count]];

            if([(NSArray*)values_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)values_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _values = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _values = [[NSArray alloc] init];
            }
        }
        else {
            _values = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_values != nil){
        if([_values isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *values in (NSArray*)_values) {
                [array addObject:[(SWGObject*)values asDictionary]];
            }
            dict[@"values"] = array;
        }
        else if(_values && [_values isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_values toString];
            if(dateString){
                dict[@"values"] = dateString;
            }
        }
        else {
        if(_values != nil) dict[@"values"] = [(SWGObject*)_values asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

