#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGMetadata : SWGObject

@property(nonatomic) NSString* api_version;  

@property(nonatomic) NSString* trial;  

@property(nonatomic) NSString* created;  

@property(nonatomic) NSString* updated;  

- (id) api_version: (NSString*) api_version
     trial: (NSString*) trial
     created: (NSString*) created
     updated: (NSString*) updated;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

