#import "SWGDate.h"
#import "SWGSocial_events_report.h"

@implementation SWGSocial_events_report

-(id)events: (NSArray*) events
    metadata: (SWGMetadata*) metadata
{
  _events = events;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id events_dict = dict[@"events"];
        if([events_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)events_dict count]];

            if([(NSArray*)events_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)events_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _events = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _events = [[NSArray alloc] init];
            }
        }
        else {
            _events = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_events != nil){
        if([_events isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *events in (NSArray*)_events) {
                [array addObject:[(SWGObject*)events asDictionary]];
            }
            dict[@"events"] = array;
        }
        else if(_events && [_events isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_events toString];
            if(dateString){
                dict[@"events"] = dateString;
            }
        }
        else {
        if(_events != nil) dict[@"events"] = [(SWGObject*)_events asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

