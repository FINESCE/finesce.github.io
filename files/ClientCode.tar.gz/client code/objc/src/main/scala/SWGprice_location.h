#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGPrice_location : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* name;  

@property(nonatomic) NSString* postcode;  

@property(nonatomic) NSString* description;  

@property(nonatomic) NSString* url;  

@property(nonatomic) NSString* price_region;  

@property(nonatomic) NSString* latitude;  

@property(nonatomic) NSString* longitude;  

@property(nonatomic) NSString* timezome;  

- (id) _id: (NSString*) _id
     name: (NSString*) name
     postcode: (NSString*) postcode
     description: (NSString*) description
     url: (NSString*) url
     price_region: (NSString*) price_region
     latitude: (NSString*) latitude
     longitude: (NSString*) longitude
     timezome: (NSString*) timezome;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

