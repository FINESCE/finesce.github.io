#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGEv_supply_equipment_connection_state : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* name;  

@property(nonatomic) NSString* code;  

- (id) _id: (NSString*) _id
     name: (NSString*) name
     code: (NSString*) code;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

