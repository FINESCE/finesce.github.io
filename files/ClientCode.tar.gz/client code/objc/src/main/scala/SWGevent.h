#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGLocation.h"


@interface SWGEvent : SWGObject

@property(nonatomic) SWGLocation* location;  

@property(nonatomic) NSString* type;  

@property(nonatomic) NSString* significance;  

@property(nonatomic) NSString* eventTime;  

@property(nonatomic) NSString* storeTime;  

- (id) location: (SWGLocation*) location
     type: (NSString*) type
     significance: (NSString*) significance
     eventTime: (NSString*) eventTime
     storeTime: (NSString*) storeTime;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

