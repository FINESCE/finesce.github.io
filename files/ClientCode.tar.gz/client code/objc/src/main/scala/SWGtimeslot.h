#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGTimeslot : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* start;  

@property(nonatomic) NSNumber* duration;  

- (id) _id: (NSString*) _id
     start: (NSString*) start
     duration: (NSNumber*) duration;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

