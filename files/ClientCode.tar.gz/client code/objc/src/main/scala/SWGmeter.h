#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGAddress.h"


@interface SWGMeter : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* sector;  

@property(nonatomic) SWGAddress* address;  

@property(nonatomic) NSString* latitude;  

@property(nonatomic) NSString* longitude;  

@property(nonatomic) NSString* customerId;  

@property(nonatomic) NSString* sampleIdentifier;  

@property(nonatomic) NSArray* meteringCapabilities;  

@property(nonatomic) NSArray* relatedEntities;  

- (id) _id: (NSString*) _id
     sector: (NSString*) sector
     address: (SWGAddress*) address
     latitude: (NSString*) latitude
     longitude: (NSString*) longitude
     customerId: (NSString*) customerId
     sampleIdentifier: (NSString*) sampleIdentifier
     meteringCapabilities: (NSArray*) meteringCapabilities
     relatedEntities: (NSArray*) relatedEntities;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

