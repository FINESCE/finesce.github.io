#import "SWGDate.h"
#import "SWGBuildingModulesReport.h"

@implementation SWGBuildingModulesReport

-(id)modules: (NSArray*) modules
    metadata: (SWGMetadata*) metadata
{
  _modules = modules;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id modules_dict = dict[@"modules"];
        if([modules_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)modules_dict count]];

            if([(NSArray*)modules_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)modules_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _modules = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _modules = [[NSArray alloc] init];
            }
        }
        else {
            _modules = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_modules != nil){
        if([_modules isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *modules in (NSArray*)_modules) {
                [array addObject:[(SWGObject*)modules asDictionary]];
            }
            dict[@"modules"] = array;
        }
        else if(_modules && [_modules isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_modules toString];
            if(dateString){
                dict[@"modules"] = dateString;
            }
        }
        else {
        if(_modules != nil) dict[@"modules"] = [(SWGObject*)_modules asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

