#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGRegional_energy : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSNumber* generated_energy;  

@property(nonatomic) NSNumber* aggregated_energy;  

@property(nonatomic) NSNumber* requested_energy;  

@property(nonatomic) NSNumber* actual_energy;  

@property(nonatomic) NSNumber* forecasted_energy;  

@property(nonatomic) NSString* region_id;  

@property(nonatomic) NSString* timelslot_id;  

- (id) _id: (NSString*) _id
     generated_energy: (NSNumber*) generated_energy
     aggregated_energy: (NSNumber*) aggregated_energy
     requested_energy: (NSNumber*) requested_energy
     actual_energy: (NSNumber*) actual_energy
     forecasted_energy: (NSNumber*) forecasted_energy
     region_id: (NSString*) region_id
     timelslot_id: (NSString*) timelslot_id;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

