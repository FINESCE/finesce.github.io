#import "SWGDate.h"
#import "SWGMetadata.h"

@implementation SWGMetadata

-(id)api_version: (NSString*) api_version
    trial: (NSString*) trial
    created: (NSString*) created
    updated: (NSString*) updated
{
  _api_version = api_version;
  _trial = trial;
  _created = created;
  _updated = updated;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _api_version = dict[@"api_version"]; 
        _trial = dict[@"trial"]; 
        _created = dict[@"created"]; 
        _updated = dict[@"updated"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_api_version != nil) dict[@"api_version"] = _api_version ;
        if(_trial != nil) dict[@"trial"] = _trial ;
        if(_created != nil) dict[@"created"] = _created ;
        if(_updated != nil) dict[@"updated"] = _updated ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

