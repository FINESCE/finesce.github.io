#import "SWGDate.h"
#import "SWGMeasurements.h"

@implementation SWGMeasurements

-(id)values: (NSArray*) values
    start_time: (NSString*) start_time
    end_time: (NSString*) end_time
    type: (NSString*) type
    identifier: (NSString*) identifier
{
  _values = values;
  _start_time = start_time;
  _end_time = end_time;
  _type = type;
  _identifier = identifier;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id values_dict = dict[@"values"];
        if([values_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)values_dict count]];

            if([(NSArray*)values_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)values_dict) {
                    SWGList[eu.finesce.api.generic.Value<T>]* d = [[SWGList[eu.finesce.api.generic.Value<T>] alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _values = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _values = [[NSArray alloc] init];
            }
        }
        else {
            _values = [[NSArray alloc] init];
        }
        _start_time = dict[@"start_time"]; 
        _end_time = dict[@"end_time"]; 
        _type = dict[@"type"]; 
        _identifier = dict[@"identifier"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_values != nil){
        if([_values isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGList[eu.finesce.api.generic.Value&lt;T&gt;] *values in (NSArray*)_values) {
                [array addObject:[(SWGObject*)values asDictionary]];
            }
            dict[@"values"] = array;
        }
        else if(_values && [_values isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_values toString];
            if(dateString){
                dict[@"values"] = dateString;
            }
        }
        else {
        if(_values != nil) dict[@"values"] = [(SWGObject*)_values asDictionary];
        }
    }
    if(_start_time != nil) dict[@"start_time"] = _start_time ;
        if(_end_time != nil) dict[@"end_time"] = _end_time ;
        if(_type != nil) dict[@"type"] = _type ;
        if(_identifier != nil) dict[@"identifier"] = _identifier ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

