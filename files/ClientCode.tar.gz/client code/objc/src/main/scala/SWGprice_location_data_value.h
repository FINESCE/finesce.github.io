#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGPrice_location_data_value : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* time;  

@property(nonatomic) NSString* value;  

- (id) _id: (NSString*) _id
     time: (NSString*) time
     value: (NSString*) value;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

