#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGAddress.h"


@interface SWGLocation : SWGObject

@property(nonatomic) NSString* name;  

@property(nonatomic) NSString* description;  

@property(nonatomic) SWGAddress* address;  

@property(nonatomic) NSString* url;  

@property(nonatomic) NSString* latitude;  

@property(nonatomic) NSString* longitude;  

- (id) name: (NSString*) name
     description: (NSString*) description
     address: (SWGAddress*) address
     url: (NSString*) url
     latitude: (NSString*) latitude
     longitude: (NSString*) longitude;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

