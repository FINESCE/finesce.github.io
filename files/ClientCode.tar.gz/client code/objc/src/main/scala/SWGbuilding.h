#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGAddress.h"
#import "SWGMap[string,string].h"


@interface SWGBuilding : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* type;  

@property(nonatomic) SWGAddress* address;  

@property(nonatomic) NSArray* measurement_points;  

@property(nonatomic) NSArray* related_entities_ids;  

- (id) _id: (NSString*) _id
     type: (NSString*) type
     address: (SWGAddress*) address
     measurement_points: (NSArray*) measurement_points
     related_entities_ids: (NSArray*) related_entities_ids;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

