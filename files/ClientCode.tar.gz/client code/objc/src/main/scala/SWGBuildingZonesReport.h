#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGBuildingZonesReport : SWGObject

@property(nonatomic) NSArray* building_zones;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) building_zones: (NSArray*) building_zones
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

