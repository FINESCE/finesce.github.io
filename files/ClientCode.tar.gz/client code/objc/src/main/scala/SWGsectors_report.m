#import "SWGDate.h"
#import "SWGSectors_report.h"

@implementation SWGSectors_report

-(id)sectors: (NSArray*) sectors
    metadata: (SWGMetadata*) metadata
{
  _sectors = sectors;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id sectors_dict = dict[@"sectors"];
        if([sectors_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)sectors_dict count]];

            if([(NSArray*)sectors_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)sectors_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _sectors = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _sectors = [[NSArray alloc] init];
            }
        }
        else {
            _sectors = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_sectors != nil){
        if([_sectors isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *sectors in (NSArray*)_sectors) {
                [array addObject:[(SWGObject*)sectors asDictionary]];
            }
            dict[@"sectors"] = array;
        }
        else if(_sectors && [_sectors isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_sectors toString];
            if(dateString){
                dict[@"sectors"] = dateString;
            }
        }
        else {
        if(_sectors != nil) dict[@"sectors"] = [(SWGObject*)_sectors asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

