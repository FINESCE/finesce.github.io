#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGCharging_modes : SWGObject

@property(nonatomic) NSArray* charging_modes;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) charging_modes: (NSArray*) charging_modes
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

