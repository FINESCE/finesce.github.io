#import "SWGDate.h"
#import "SWGLocation.h"

@implementation SWGLocation

-(id)name: (NSString*) name
    description: (NSString*) description
    address: (SWGAddress*) address
    url: (NSString*) url
    latitude: (NSString*) latitude
    longitude: (NSString*) longitude
{
  _name = name;
  _description = description;
  _address = address;
  _url = url;
  _latitude = latitude;
  _longitude = longitude;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _name = dict[@"name"]; 
        _description = dict[@"description"]; 
        id address_dict = dict[@"address"];
        if(address_dict != nil)
            _address = [[SWGAddress alloc]initWithValues:address_dict];
        _url = dict[@"url"]; 
        _latitude = dict[@"latitude"]; 
        _longitude = dict[@"longitude"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_name != nil) dict[@"name"] = _name ;
        if(_description != nil) dict[@"description"] = _description ;
        if(_address != nil){
        if([_address isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGAddress *address in (NSArray*)_address) {
                [array addObject:[(SWGObject*)address asDictionary]];
            }
            dict[@"address"] = array;
        }
        else if(_address && [_address isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_address toString];
            if(dateString){
                dict[@"address"] = dateString;
            }
        }
        else {
        if(_address != nil) dict[@"address"] = [(SWGObject*)_address asDictionary];
        }
    }
    if(_url != nil) dict[@"url"] = _url ;
        if(_latitude != nil) dict[@"latitude"] = _latitude ;
        if(_longitude != nil) dict[@"longitude"] = _longitude ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

