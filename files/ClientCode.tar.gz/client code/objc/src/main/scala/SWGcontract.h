#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGContract : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* incentive_plan_id;  

@property(nonatomic) NSString* customer_id;  

@property(nonatomic) NSString* state;  

@property(nonatomic) NSArray* action;  

- (id) _id: (NSString*) _id
     incentive_plan_id: (NSString*) incentive_plan_id
     customer_id: (NSString*) customer_id
     state: (NSString*) state
     action: (NSArray*) action;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

