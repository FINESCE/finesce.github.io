#import "SWGDate.h"
#import "SWGCharging_state.h"

@implementation SWGCharging_state

-(id)_id: (NSString*) _id
    change_requested: (NSNumber*) change_requested
    responded: (NSNumber*) responded
    requested_state_is_on: (NSNumber*) requested_state_is_on
    is_charging: (NSNumber*) is_charging
    is_connected: (NSNumber*) is_connected
    battery_full: (NSNumber*) battery_full
    ev_id: (NSString*) ev_id
    ev_supply_equipment_id: (NSString*) ev_supply_equipment_id
    timeslot_id: (NSString*) timeslot_id
    charging_mode_id: (NSString*) charging_mode_id
{
  __id = _id;
  _change_requested = change_requested;
  _responded = responded;
  _requested_state_is_on = requested_state_is_on;
  _is_charging = is_charging;
  _is_connected = is_connected;
  _battery_full = battery_full;
  _ev_id = ev_id;
  _ev_supply_equipment_id = ev_supply_equipment_id;
  _timeslot_id = timeslot_id;
  _charging_mode_id = charging_mode_id;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _change_requested = dict[@"change_requested"]; 
        _responded = dict[@"responded"]; 
        _requested_state_is_on = dict[@"requested_state_is_on"]; 
        _is_charging = dict[@"is_charging"]; 
        _is_connected = dict[@"is_connected"]; 
        _battery_full = dict[@"battery_full"]; 
        _ev_id = dict[@"ev_id"]; 
        _ev_supply_equipment_id = dict[@"ev_supply_equipment_id"]; 
        _timeslot_id = dict[@"timeslot_id"]; 
        _charging_mode_id = dict[@"charging_mode_id"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_change_requested != nil) dict[@"change_requested"] = _change_requested ;
        if(_responded != nil) dict[@"responded"] = _responded ;
        if(_requested_state_is_on != nil) dict[@"requested_state_is_on"] = _requested_state_is_on ;
        if(_is_charging != nil) dict[@"is_charging"] = _is_charging ;
        if(_is_connected != nil) dict[@"is_connected"] = _is_connected ;
        if(_battery_full != nil) dict[@"battery_full"] = _battery_full ;
        if(_ev_id != nil) dict[@"ev_id"] = _ev_id ;
        if(_ev_supply_equipment_id != nil) dict[@"ev_supply_equipment_id"] = _ev_supply_equipment_id ;
        if(_timeslot_id != nil) dict[@"timeslot_id"] = _timeslot_id ;
        if(_charging_mode_id != nil) dict[@"charging_mode_id"] = _charging_mode_id ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

