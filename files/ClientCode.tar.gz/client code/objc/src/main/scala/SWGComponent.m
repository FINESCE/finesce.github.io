#import "SWGDate.h"
#import "SWGComponent.h"

@implementation SWGComponent

-(id)access: (NSString*) access
    _id: (NSString*) _id
    url: (NSString*) url
{
  _access = access;
  __id = _id;
  _url = url;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _access = dict[@"access"]; 
        __id = dict[@"id"]; 
        _url = dict[@"url"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_access != nil) dict[@"access"] = _access ;
        if(__id != nil) dict[@"id"] = __id ;
        if(_url != nil) dict[@"url"] = _url ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

