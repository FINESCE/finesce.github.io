#import <Foundation/Foundation.h>
#import "SWGAuth_response.h"
#import "SWGAuth_refresh.h"
#import "SWGComponent_data_report.h"
#import "SWGAuth_request.h"
#import "SWGComponents_report.h"
#import "SWGMachine_details.h"
#import "SWGMachines_report.h"
#import "SWGMeasurements_report.h"



@interface SWGAachenApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGAachenApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 Retrieve authentication tokens
 
 @param body 
 */
-(NSNumber*) postAachenTokensWithCompletionBlock :(SWGAuth_request*) body 
        completionHandler : (void (^)(SWGAuth_response* output, NSError* error))completionBlock;

/**

 Refresh an authentication token
 
 @param body 
 */
-(NSNumber*) postAachenTokensRefreshWithCompletionBlock :(SWGAuth_refresh*) body 
        completionHandler : (void (^)(SWGAuth_response* output, NSError* error))completionBlock;

/**

 Provides the list of available machines of the smart factory.
 
 */
-(NSNumber*) getAachenFactoryEquipmentMachinesWithCompletionBlock :(void (^)(SWGMachines_report* output, NSError* error))completionBlock;

/**

 Provides details related to a single machine. A valid {machine_id} can be found from the /factory/equipment/machines service.
 
 @param machine_id 
 */
-(NSNumber*) getAachenFactoryEquipmentMachinesMachine_idWithCompletionBlock :(NSString*) machine_id 
        completionHandler : (void (^)(SWGMachine_details* output, NSError* error))completionBlock;

/**

 Gets the list of dates of available data for a component. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service.
 
 @param comp_type 
 @param comp_id 
 */
-(NSNumber*) getAachenVppComp_typeComp_idDataWithCompletionBlock :(NSString*) comp_type 
        comp_id:(NSString*) comp_id 
        completionHandler : (void (^)(SWGComponent_data_report* output, NSError* error))completionBlock;

/**

 Gets measurement data for component for a specified data and data type. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service. A valid {date} can be found from the /vpp/{comp_type}/{comp_id}/data service. 
 
 @param comp_type 
 @param comp_id 
 @param date 
 */
-(NSNumber*) getAachenVppComp_typeComp_idMeasurementsDateWithCompletionBlock :(NSString*) comp_type 
        comp_id:(NSString*) comp_id 
        date:(NSString*) date 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Gets prediction data for component for a specified data and data type. The {comp_type} can be either 'production' or 'consumption'. A valid {comp_id} can be found from the /vpp/components service. A valid {date} can be found from the /vpp/{comp_type}/{comp_id}/data service. 
 
 @param comp_type 
 @param comp_id 
 @param date 
 */
-(NSNumber*) getAachenVppComp_typeComp_idPredictionsDateWithCompletionBlock :(NSString*) comp_type 
        comp_id:(NSString*) comp_id 
        date:(NSString*) date 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Provides the list of available components of the VPP
 
 */
-(NSNumber*) getAachenVppComponentsWithCompletionBlock :(void (^)(SWGComponents_report* output, NSError* error))completionBlock;

@end
