#import "SWGDate.h"
#import "SWGRegional_energy_average_report.h"

@implementation SWGRegional_energy_average_report

-(id)regional_energy_average: (NSArray*) regional_energy_average
    metadata: (SWGMetadata*) metadata
{
  _regional_energy_average = regional_energy_average;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id regional_energy_average_dict = dict[@"regional_energy_average"];
        if([regional_energy_average_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)regional_energy_average_dict count]];

            if([(NSArray*)regional_energy_average_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)regional_energy_average_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _regional_energy_average = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _regional_energy_average = [[NSArray alloc] init];
            }
        }
        else {
            _regional_energy_average = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_regional_energy_average != nil){
        if([_regional_energy_average isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *regional_energy_average in (NSArray*)_regional_energy_average) {
                [array addObject:[(SWGObject*)regional_energy_average asDictionary]];
            }
            dict[@"regional_energy_average"] = array;
        }
        else if(_regional_energy_average && [_regional_energy_average isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_regional_energy_average toString];
            if(dateString){
                dict[@"regional_energy_average"] = dateString;
            }
        }
        else {
        if(_regional_energy_average != nil) dict[@"regional_energy_average"] = [(SWGObject*)_regional_energy_average asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

