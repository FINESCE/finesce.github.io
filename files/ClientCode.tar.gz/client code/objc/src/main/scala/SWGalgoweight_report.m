#import "SWGDate.h"
#import "SWGAlgoweight_report.h"

@implementation SWGAlgoweight_report

-(id)algoweight_list: (NSArray*) algoweight_list
    metadata: (SWGMetadata*) metadata
{
  _algoweight_list = algoweight_list;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id algoweight_list_dict = dict[@"algoweight_list"];
        if([algoweight_list_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)algoweight_list_dict count]];

            if([(NSArray*)algoweight_list_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)algoweight_list_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _algoweight_list = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _algoweight_list = [[NSArray alloc] init];
            }
        }
        else {
            _algoweight_list = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_algoweight_list != nil){
        if([_algoweight_list isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *algoweight_list in (NSArray*)_algoweight_list) {
                [array addObject:[(SWGObject*)algoweight_list asDictionary]];
            }
            dict[@"algoweight_list"] = array;
        }
        else if(_algoweight_list && [_algoweight_list isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_algoweight_list toString];
            if(dateString){
                dict[@"algoweight_list"] = dateString;
            }
        }
        else {
        if(_algoweight_list != nil) dict[@"algoweight_list"] = [(SWGObject*)_algoweight_list asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

