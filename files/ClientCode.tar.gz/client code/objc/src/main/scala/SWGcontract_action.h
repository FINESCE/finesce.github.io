#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGContract_action : SWGObject

@property(nonatomic) NSString* customer_approval;  

@property(nonatomic) NSString* offer;  

@property(nonatomic) NSString* start_time;  

@property(nonatomic) NSString* end_time;  

@property(nonatomic) NSString* value;  

@property(nonatomic) NSString* type;  

@property(nonatomic) NSString* target;  

- (id) customer_approval: (NSString*) customer_approval
     offer: (NSString*) offer
     start_time: (NSString*) start_time
     end_time: (NSString*) end_time
     value: (NSString*) value
     type: (NSString*) type
     target: (NSString*) target;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

