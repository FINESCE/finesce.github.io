#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGIssue_resolution_plan : SWGObject

@property(nonatomic) NSString* time;  

@property(nonatomic) NSString* sector;  

@property(nonatomic) NSString* author;  

@property(nonatomic) NSString* author_email;  

@property(nonatomic) NSString* snapshot_filename;  

@property(nonatomic) NSString* aggregator_notes;  

@property(nonatomic) NSString* dso_notes;  

@property(nonatomic) NSArray* action;  

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* state;  

- (id) time: (NSString*) time
     sector: (NSString*) sector
     author: (NSString*) author
     author_email: (NSString*) author_email
     snapshot_filename: (NSString*) snapshot_filename
     aggregator_notes: (NSString*) aggregator_notes
     dso_notes: (NSString*) dso_notes
     action: (NSArray*) action
     _id: (NSString*) _id
     state: (NSString*) state;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

