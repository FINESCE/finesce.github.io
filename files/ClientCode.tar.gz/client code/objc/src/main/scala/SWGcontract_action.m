#import "SWGDate.h"
#import "SWGContract_action.h"

@implementation SWGContract_action

-(id)customer_approval: (NSString*) customer_approval
    offer: (NSString*) offer
    start_time: (NSString*) start_time
    end_time: (NSString*) end_time
    value: (NSString*) value
    type: (NSString*) type
    target: (NSString*) target
{
  _customer_approval = customer_approval;
  _offer = offer;
  _start_time = start_time;
  _end_time = end_time;
  _value = value;
  _type = type;
  _target = target;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _customer_approval = dict[@"customer_approval"]; 
        _offer = dict[@"offer"]; 
        _start_time = dict[@"start_time"]; 
        _end_time = dict[@"end_time"]; 
        _value = dict[@"value"]; 
        _type = dict[@"type"]; 
        _target = dict[@"target"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_customer_approval != nil) dict[@"customer_approval"] = _customer_approval ;
        if(_offer != nil) dict[@"offer"] = _offer ;
        if(_start_time != nil) dict[@"start_time"] = _start_time ;
        if(_end_time != nil) dict[@"end_time"] = _end_time ;
        if(_value != nil) dict[@"value"] = _value ;
        if(_type != nil) dict[@"type"] = _type ;
        if(_target != nil) dict[@"target"] = _target ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

