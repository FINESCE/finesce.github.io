#import "SWGDate.h"
#import "SWGPrice_location_report.h"

@implementation SWGPrice_location_report

-(id)price_locations: (NSArray*) price_locations
    metadata: (SWGMetadata*) metadata
{
  _price_locations = price_locations;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id price_locations_dict = dict[@"price_locations"];
        if([price_locations_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)price_locations_dict count]];

            if([(NSArray*)price_locations_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)price_locations_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _price_locations = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _price_locations = [[NSArray alloc] init];
            }
        }
        else {
            _price_locations = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_price_locations != nil){
        if([_price_locations isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *price_locations in (NSArray*)_price_locations) {
                [array addObject:[(SWGObject*)price_locations asDictionary]];
            }
            dict[@"price_locations"] = array;
        }
        else if(_price_locations && [_price_locations isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_price_locations toString];
            if(dateString){
                dict[@"price_locations"] = dateString;
            }
        }
        else {
        if(_price_locations != nil) dict[@"price_locations"] = [(SWGObject*)_price_locations asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

