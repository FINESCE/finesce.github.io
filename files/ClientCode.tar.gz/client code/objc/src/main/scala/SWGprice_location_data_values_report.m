#import "SWGDate.h"
#import "SWGPrice_location_data_values_report.h"

@implementation SWGPrice_location_data_values_report

-(id)price_location_data_values: (NSArray*) price_location_data_values
    metadata: (SWGMetadata*) metadata
{
  _price_location_data_values = price_location_data_values;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id price_location_data_values_dict = dict[@"price_location_data_values"];
        if([price_location_data_values_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)price_location_data_values_dict count]];

            if([(NSArray*)price_location_data_values_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)price_location_data_values_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _price_location_data_values = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _price_location_data_values = [[NSArray alloc] init];
            }
        }
        else {
            _price_location_data_values = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_price_location_data_values != nil){
        if([_price_location_data_values isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *price_location_data_values in (NSArray*)_price_location_data_values) {
                [array addObject:[(SWGObject*)price_location_data_values asDictionary]];
            }
            dict[@"price_location_data_values"] = array;
        }
        else if(_price_location_data_values && [_price_location_data_values isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_price_location_data_values toString];
            if(dateString){
                dict[@"price_location_data_values"] = dateString;
            }
        }
        else {
        if(_price_location_data_values != nil) dict[@"price_location_data_values"] = [(SWGObject*)_price_location_data_values asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

