#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGProduction_components : SWGObject

@property(nonatomic) NSArray* components;  

- (id) components: (NSArray*) components;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

