#import "SWGDate.h"
#import "SWGBuildingZonesReport.h"

@implementation SWGBuildingZonesReport

-(id)building_zones: (NSArray*) building_zones
    metadata: (SWGMetadata*) metadata
{
  _building_zones = building_zones;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id building_zones_dict = dict[@"building_zones"];
        if([building_zones_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)building_zones_dict count]];

            if([(NSArray*)building_zones_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)building_zones_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _building_zones = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _building_zones = [[NSArray alloc] init];
            }
        }
        else {
            _building_zones = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_building_zones != nil){
        if([_building_zones isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *building_zones in (NSArray*)_building_zones) {
                [array addObject:[(SWGObject*)building_zones asDictionary]];
            }
            dict[@"building_zones"] = array;
        }
        else if(_building_zones && [_building_zones isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_building_zones toString];
            if(dateString){
                dict[@"building_zones"] = dateString;
            }
        }
        else {
        if(_building_zones != nil) dict[@"building_zones"] = [(SWGObject*)_building_zones asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

