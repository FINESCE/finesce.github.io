#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGT.h"


@interface SWGValue : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* datetime;  

@property(nonatomic) SWGT* value;  

- (id) _id: (NSString*) _id
     datetime: (NSString*) datetime
     value: (SWGT*) value;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

