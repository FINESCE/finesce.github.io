#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGWeather_forecast : SWGObject

@property(nonatomic) NSArray* weather_data;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) weather_data: (NSArray*) weather_data
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

