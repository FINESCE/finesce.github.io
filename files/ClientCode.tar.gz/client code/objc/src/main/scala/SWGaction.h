#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGAction : SWGObject

@property(nonatomic) NSString* target;  

@property(nonatomic) NSString* type;  

@property(nonatomic) NSString* value;  

@property(nonatomic) NSString* start_time;  

@property(nonatomic) NSString* end_time;  

- (id) target: (NSString*) target
     type: (NSString*) type
     value: (NSString*) value
     start_time: (NSString*) start_time
     end_time: (NSString*) end_time;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

