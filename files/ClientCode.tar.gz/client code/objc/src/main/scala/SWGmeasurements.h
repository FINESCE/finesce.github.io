#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGList[eu.finesce.api.generic.Value&lt;T&gt;].h"


@interface SWGMeasurements : SWGObject

@property(nonatomic) NSArray* values;  

@property(nonatomic) NSString* start_time;  

@property(nonatomic) NSString* end_time;  

@property(nonatomic) NSString* type;  

@property(nonatomic) NSString* identifier;  

- (id) values: (NSArray*) values
     start_time: (NSString*) start_time
     end_time: (NSString*) end_time
     type: (NSString*) type
     identifier: (NSString*) identifier;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

