#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGWeather_descriptors : SWGObject

@property(nonatomic) NSArray* descriptors;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) descriptors: (NSArray*) descriptors
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

