#import "SWGDate.h"
#import "SWGEv_types_report.h"

@implementation SWGEv_types_report

-(id)list: (NSArray*) list
    metadata: (SWGMetadata*) metadata
{
  _list = list;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id list_dict = dict[@"list"];
        if([list_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)list_dict count]];

            if([(NSArray*)list_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)list_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _list = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _list = [[NSArray alloc] init];
            }
        }
        else {
            _list = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_list != nil){
        if([_list isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *list in (NSArray*)_list) {
                [array addObject:[(SWGObject*)list asDictionary]];
            }
            dict[@"list"] = array;
        }
        else if(_list && [_list isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_list toString];
            if(dateString){
                dict[@"list"] = dateString;
            }
        }
        else {
        if(_list != nil) dict[@"list"] = [(SWGObject*)_list asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

