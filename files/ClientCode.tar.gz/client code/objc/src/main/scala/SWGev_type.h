#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGEv_type : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* brand;  

@property(nonatomic) NSString* manufacturer;  

@property(nonatomic) NSNumber* capacity;  

@property(nonatomic) NSNumber* max_range;  

@property(nonatomic) NSNumber* min_range;  

- (id) _id: (NSString*) _id
     brand: (NSString*) brand
     manufacturer: (NSString*) manufacturer
     capacity: (NSNumber*) capacity
     max_range: (NSNumber*) max_range
     min_range: (NSNumber*) min_range;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

