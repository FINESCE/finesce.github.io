#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGBuilding_zone : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* date;  

- (id) _id: (NSString*) _id
     date: (NSString*) date;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

