#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGMeters_report : SWGObject

@property(nonatomic) NSArray* meters;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) meters: (NSArray*) meters
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

