#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGComponent_data_container : SWGObject

@property(nonatomic) NSArray* data;  

- (id) data: (NSArray*) data;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

