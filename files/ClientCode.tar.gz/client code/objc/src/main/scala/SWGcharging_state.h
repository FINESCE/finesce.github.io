#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGCharging_state : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSNumber* change_requested;  

@property(nonatomic) NSNumber* responded;  

@property(nonatomic) NSNumber* requested_state_is_on;  

@property(nonatomic) NSNumber* is_charging;  

@property(nonatomic) NSNumber* is_connected;  

@property(nonatomic) NSNumber* battery_full;  

@property(nonatomic) NSString* ev_id;  

@property(nonatomic) NSString* ev_supply_equipment_id;  

@property(nonatomic) NSString* timeslot_id;  

@property(nonatomic) NSString* charging_mode_id;  

- (id) _id: (NSString*) _id
     change_requested: (NSNumber*) change_requested
     responded: (NSNumber*) responded
     requested_state_is_on: (NSNumber*) requested_state_is_on
     is_charging: (NSNumber*) is_charging
     is_connected: (NSNumber*) is_connected
     battery_full: (NSNumber*) battery_full
     ev_id: (NSString*) ev_id
     ev_supply_equipment_id: (NSString*) ev_supply_equipment_id
     timeslot_id: (NSString*) timeslot_id
     charging_mode_id: (NSString*) charging_mode_id;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

