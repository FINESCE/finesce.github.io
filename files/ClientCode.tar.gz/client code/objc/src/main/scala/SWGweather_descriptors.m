#import "SWGDate.h"
#import "SWGWeather_descriptors.h"

@implementation SWGWeather_descriptors

-(id)descriptors: (NSArray*) descriptors
    metadata: (SWGMetadata*) metadata
{
  _descriptors = descriptors;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id descriptors_dict = dict[@"descriptors"];
        if([descriptors_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)descriptors_dict count]];

            if([(NSArray*)descriptors_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)descriptors_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _descriptors = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _descriptors = [[NSArray alloc] init];
            }
        }
        else {
            _descriptors = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_descriptors != nil){
        if([_descriptors isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *descriptors in (NSArray*)_descriptors) {
                [array addObject:[(SWGObject*)descriptors asDictionary]];
            }
            dict[@"descriptors"] = array;
        }
        else if(_descriptors && [_descriptors isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_descriptors toString];
            if(dateString){
                dict[@"descriptors"] = dateString;
            }
        }
        else {
        if(_descriptors != nil) dict[@"descriptors"] = [(SWGObject*)_descriptors asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

