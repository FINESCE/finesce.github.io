#import "SWGDate.h"
#import "SWGEv_type.h"

@implementation SWGEv_type

-(id)_id: (NSString*) _id
    brand: (NSString*) brand
    manufacturer: (NSString*) manufacturer
    capacity: (NSNumber*) capacity
    max_range: (NSNumber*) max_range
    min_range: (NSNumber*) min_range
{
  __id = _id;
  _brand = brand;
  _manufacturer = manufacturer;
  _capacity = capacity;
  _max_range = max_range;
  _min_range = min_range;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _brand = dict[@"brand"]; 
        _manufacturer = dict[@"manufacturer"]; 
        _capacity = dict[@"capacity"]; 
        _max_range = dict[@"max_range"]; 
        _min_range = dict[@"min_range"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_brand != nil) dict[@"brand"] = _brand ;
        if(_manufacturer != nil) dict[@"manufacturer"] = _manufacturer ;
        if(_capacity != nil) dict[@"capacity"] = _capacity ;
        if(_max_range != nil) dict[@"max_range"] = _max_range ;
        if(_min_range != nil) dict[@"min_range"] = _min_range ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

