#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGMachine : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* name;  

@property(nonatomic) NSString* process;  

@property(nonatomic) NSString* plc;  

@property(nonatomic) NSString* monitor;  

@property(nonatomic) NSNumber* resolution;  

@property(nonatomic) NSString* res_unit;  

@property(nonatomic) NSNumber* is_cumulative;  

@property(nonatomic) NSNumber* measurement;  

@property(nonatomic) NSString* measurement_unit;  

@property(nonatomic) NSString* status;  

- (id) _id: (NSString*) _id
     name: (NSString*) name
     process: (NSString*) process
     plc: (NSString*) plc
     monitor: (NSString*) monitor
     resolution: (NSNumber*) resolution
     res_unit: (NSString*) res_unit
     is_cumulative: (NSNumber*) is_cumulative
     measurement: (NSNumber*) measurement
     measurement_unit: (NSString*) measurement_unit
     status: (NSString*) status;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

