#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGEu.finesce.api.generic.Measurement&lt;eu.finesce.api.measurements.types.EnergyStatusSingleton&gt;.h"


@interface SWGMachine_history : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* name;  

@property(nonatomic) NSString* process;  

@property(nonatomic) NSString* plc;  

@property(nonatomic) NSString* monitor;  

@property(nonatomic) NSNumber* resolution;  

@property(nonatomic) NSString* res_unit;  

@property(nonatomic) NSNumber* is_cumulative;  

@property(nonatomic) SWGEu.finesce.api.generic.Measurement&lt;eu.finesce.api.measurements.types.EnergyStatusSingleton&gt;* measurements;  

- (id) _id: (NSString*) _id
     name: (NSString*) name
     process: (NSString*) process
     plc: (NSString*) plc
     monitor: (NSString*) monitor
     resolution: (NSNumber*) resolution
     res_unit: (NSString*) res_unit
     is_cumulative: (NSNumber*) is_cumulative
     measurements: (SWGEu.finesce.api.generic.Measurement&lt;eu.finesce.api.measurements.types.EnergyStatusSingleton&gt;*) measurements;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

