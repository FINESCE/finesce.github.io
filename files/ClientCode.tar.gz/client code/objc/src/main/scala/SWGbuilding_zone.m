#import "SWGDate.h"
#import "SWGBuilding_zone.h"

@implementation SWGBuilding_zone

-(id)_id: (NSString*) _id
    date: (NSString*) date
{
  __id = _id;
  _date = date;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _date = dict[@"date"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_date != nil) dict[@"date"] = _date ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

