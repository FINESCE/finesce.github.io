#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGPrice_location_data_report : SWGObject

@property(nonatomic) NSArray* list;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) list: (NSArray*) list
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

