#import "SWGDate.h"
#import "SWGMeters_report.h"

@implementation SWGMeters_report

-(id)meters: (NSArray*) meters
    metadata: (SWGMetadata*) metadata
{
  _meters = meters;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id meters_dict = dict[@"meters"];
        if([meters_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)meters_dict count]];

            if([(NSArray*)meters_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)meters_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _meters = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _meters = [[NSArray alloc] init];
            }
        }
        else {
            _meters = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_meters != nil){
        if([_meters isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *meters in (NSArray*)_meters) {
                [array addObject:[(SWGObject*)meters asDictionary]];
            }
            dict[@"meters"] = array;
        }
        else if(_meters && [_meters isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_meters toString];
            if(dateString){
                dict[@"meters"] = dateString;
            }
        }
        else {
        if(_meters != nil) dict[@"meters"] = [(SWGObject*)_meters asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

