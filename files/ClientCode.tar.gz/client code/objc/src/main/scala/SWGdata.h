#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGData : SWGObject

@property(nonatomic) NSString* date;  

@property(nonatomic) NSString* url;  

- (id) date: (NSString*) date
     url: (NSString*) url;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

