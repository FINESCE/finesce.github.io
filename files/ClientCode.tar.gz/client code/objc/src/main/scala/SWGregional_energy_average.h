#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGRegional_energy_average : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSNumber* max_possible_energy;  

@property(nonatomic) NSNumber* current_energy;  

@property(nonatomic) NSString* region_id;  

- (id) _id: (NSString*) _id
     max_possible_energy: (NSNumber*) max_possible_energy
     current_energy: (NSNumber*) current_energy
     region_id: (NSString*) region_id;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

