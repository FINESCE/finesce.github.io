#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGEv_connection : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* start;  

@property(nonatomic) NSNumber* energy_current;  

@property(nonatomic) NSNumber* energy_previous;  

@property(nonatomic) NSNumber* duration;  

@property(nonatomic) NSNumber* total_energy_per_connection;  

@property(nonatomic) NSNumber* total_energy;  

@property(nonatomic) NSString* charging_mode_id;  

@property(nonatomic) NSString* ev_supply_equipment_id;  

@property(nonatomic) NSString* ev_supply_equipment_connection_state_id;  

@property(nonatomic) NSString* ev_id;  

- (id) _id: (NSString*) _id
     start: (NSString*) start
     energy_current: (NSNumber*) energy_current
     energy_previous: (NSNumber*) energy_previous
     duration: (NSNumber*) duration
     total_energy_per_connection: (NSNumber*) total_energy_per_connection
     total_energy: (NSNumber*) total_energy
     charging_mode_id: (NSString*) charging_mode_id
     ev_supply_equipment_id: (NSString*) ev_supply_equipment_id
     ev_supply_equipment_connection_state_id: (NSString*) ev_supply_equipment_connection_state_id
     ev_id: (NSString*) ev_id;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

