#import "SWGDate.h"
#import "SWGTimeslot.h"

@implementation SWGTimeslot

-(id)_id: (NSString*) _id
    start: (NSString*) start
    duration: (NSNumber*) duration
{
  __id = _id;
  _start = start;
  _duration = duration;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _start = dict[@"start"]; 
        _duration = dict[@"duration"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_start != nil) dict[@"start"] = _start ;
        if(_duration != nil) dict[@"duration"] = _duration ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

