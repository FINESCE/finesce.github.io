#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGPrice_location_data : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* name;  

@property(nonatomic) NSString* location_id;  

@property(nonatomic) NSString* measurement_type;  

@property(nonatomic) NSString* value_id;  

- (id) _id: (NSString*) _id
     name: (NSString*) name
     location_id: (NSString*) location_id
     measurement_type: (NSString*) measurement_type
     value_id: (NSString*) value_id;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

