#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGRegional_energy_average_report : SWGObject

@property(nonatomic) NSArray* regional_energy_average;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) regional_energy_average: (NSArray*) regional_energy_average
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

