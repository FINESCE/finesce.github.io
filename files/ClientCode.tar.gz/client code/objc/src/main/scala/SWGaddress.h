#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGAddress : SWGObject

@property(nonatomic) NSString* street_name;  

@property(nonatomic) NSNumber* number;  

@property(nonatomic) NSString* city;  

@property(nonatomic) NSString* province;  

@property(nonatomic) NSNumber* zip_code;  

@property(nonatomic) NSString* country;  

- (id) street_name: (NSString*) street_name
     number: (NSNumber*) number
     city: (NSString*) city
     province: (NSString*) province
     zip_code: (NSNumber*) zip_code
     country: (NSString*) country;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

