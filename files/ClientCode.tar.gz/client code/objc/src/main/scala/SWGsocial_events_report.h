#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGSocial_events_report : SWGObject

@property(nonatomic) NSArray* events;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) events: (NSArray*) events
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

