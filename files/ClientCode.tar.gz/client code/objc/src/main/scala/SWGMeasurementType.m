#import "SWGDate.h"
#import "SWGMeasurementType.h"

@implementation SWGMeasurementType

-(id)_id: (NSString*) _id
    name: (NSString*) name
    description: (NSString*) description
    type: (NSString*) type
    unit: (NSString*) unit
{
  __id = _id;
  _name = name;
  _description = description;
  _type = type;
  _unit = unit;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _name = dict[@"name"]; 
        _description = dict[@"description"]; 
        _type = dict[@"type"]; 
        _unit = dict[@"unit"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_name != nil) dict[@"name"] = _name ;
        if(_description != nil) dict[@"description"] = _description ;
        if(_type != nil) dict[@"type"] = _type ;
        if(_unit != nil) dict[@"unit"] = _unit ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

