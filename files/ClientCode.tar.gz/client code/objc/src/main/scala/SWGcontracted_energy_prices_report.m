#import "SWGDate.h"
#import "SWGContracted_energy_prices_report.h"

@implementation SWGContracted_energy_prices_report

-(id)contracted_energy_cost: (NSArray*) contracted_energy_cost
    metadata: (SWGMetadata*) metadata
{
  _contracted_energy_cost = contracted_energy_cost;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id contracted_energy_cost_dict = dict[@"contracted_energy_cost"];
        if([contracted_energy_cost_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)contracted_energy_cost_dict count]];

            if([(NSArray*)contracted_energy_cost_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)contracted_energy_cost_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _contracted_energy_cost = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _contracted_energy_cost = [[NSArray alloc] init];
            }
        }
        else {
            _contracted_energy_cost = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_contracted_energy_cost != nil){
        if([_contracted_energy_cost isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *contracted_energy_cost in (NSArray*)_contracted_energy_cost) {
                [array addObject:[(SWGObject*)contracted_energy_cost asDictionary]];
            }
            dict[@"contracted_energy_cost"] = array;
        }
        else if(_contracted_energy_cost && [_contracted_energy_cost isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_contracted_energy_cost toString];
            if(dateString){
                dict[@"contracted_energy_cost"] = dateString;
            }
        }
        else {
        if(_contracted_energy_cost != nil) dict[@"contracted_energy_cost"] = [(SWGObject*)_contracted_energy_cost asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

