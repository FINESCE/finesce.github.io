#import "SWGDate.h"
#import "SWGPrice_location_data_value.h"

@implementation SWGPrice_location_data_value

-(id)_id: (NSString*) _id
    time: (NSString*) time
    value: (NSString*) value
{
  __id = _id;
  _time = time;
  _value = value;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _time = dict[@"time"]; 
        _value = dict[@"value"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_time != nil) dict[@"time"] = _time ;
        if(_value != nil) dict[@"value"] = _value ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

