#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGAuth_response : SWGObject

@property(nonatomic) NSString* expires;  

@property(nonatomic) NSString* role;  

@property(nonatomic) NSString* token;  

@property(nonatomic) NSString* refresh_token;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) expires: (NSString*) expires
     role: (NSString*) role
     token: (NSString*) token
     refresh_token: (NSString*) refresh_token
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

