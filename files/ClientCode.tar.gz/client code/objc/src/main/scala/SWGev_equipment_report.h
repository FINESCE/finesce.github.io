#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGEv_equipment_report : SWGObject

@property(nonatomic) NSArray* evses;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) evses: (NSArray*) evses
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

