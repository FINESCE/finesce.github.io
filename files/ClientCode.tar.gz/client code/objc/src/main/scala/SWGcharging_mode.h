#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGCharging_mode : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* name;  

@property(nonatomic) NSNumber* power;  

- (id) _id: (NSString*) _id
     name: (NSString*) name
     power: (NSNumber*) power;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

