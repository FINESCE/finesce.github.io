#import "SWGDate.h"
#import "SWGIncentive_plan.h"

@implementation SWGIncentive_plan

-(id)_id: (NSString*) _id
    time: (NSString*) time
    customer_id: (NSString*) customer_id
    meter_id: (NSString*) meter_id
    profile_object_name: (NSString*) profile_object_name
    irp_id: (NSString*) irp_id
    actions: (NSArray*) actions
    der_cost: (NSNumber*) der_cost
    primary_energy_cost: (NSNumber*) primary_energy_cost
    energy_cost: (NSNumber*) energy_cost
    state: (NSString*) state
    retailer_notes: (NSString*) retailer_notes
    market_regulator_notes: (NSString*) market_regulator_notes
    author: (NSString*) author
    author_email: (NSString*) author_email
{
  __id = _id;
  _time = time;
  _customer_id = customer_id;
  _meter_id = meter_id;
  _profile_object_name = profile_object_name;
  _irp_id = irp_id;
  _actions = actions;
  _der_cost = der_cost;
  _primary_energy_cost = primary_energy_cost;
  _energy_cost = energy_cost;
  _state = state;
  _retailer_notes = retailer_notes;
  _market_regulator_notes = market_regulator_notes;
  _author = author;
  _author_email = author_email;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _time = dict[@"time"]; 
        _customer_id = dict[@"customer_id"]; 
        _meter_id = dict[@"meter_id"]; 
        _profile_object_name = dict[@"profile_object_name"]; 
        _irp_id = dict[@"irp_id"]; 
        id actions_dict = dict[@"actions"];
        if([actions_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)actions_dict count]];

            if([(NSArray*)actions_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)actions_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _actions = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _actions = [[NSArray alloc] init];
            }
        }
        else {
            _actions = [[NSArray alloc] init];
        }
        _der_cost = dict[@"der_cost"]; 
        _primary_energy_cost = dict[@"primary_energy_cost"]; 
        _energy_cost = dict[@"energy_cost"]; 
        _state = dict[@"state"]; 
        _retailer_notes = dict[@"retailer_notes"]; 
        _market_regulator_notes = dict[@"market_regulator_notes"]; 
        _author = dict[@"author"]; 
        _author_email = dict[@"author_email"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_time != nil) dict[@"time"] = _time ;
        if(_customer_id != nil) dict[@"customer_id"] = _customer_id ;
        if(_meter_id != nil) dict[@"meter_id"] = _meter_id ;
        if(_profile_object_name != nil) dict[@"profile_object_name"] = _profile_object_name ;
        if(_irp_id != nil) dict[@"irp_id"] = _irp_id ;
        if(_actions != nil){
        if([_actions isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *actions in (NSArray*)_actions) {
                [array addObject:[(SWGObject*)actions asDictionary]];
            }
            dict[@"actions"] = array;
        }
        else if(_actions && [_actions isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_actions toString];
            if(dateString){
                dict[@"actions"] = dateString;
            }
        }
        else {
        if(_actions != nil) dict[@"actions"] = [(SWGObject*)_actions asDictionary];
        }
    }
    if(_der_cost != nil) dict[@"der_cost"] = _der_cost ;
        if(_primary_energy_cost != nil) dict[@"primary_energy_cost"] = _primary_energy_cost ;
        if(_energy_cost != nil) dict[@"energy_cost"] = _energy_cost ;
        if(_state != nil) dict[@"state"] = _state ;
        if(_retailer_notes != nil) dict[@"retailer_notes"] = _retailer_notes ;
        if(_market_regulator_notes != nil) dict[@"market_regulator_notes"] = _market_regulator_notes ;
        if(_author != nil) dict[@"author"] = _author ;
        if(_author_email != nil) dict[@"author_email"] = _author_email ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

