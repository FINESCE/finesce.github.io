#import <Foundation/Foundation.h>
#import "SWGConnections.h"
#import "SWGAuth_response.h"
#import "SWGAuth_refresh.h"
#import "SWGTimeslots.h"
#import "SWGCharging_modes.h"
#import "SWGRegional_energy_average_report.h"
#import "SWGEv_equipment_report.h"
#import "SWGVehicles_report.h"
#import "SWGConnection_states_report.h"
#import "SWGEv_types_report.h"
#import "SWGAlgoweight_report.h"
#import "SWGAuth_request.h"
#import "SWGCharging_states_report.h"
#import "SWGRegional_energy_report.h"
#import "SWGRegion_report.h"



@interface SWGIrelandApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGIrelandApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 Allows a user to retrieve a collection of algoweights
 
 */
-(NSNumber*) getIrelandAlgoweightsWithCompletionBlock :(void (^)(SWGAlgoweight_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve an algoweights record, based on its ID. A valid {id} can be obtained by calling the /algoweights service.
 
 @param _id 
 */
-(NSNumber*) getIrelandAlgoweightsIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGAlgoweight_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of ev evse connections
 
 */
-(NSNumber*) getIrelandConnectionsWithCompletionBlock :(void (^)(SWGConnections* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve an ev evse connection, based on its ID. A valid {id} can be obtained by calling the /connections service.
 
 @param _id 
 */
-(NSNumber*) getIrelandConnectionsIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGConnections* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a charging mode associated with an ev evse connection. A valid {id} can be obtained by calling the /connections service.
 
 @param _id 
 */
-(NSNumber*) getIrelandConnectionsIdCharging_modeWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGCharging_modes* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve an ev evse connection state associated with an ev evse connection. A valid {id} can be obtained by calling the /connections service.
 
 @param _id 
 */
-(NSNumber*) getIrelandConnectionsIdConnection_stateWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGConnection_states_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of regional energy records
 
 */
-(NSNumber*) getIrelandEnergyRegionalWithCompletionBlock :(void (^)(SWGRegional_energy_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a regional energy record. A valid {id} can be obtained by calling the /energy/regional service.
 
 @param _id 
 */
-(NSNumber*) getIrelandEnergyRegionalIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGRegional_energy_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a region associated with a regional energy record. A valid {id} can be obtained by calling the /energy/regional service.
 
 @param _id 
 */
-(NSNumber*) getIrelandEnergyRegionalIdRegionWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGRegion_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a timeslot associated with a regional energy record. A valid {id} can be obtained by calling the /energy/regional service.
 
 @param _id 
 */
-(NSNumber*) getIrelandEnergyRegionalIdTimeslotWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGTimeslots* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of aggregated regional evse energy records
 
 */
-(NSNumber*) getIrelandEnergyRegionalAvgWithCompletionBlock :(void (^)(SWGRegional_energy_average_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve an aggregate regional evse energy record, based on its ID
 
 @param _id 
 */
-(NSNumber*) getIrelandEnergyRegionalAvgIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGRegional_energy_average_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of time slot records
 
 */
-(NSNumber*) getIrelandTimeslotsWithCompletionBlock :(void (^)(SWGTimeslots* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a time slot record, based on its ID. A valid {id} can be obtained by calling the /timeslots service.
 
 @param _id 
 */
-(NSNumber*) getIrelandTimeslotsIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGTimeslots* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of algorithm weight records associated with a time slot. A valid {id} can be obtained by calling the /timeslots service.
 
 @param _id 
 */
-(NSNumber*) getIrelandTimeslotsIdAlgoweightsWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGAlgoweight_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of charging state records associated with a time slot, based on its ID. A valid {id} can be obtained by calling the /timeslots service.
 
 @param _id 
 */
-(NSNumber*) getIrelandTimeslotsIdCharging_statesWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGCharging_states_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of aggregated regional evse energy records. A valid {id} can be obtained by calling the /timeslots service.
 
 @param _id 
 */
-(NSNumber*) getIrelandTimeslotsIdEnergyRegionalWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGRegional_energy_report* output, NSError* error))completionBlock;

/**

 Retrieve authentication tokens
 
 @param body 
 */
-(NSNumber*) postIrelandTokensWithCompletionBlock :(SWGAuth_request*) body 
        completionHandler : (void (^)(SWGAuth_response* output, NSError* error))completionBlock;

/**

 Refresh an authentication token
 
 @param body 
 */
-(NSNumber*) postIrelandTokensRefreshWithCompletionBlock :(SWGAuth_refresh*) body 
        completionHandler : (void (^)(SWGAuth_response* output, NSError* error))completionBlock;

/**

 Provides the list of vehicles available
 
 */
-(NSNumber*) getIrelandVehiclesWithCompletionBlock :(void (^)(SWGVehicles_report* output, NSError* error))completionBlock;

/**

 Provides information regarding a single vehicle. A valid {id} can be obtained by calling the /vehicles service.
 
 @param _id 
 */
-(NSNumber*) getIrelandVehiclesIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGVehicles_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of ev evse connections associated with an electric vehicle. A valid {id} can be obtained by calling the /vehicles service.
 
 @param _id 
 */
-(NSNumber*) getIrelandVehiclesIdConnectionsWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGConnections* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of ev evse connection states
 
 */
-(NSNumber*) getIrelandConnection_statesWithCompletionBlock :(void (^)(SWGConnection_states_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve an ev evse connection state record, based on its ID. A valid {id} can be obtained by calling the /connection_states service.
 
 @param _id 
 */
-(NSNumber*) getIrelandConnection_statesIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGConnection_states_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of electric vehicle supply equipment components
 
 */
-(NSNumber*) getIrelandSupply_equipmentWithCompletionBlock :(void (^)(SWGEv_equipment_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve an electric vehicle supply equipment component, based on its ID. A valid {id} can be obtained by calling the /supply_equipment service.
 
 @param _id 
 */
-(NSNumber*) getIrelandSupply_equipmentIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGEv_equipment_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of charging modes associated with an evse. A valid {id} can be obtained by calling the /supply_equipment service.
 
 @param _id 
 */
-(NSNumber*) getIrelandSupply_equipmentIdCharging_modesWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGCharging_modes* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of ev evse connections associated with an evse. A valid {id} can be obtained by calling the /supply_equipment service.
 
 @param _id 
 */
-(NSNumber*) getIrelandSupply_equipmentIdConnectionsWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGConnections* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of chargingmodes
 
 */
-(NSNumber*) getIrelandCharging_modesWithCompletionBlock :(void (^)(SWGCharging_modes* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a chargingmode based on an ID. A valid {id} can be obtained by calling the /charging_modes service.
 
 @param _id 
 */
-(NSNumber*) getIrelandCharging_modesIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGCharging_modes* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of evses associated with a charging mode. A valid {id} can be obtained by calling the /charging_modes service.
 
 @param _id 
 */
-(NSNumber*) getIrelandCharging_modesIdEvsesWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGEv_equipment_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of electric vehicle types associated with a charging mode. A valid {id} can be obtained by calling the /charging_modes service.
 
 @param _id 
 */
-(NSNumber*) getIrelandCharging_modesIdEvtypesWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGEv_types_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of chargingmodes
 
 */
-(NSNumber*) getIrelandCharging_statesWithCompletionBlock :(void (^)(SWGCharging_states_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a chargingmode based on an ID. A valid {id} can be obtained by calling the /charging_states service.
 
 @param _id 
 */
-(NSNumber*) getIrelandCharging_statesIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGCharging_states_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of electric vehicle types
 
 */
-(NSNumber*) getIrelandVehicle_typesWithCompletionBlock :(void (^)(SWGEv_types_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve an electric vehicle type record, based on its ID. A valid {id} can be obtained by calling the /vehicle_types service.
 
 @param _id 
 */
-(NSNumber*) getIrelandVehicle_typesIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGEv_types_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of electric vehicles associated with an electric vehicle type. A valid {id} can be obtained by calling the /vehicle_types service.
 
 @param _id 
 */
-(NSNumber*) getIrelandVehicle_typesIdVehiclesWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGVehicles_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of region records
 
 */
-(NSNumber*) getIrelandRegionsWithCompletionBlock :(void (^)(SWGRegion_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a region record, based on its ID. A valid {id} can be obtained by calling the /regions service.
 
 @param _id 
 */
-(NSNumber*) getIrelandRegionsIdWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGRegion_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of algorithm weight records associated with a region. A valid {id} can be obtained by calling the /regions service.
 
 @param _id 
 */
-(NSNumber*) getIrelandRegionsIdAlgoweightsWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGAlgoweight_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of aggregated regional evse energy records. A valid {id} can be obtained by calling the /regions service.
 
 @param _id 
 */
-(NSNumber*) getIrelandRegionsIdEnergyWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGRegional_energy_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of aggregate regional evse energy records associated with a region, based on its ID. A valid {id} can be obtained by calling the /regions service.
 
 @param _id 
 */
-(NSNumber*) getIrelandRegionsIdEnergyAvgWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGRegional_energy_average_report* output, NSError* error))completionBlock;

/**

 Allows a user to retrieve a collection of evse records associated with a region. A valid {id} can be obtained by calling the /regions service.
 
 @param _id 
 */
-(NSNumber*) getIrelandRegionsIdSupply_equipmentWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGEv_equipment_report* output, NSError* error))completionBlock;

@end
