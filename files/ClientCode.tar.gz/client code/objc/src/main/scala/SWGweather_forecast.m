#import "SWGDate.h"
#import "SWGWeather_forecast.h"

@implementation SWGWeather_forecast

-(id)weather_data: (NSArray*) weather_data
    metadata: (SWGMetadata*) metadata
{
  _weather_data = weather_data;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id weather_data_dict = dict[@"weather_data"];
        if([weather_data_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)weather_data_dict count]];

            if([(NSArray*)weather_data_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)weather_data_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _weather_data = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _weather_data = [[NSArray alloc] init];
            }
        }
        else {
            _weather_data = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_weather_data != nil){
        if([_weather_data isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *weather_data in (NSArray*)_weather_data) {
                [array addObject:[(SWGObject*)weather_data asDictionary]];
            }
            dict[@"weather_data"] = array;
        }
        else if(_weather_data && [_weather_data isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_weather_data toString];
            if(dateString){
                dict[@"weather_data"] = dateString;
            }
        }
        else {
        if(_weather_data != nil) dict[@"weather_data"] = [(SWGObject*)_weather_data asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

