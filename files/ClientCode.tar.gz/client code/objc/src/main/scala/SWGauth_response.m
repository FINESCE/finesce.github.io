#import "SWGDate.h"
#import "SWGAuth_response.h"

@implementation SWGAuth_response

-(id)expires: (NSString*) expires
    role: (NSString*) role
    token: (NSString*) token
    refresh_token: (NSString*) refresh_token
    metadata: (SWGMetadata*) metadata
{
  _expires = expires;
  _role = role;
  _token = token;
  _refresh_token = refresh_token;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _expires = dict[@"expires"]; 
        _role = dict[@"role"]; 
        _token = dict[@"token"]; 
        _refresh_token = dict[@"refresh_token"]; 
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_expires != nil) dict[@"expires"] = _expires ;
        if(_role != nil) dict[@"role"] = _role ;
        if(_token != nil) dict[@"token"] = _token ;
        if(_refresh_token != nil) dict[@"refresh_token"] = _refresh_token ;
        if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

