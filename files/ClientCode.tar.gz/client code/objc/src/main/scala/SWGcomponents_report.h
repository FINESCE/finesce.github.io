#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGProduction_components.h"
#import "SWGMetadata.h"
#import "SWGConsumption_components.h"


@interface SWGComponents_report : SWGObject

@property(nonatomic) SWGConsumption_components* consumption_components;  

@property(nonatomic) SWGProduction_components* production_components;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) consumption_components: (SWGConsumption_components*) consumption_components
     production_components: (SWGProduction_components*) production_components
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

