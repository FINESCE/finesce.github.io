#import "SWGDate.h"
#import "SWGEv_equipment_report.h"

@implementation SWGEv_equipment_report

-(id)evses: (NSArray*) evses
    metadata: (SWGMetadata*) metadata
{
  _evses = evses;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id evses_dict = dict[@"evses"];
        if([evses_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)evses_dict count]];

            if([(NSArray*)evses_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)evses_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _evses = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _evses = [[NSArray alloc] init];
            }
        }
        else {
            _evses = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_evses != nil){
        if([_evses isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *evses in (NSArray*)_evses) {
                [array addObject:[(SWGObject*)evses asDictionary]];
            }
            dict[@"evses"] = array;
        }
        else if(_evses && [_evses isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_evses toString];
            if(dateString){
                dict[@"evses"] = dateString;
            }
        }
        else {
        if(_evses != nil) dict[@"evses"] = [(SWGObject*)_evses asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

