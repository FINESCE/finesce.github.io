#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGComponent : SWGObject

@property(nonatomic) NSString* access;  

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* url;  

- (id) access: (NSString*) access
     _id: (NSString*) _id
     url: (NSString*) url;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

