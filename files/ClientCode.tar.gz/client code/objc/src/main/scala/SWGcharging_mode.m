#import "SWGDate.h"
#import "SWGCharging_mode.h"

@implementation SWGCharging_mode

-(id)_id: (NSString*) _id
    name: (NSString*) name
    power: (NSNumber*) power
{
  __id = _id;
  _name = name;
  _power = power;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _name = dict[@"name"]; 
        _power = dict[@"power"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_name != nil) dict[@"name"] = _name ;
        if(_power != nil) dict[@"power"] = _power ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

