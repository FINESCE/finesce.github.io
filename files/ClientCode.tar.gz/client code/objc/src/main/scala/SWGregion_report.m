#import "SWGDate.h"
#import "SWGRegion_report.h"

@implementation SWGRegion_report

-(id)regions: (NSArray*) regions
    metadata: (SWGMetadata*) metadata
{
  _regions = regions;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id regions_dict = dict[@"regions"];
        if([regions_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)regions_dict count]];

            if([(NSArray*)regions_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)regions_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _regions = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _regions = [[NSArray alloc] init];
            }
        }
        else {
            _regions = [[NSArray alloc] init];
        }
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_regions != nil){
        if([_regions isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *regions in (NSArray*)_regions) {
                [array addObject:[(SWGObject*)regions asDictionary]];
            }
            dict[@"regions"] = array;
        }
        else if(_regions && [_regions isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_regions toString];
            if(dateString){
                dict[@"regions"] = dateString;
            }
        }
        else {
        if(_regions != nil) dict[@"regions"] = [(SWGObject*)_regions asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

