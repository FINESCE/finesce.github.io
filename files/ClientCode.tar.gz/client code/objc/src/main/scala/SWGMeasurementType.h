#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGMeasurementType : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* name;  

@property(nonatomic) NSString* description;  

@property(nonatomic) NSString* type;  

@property(nonatomic) NSString* unit;  

- (id) _id: (NSString*) _id
     name: (NSString*) name
     description: (NSString*) description
     type: (NSString*) type
     unit: (NSString*) unit;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

