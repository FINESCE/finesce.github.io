#import "SWGDate.h"
#import "SWGData.h"

@implementation SWGData

-(id)date: (NSString*) date
    url: (NSString*) url
{
  _date = date;
  _url = url;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _date = dict[@"date"]; 
        _url = dict[@"url"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_date != nil) dict[@"date"] = _date ;
        if(_url != nil) dict[@"url"] = _url ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

