#import "SWGDate.h"
#import "SWGValue.h"

@implementation SWGValue

-(id)_id: (NSString*) _id
    datetime: (NSString*) datetime
    value: (SWGT*) value
{
  __id = _id;
  _datetime = datetime;
  _value = value;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _datetime = dict[@"datetime"]; 
        id value_dict = dict[@"value"];
        if(value_dict != nil)
            _value = [[SWGT alloc]initWithValues:value_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_datetime != nil) dict[@"datetime"] = _datetime ;
        if(_value != nil){
        if([_value isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGT *value in (NSArray*)_value) {
                [array addObject:[(SWGObject*)value asDictionary]];
            }
            dict[@"value"] = array;
        }
        else if(_value && [_value isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_value toString];
            if(dateString){
                dict[@"value"] = dateString;
            }
        }
        else {
        if(_value != nil) dict[@"value"] = [(SWGObject*)_value asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

