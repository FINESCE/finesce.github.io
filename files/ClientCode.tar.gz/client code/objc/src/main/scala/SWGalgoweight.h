#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGAlgoweight : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* renewables;  

@property(nonatomic) NSString* interconnect;  

@property(nonatomic) NSString* specific;  

@property(nonatomic) NSString* timeslot_id;  

@property(nonatomic) NSString* region_id;  

- (id) _id: (NSString*) _id
     renewables: (NSString*) renewables
     interconnect: (NSString*) interconnect
     specific: (NSString*) specific
     timeslot_id: (NSString*) timeslot_id
     region_id: (NSString*) region_id;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

