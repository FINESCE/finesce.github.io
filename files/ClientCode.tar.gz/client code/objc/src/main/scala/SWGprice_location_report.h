#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGPrice_location_report : SWGObject

@property(nonatomic) NSArray* price_locations;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) price_locations: (NSArray*) price_locations
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

