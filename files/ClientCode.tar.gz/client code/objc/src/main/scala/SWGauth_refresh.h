#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGAuth_refresh : SWGObject

@property(nonatomic) NSString* refresh_token;  

- (id) refresh_token: (NSString*) refresh_token;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

