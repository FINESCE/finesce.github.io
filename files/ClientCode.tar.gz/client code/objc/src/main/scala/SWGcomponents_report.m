#import "SWGDate.h"
#import "SWGComponents_report.h"

@implementation SWGComponents_report

-(id)consumption_components: (SWGConsumption_components*) consumption_components
    production_components: (SWGProduction_components*) production_components
    metadata: (SWGMetadata*) metadata
{
  _consumption_components = consumption_components;
  _production_components = production_components;
  _metadata = metadata;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id consumption_components_dict = dict[@"consumption_components"];
        if(consumption_components_dict != nil)
            _consumption_components = [[SWGConsumption_components alloc]initWithValues:consumption_components_dict];
        id production_components_dict = dict[@"production_components"];
        if(production_components_dict != nil)
            _production_components = [[SWGProduction_components alloc]initWithValues:production_components_dict];
        id metadata_dict = dict[@"metadata"];
        if(metadata_dict != nil)
            _metadata = [[SWGMetadata alloc]initWithValues:metadata_dict];
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_consumption_components != nil){
        if([_consumption_components isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGConsumption_components *consumption_components in (NSArray*)_consumption_components) {
                [array addObject:[(SWGObject*)consumption_components asDictionary]];
            }
            dict[@"consumption_components"] = array;
        }
        else if(_consumption_components && [_consumption_components isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_consumption_components toString];
            if(dateString){
                dict[@"consumption_components"] = dateString;
            }
        }
        else {
        if(_consumption_components != nil) dict[@"consumption_components"] = [(SWGObject*)_consumption_components asDictionary];
        }
    }
    if(_production_components != nil){
        if([_production_components isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGProduction_components *production_components in (NSArray*)_production_components) {
                [array addObject:[(SWGObject*)production_components asDictionary]];
            }
            dict[@"production_components"] = array;
        }
        else if(_production_components && [_production_components isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_production_components toString];
            if(dateString){
                dict[@"production_components"] = dateString;
            }
        }
        else {
        if(_production_components != nil) dict[@"production_components"] = [(SWGObject*)_production_components asDictionary];
        }
    }
    if(_metadata != nil){
        if([_metadata isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( SWGMetadata *metadata in (NSArray*)_metadata) {
                [array addObject:[(SWGObject*)metadata asDictionary]];
            }
            dict[@"metadata"] = array;
        }
        else if(_metadata && [_metadata isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_metadata toString];
            if(dateString){
                dict[@"metadata"] = dateString;
            }
        }
        else {
        if(_metadata != nil) dict[@"metadata"] = [(SWGObject*)_metadata asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

