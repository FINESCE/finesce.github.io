#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGEv_equipment : SWGObject

@property(nonatomic) NSString* _id;  

@property(nonatomic) NSString* manufacturer;  

@property(nonatomic) NSString* model;  

@property(nonatomic) NSString* hw_version;  

@property(nonatomic) NSString* fw_version;  

@property(nonatomic) NSString* region;  

- (id) _id: (NSString*) _id
     manufacturer: (NSString*) manufacturer
     model: (NSString*) model
     hw_version: (NSString*) hw_version
     fw_version: (NSString*) fw_version
     region: (NSString*) region;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

