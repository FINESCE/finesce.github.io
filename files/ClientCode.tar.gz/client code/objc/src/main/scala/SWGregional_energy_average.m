#import "SWGDate.h"
#import "SWGRegional_energy_average.h"

@implementation SWGRegional_energy_average

-(id)_id: (NSString*) _id
    max_possible_energy: (NSNumber*) max_possible_energy
    current_energy: (NSNumber*) current_energy
    region_id: (NSString*) region_id
{
  __id = _id;
  _max_possible_energy = max_possible_energy;
  _current_energy = current_energy;
  _region_id = region_id;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _max_possible_energy = dict[@"max_possible_energy"]; 
        _current_energy = dict[@"current_energy"]; 
        _region_id = dict[@"region_id"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_max_possible_energy != nil) dict[@"max_possible_energy"] = _max_possible_energy ;
        if(_current_energy != nil) dict[@"current_energy"] = _current_energy ;
        if(_region_id != nil) dict[@"region_id"] = _region_id ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

