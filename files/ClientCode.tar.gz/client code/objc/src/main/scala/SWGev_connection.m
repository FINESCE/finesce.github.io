#import "SWGDate.h"
#import "SWGEv_connection.h"

@implementation SWGEv_connection

-(id)_id: (NSString*) _id
    start: (NSString*) start
    energy_current: (NSNumber*) energy_current
    energy_previous: (NSNumber*) energy_previous
    duration: (NSNumber*) duration
    total_energy_per_connection: (NSNumber*) total_energy_per_connection
    total_energy: (NSNumber*) total_energy
    charging_mode_id: (NSString*) charging_mode_id
    ev_supply_equipment_id: (NSString*) ev_supply_equipment_id
    ev_supply_equipment_connection_state_id: (NSString*) ev_supply_equipment_connection_state_id
    ev_id: (NSString*) ev_id
{
  __id = _id;
  _start = start;
  _energy_current = energy_current;
  _energy_previous = energy_previous;
  _duration = duration;
  _total_energy_per_connection = total_energy_per_connection;
  _total_energy = total_energy;
  _charging_mode_id = charging_mode_id;
  _ev_supply_equipment_id = ev_supply_equipment_id;
  _ev_supply_equipment_connection_state_id = ev_supply_equipment_connection_state_id;
  _ev_id = ev_id;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _start = dict[@"start"]; 
        _energy_current = dict[@"energy_current"]; 
        _energy_previous = dict[@"energy_previous"]; 
        _duration = dict[@"duration"]; 
        _total_energy_per_connection = dict[@"total_energy_per_connection"]; 
        _total_energy = dict[@"total_energy"]; 
        _charging_mode_id = dict[@"charging_mode_id"]; 
        _ev_supply_equipment_id = dict[@"ev_supply_equipment_id"]; 
        _ev_supply_equipment_connection_state_id = dict[@"ev_supply_equipment_connection_state_id"]; 
        _ev_id = dict[@"ev_id"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_start != nil) dict[@"start"] = _start ;
        if(_energy_current != nil) dict[@"energy_current"] = _energy_current ;
        if(_energy_previous != nil) dict[@"energy_previous"] = _energy_previous ;
        if(_duration != nil) dict[@"duration"] = _duration ;
        if(_total_energy_per_connection != nil) dict[@"total_energy_per_connection"] = _total_energy_per_connection ;
        if(_total_energy != nil) dict[@"total_energy"] = _total_energy ;
        if(_charging_mode_id != nil) dict[@"charging_mode_id"] = _charging_mode_id ;
        if(_ev_supply_equipment_id != nil) dict[@"ev_supply_equipment_id"] = _ev_supply_equipment_id ;
        if(_ev_supply_equipment_connection_state_id != nil) dict[@"ev_supply_equipment_connection_state_id"] = _ev_supply_equipment_connection_state_id ;
        if(_ev_id != nil) dict[@"ev_id"] = _ev_id ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

