#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGMeasurement_types_report : SWGObject

@property(nonatomic) NSArray* values;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) values: (NSArray*) values
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

