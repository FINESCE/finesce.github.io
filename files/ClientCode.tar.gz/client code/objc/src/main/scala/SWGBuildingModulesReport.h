#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGBuildingModulesReport : SWGObject

@property(nonatomic) NSArray* modules;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) modules: (NSArray*) modules
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

