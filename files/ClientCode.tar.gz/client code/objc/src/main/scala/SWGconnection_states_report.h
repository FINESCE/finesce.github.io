#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGConnection_states_report : SWGObject

@property(nonatomic) NSArray* connection_states;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) connection_states: (NSArray*) connection_states
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

