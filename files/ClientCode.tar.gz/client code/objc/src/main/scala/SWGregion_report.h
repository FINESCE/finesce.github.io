#import <Foundation/Foundation.h>
#import "SWGObject.h"
#import "SWGMetadata.h"


@interface SWGRegion_report : SWGObject

@property(nonatomic) NSArray* regions;  

@property(nonatomic) SWGMetadata* metadata;  

- (id) regions: (NSArray*) regions
     metadata: (SWGMetadata*) metadata;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

