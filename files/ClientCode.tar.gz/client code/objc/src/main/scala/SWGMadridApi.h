#import <Foundation/Foundation.h>
#import "SWGWeather_descriptors.h"
#import "SWGWeather_forecast.h"
#import "SWGBuildingZonesReport.h"
#import "SWGBuildingModulesReport.h"
#import "SWGMeasurements_report.h"



@interface SWGMadridApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGMadridApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 Provides measurements regarding the total power generated/consumed (mixed) from a module of a building. Currently, 'inverter' is the only module supported. 'Madrid' is the only trial site offering this service.
 
 @param module_id 
 @param building_id 
 @param date 
 */
-(NSNumber*) getMadridPowerMixedModulesModule_idBuilding_idDateWithCompletionBlock :(NSString*) module_id 
        building_id:(NSString*) building_id 
        date:(NSString*) date 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Provides measurements regarding the power generated from a module of a building. Currently, 'pv' is the only module supported. 'Madrid' is the only trial site offering this service.
 
 @param module_id 
 @param building_id 
 @param date 
 */
-(NSNumber*) getMadridPowerSupplyModulesModule_idBuilding_idDateWithCompletionBlock :(NSString*) module_id 
        building_id:(NSString*) building_id 
        date:(NSString*) date 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Provides weather reports for a specific timeperiod in the area of Madrid, considering a single weather descriptor (see /{version}/{trial}/weather/available_descriptors for the supported descriptor. 'Madrid' is the only trial site offering this service.
 
 @param descriptor 
 @param from 
 @param to 
 @param number_of_measurements 
 */
-(NSNumber*) getMadridWeatherDescriptorFromToNumber_of_measurementsWithCompletionBlock :(NSString*) descriptor 
        from:(NSString*) from 
        to:(NSString*) to 
        number_of_measurements:(NSString*) number_of_measurements 
        completionHandler : (void (^)(SWGWeather_forecast* output, NSError* error))completionBlock;

/**

 Provides information regarding the available forecast descriptors of the trial infrastructure. 'Madrid' is the only trial site offering this service.
 
 */
-(NSNumber*) getMadridWeatherAvailable_descriptorsWithCompletionBlock :(void (^)(SWGWeather_descriptors* output, NSError* error))completionBlock;

/**

 Provides the provides a list of devices or modules which status can be monitored by the Building Control Center.
 
 @param _id 
 */
-(NSNumber*) getMadridBuildingsIdModulesWithCompletionBlock :(NSString*) _id 
        completionHandler : (void (^)(SWGBuildingModulesReport* output, NSError* error))completionBlock;

/**

 Provides information about the status of a specific building module. The available building modules may be retrieved via the /{version}/{trial}/buildings/{id}/modules service. 'Madrid' is the only trial site offering this service.
 
 @param _id 
 @param module_id 
 @param date 
 */
-(NSNumber*) getMadridBuildingsIdModulesModule_idStatusDateWithCompletionBlock :(NSString*) _id 
        module_id:(NSString*) module_id 
        date:(NSString*) date 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

/**

 Provides information regarding the available zones of a specific building at a date. 'Madrid' is the only trial site offering this service.
 
 @param _id 
 @param date 
 */
-(NSNumber*) getMadridBuildingsIdZonesDateWithCompletionBlock :(NSString*) _id 
        date:(NSString*) date 
        completionHandler : (void (^)(SWGBuildingZonesReport* output, NSError* error))completionBlock;

/**

 Provides measurements of a certain type of a building zone. Valid {zone_id} values can be retrieved by invoking the /{version}/{trial}/buildings/{id}/zones/{date} service. Valid measurement types are PowerDemandGrid, EnergyConsumptionGrid, Temperature, RelativeHumidity, BatteryLevel. 'Madrid' is the only trial site offering this service.
 
 @param _id 
 @param zone_id 
 @param measurement_type 
 @param date 
 */
-(NSNumber*) getMadridBuildingsIdZonesZone_idMeasurement_typeDateWithCompletionBlock :(NSString*) _id 
        zone_id:(NSString*) zone_id 
        measurement_type:(NSString*) measurement_type 
        date:(NSString*) date 
        completionHandler : (void (^)(SWGMeasurements_report* output, NSError* error))completionBlock;

@end
