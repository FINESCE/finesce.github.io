#import "SWGDate.h"
#import "SWGPrice_location.h"

@implementation SWGPrice_location

-(id)_id: (NSString*) _id
    name: (NSString*) name
    postcode: (NSString*) postcode
    description: (NSString*) description
    url: (NSString*) url
    price_region: (NSString*) price_region
    latitude: (NSString*) latitude
    longitude: (NSString*) longitude
    timezome: (NSString*) timezome
{
  __id = _id;
  _name = name;
  _postcode = postcode;
  _description = description;
  _url = url;
  _price_region = price_region;
  _latitude = latitude;
  _longitude = longitude;
  _timezome = timezome;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        __id = dict[@"id"]; 
        _name = dict[@"name"]; 
        _postcode = dict[@"postcode"]; 
        _description = dict[@"description"]; 
        _url = dict[@"url"]; 
        _price_region = dict[@"price_region"]; 
        _latitude = dict[@"latitude"]; 
        _longitude = dict[@"longitude"]; 
        _timezome = dict[@"timezome"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(__id != nil) dict[@"id"] = __id ;
        if(_name != nil) dict[@"name"] = _name ;
        if(_postcode != nil) dict[@"postcode"] = _postcode ;
        if(_description != nil) dict[@"description"] = _description ;
        if(_url != nil) dict[@"url"] = _url ;
        if(_price_region != nil) dict[@"price_region"] = _price_region ;
        if(_latitude != nil) dict[@"latitude"] = _latitude ;
        if(_longitude != nil) dict[@"longitude"] = _longitude ;
        if(_timezome != nil) dict[@"timezome"] = _timezome ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

