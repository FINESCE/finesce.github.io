#import "SWGDate.h"
#import "SWGPrice.h"

@implementation SWGPrice

-(id)currency: (NSString*) currency
    locationName: (NSString*) locationName
    electricityPrice: (NSString*) electricityPrice
    heatingPrice: (NSString*) heatingPrice
    heatingOffset: (NSString*) heatingOffset
    startTime: (NSString*) startTime
    endTime: (NSString*) endTime
    identifier: (NSString*) identifier
{
  _currency = currency;
  _locationName = locationName;
  _electricityPrice = electricityPrice;
  _heatingPrice = heatingPrice;
  _heatingOffset = heatingOffset;
  _startTime = startTime;
  _endTime = endTime;
  _identifier = identifier;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _currency = dict[@"currency"]; 
        _locationName = dict[@"locationName"]; 
        _electricityPrice = dict[@"electricityPrice"]; 
        _heatingPrice = dict[@"heatingPrice"]; 
        _heatingOffset = dict[@"heatingOffset"]; 
        _startTime = dict[@"startTime"]; 
        _endTime = dict[@"endTime"]; 
        _identifier = dict[@"identifier"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_currency != nil) dict[@"currency"] = _currency ;
        if(_locationName != nil) dict[@"locationName"] = _locationName ;
        if(_electricityPrice != nil) dict[@"electricityPrice"] = _electricityPrice ;
        if(_heatingPrice != nil) dict[@"heatingPrice"] = _heatingPrice ;
        if(_heatingOffset != nil) dict[@"heatingOffset"] = _heatingOffset ;
        if(_startTime != nil) dict[@"startTime"] = _startTime ;
        if(_endTime != nil) dict[@"endTime"] = _endTime ;
        if(_identifier != nil) dict[@"identifier"] = _identifier ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

