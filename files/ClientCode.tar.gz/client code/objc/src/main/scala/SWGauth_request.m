#import "SWGDate.h"
#import "SWGAuth_request.h"

@implementation SWGAuth_request

-(id)authorization_id: (NSString*) authorization_id
    password: (NSString*) password
{
  _authorization_id = authorization_id;
  _password = password;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _authorization_id = dict[@"authorization_id"]; 
        _password = dict[@"password"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_authorization_id != nil) dict[@"authorization_id"] = _authorization_id ;
        if(_password != nil) dict[@"password"] = _password ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

