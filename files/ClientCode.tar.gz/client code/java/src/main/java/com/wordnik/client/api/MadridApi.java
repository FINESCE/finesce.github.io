package com.wordnik.client.api;

import com.wordnik.client.common.ApiException;
import com.wordnik.client.common.ApiInvoker;

import com.wordnik.client.model.Weather_descriptors;
import com.wordnik.client.model.Weather_forecast;
import com.wordnik.client.model.BuildingZonesReport;
import com.wordnik.client.model.BuildingModulesReport;
import com.wordnik.client.model.Measurements_report;
import com.sun.jersey.multipart.FormDataMultiPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.*;

public class MadridApi {
  String basePath = "http://192.168.1.80/finesce/api/v0.1";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }
  
  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }
  
  public String getBasePath() {
    return basePath;
  }

  /*
  */
  public measurements_report getMadridPowerMixedModulesModule_idBuilding_idDate (String module_id, String building_id, String date) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(module_id == null || building_id == null || date == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Madrid/power/mixed/modules/{module_id}/{building_id}/{date}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "module_id" + "\\}", apiInvoker.escapeString(module_id.toString())).replaceAll("\\{" + "building_id" + "\\}", apiInvoker.escapeString(building_id.toString())).replaceAll("\\{" + "date" + "\\}", apiInvoker.escapeString(date.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getMadridPowerSupplyModulesModule_idBuilding_idDate (String module_id, String building_id, String date) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(module_id == null || building_id == null || date == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Madrid/power/supply/modules/{module_id}/{building_id}/{date}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "module_id" + "\\}", apiInvoker.escapeString(module_id.toString())).replaceAll("\\{" + "building_id" + "\\}", apiInvoker.escapeString(building_id.toString())).replaceAll("\\{" + "date" + "\\}", apiInvoker.escapeString(date.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public weather_forecast getMadridWeatherDescriptorFromToNumber_of_measurements (String descriptor, String from, String to, String number_of_measurements) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(descriptor == null || from == null || to == null || number_of_measurements == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Madrid/weather/{descriptor}/{from}/{to}/{number_of_measurements}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "descriptor" + "\\}", apiInvoker.escapeString(descriptor.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString())).replaceAll("\\{" + "number_of_measurements" + "\\}", apiInvoker.escapeString(number_of_measurements.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (weather_forecast) ApiInvoker.deserialize(response, "", weather_forecast.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public weather_descriptors getMadridWeatherAvailable_descriptors () throws ApiException {
    Object postBody = null;
    // create path and map variables
    String path = "/Madrid/weather/available_descriptors".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (weather_descriptors) ApiInvoker.deserialize(response, "", weather_descriptors.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public BuildingModulesReport getMadridBuildingsIdModules (String id) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(id == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Madrid/buildings/{id}/modules".replaceAll("\\{format\\}","json").replaceAll("\\{" + "id" + "\\}", apiInvoker.escapeString(id.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (BuildingModulesReport) ApiInvoker.deserialize(response, "", BuildingModulesReport.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getMadridBuildingsIdModulesModule_idStatusDate (String id, String module_id, String date) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(id == null || module_id == null || date == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Madrid/buildings/{id}/modules/{module_id}/status/{date}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "id" + "\\}", apiInvoker.escapeString(id.toString())).replaceAll("\\{" + "module_id" + "\\}", apiInvoker.escapeString(module_id.toString())).replaceAll("\\{" + "date" + "\\}", apiInvoker.escapeString(date.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public BuildingZonesReport getMadridBuildingsIdZonesDate (String id, String date) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(id == null || date == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Madrid/buildings/{id}/zones/{date}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "id" + "\\}", apiInvoker.escapeString(id.toString())).replaceAll("\\{" + "date" + "\\}", apiInvoker.escapeString(date.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (BuildingZonesReport) ApiInvoker.deserialize(response, "", BuildingZonesReport.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getMadridBuildingsIdZonesZone_idMeasurement_typeDate (String id, String zone_id, String measurement_type, String date) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(id == null || zone_id == null || measurement_type == null || date == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Madrid/buildings/{id}/zones/{zone_id}/{measurement_type}/{date}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "id" + "\\}", apiInvoker.escapeString(id.toString())).replaceAll("\\{" + "zone_id" + "\\}", apiInvoker.escapeString(zone_id.toString())).replaceAll("\\{" + "measurement_type" + "\\}", apiInvoker.escapeString(measurement_type.toString())).replaceAll("\\{" + "date" + "\\}", apiInvoker.escapeString(date.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  }

