package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.T;
import com.wordnik.client.model.Metadata;
public class Measurements_report {
  private T measurements = null;
  private List<Value> _value_list = new ArrayList<Value>();
  private Metadata metadata = null;
  public T getMeasurements() {
    return measurements;
  }
  public void setMeasurements(T measurements) {
    this.measurements = measurements;
  }

  public List<Value> get_value_list() {
    return _value_list;
  }
  public void set_value_list(List<Value> _value_list) {
    this._value_list = _value_list;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Measurements_report {\n");
    sb.append("  measurements: ").append(measurements).append("\n");
    sb.append("  _value_list: ").append(_value_list).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

