package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Charging_modes {
  private List<charging_mode> charging_modes = new ArrayList<charging_mode>();
  private Metadata metadata = null;
  public List<charging_mode> getCharging_modes() {
    return charging_modes;
  }
  public void setCharging_modes(List<charging_mode> charging_modes) {
    this.charging_modes = charging_modes;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Charging_modes {\n");
    sb.append("  charging_modes: ").append(charging_modes).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

