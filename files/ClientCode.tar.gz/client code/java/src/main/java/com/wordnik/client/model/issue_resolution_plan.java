package com.wordnik.client.model;

import java.util.*;
public class Issue_resolution_plan {
  private String time = null;
  private String sector = null;
  private String author = null;
  private String author_email = null;
  private String snapshot_filename = null;
  private String aggregator_notes = null;
  private String dso_notes = null;
  private List<action> action = new ArrayList<action>();
  private String id = null;
  private String state = null;
  public String getTime() {
    return time;
  }
  public void setTime(String time) {
    this.time = time;
  }

  public String getSector() {
    return sector;
  }
  public void setSector(String sector) {
    this.sector = sector;
  }

  public String getAuthor() {
    return author;
  }
  public void setAuthor(String author) {
    this.author = author;
  }

  public String getAuthor_email() {
    return author_email;
  }
  public void setAuthor_email(String author_email) {
    this.author_email = author_email;
  }

  public String getSnapshot_filename() {
    return snapshot_filename;
  }
  public void setSnapshot_filename(String snapshot_filename) {
    this.snapshot_filename = snapshot_filename;
  }

  public String getAggregator_notes() {
    return aggregator_notes;
  }
  public void setAggregator_notes(String aggregator_notes) {
    this.aggregator_notes = aggregator_notes;
  }

  public String getDso_notes() {
    return dso_notes;
  }
  public void setDso_notes(String dso_notes) {
    this.dso_notes = dso_notes;
  }

  public List<action> getAction() {
    return action;
  }
  public void setAction(List<action> action) {
    this.action = action;
  }

  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getState() {
    return state;
  }
  public void setState(String state) {
    this.state = state;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Issue_resolution_plan {\n");
    sb.append("  time: ").append(time).append("\n");
    sb.append("  sector: ").append(sector).append("\n");
    sb.append("  author: ").append(author).append("\n");
    sb.append("  author_email: ").append(author_email).append("\n");
    sb.append("  snapshot_filename: ").append(snapshot_filename).append("\n");
    sb.append("  aggregator_notes: ").append(aggregator_notes).append("\n");
    sb.append("  dso_notes: ").append(dso_notes).append("\n");
    sb.append("  action: ").append(action).append("\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  state: ").append(state).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

