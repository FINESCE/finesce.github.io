package com.wordnik.client.model;

public class Charging_mode {
  private String id = null;
  private String name = null;
  private Double power = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  public Double getPower() {
    return power;
  }
  public void setPower(Double power) {
    this.power = power;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Charging_mode {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  name: ").append(name).append("\n");
    sb.append("  power: ").append(power).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

