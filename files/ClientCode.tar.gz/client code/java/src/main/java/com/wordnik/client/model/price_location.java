package com.wordnik.client.model;

public class Price_location {
  private String id = null;
  private String name = null;
  private String postcode = null;
  private String description = null;
  private String url = null;
  private String price_region = null;
  private String latitude = null;
  private String longitude = null;
  private String timezome = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  public String getPostcode() {
    return postcode;
  }
  public void setPostcode(String postcode) {
    this.postcode = postcode;
  }

  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  public String getPrice_region() {
    return price_region;
  }
  public void setPrice_region(String price_region) {
    this.price_region = price_region;
  }

  public String getLatitude() {
    return latitude;
  }
  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getLongitude() {
    return longitude;
  }
  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

  public String getTimezome() {
    return timezome;
  }
  public void setTimezome(String timezome) {
    this.timezome = timezome;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Price_location {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  name: ").append(name).append("\n");
    sb.append("  postcode: ").append(postcode).append("\n");
    sb.append("  description: ").append(description).append("\n");
    sb.append("  url: ").append(url).append("\n");
    sb.append("  price_region: ").append(price_region).append("\n");
    sb.append("  latitude: ").append(latitude).append("\n");
    sb.append("  longitude: ").append(longitude).append("\n");
    sb.append("  timezome: ").append(timezome).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

