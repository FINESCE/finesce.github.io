package com.wordnik.client.model;

public class Ev_connection {
  private String id = null;
  private String start = null;
  private Double energy_current = null;
  private Double energy_previous = null;
  private Integer duration = null;
  private Double total_energy_per_connection = null;
  private Double total_energy = null;
  private String charging_mode_id = null;
  private String ev_supply_equipment_id = null;
  private String ev_supply_equipment_connection_state_id = null;
  private String ev_id = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getStart() {
    return start;
  }
  public void setStart(String start) {
    this.start = start;
  }

  public Double getEnergy_current() {
    return energy_current;
  }
  public void setEnergy_current(Double energy_current) {
    this.energy_current = energy_current;
  }

  public Double getEnergy_previous() {
    return energy_previous;
  }
  public void setEnergy_previous(Double energy_previous) {
    this.energy_previous = energy_previous;
  }

  public Integer getDuration() {
    return duration;
  }
  public void setDuration(Integer duration) {
    this.duration = duration;
  }

  public Double getTotal_energy_per_connection() {
    return total_energy_per_connection;
  }
  public void setTotal_energy_per_connection(Double total_energy_per_connection) {
    this.total_energy_per_connection = total_energy_per_connection;
  }

  public Double getTotal_energy() {
    return total_energy;
  }
  public void setTotal_energy(Double total_energy) {
    this.total_energy = total_energy;
  }

  public String getCharging_mode_id() {
    return charging_mode_id;
  }
  public void setCharging_mode_id(String charging_mode_id) {
    this.charging_mode_id = charging_mode_id;
  }

  public String getEv_supply_equipment_id() {
    return ev_supply_equipment_id;
  }
  public void setEv_supply_equipment_id(String ev_supply_equipment_id) {
    this.ev_supply_equipment_id = ev_supply_equipment_id;
  }

  public String getEv_supply_equipment_connection_state_id() {
    return ev_supply_equipment_connection_state_id;
  }
  public void setEv_supply_equipment_connection_state_id(String ev_supply_equipment_connection_state_id) {
    this.ev_supply_equipment_connection_state_id = ev_supply_equipment_connection_state_id;
  }

  public String getEv_id() {
    return ev_id;
  }
  public void setEv_id(String ev_id) {
    this.ev_id = ev_id;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Ev_connection {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  start: ").append(start).append("\n");
    sb.append("  energy_current: ").append(energy_current).append("\n");
    sb.append("  energy_previous: ").append(energy_previous).append("\n");
    sb.append("  duration: ").append(duration).append("\n");
    sb.append("  total_energy_per_connection: ").append(total_energy_per_connection).append("\n");
    sb.append("  total_energy: ").append(total_energy).append("\n");
    sb.append("  charging_mode_id: ").append(charging_mode_id).append("\n");
    sb.append("  ev_supply_equipment_id: ").append(ev_supply_equipment_id).append("\n");
    sb.append("  ev_supply_equipment_connection_state_id: ").append(ev_supply_equipment_connection_state_id).append("\n");
    sb.append("  ev_id: ").append(ev_id).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

