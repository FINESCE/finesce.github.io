package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Algoweight_report {
  private List<algoweight> algoweight_list = new ArrayList<algoweight>();
  private Metadata metadata = null;
  public List<algoweight> getAlgoweight_list() {
    return algoweight_list;
  }
  public void setAlgoweight_list(List<algoweight> algoweight_list) {
    this.algoweight_list = algoweight_list;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Algoweight_report {\n");
    sb.append("  algoweight_list: ").append(algoweight_list).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

