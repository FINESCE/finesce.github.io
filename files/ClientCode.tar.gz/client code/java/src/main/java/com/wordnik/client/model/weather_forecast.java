package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Weather_forecast {
  private List<measurements> weather_data = new ArrayList<measurements>();
  private Metadata metadata = null;
  public List<measurements> getWeather_data() {
    return weather_data;
  }
  public void setWeather_data(List<measurements> weather_data) {
    this.weather_data = weather_data;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Weather_forecast {\n");
    sb.append("  weather_data: ").append(weather_data).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

