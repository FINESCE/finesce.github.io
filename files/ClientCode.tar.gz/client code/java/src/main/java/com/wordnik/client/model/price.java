package com.wordnik.client.model;

public class Price {
  private String currency = null;
  private String locationName = null;
  private String electricityPrice = null;
  private String heatingPrice = null;
  private String heatingOffset = null;
  private String startTime = null;
  private String endTime = null;
  private String identifier = null;
  public String getCurrency() {
    return currency;
  }
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getLocationName() {
    return locationName;
  }
  public void setLocationName(String locationName) {
    this.locationName = locationName;
  }

  public String getElectricityPrice() {
    return electricityPrice;
  }
  public void setElectricityPrice(String electricityPrice) {
    this.electricityPrice = electricityPrice;
  }

  public String getHeatingPrice() {
    return heatingPrice;
  }
  public void setHeatingPrice(String heatingPrice) {
    this.heatingPrice = heatingPrice;
  }

  public String getHeatingOffset() {
    return heatingOffset;
  }
  public void setHeatingOffset(String heatingOffset) {
    this.heatingOffset = heatingOffset;
  }

  public String getStartTime() {
    return startTime;
  }
  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }

  public String getEndTime() {
    return endTime;
  }
  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }

  public String getIdentifier() {
    return identifier;
  }
  public void setIdentifier(String identifier) {
    this.identifier = identifier;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Price {\n");
    sb.append("  currency: ").append(currency).append("\n");
    sb.append("  locationName: ").append(locationName).append("\n");
    sb.append("  electricityPrice: ").append(electricityPrice).append("\n");
    sb.append("  heatingPrice: ").append(heatingPrice).append("\n");
    sb.append("  heatingOffset: ").append(heatingOffset).append("\n");
    sb.append("  startTime: ").append(startTime).append("\n");
    sb.append("  endTime: ").append(endTime).append("\n");
    sb.append("  identifier: ").append(identifier).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

