package com.wordnik.client.model;

public class Regional_energy {
  private String id = null;
  private Double generated_energy = null;
  private Double aggregated_energy = null;
  private Double requested_energy = null;
  private Double actual_energy = null;
  private Double forecasted_energy = null;
  private String region_id = null;
  private String timelslot_id = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public Double getGenerated_energy() {
    return generated_energy;
  }
  public void setGenerated_energy(Double generated_energy) {
    this.generated_energy = generated_energy;
  }

  public Double getAggregated_energy() {
    return aggregated_energy;
  }
  public void setAggregated_energy(Double aggregated_energy) {
    this.aggregated_energy = aggregated_energy;
  }

  public Double getRequested_energy() {
    return requested_energy;
  }
  public void setRequested_energy(Double requested_energy) {
    this.requested_energy = requested_energy;
  }

  public Double getActual_energy() {
    return actual_energy;
  }
  public void setActual_energy(Double actual_energy) {
    this.actual_energy = actual_energy;
  }

  public Double getForecasted_energy() {
    return forecasted_energy;
  }
  public void setForecasted_energy(Double forecasted_energy) {
    this.forecasted_energy = forecasted_energy;
  }

  public String getRegion_id() {
    return region_id;
  }
  public void setRegion_id(String region_id) {
    this.region_id = region_id;
  }

  public String getTimelslot_id() {
    return timelslot_id;
  }
  public void setTimelslot_id(String timelslot_id) {
    this.timelslot_id = timelslot_id;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Regional_energy {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  generated_energy: ").append(generated_energy).append("\n");
    sb.append("  aggregated_energy: ").append(aggregated_energy).append("\n");
    sb.append("  requested_energy: ").append(requested_energy).append("\n");
    sb.append("  actual_energy: ").append(actual_energy).append("\n");
    sb.append("  forecasted_energy: ").append(forecasted_energy).append("\n");
    sb.append("  region_id: ").append(region_id).append("\n");
    sb.append("  timelslot_id: ").append(timelslot_id).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

