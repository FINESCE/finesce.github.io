package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Contracted_energy_prices_report {
  private List<contracted_energy_prices> contracted_energy_cost = new ArrayList<contracted_energy_prices>();
  private Metadata metadata = null;
  public List<contracted_energy_prices> getContracted_energy_cost() {
    return contracted_energy_cost;
  }
  public void setContracted_energy_cost(List<contracted_energy_prices> contracted_energy_cost) {
    this.contracted_energy_cost = contracted_energy_cost;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Contracted_energy_prices_report {\n");
    sb.append("  contracted_energy_cost: ").append(contracted_energy_cost).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

