package com.wordnik.client.model;

import com.wordnik.client.model.Eu.finesce.api.generic.Measurement&lt;eu.finesce.api.measurements.types.EnergyStatusSingleton&gt;;
public class Machine_history {
  private String id = null;
  private String name = null;
  private String process = null;
  private String plc = null;
  private String monitor = null;
  private Integer resolution = null;
  private String res_unit = null;
  private Boolean is_cumulative = null;
  private eu.finesce.api.generic.Measurement<eu.finesce.api.measurements.types.EnergyStatusSingleton> measurements = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  public String getProcess() {
    return process;
  }
  public void setProcess(String process) {
    this.process = process;
  }

  public String getPlc() {
    return plc;
  }
  public void setPlc(String plc) {
    this.plc = plc;
  }

  public String getMonitor() {
    return monitor;
  }
  public void setMonitor(String monitor) {
    this.monitor = monitor;
  }

  public Integer getResolution() {
    return resolution;
  }
  public void setResolution(Integer resolution) {
    this.resolution = resolution;
  }

  public String getRes_unit() {
    return res_unit;
  }
  public void setRes_unit(String res_unit) {
    this.res_unit = res_unit;
  }

  public Boolean getIs_cumulative() {
    return is_cumulative;
  }
  public void setIs_cumulative(Boolean is_cumulative) {
    this.is_cumulative = is_cumulative;
  }

  public eu.finesce.api.generic.Measurement<eu.finesce.api.measurements.types.EnergyStatusSingleton> getMeasurements() {
    return measurements;
  }
  public void setMeasurements(eu.finesce.api.generic.Measurement<eu.finesce.api.measurements.types.EnergyStatusSingleton> measurements) {
    this.measurements = measurements;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Machine_history {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  name: ").append(name).append("\n");
    sb.append("  process: ").append(process).append("\n");
    sb.append("  plc: ").append(plc).append("\n");
    sb.append("  monitor: ").append(monitor).append("\n");
    sb.append("  resolution: ").append(resolution).append("\n");
    sb.append("  res_unit: ").append(res_unit).append("\n");
    sb.append("  is_cumulative: ").append(is_cumulative).append("\n");
    sb.append("  measurements: ").append(measurements).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

