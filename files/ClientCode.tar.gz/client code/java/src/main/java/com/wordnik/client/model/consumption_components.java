package com.wordnik.client.model;

import java.util.*;
public class Consumption_components {
  private List<Component> components = new ArrayList<Component>();
  public List<Component> getComponents() {
    return components;
  }
  public void setComponents(List<Component> components) {
    this.components = components;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Consumption_components {\n");
    sb.append("  components: ").append(components).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

