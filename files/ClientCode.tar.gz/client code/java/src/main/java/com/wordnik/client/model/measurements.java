package com.wordnik.client.model;

import com.wordnik.client.model.List[eu.finesce.api.generic.Value&lt;T&gt;];
public class Measurements {
  private List<eu.finesce.api.generic.Value<T>> values = null;
  private String start_time = null;
  private String end_time = null;
  private String type = null;
  private String identifier = null;
  public List<eu.finesce.api.generic.Value<T>> getValues() {
    return values;
  }
  public void setValues(List<eu.finesce.api.generic.Value<T>> values) {
    this.values = values;
  }

  public String getStart_time() {
    return start_time;
  }
  public void setStart_time(String start_time) {
    this.start_time = start_time;
  }

  public String getEnd_time() {
    return end_time;
  }
  public void setEnd_time(String end_time) {
    this.end_time = end_time;
  }

  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  public String getIdentifier() {
    return identifier;
  }
  public void setIdentifier(String identifier) {
    this.identifier = identifier;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Measurements {\n");
    sb.append("  values: ").append(values).append("\n");
    sb.append("  start_time: ").append(start_time).append("\n");
    sb.append("  end_time: ").append(end_time).append("\n");
    sb.append("  type: ").append(type).append("\n");
    sb.append("  identifier: ").append(identifier).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

