package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Ev_equipment_report {
  private List<ev_equipment> evses = new ArrayList<ev_equipment>();
  private Metadata metadata = null;
  public List<ev_equipment> getEvses() {
    return evses;
  }
  public void setEvses(List<ev_equipment> evses) {
    this.evses = evses;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Ev_equipment_report {\n");
    sb.append("  evses: ").append(evses).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

