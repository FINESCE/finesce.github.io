package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Timeslots {
  private List<timeslot> list = new ArrayList<timeslot>();
  private Metadata metadata = null;
  public List<timeslot> getList() {
    return list;
  }
  public void setList(List<timeslot> list) {
    this.list = list;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Timeslots {\n");
    sb.append("  list: ").append(list).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

