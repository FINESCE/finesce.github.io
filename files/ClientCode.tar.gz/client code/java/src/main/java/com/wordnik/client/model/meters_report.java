package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Meters_report {
  private List<meter> meters = new ArrayList<meter>();
  private Metadata metadata = null;
  public List<meter> getMeters() {
    return meters;
  }
  public void setMeters(List<meter> meters) {
    this.meters = meters;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Meters_report {\n");
    sb.append("  meters: ").append(meters).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

