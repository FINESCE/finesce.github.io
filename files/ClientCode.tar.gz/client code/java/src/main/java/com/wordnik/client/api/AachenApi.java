package com.wordnik.client.api;

import com.wordnik.client.common.ApiException;
import com.wordnik.client.common.ApiInvoker;

import com.wordnik.client.model.Auth_response;
import com.wordnik.client.model.Auth_refresh;
import com.wordnik.client.model.Component_data_report;
import com.wordnik.client.model.Auth_request;
import com.wordnik.client.model.Components_report;
import com.wordnik.client.model.Machine_details;
import com.wordnik.client.model.Machines_report;
import com.wordnik.client.model.Measurements_report;
import com.sun.jersey.multipart.FormDataMultiPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.*;

public class AachenApi {
  String basePath = "http://192.168.1.80/finesce/api/v0.1";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }
  
  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }
  
  public String getBasePath() {
    return basePath;
  }

  /*
  */
  public auth_response postAachenTokens (auth_request body) throws ApiException {
    Object postBody = body;
    // verify required params are set
    if(body == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Aachen/tokens".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (auth_response) ApiInvoker.deserialize(response, "", auth_response.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public auth_response postAachenTokensRefresh (auth_refresh body) throws ApiException {
    Object postBody = body;
    // verify required params are set
    if(body == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Aachen/tokens/refresh".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (auth_response) ApiInvoker.deserialize(response, "", auth_response.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public machines_report getAachenFactoryEquipmentMachines () throws ApiException {
    Object postBody = null;
    // create path and map variables
    String path = "/Aachen/factory/equipment/machines".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (machines_report) ApiInvoker.deserialize(response, "", machines_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public machine_details getAachenFactoryEquipmentMachinesMachine_id (String machine_id) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(machine_id == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Aachen/factory/equipment/machines/{machine_id}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "machine_id" + "\\}", apiInvoker.escapeString(machine_id.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (machine_details) ApiInvoker.deserialize(response, "", machine_details.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public component_data_report getAachenVppComp_typeComp_idData (String comp_type, String comp_id) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(comp_type == null || comp_id == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Aachen/vpp/{comp_type}/{comp_id}/data".replaceAll("\\{format\\}","json").replaceAll("\\{" + "comp_type" + "\\}", apiInvoker.escapeString(comp_type.toString())).replaceAll("\\{" + "comp_id" + "\\}", apiInvoker.escapeString(comp_id.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (component_data_report) ApiInvoker.deserialize(response, "", component_data_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getAachenVppComp_typeComp_idMeasurementsDate (String comp_type, String comp_id, String date) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(comp_type == null || comp_id == null || date == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Aachen/vpp/{comp_type}/{comp_id}/measurements/{date}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "comp_type" + "\\}", apiInvoker.escapeString(comp_type.toString())).replaceAll("\\{" + "comp_id" + "\\}", apiInvoker.escapeString(comp_id.toString())).replaceAll("\\{" + "date" + "\\}", apiInvoker.escapeString(date.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getAachenVppComp_typeComp_idPredictionsDate (String comp_type, String comp_id, String date) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(comp_type == null || comp_id == null || date == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Aachen/vpp/{comp_type}/{comp_id}/predictions/{date}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "comp_type" + "\\}", apiInvoker.escapeString(comp_type.toString())).replaceAll("\\{" + "comp_id" + "\\}", apiInvoker.escapeString(comp_id.toString())).replaceAll("\\{" + "date" + "\\}", apiInvoker.escapeString(date.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public components_report getAachenVppComponents () throws ApiException {
    Object postBody = null;
    // create path and map variables
    String path = "/Aachen/vpp/components".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (components_report) ApiInvoker.deserialize(response, "", components_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  }

