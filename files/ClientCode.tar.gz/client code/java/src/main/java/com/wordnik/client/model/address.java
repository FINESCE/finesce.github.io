package com.wordnik.client.model;

public class Address {
  private String street_name = null;
  private Integer number = null;
  private String city = null;
  private String province = null;
  private Integer zip_code = null;
  private String country = null;
  public String getStreet_name() {
    return street_name;
  }
  public void setStreet_name(String street_name) {
    this.street_name = street_name;
  }

  public Integer getNumber() {
    return number;
  }
  public void setNumber(Integer number) {
    this.number = number;
  }

  public String getCity() {
    return city;
  }
  public void setCity(String city) {
    this.city = city;
  }

  public String getProvince() {
    return province;
  }
  public void setProvince(String province) {
    this.province = province;
  }

  public Integer getZip_code() {
    return zip_code;
  }
  public void setZip_code(Integer zip_code) {
    this.zip_code = zip_code;
  }

  public String getCountry() {
    return country;
  }
  public void setCountry(String country) {
    this.country = country;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Address {\n");
    sb.append("  street_name: ").append(street_name).append("\n");
    sb.append("  number: ").append(number).append("\n");
    sb.append("  city: ").append(city).append("\n");
    sb.append("  province: ").append(province).append("\n");
    sb.append("  zip_code: ").append(zip_code).append("\n");
    sb.append("  country: ").append(country).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

