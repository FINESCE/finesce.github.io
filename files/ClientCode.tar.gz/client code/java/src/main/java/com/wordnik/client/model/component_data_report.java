package com.wordnik.client.model;

import com.wordnik.client.model.Metadata;
import com.wordnik.client.model.Component_data_container;
public class Component_data_report {
  private component_data_container measurements = null;
  private component_data_container predictions = null;
  private Metadata metadata = null;
  public component_data_container getMeasurements() {
    return measurements;
  }
  public void setMeasurements(component_data_container measurements) {
    this.measurements = measurements;
  }

  public component_data_container getPredictions() {
    return predictions;
  }
  public void setPredictions(component_data_container predictions) {
    this.predictions = predictions;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Component_data_report {\n");
    sb.append("  measurements: ").append(measurements).append("\n");
    sb.append("  predictions: ").append(predictions).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

