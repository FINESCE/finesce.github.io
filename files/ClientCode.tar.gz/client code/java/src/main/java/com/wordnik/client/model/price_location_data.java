package com.wordnik.client.model;

public class Price_location_data {
  private String id = null;
  private String name = null;
  private String location_id = null;
  private String measurement_type = null;
  private String value_id = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  public String getLocation_id() {
    return location_id;
  }
  public void setLocation_id(String location_id) {
    this.location_id = location_id;
  }

  public String getMeasurement_type() {
    return measurement_type;
  }
  public void setMeasurement_type(String measurement_type) {
    this.measurement_type = measurement_type;
  }

  public String getValue_id() {
    return value_id;
  }
  public void setValue_id(String value_id) {
    this.value_id = value_id;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Price_location_data {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  name: ").append(name).append("\n");
    sb.append("  location_id: ").append(location_id).append("\n");
    sb.append("  measurement_type: ").append(measurement_type).append("\n");
    sb.append("  value_id: ").append(value_id).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

