package com.wordnik.client.model;

import com.wordnik.client.model.T;
public class Value {
  private String id = null;
  private String datetime = null;
  private T value = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getDatetime() {
    return datetime;
  }
  public void setDatetime(String datetime) {
    this.datetime = datetime;
  }

  public T getValue() {
    return value;
  }
  public void setValue(T value) {
    this.value = value;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Value {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  datetime: ").append(datetime).append("\n");
    sb.append("  value: ").append(value).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

