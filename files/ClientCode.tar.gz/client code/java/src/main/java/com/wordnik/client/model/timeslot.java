package com.wordnik.client.model;

public class Timeslot {
  private String id = null;
  private String start = null;
  private Integer duration = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getStart() {
    return start;
  }
  public void setStart(String start) {
    this.start = start;
  }

  public Integer getDuration() {
    return duration;
  }
  public void setDuration(Integer duration) {
    this.duration = duration;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Timeslot {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  start: ").append(start).append("\n");
    sb.append("  duration: ").append(duration).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

