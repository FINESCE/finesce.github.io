package com.wordnik.client.model;

import com.wordnik.client.model.Metadata;
public class Auth_response {
  private String expires = null;
  private String role = null;
  private String token = null;
  private String refresh_token = null;
  private Metadata metadata = null;
  public String getExpires() {
    return expires;
  }
  public void setExpires(String expires) {
    this.expires = expires;
  }

  public String getRole() {
    return role;
  }
  public void setRole(String role) {
    this.role = role;
  }

  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  public String getRefresh_token() {
    return refresh_token;
  }
  public void setRefresh_token(String refresh_token) {
    this.refresh_token = refresh_token;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Auth_response {\n");
    sb.append("  expires: ").append(expires).append("\n");
    sb.append("  role: ").append(role).append("\n");
    sb.append("  token: ").append(token).append("\n");
    sb.append("  refresh_token: ").append(refresh_token).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

