package com.wordnik.client.model;

import com.wordnik.client.model.Map[string,string];
public class Vehicle {
  private String id = null;
  private String type = null;
  private Map<string,string> measurement_points = null;
  private Map<string,string> related_entities_ids = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  public Map<string,string> getMeasurement_points() {
    return measurement_points;
  }
  public void setMeasurement_points(Map<string,string> measurement_points) {
    this.measurement_points = measurement_points;
  }

  public Map<string,string> getRelated_entities_ids() {
    return related_entities_ids;
  }
  public void setRelated_entities_ids(Map<string,string> related_entities_ids) {
    this.related_entities_ids = related_entities_ids;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Vehicle {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  type: ").append(type).append("\n");
    sb.append("  measurement_points: ").append(measurement_points).append("\n");
    sb.append("  related_entities_ids: ").append(related_entities_ids).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

