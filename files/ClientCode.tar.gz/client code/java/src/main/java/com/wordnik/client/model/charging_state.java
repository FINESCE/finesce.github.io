package com.wordnik.client.model;

public class Charging_state {
  private String id = null;
  private Boolean change_requested = null;
  private Boolean responded = null;
  private Boolean requested_state_is_on = null;
  private Boolean is_charging = null;
  private Boolean is_connected = null;
  private Boolean battery_full = null;
  private String ev_id = null;
  private String ev_supply_equipment_id = null;
  private String timeslot_id = null;
  private String charging_mode_id = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public Boolean getChange_requested() {
    return change_requested;
  }
  public void setChange_requested(Boolean change_requested) {
    this.change_requested = change_requested;
  }

  public Boolean getResponded() {
    return responded;
  }
  public void setResponded(Boolean responded) {
    this.responded = responded;
  }

  public Boolean getRequested_state_is_on() {
    return requested_state_is_on;
  }
  public void setRequested_state_is_on(Boolean requested_state_is_on) {
    this.requested_state_is_on = requested_state_is_on;
  }

  public Boolean getIs_charging() {
    return is_charging;
  }
  public void setIs_charging(Boolean is_charging) {
    this.is_charging = is_charging;
  }

  public Boolean getIs_connected() {
    return is_connected;
  }
  public void setIs_connected(Boolean is_connected) {
    this.is_connected = is_connected;
  }

  public Boolean getBattery_full() {
    return battery_full;
  }
  public void setBattery_full(Boolean battery_full) {
    this.battery_full = battery_full;
  }

  public String getEv_id() {
    return ev_id;
  }
  public void setEv_id(String ev_id) {
    this.ev_id = ev_id;
  }

  public String getEv_supply_equipment_id() {
    return ev_supply_equipment_id;
  }
  public void setEv_supply_equipment_id(String ev_supply_equipment_id) {
    this.ev_supply_equipment_id = ev_supply_equipment_id;
  }

  public String getTimeslot_id() {
    return timeslot_id;
  }
  public void setTimeslot_id(String timeslot_id) {
    this.timeslot_id = timeslot_id;
  }

  public String getCharging_mode_id() {
    return charging_mode_id;
  }
  public void setCharging_mode_id(String charging_mode_id) {
    this.charging_mode_id = charging_mode_id;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Charging_state {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  change_requested: ").append(change_requested).append("\n");
    sb.append("  responded: ").append(responded).append("\n");
    sb.append("  requested_state_is_on: ").append(requested_state_is_on).append("\n");
    sb.append("  is_charging: ").append(is_charging).append("\n");
    sb.append("  is_connected: ").append(is_connected).append("\n");
    sb.append("  battery_full: ").append(battery_full).append("\n");
    sb.append("  ev_id: ").append(ev_id).append("\n");
    sb.append("  ev_supply_equipment_id: ").append(ev_supply_equipment_id).append("\n");
    sb.append("  timeslot_id: ").append(timeslot_id).append("\n");
    sb.append("  charging_mode_id: ").append(charging_mode_id).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

