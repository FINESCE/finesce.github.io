package com.wordnik.client.model;

public class Auth_refresh {
  private String refresh_token = null;
  public String getRefresh_token() {
    return refresh_token;
  }
  public void setRefresh_token(String refresh_token) {
    this.refresh_token = refresh_token;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Auth_refresh {\n");
    sb.append("  refresh_token: ").append(refresh_token).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

