package com.wordnik.client.model;

import com.wordnik.client.model.Production_components;
import com.wordnik.client.model.Metadata;
import com.wordnik.client.model.Consumption_components;
public class Components_report {
  private consumption_components consumption_components = null;
  private production_components production_components = null;
  private Metadata metadata = null;
  public consumption_components getConsumption_components() {
    return consumption_components;
  }
  public void setConsumption_components(consumption_components consumption_components) {
    this.consumption_components = consumption_components;
  }

  public production_components getProduction_components() {
    return production_components;
  }
  public void setProduction_components(production_components production_components) {
    this.production_components = production_components;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Components_report {\n");
    sb.append("  consumption_components: ").append(consumption_components).append("\n");
    sb.append("  production_components: ").append(production_components).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

