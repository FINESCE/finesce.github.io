package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Connections {
  private List<ev_connection> list = new ArrayList<ev_connection>();
  private Metadata metadata = null;
  public List<ev_connection> getList() {
    return list;
  }
  public void setList(List<ev_connection> list) {
    this.list = list;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Connections {\n");
    sb.append("  list: ").append(list).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

