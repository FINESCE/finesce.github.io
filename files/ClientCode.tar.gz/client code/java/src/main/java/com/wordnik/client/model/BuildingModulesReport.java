package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class BuildingModulesReport {
  private List<String> modules = new ArrayList<String>();
  private Metadata metadata = null;
  public List<String> getModules() {
    return modules;
  }
  public void setModules(List<String> modules) {
    this.modules = modules;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuildingModulesReport {\n");
    sb.append("  modules: ").append(modules).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

