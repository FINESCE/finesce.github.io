package com.wordnik.client.model;

public class Regional_energy_average {
  private String id = null;
  private Double max_possible_energy = null;
  private Double current_energy = null;
  private String region_id = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public Double getMax_possible_energy() {
    return max_possible_energy;
  }
  public void setMax_possible_energy(Double max_possible_energy) {
    this.max_possible_energy = max_possible_energy;
  }

  public Double getCurrent_energy() {
    return current_energy;
  }
  public void setCurrent_energy(Double current_energy) {
    this.current_energy = current_energy;
  }

  public String getRegion_id() {
    return region_id;
  }
  public void setRegion_id(String region_id) {
    this.region_id = region_id;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Regional_energy_average {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  max_possible_energy: ").append(max_possible_energy).append("\n");
    sb.append("  current_energy: ").append(current_energy).append("\n");
    sb.append("  region_id: ").append(region_id).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

