package com.wordnik.client.model;

import java.util.*;
public class Incentive_plan {
  private String id = null;
  private String time = null;
  private String customer_id = null;
  private String meter_id = null;
  private String profile_object_name = null;
  private String irp_id = null;
  private List<IPAction> actions = new ArrayList<IPAction>();
  private Double der_cost = null;
  private Double primary_energy_cost = null;
  private Double energy_cost = null;
  private String state = null;
  private String retailer_notes = null;
  private String market_regulator_notes = null;
  private String author = null;
  private String author_email = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getTime() {
    return time;
  }
  public void setTime(String time) {
    this.time = time;
  }

  public String getCustomer_id() {
    return customer_id;
  }
  public void setCustomer_id(String customer_id) {
    this.customer_id = customer_id;
  }

  public String getMeter_id() {
    return meter_id;
  }
  public void setMeter_id(String meter_id) {
    this.meter_id = meter_id;
  }

  public String getProfile_object_name() {
    return profile_object_name;
  }
  public void setProfile_object_name(String profile_object_name) {
    this.profile_object_name = profile_object_name;
  }

  public String getIrp_id() {
    return irp_id;
  }
  public void setIrp_id(String irp_id) {
    this.irp_id = irp_id;
  }

  public List<IPAction> getActions() {
    return actions;
  }
  public void setActions(List<IPAction> actions) {
    this.actions = actions;
  }

  public Double getDer_cost() {
    return der_cost;
  }
  public void setDer_cost(Double der_cost) {
    this.der_cost = der_cost;
  }

  public Double getPrimary_energy_cost() {
    return primary_energy_cost;
  }
  public void setPrimary_energy_cost(Double primary_energy_cost) {
    this.primary_energy_cost = primary_energy_cost;
  }

  public Double getEnergy_cost() {
    return energy_cost;
  }
  public void setEnergy_cost(Double energy_cost) {
    this.energy_cost = energy_cost;
  }

  public String getState() {
    return state;
  }
  public void setState(String state) {
    this.state = state;
  }

  public String getRetailer_notes() {
    return retailer_notes;
  }
  public void setRetailer_notes(String retailer_notes) {
    this.retailer_notes = retailer_notes;
  }

  public String getMarket_regulator_notes() {
    return market_regulator_notes;
  }
  public void setMarket_regulator_notes(String market_regulator_notes) {
    this.market_regulator_notes = market_regulator_notes;
  }

  public String getAuthor() {
    return author;
  }
  public void setAuthor(String author) {
    this.author = author;
  }

  public String getAuthor_email() {
    return author_email;
  }
  public void setAuthor_email(String author_email) {
    this.author_email = author_email;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Incentive_plan {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  time: ").append(time).append("\n");
    sb.append("  customer_id: ").append(customer_id).append("\n");
    sb.append("  meter_id: ").append(meter_id).append("\n");
    sb.append("  profile_object_name: ").append(profile_object_name).append("\n");
    sb.append("  irp_id: ").append(irp_id).append("\n");
    sb.append("  actions: ").append(actions).append("\n");
    sb.append("  der_cost: ").append(der_cost).append("\n");
    sb.append("  primary_energy_cost: ").append(primary_energy_cost).append("\n");
    sb.append("  energy_cost: ").append(energy_cost).append("\n");
    sb.append("  state: ").append(state).append("\n");
    sb.append("  retailer_notes: ").append(retailer_notes).append("\n");
    sb.append("  market_regulator_notes: ").append(market_regulator_notes).append("\n");
    sb.append("  author: ").append(author).append("\n");
    sb.append("  author_email: ").append(author_email).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

