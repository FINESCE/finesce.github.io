package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Regional_energy_average_report {
  private List<regional_energy_average> regional_energy_average = new ArrayList<regional_energy_average>();
  private Metadata metadata = null;
  public List<regional_energy_average> getRegional_energy_average() {
    return regional_energy_average;
  }
  public void setRegional_energy_average(List<regional_energy_average> regional_energy_average) {
    this.regional_energy_average = regional_energy_average;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Regional_energy_average_report {\n");
    sb.append("  regional_energy_average: ").append(regional_energy_average).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

