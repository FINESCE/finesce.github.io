package com.wordnik.client.model;

import com.wordnik.client.model.Location;
public class Event {
  private location location = null;
  private String type = null;
  private String significance = null;
  private String eventTime = null;
  private String storeTime = null;
  public location getLocation() {
    return location;
  }
  public void setLocation(location location) {
    this.location = location;
  }

  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  public String getSignificance() {
    return significance;
  }
  public void setSignificance(String significance) {
    this.significance = significance;
  }

  public String getEventTime() {
    return eventTime;
  }
  public void setEventTime(String eventTime) {
    this.eventTime = eventTime;
  }

  public String getStoreTime() {
    return storeTime;
  }
  public void setStoreTime(String storeTime) {
    this.storeTime = storeTime;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Event {\n");
    sb.append("  location: ").append(location).append("\n");
    sb.append("  type: ").append(type).append("\n");
    sb.append("  significance: ").append(significance).append("\n");
    sb.append("  eventTime: ").append(eventTime).append("\n");
    sb.append("  storeTime: ").append(storeTime).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

