package com.wordnik.client.model;

import java.util.*;
public class Component_data_container {
  private List<data> data = new ArrayList<data>();
  public List<data> getData() {
    return data;
  }
  public void setData(List<data> data) {
    this.data = data;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Component_data_container {\n");
    sb.append("  data: ").append(data).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

