package com.wordnik.client.model;

public class Metadata {
  private String api_version = null;
  private String trial = null;
  private String created = null;
  private String updated = null;
  public String getApi_version() {
    return api_version;
  }
  public void setApi_version(String api_version) {
    this.api_version = api_version;
  }

  public String getTrial() {
    return trial;
  }
  public void setTrial(String trial) {
    this.trial = trial;
  }

  public String getCreated() {
    return created;
  }
  public void setCreated(String created) {
    this.created = created;
  }

  public String getUpdated() {
    return updated;
  }
  public void setUpdated(String updated) {
    this.updated = updated;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Metadata {\n");
    sb.append("  api_version: ").append(api_version).append("\n");
    sb.append("  trial: ").append(trial).append("\n");
    sb.append("  created: ").append(created).append("\n");
    sb.append("  updated: ").append(updated).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

