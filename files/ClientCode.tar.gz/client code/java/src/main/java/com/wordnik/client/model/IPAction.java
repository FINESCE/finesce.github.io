package com.wordnik.client.model;

public class IPAction {
  private String offer = null;
  private String start_time = null;
  private String end_time = null;
  private String value = null;
  private String type = null;
  private String target = null;
  public String getOffer() {
    return offer;
  }
  public void setOffer(String offer) {
    this.offer = offer;
  }

  public String getStart_time() {
    return start_time;
  }
  public void setStart_time(String start_time) {
    this.start_time = start_time;
  }

  public String getEnd_time() {
    return end_time;
  }
  public void setEnd_time(String end_time) {
    this.end_time = end_time;
  }

  public String getValue() {
    return value;
  }
  public void setValue(String value) {
    this.value = value;
  }

  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  public String getTarget() {
    return target;
  }
  public void setTarget(String target) {
    this.target = target;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class IPAction {\n");
    sb.append("  offer: ").append(offer).append("\n");
    sb.append("  start_time: ").append(start_time).append("\n");
    sb.append("  end_time: ").append(end_time).append("\n");
    sb.append("  value: ").append(value).append("\n");
    sb.append("  type: ").append(type).append("\n");
    sb.append("  target: ").append(target).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

