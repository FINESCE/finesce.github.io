package com.wordnik.client.model;

public class Auth_request {
  private String authorization_id = null;
  private String password = null;
  public String getAuthorization_id() {
    return authorization_id;
  }
  public void setAuthorization_id(String authorization_id) {
    this.authorization_id = authorization_id;
  }

  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Auth_request {\n");
    sb.append("  authorization_id: ").append(authorization_id).append("\n");
    sb.append("  password: ").append(password).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

