package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class BuildingZonesReport {
  private List<building_zone> building_zones = new ArrayList<building_zone>();
  private Metadata metadata = null;
  public List<building_zone> getBuilding_zones() {
    return building_zones;
  }
  public void setBuilding_zones(List<building_zone> building_zones) {
    this.building_zones = building_zones;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuildingZonesReport {\n");
    sb.append("  building_zones: ").append(building_zones).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

