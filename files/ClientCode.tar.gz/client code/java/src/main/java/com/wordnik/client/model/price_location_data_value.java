package com.wordnik.client.model;

public class Price_location_data_value {
  private String id = null;
  private String time = null;
  private String value = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getTime() {
    return time;
  }
  public void setTime(String time) {
    this.time = time;
  }

  public String getValue() {
    return value;
  }
  public void setValue(String value) {
    this.value = value;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Price_location_data_value {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  time: ").append(time).append("\n");
    sb.append("  value: ").append(value).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

