package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Incentive_plans_report {
  private List<incentive_plan> list = new ArrayList<incentive_plan>();
  private Metadata metadata = null;
  public List<incentive_plan> getList() {
    return list;
  }
  public void setList(List<incentive_plan> list) {
    this.list = list;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Incentive_plans_report {\n");
    sb.append("  list: ").append(list).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

