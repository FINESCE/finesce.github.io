package com.wordnik.client.model;

public class Algoweight {
  private String id = null;
  private String renewables = null;
  private String interconnect = null;
  private String specific = null;
  private String timeslot_id = null;
  private String region_id = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getRenewables() {
    return renewables;
  }
  public void setRenewables(String renewables) {
    this.renewables = renewables;
  }

  public String getInterconnect() {
    return interconnect;
  }
  public void setInterconnect(String interconnect) {
    this.interconnect = interconnect;
  }

  public String getSpecific() {
    return specific;
  }
  public void setSpecific(String specific) {
    this.specific = specific;
  }

  public String getTimeslot_id() {
    return timeslot_id;
  }
  public void setTimeslot_id(String timeslot_id) {
    this.timeslot_id = timeslot_id;
  }

  public String getRegion_id() {
    return region_id;
  }
  public void setRegion_id(String region_id) {
    this.region_id = region_id;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Algoweight {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  renewables: ").append(renewables).append("\n");
    sb.append("  interconnect: ").append(interconnect).append("\n");
    sb.append("  specific: ").append(specific).append("\n");
    sb.append("  timeslot_id: ").append(timeslot_id).append("\n");
    sb.append("  region_id: ").append(region_id).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

