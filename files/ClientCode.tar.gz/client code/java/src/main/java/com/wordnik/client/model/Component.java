package com.wordnik.client.model;

public class Component {
  private String access = null;
  private String id = null;
  private String url = null;
  public String getAccess() {
    return access;
  }
  public void setAccess(String access) {
    this.access = access;
  }

  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Component {\n");
    sb.append("  access: ").append(access).append("\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  url: ").append(url).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

