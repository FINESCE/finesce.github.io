package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Connection_states_report {
  private List<ev_supply_equipment_connection_state> connection_states = new ArrayList<ev_supply_equipment_connection_state>();
  private Metadata metadata = null;
  public List<ev_supply_equipment_connection_state> getConnection_states() {
    return connection_states;
  }
  public void setConnection_states(List<ev_supply_equipment_connection_state> connection_states) {
    this.connection_states = connection_states;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Connection_states_report {\n");
    sb.append("  connection_states: ").append(connection_states).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

