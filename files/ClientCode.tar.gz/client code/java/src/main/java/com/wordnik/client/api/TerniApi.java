package com.wordnik.client.api;

import com.wordnik.client.common.ApiException;
import com.wordnik.client.common.ApiInvoker;

import com.wordnik.client.model.Measurements_report;
import com.wordnik.client.model.Meters_report;
import com.wordnik.client.model.Incentive_plans_report;
import com.wordnik.client.model.Contract_report;
import com.wordnik.client.model.Contracted_energy_prices_report;
import com.wordnik.client.model.Social_events_report;
import com.wordnik.client.model.Weather_forecast;
import com.wordnik.client.model.Issue_resolution_plans_report;
import com.wordnik.client.model.Sectors_report;
import com.wordnik.client.model.Weather_descriptors;
import com.sun.jersey.multipart.FormDataMultiPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.*;

public class TerniApi {
  String basePath = "http://192.168.1.80/finesce/api/v0.1";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }
  
  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }
  
  public String getBasePath() {
    return basePath;
  }

  /*
  */
  public weather_forecast getTerniWeatherFromTo (String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/weather/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (weather_forecast) ApiInvoker.deserialize(response, "", weather_forecast.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public weather_forecast getTerniWeatherDescriptorFromTo (String descriptor, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(descriptor == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/weather/{descriptor}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "descriptor" + "\\}", apiInvoker.escapeString(descriptor.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (weather_forecast) ApiInvoker.deserialize(response, "", weather_forecast.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public weather_descriptors getTerniWeatherAvailable_descriptors () throws ApiException {
    Object postBody = null;
    // create path and map variables
    String path = "/Terni/weather/available_descriptors".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (weather_descriptors) ApiInvoker.deserialize(response, "", weather_descriptors.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniSimulationPredictionPowerDemandSectorSector_id (String sector_id) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(sector_id == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/simulation/prediction/power/demand/sector/{sector_id}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "sector_id" + "\\}", apiInvoker.escapeString(sector_id.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniSimulationPredictionPowerDemandUserCustomer_id (String customer_id) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer_id == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/simulation/prediction/power/demand/user/{customer_id}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer_id" + "\\}", apiInvoker.escapeString(customer_id.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniSimulationPredictionPowerSupplySectorSector_id (String sector_id) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(sector_id == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/simulation/prediction/power/supply/sector/{sector_id}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "sector_id" + "\\}", apiInvoker.escapeString(sector_id.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniSimulationPredictionPowerSupplyUserCustomer_id (String customer_id) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer_id == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/simulation/prediction/power/supply/user/{customer_id}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer_id" + "\\}", apiInvoker.escapeString(customer_id.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public social_events_report getTerniSocial () throws ApiException {
    Object postBody = null;
    // create path and map variables
    String path = "/Terni/social".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (social_events_report) ApiInvoker.deserialize(response, "", social_events_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public social_events_report getTerniSocialEvents_number (String events_number) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(events_number == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/social/{events_number}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "events_number" + "\\}", apiInvoker.escapeString(events_number.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (social_events_report) ApiInvoker.deserialize(response, "", social_events_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public meters_report getTerniMeters () throws ApiException {
    Object postBody = null;
    // create path and map variables
    String path = "/Terni/meters".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (meters_report) ApiInvoker.deserialize(response, "", meters_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public meters_report getTerniMetersSearch_options (String search_options) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(search_options == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/meters/{search_options}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "search_options" + "\\}", apiInvoker.escapeString(search_options.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (meters_report) ApiInvoker.deserialize(response, "", meters_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public sectors_report getTerniMetersSectors () throws ApiException {
    Object postBody = null;
    // create path and map variables
    String path = "/Terni/meters/sectors".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (sectors_report) ApiInvoker.deserialize(response, "", sectors_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public incentive_plans_report getTerniDsmIpAuthorAuthor (String author) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(author == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/dsm/ip/author/{author}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "author" + "\\}", apiInvoker.escapeString(author.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (incentive_plans_report) ApiInvoker.deserialize(response, "", incentive_plans_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public incentive_plans_report getTerniDsmIpAuthorAuthorStateState (String author, String state) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(author == null || state == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/dsm/ip/author/{author}/state/{state}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "author" + "\\}", apiInvoker.escapeString(author.toString())).replaceAll("\\{" + "state" + "\\}", apiInvoker.escapeString(state.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (incentive_plans_report) ApiInvoker.deserialize(response, "", incentive_plans_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public incentive_plans_report getTerniDsmIpStateState (String state) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(state == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/dsm/ip/state/{state}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "state" + "\\}", apiInvoker.escapeString(state.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (incentive_plans_report) ApiInvoker.deserialize(response, "", incentive_plans_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public issue_resolution_plans_report getTerniDsmIrpAuthorAuthor (String author) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(author == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/dsm/irp/author/{author}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "author" + "\\}", apiInvoker.escapeString(author.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (issue_resolution_plans_report) ApiInvoker.deserialize(response, "", issue_resolution_plans_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public issue_resolution_plans_report getTerniDsmIrpAuthorAuthorStateState (String author, String state) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(author == null || state == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/dsm/irp/author/{author}/state/{state}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "author" + "\\}", apiInvoker.escapeString(author.toString())).replaceAll("\\{" + "state" + "\\}", apiInvoker.escapeString(state.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (issue_resolution_plans_report) ApiInvoker.deserialize(response, "", issue_resolution_plans_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public issue_resolution_plans_report getTerniDsmIrpStateState (String state) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(state == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/dsm/irp/state/{state}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "state" + "\\}", apiInvoker.escapeString(state.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (issue_resolution_plans_report) ApiInvoker.deserialize(response, "", issue_resolution_plans_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniPowerDemandUserCustomer_idFromTo (String customer_id, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer_id == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/power/demand/user/{customer_id}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer_id" + "\\}", apiInvoker.escapeString(customer_id.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniPowerSupplyUserCustomer_idFromTo (String customer_id, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer_id == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/power/supply/user/{customer_id}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer_id" + "\\}", apiInvoker.escapeString(customer_id.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public contract_report getTerniContractsCustomerCustomer (String customer) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/contracts/customer/{customer}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer" + "\\}", apiInvoker.escapeString(customer.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (contract_report) ApiInvoker.deserialize(response, "", contract_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public contract_report getTerniContractsCustomerCustomerStateState (String customer, String state) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer == null || state == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/contracts/customer/{customer}/state/{state}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer" + "\\}", apiInvoker.escapeString(customer.toString())).replaceAll("\\{" + "state" + "\\}", apiInvoker.escapeString(state.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (contract_report) ApiInvoker.deserialize(response, "", contract_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public contract_report getTerniContractsStateState (String state) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(state == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/contracts/state/{state}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "state" + "\\}", apiInvoker.escapeString(state.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (contract_report) ApiInvoker.deserialize(response, "", contract_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public contracted_energy_prices_report getTerniContractsPrices () throws ApiException {
    Object postBody = null;
    // create path and map variables
    String path = "/Terni/contracts/prices".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (contracted_energy_prices_report) ApiInvoker.deserialize(response, "", contracted_energy_prices_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniEnergyConsumptionProfileSectorSectorFromTo (String sector, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(sector == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/energy/consumption/profile/sector/{sector}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "sector" + "\\}", apiInvoker.escapeString(sector.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniEnergyConsumptionProfileUserCustomer_idFromTo (String customer_id, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer_id == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/energy/consumption/profile/user/{customer_id}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer_id" + "\\}", apiInvoker.escapeString(customer_id.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniEnergyConsumptionTotalUserCustomer_idFromTo (String customer_id, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer_id == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/energy/consumption/total/user/{customer_id}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer_id" + "\\}", apiInvoker.escapeString(customer_id.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniEnergyProductionProfileSectorSectorFromTo (String sector, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(sector == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/energy/production/profile/sector/{sector}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "sector" + "\\}", apiInvoker.escapeString(sector.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/xml"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniEnergyProductionProfileUserCustomer_idFromTo (String customer_id, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer_id == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/energy/production/profile/user/{customer_id}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer_id" + "\\}", apiInvoker.escapeString(customer_id.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/xml"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  /*
  */
  public measurements_report getTerniEnergyProductionTotalUserCustomer_idFromTo (String customer_id, String from, String to) throws ApiException {
    Object postBody = null;
    // verify required params are set
    if(customer_id == null || from == null || to == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/Terni/energy/production/total/user/{customer_id}/{from}/{to}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "customer_id" + "\\}", apiInvoker.escapeString(customer_id.toString())).replaceAll("\\{" + "from" + "\\}", apiInvoker.escapeString(from.toString())).replaceAll("\\{" + "to" + "\\}", apiInvoker.escapeString(to.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    String[] contentTypes = {
      "application/xml"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      if(hasFields)
        postBody = mp;
    }
    else {
      }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (measurements_report) ApiInvoker.deserialize(response, "", measurements_report.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
      	return null;
      }
      else {
        throw ex;
      }
    }
  }
  }

