package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Contract_report {
  private List<contract> list = new ArrayList<contract>();
  private Metadata metadata = null;
  public List<contract> getList() {
    return list;
  }
  public void setList(List<contract> list) {
    this.list = list;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Contract_report {\n");
    sb.append("  list: ").append(list).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

