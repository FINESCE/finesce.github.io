package com.wordnik.client.model;

import java.util.*;
public class Contract {
  private String id = null;
  private String incentive_plan_id = null;
  private String customer_id = null;
  private String state = null;
  private List<contract_action> action = new ArrayList<contract_action>();
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getIncentive_plan_id() {
    return incentive_plan_id;
  }
  public void setIncentive_plan_id(String incentive_plan_id) {
    this.incentive_plan_id = incentive_plan_id;
  }

  public String getCustomer_id() {
    return customer_id;
  }
  public void setCustomer_id(String customer_id) {
    this.customer_id = customer_id;
  }

  public String getState() {
    return state;
  }
  public void setState(String state) {
    this.state = state;
  }

  public List<contract_action> getAction() {
    return action;
  }
  public void setAction(List<contract_action> action) {
    this.action = action;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Contract {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  incentive_plan_id: ").append(incentive_plan_id).append("\n");
    sb.append("  customer_id: ").append(customer_id).append("\n");
    sb.append("  state: ").append(state).append("\n");
    sb.append("  action: ").append(action).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

