package com.wordnik.client.model;

public class Ev_equipment {
  private String id = null;
  private String manufacturer = null;
  private String model = null;
  private String hw_version = null;
  private String fw_version = null;
  private String region = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getManufacturer() {
    return manufacturer;
  }
  public void setManufacturer(String manufacturer) {
    this.manufacturer = manufacturer;
  }

  public String getModel() {
    return model;
  }
  public void setModel(String model) {
    this.model = model;
  }

  public String getHw_version() {
    return hw_version;
  }
  public void setHw_version(String hw_version) {
    this.hw_version = hw_version;
  }

  public String getFw_version() {
    return fw_version;
  }
  public void setFw_version(String fw_version) {
    this.fw_version = fw_version;
  }

  public String getRegion() {
    return region;
  }
  public void setRegion(String region) {
    this.region = region;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Ev_equipment {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  manufacturer: ").append(manufacturer).append("\n");
    sb.append("  model: ").append(model).append("\n");
    sb.append("  hw_version: ").append(hw_version).append("\n");
    sb.append("  fw_version: ").append(fw_version).append("\n");
    sb.append("  region: ").append(region).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

