package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Price_location_data_values_report {
  private List<price_location_data_value> price_location_data_values = new ArrayList<price_location_data_value>();
  private Metadata metadata = null;
  public List<price_location_data_value> getPrice_location_data_values() {
    return price_location_data_values;
  }
  public void setPrice_location_data_values(List<price_location_data_value> price_location_data_values) {
    this.price_location_data_values = price_location_data_values;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Price_location_data_values_report {\n");
    sb.append("  price_location_data_values: ").append(price_location_data_values).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

