package com.wordnik.client.model;

public class Contracted_energy_prices {
  private Double der = null;
  private Double bulk = null;
  private Double sold = null;
  private String start_date = null;
  private String end_date = null;
  private String volume = null;
  private String currency = null;
  public Double getDer() {
    return der;
  }
  public void setDer(Double der) {
    this.der = der;
  }

  public Double getBulk() {
    return bulk;
  }
  public void setBulk(Double bulk) {
    this.bulk = bulk;
  }

  public Double getSold() {
    return sold;
  }
  public void setSold(Double sold) {
    this.sold = sold;
  }

  public String getStart_date() {
    return start_date;
  }
  public void setStart_date(String start_date) {
    this.start_date = start_date;
  }

  public String getEnd_date() {
    return end_date;
  }
  public void setEnd_date(String end_date) {
    this.end_date = end_date;
  }

  public String getVolume() {
    return volume;
  }
  public void setVolume(String volume) {
    this.volume = volume;
  }

  public String getCurrency() {
    return currency;
  }
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Contracted_energy_prices {\n");
    sb.append("  der: ").append(der).append("\n");
    sb.append("  bulk: ").append(bulk).append("\n");
    sb.append("  sold: ").append(sold).append("\n");
    sb.append("  start_date: ").append(start_date).append("\n");
    sb.append("  end_date: ").append(end_date).append("\n");
    sb.append("  volume: ").append(volume).append("\n");
    sb.append("  currency: ").append(currency).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

