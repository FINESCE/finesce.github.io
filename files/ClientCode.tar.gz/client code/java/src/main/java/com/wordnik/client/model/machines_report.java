package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Machines_report {
  private List<machine> machines = new ArrayList<machine>();
  private Metadata metadata = null;
  public List<machine> getMachines() {
    return machines;
  }
  public void setMachines(List<machine> machines) {
    this.machines = machines;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Machines_report {\n");
    sb.append("  machines: ").append(machines).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

