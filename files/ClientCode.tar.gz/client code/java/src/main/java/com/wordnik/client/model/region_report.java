package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Region_report {
  private List<region> regions = new ArrayList<region>();
  private Metadata metadata = null;
  public List<region> getRegions() {
    return regions;
  }
  public void setRegions(List<region> regions) {
    this.regions = regions;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Region_report {\n");
    sb.append("  regions: ").append(regions).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

