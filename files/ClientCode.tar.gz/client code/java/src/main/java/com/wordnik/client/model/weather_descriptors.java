package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Weather_descriptors {
  private List<MeasurementType> descriptors = new ArrayList<MeasurementType>();
  private Metadata metadata = null;
  public List<MeasurementType> getDescriptors() {
    return descriptors;
  }
  public void setDescriptors(List<MeasurementType> descriptors) {
    this.descriptors = descriptors;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Weather_descriptors {\n");
    sb.append("  descriptors: ").append(descriptors).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

