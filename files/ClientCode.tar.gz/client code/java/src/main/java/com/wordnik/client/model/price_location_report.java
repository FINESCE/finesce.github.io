package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Metadata;
public class Price_location_report {
  private List<price_location> price_locations = new ArrayList<price_location>();
  private Metadata metadata = null;
  public List<price_location> getPrice_locations() {
    return price_locations;
  }
  public void setPrice_locations(List<price_location> price_locations) {
    this.price_locations = price_locations;
  }

  public Metadata getMetadata() {
    return metadata;
  }
  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Price_location_report {\n");
    sb.append("  price_locations: ").append(price_locations).append("\n");
    sb.append("  metadata: ").append(metadata).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

