package com.wordnik.client.model;

import java.util.*;
import com.wordnik.client.model.Address;
public class Meter {
  private String id = null;
  private String sector = null;
  private address address = null;
  private String latitude = null;
  private String longitude = null;
  private String customerId = null;
  private String sampleIdentifier = null;
  private List<String> meteringCapabilities = new ArrayList<String>();
  private List<String> relatedEntities = new ArrayList<String>();
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getSector() {
    return sector;
  }
  public void setSector(String sector) {
    this.sector = sector;
  }

  public address getAddress() {
    return address;
  }
  public void setAddress(address address) {
    this.address = address;
  }

  public String getLatitude() {
    return latitude;
  }
  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getLongitude() {
    return longitude;
  }
  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

  public String getCustomerId() {
    return customerId;
  }
  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  public String getSampleIdentifier() {
    return sampleIdentifier;
  }
  public void setSampleIdentifier(String sampleIdentifier) {
    this.sampleIdentifier = sampleIdentifier;
  }

  public List<String> getMeteringCapabilities() {
    return meteringCapabilities;
  }
  public void setMeteringCapabilities(List<String> meteringCapabilities) {
    this.meteringCapabilities = meteringCapabilities;
  }

  public List<String> getRelatedEntities() {
    return relatedEntities;
  }
  public void setRelatedEntities(List<String> relatedEntities) {
    this.relatedEntities = relatedEntities;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Meter {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  sector: ").append(sector).append("\n");
    sb.append("  address: ").append(address).append("\n");
    sb.append("  latitude: ").append(latitude).append("\n");
    sb.append("  longitude: ").append(longitude).append("\n");
    sb.append("  customerId: ").append(customerId).append("\n");
    sb.append("  sampleIdentifier: ").append(sampleIdentifier).append("\n");
    sb.append("  meteringCapabilities: ").append(meteringCapabilities).append("\n");
    sb.append("  relatedEntities: ").append(relatedEntities).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

