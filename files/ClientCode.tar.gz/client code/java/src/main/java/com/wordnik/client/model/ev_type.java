package com.wordnik.client.model;

public class Ev_type {
  private String id = null;
  private String brand = null;
  private String manufacturer = null;
  private Double capacity = null;
  private Integer max_range = null;
  private Integer min_range = null;
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getBrand() {
    return brand;
  }
  public void setBrand(String brand) {
    this.brand = brand;
  }

  public String getManufacturer() {
    return manufacturer;
  }
  public void setManufacturer(String manufacturer) {
    this.manufacturer = manufacturer;
  }

  public Double getCapacity() {
    return capacity;
  }
  public void setCapacity(Double capacity) {
    this.capacity = capacity;
  }

  public Integer getMax_range() {
    return max_range;
  }
  public void setMax_range(Integer max_range) {
    this.max_range = max_range;
  }

  public Integer getMin_range() {
    return min_range;
  }
  public void setMin_range(Integer min_range) {
    this.min_range = min_range;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Ev_type {\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  brand: ").append(brand).append("\n");
    sb.append("  manufacturer: ").append(manufacturer).append("\n");
    sb.append("  capacity: ").append(capacity).append("\n");
    sb.append("  max_range: ").append(max_range).append("\n");
    sb.append("  min_range: ").append(min_range).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

