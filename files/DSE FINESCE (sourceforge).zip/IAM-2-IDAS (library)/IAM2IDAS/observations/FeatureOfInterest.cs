﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace IAM2IDAS.observations
{
    [XmlType("FeatureOfInterest", Namespace = "http://www.opengis.net/om/1.0")]
    public class FeatureOfInterest
    {
        //TODO to be completed
    }
}
